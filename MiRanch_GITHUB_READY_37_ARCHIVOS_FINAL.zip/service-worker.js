'use strict';

const CACHE_NAME = 'miranch-v-final-20260905-02';
const SHELL = [
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './apple-touch-icon.png',
  './icon-logo.jpg',
  './iranch-modular/assets/logo-miranch-horizontal.png',
  './iranch-modular/assets/logo-miranch-vertical.png',
  './iranch-modular/assets/header-sunrise.webp',
  './iranch-modular/assets/home-semana-1.webp',
  './iranch-modular/assets/home-semana-2.webp',
  './iranch-modular/assets/home-semana-3.webp',
  './iranch-modular/assets/home-semana-4.webp'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys
          .filter((key) => key !== CACHE_NAME)
          .map((key) => caches.delete(key))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put('./index.html', copy);
          });
          return response;
        })
        .catch(() => caches.match('./index.html'))
    );
    return;
  }

  event.respondWith(
    caches.match(request).then((cached) => {
      if (cached) return cached;
      return fetch(request).then((response) => {
        if (response && response.ok) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(request, copy);
          });
        }
        return response;
      });
    })
  );
});

self.addEventListener('push', (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch (error) {
    data = { body: event.data ? event.data.text() : '' };
  }

  event.waitUntil(
    self.registration.showNotification(data.title || 'MiRanch', {
      body: data.body || 'Tienes una nueva notificación',
      icon: './icon-192.png',
      badge: './icon-192.png',
      data: { url: data.url || './index.html' }
    })
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const target = event.notification && event.notification.data && event.notification.data.url
    ? event.notification.data.url
    : './index.html';

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true })
      .then((clientsList) => {
        for (const client of clientsList) {
          if ('navigate' in client && 'focus' in client) {
            return client.navigate(target).then(() => client.focus());
          }
        }
        return self.clients.openWindow(target);
      })
  );
});

self.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'IRANCH_LOCAL_NOTIFICATION') return;

  event.waitUntil(
    self.registration.showNotification(event.data.title || 'MiRanch', {
      body: event.data.body || '',
      icon: './icon-192.png',
      badge: './icon-192.png',
      data: { url: event.data.url || './index.html' }
    })
  );
});
