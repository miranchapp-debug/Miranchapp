# MiRanch — Arquitectura de cuentas

Persona → autenticación → perfiles → organizaciones/membresías → cuentas productivas/UPP → suscripción.

Una persona puede tener varias UPP independientes. Una UPP no se crea por agregar un perfil: cada UPP es una cuenta productiva separada.

La identidad del productor, la ubicación residencial y la ubicación de la UPP son datos diferentes. El fierro se trata como identidad propia: número + figura, conservando la evidencia original.

El alta inicial de identidad no exige UPP. La cuenta productiva sí requiere UPP para habilitar plenamente las funciones productivas.
