# MiRanch — paquete GitHub 37 archivos

Paquete modular de aplicación web/PWA.

## Seguridad
- Google/Facebook mediante Firebase Auth.
- Las credenciales legacy se almacenan como PBKDF2-SHA256 con salt; no se persisten contraseñas en claro.
- Las cuentas recordadas en el dispositivo conservan únicamente usuario/etiqueta.
- Los accesos privilegiados hardcodeados de prueba fueron retirados.

## OCR Document AI
- Corrección de perspectiva y calidad de captura.
- Variantes de preprocesamiento y orientación.
- Lectura multihoja.
- Normalización de CURP/UPP/arete.
- Separación Productor / UPP / Fierro.
- Original + procesado + SVG del fierro.

## UPP
- Alta de identidad sin UPP.
- Recordatorio desde el segundo acceso.
- Obligatoria al tercer acceso o al quinto día para funciones productivas.
- Múltiples cuentas productivas independientes.

## Publicación
Este ZIP contiene 37 archivos de aplicación. `firestore.rules` se entrega como paquete complementario para despliegue de Firebase. La prueba real contra Firebase, cámara, Storage y APIs del dispositivo debe hacerse después de publicar por HTTPS.
