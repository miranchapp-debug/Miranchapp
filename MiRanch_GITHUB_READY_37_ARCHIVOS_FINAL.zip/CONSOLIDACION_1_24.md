# MiRanch — Consolidación forense 1–24

Estado: COMPLETADO EN CÓDIGO (pre-GitHub).

Se integraron y verificaron los requisitos de arquitectura modular, OCR Document AI, separación productor/UPP/fierro, captura multihoja, deduplicación, onboarding progresivo de UPP, cuentas productivas múltiples, organizaciones/QR, controles de sesión, protección de credenciales, PWA, rutas y QA estático.

Importante: la certificación de Firebase/cámara/GPS/Storage/Push/QR en dispositivo real requiere HTTPS y pruebas reales; no se declara como prueba realizada localmente.

## Correcciones finales de esta consolidación
1. El registro inicial no presenta la UPP como obligatoria.
2. A partir del segundo acceso aparece recordatorio; al tercer acceso o al quinto día el registro de UPP pasa a obligatorio.
3. El bloqueo de navegación productiva se aplica en `producer-core.js`; quedan permitidas las rutas de inicio/perfil/configuración/escaneo/mensajes/boletines para completar la UPP.
4. El selector veterinario de listas admite varias fotografías.
5. Las cuentas guardadas en el dispositivo conservan solo usuario/etiqueta; nunca contraseña.
6. Las credenciales legacy se migran a PBKDF2-SHA256 con salt y 120000 iteraciones; el almacenamiento local/remoto elimina la contraseña en claro.
7. Se retiraron cuentas de prueba hardcodeadas y accesos directos privilegiados.
8. El fierro conserva original, PNG procesado y representación SVG por contornos/componentes conectados.
9. El Service Worker cambió a `miranch-v-final-20260905-02`.
