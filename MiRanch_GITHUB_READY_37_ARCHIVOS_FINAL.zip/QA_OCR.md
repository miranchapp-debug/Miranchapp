# QA OCR / Document AI — estado final

- Motor OCR Ultra 2.0 integrado en `iranch-modular/modules/ocr.js`.
- Quality gate: nitidez, exposición, contraste, recorte de altas luces/sombras y variantes.
- Multihoja: inventario productor, lista veterinaria y SINIIGA.
- Deduplicación por identificador/arete.
- Normalización de CURP, UPP y arete.
- Validación documental: productor por un lado; UPP/predio por otro; fierro como entidad separada.
- No se compara el municipio del domicilio del productor con el municipio de la UPP.
- El fierro conserva original, derivado PNG y SVG vectorial por contornos.

La precisión porcentual de OCR no se declara como certificada en campo: requiere un corpus real y pruebas repetibles en dispositivos.
