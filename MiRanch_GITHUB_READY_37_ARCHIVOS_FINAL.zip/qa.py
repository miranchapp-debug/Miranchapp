from pathlib import Path
from bs4 import BeautifulSoup
import re, json, subprocess, sys, os
ROOT=Path(__file__).resolve().parent
errors=[]; warnings=[]
# 1) JS syntax
for p in list((ROOT/'iranch-modular/modules').glob('*.js'))+[ROOT/'service-worker.js']:
    r=subprocess.run(['node','--check',str(p)],capture_output=True,text=True)
    if r.returncode: errors.append(('JS syntax',str(p),r.stderr))
# 2) local refs from HTML/CSS/JS/manifest/service worker
text_files=[p for p in ROOT.rglob('*') if p.is_file() and p.suffix.lower() in {'.html','.js','.json','.css','.md'}]
for p in text_files:
    t=p.read_text(errors='ignore')
    # quoted relative file refs (not data/http)
    refs=re.findall(r'["\'](\.?\.?/[^"\']+?\.(?:html|js|json|css|png|jpg|jpeg|webp|svg|ico))(?:["\'?#])',t,re.I)
    for ref in refs:
        clean=ref.split('?')[0].split('#')[0]
        if '${' in clean or clean.startswith('//'): continue
        # La app carga scripts/vistas desde index.html, por lo que las rutas
        # ./... se resuelven contra la raíz del documento, no contra la carpeta
        # física del archivo que contiene la cadena.
        target=(ROOT/clean[2:]).resolve() if clean.startswith('./') else (p.parent/clean).resolve()
        if not target.exists(): errors.append(('Broken local ref',str(p),ref))
# 3) view source files
idx=(ROOT/'index.html').read_text(errors='ignore')
for src in re.findall(r'data-iranch-view-source=["\']([^"\']+)',idx):
    if not (ROOT/src).exists(): errors.append(('Missing view',str(ROOT/'index.html'),src))
# 4) duplicate ids within each HTML artifact
for p in [ROOT/'index.html']+list((ROOT/'iranch-modular/views').glob('*.html')):
    soup=BeautifulSoup(p.read_text(errors='ignore'),'html.parser')
    ids={}
    for e in soup.find_all(id=True): ids.setdefault(e['id'],[]).append(e.name)
    dup={k:v for k,v in ids.items() if len(v)>1}
    if dup: errors.append(('Duplicate IDs',str(p),list(dup)[:20]))
# 5) onclick function existence
funcs=set()
for p in (ROOT/'iranch-modular/modules').glob('*.js'):
    t=p.read_text(errors='ignore')
    funcs.update(re.findall(r'(?:function|async function)\s+([A-Za-z_$][\w$]*)\s*\(',t))
# core itself + inline script 0
funcs.update(re.findall(r'(?:function|async function)\s+([A-Za-z_$][\w$]*)\s*\(',idx))
# known global methods / JS keywords / DOM methods etc
ignore={'if','for','while','switch','catch','setTimeout','setInterval','clearTimeout','clearInterval','confirm','alert','prompt','parseInt','parseFloat','String','Number','Date','Math','JSON','Object','Array','Boolean','console','fetch','requestAnimationFrame','scrollTo','open','close','print','focus','blur','submit','reset','remove','click','toString','preventDefault','stopPropagation'}
for p in [ROOT/'index.html']+list((ROOT/'iranch-modular/views').glob('*.html')):
    soup=BeautifulSoup(p.read_text(errors='ignore'),'html.parser')
    for e in soup.find_all(attrs={'onclick':True}):
        expr=e.get('onclick','')
        # calls at beginning or after separators; includes optional chaining
        for name in re.findall(r'(?<![.\w$])([A-Za-z_$][\w$]*)\s*\(',expr):
            if name not in funcs and name not in ignore and name not in {'event'}:
                warnings.append(('onclick maybe missing',str(p),name,expr[:160]))
# 6) module-loader route files
ml=(ROOT/'iranch-modular/modules/module-loader.js').read_text(errors='ignore')
for name,path in re.findall(r"['\"]([^'\"]+)['\"]\s*:\s*['\"]([^'\"]+\.js)['\"]",ml):
    if not (ROOT/path).exists(): errors.append(('Module route missing',name,path))
# 7) manifest icons
man=json.loads((ROOT/'manifest.json').read_text())
for icon in man.get('icons',[]):
    if not (ROOT/icon['src']).exists(): errors.append(('Manifest icon missing',icon['src']))
# 8) obsolete logos
for old in []:
    for p in ROOT.rglob('*'):
        if p.is_file() and old in p.name: errors.append(('Obsolete logo file',str(p),old))
        elif p.is_file() and p.suffix.lower() in {'.html','.js','.json','.css','.md'} and old in p.read_text(errors='ignore'): errors.append(('Obsolete logo ref',str(p),old))
# 9) empty buttons: flag only buttons with no visible text, no aria/title, and no icon/img/svg
for p in [ROOT/'index.html']+list((ROOT/'iranch-modular/views').glob('*.html')):
    soup=BeautifulSoup(p.read_text(errors='ignore'),'html.parser')
    for b in soup.find_all('button'):
        txt=' '.join(b.stripped_strings)
        if not txt and not b.get('aria-label') and not b.get('title') and not b.find(['i','svg','img']):
            warnings.append(('empty button',str(p),b.get('id'),str(b)[:220]))
# 10) obvious placeholder/dead wording
for p in text_files:
    t=p.read_text(errors='ignore')
    for pat in [r'\bTODO\b',r'FIXME',r'coming soon',r'placeholder',r'REEMPLAZAR',r'PENDIENTE']:
        if re.search(pat,t,re.I): warnings.append(('placeholder/dead marker',str(p),pat))
print('ERRORS',len(errors))
for x in errors[:100]: print('ERR',x)
print('WARNINGS',len(warnings))
for x in warnings[:120]: print('WARN',x)
