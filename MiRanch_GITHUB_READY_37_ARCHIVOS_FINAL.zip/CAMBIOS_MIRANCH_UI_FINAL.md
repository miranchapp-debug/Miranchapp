# MiRanch — paquete UI final

Cambios integrados en una sola pasada:

- Logo oficial horizontal **MiRanch** en la barra superior de las pantallas de productor, administrador y quesería.
- Barra superior compacta de 60 px con fondo panorámico de amanecer.
- Controles visibles y consistentes: **ESP** y **Salir**.
- Menús de idioma conservados y adaptados al nuevo botón compacto.
- Eliminación del nombre repetido junto al logo en la barra superior para aprovechar espacio.
- Portada con **4 fondos** ligeros y cambio automático cada semana.
- Fondo panorámico de amanecer separado del sistema de portadas.
- Logo MiRanch actualizado también para exportaciones que usan imagen de marca.
- Service Worker actualizado para precargar logo, encabezado y los 4 fondos, permitiendo uso offline.
- Manifest y título visibles actualizados a MiRanch.
- Se eliminaron del paquete los archivos de imágenes y logotipos anteriores; el paquete usa exclusivamente el branding MiRanch nuevo.
- Verificación de referencias locales: no quedan referencias rotas a los assets eliminados.
- Verificación de sintaxis JavaScript: todos los módulos pasan `node --check`.

## Rotación semanal

La portada selecciona uno de los cuatro fondos usando la semana local del año. Si el administrador establece un fondo personalizado desde Apariencia, ese fondo sigue teniendo prioridad; al restaurarlo se retoma automáticamente la rotación semanal.
