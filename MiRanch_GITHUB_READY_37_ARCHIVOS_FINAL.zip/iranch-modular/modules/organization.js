// MiRanch — Identidad, perfiles, organizaciones, membresías e invitaciones QR.
// Esta capa separa a la PERSONA de sus PERFILES y de las ORGANIZACIONES donde trabaja.
(function(){
  const ROLES = {
    PRODUCTOR: 'productor', QUESERIA: 'queseria', MVZ_LIBRE: 'mvz_libre',
    COMITE: 'comite', TV_COORDINACION: 'tv_coordinacion',
    TV_CAPTURISTA_RECEPCION: 'tv_capturista_recepcion',
    TV_CAPTURISTA_DICTAMENES: 'tv_capturista_dictamenes', MEDICO_CAMPO_TB: 'medico_campo_tb'
  };
  const PERMISOS_TV = {
    RECIBIR_PRUEBAS:'recibir_pruebas', ASIGNAR_FOLIOS:'asignar_folios', PROGRAMAR_PRUEBAS:'programar_pruebas',
    ASIGNAR_MEDICOS:'asignar_medicos', CAPTURAR_RESULTADOS:'capturar_resultados', IMPRIMIR_DICTAMENES:'imprimir_dictamenes',
    IMPRIMIR_CUARENTENA:'imprimir_cuarentena', IMPRIMIR_RESTRICCION_MOVILIZACION:'imprimir_restriccion_movilizacion',
    REPORTES_TB:'reportes_tb', ADMINISTRAR_USUARIOS:'administrar_usuarios', VER_TODO_COMITE:'ver_todo_comite'
  };
  const PLANTILLAS_PERMISOS = {
    [ROLES.TV_COORDINACION]: Object.values(PERMISOS_TV),
    [ROLES.TV_CAPTURISTA_RECEPCION]: [PERMISOS_TV.RECIBIR_PRUEBAS,PERMISOS_TV.ASIGNAR_FOLIOS,PERMISOS_TV.PROGRAMAR_PRUEBAS,PERMISOS_TV.ASIGNAR_MEDICOS],
    [ROLES.TV_CAPTURISTA_DICTAMENES]: [PERMISOS_TV.CAPTURAR_RESULTADOS,PERMISOS_TV.IMPRIMIR_DICTAMENES],
    [ROLES.MEDICO_CAMPO_TB]: ['ver_pruebas_asignadas_tb','pcc','prueba_cauda','prueba_barrido','prueba_buffer','enviar_reportes_tb']
  };
  function normalizarCorreo(v){ return String(v||'').trim().toLowerCase(); }
  function correoValido(v){ return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(normalizarCorreo(v)); }
  function telefonoNormalizado(v){ return String(v||'').replace(/\D/g,''); }
  function crearIdentidadOrganizacional(datos){
    const d=datos||{};
    return { id:d.id||('ident_'+Date.now()+'_'+Math.random().toString(36).slice(2,8)), cuentaPadreId:d.cuentaPadreId||null,
      organizacionId:d.organizacionId||null,comiteId:d.comiteId||null,estadoId:d.estadoId||d.estado||null,tipoCuenta:d.tipoCuenta||'individual',
      rol:d.rol||null,nombre:String(d.nombre||'').trim(),correo:normalizarCorreo(d.correo),telefono:telefonoNormalizado(d.telefono),usuario:String(d.usuario||'').trim(),
      estatus:d.estatus||'pendiente_verificacion',emailVerificado:d.emailVerificado===true,permisos:Array.isArray(d.permisos)?[...new Set(d.permisos)]:[],
      creado:d.creado||new Date().toISOString(),actualizado:new Date().toISOString() };
  }
  function plantillaPermisos(rol){ return [...(PLANTILLAS_PERMISOS[rol]||[])]; }
  function puede(identidad,permiso){ return !!(identidad&&Array.isArray(identidad.permisos)&&identidad.permisos.includes(permiso)); }
  function puedeCrearSubcuentasTV(identidad){ return !!identidad&&identidad.rol===ROLES.TV_COORDINACION&&puede(identidad,PERMISOS_TV.ADMINISTRAR_USUARIOS); }
  function puedeVerPruebaAsignada(identidad,prueba){ if(!identidad||identidad.rol!==ROLES.MEDICO_CAMPO_TB||!prueba)return false; return String(prueba.medicoAsignadoId||'')===String(identidad.id)&&String(prueba.comiteId||identidad.comiteId||'')===String(identidad.comiteId||''); }

  function asegurarModelo(){
    if(!window.estado)return false;
    if(!Array.isArray(estado.perfilesIdentidad)) estado.perfilesIdentidad=[];
    if(!Array.isArray(estado.organizaciones)) estado.organizaciones=[];
    if(!Array.isArray(estado.membresiasOrganizacion)) estado.membresiasOrganizacion=[];
    if(!estado.contextoActivo || typeof estado.contextoActivo!=='object') estado.contextoActivo={tipo:'perfil',id:'productor'};
    return true;
  }
  function uidActual(){ return typeof window.firebaseObtenerUsuarioActual==='function' ? window.firebaseObtenerUsuarioActual()?.uid || null : null; }
  function generarId(pref){ return pref+'_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8); }
  function generarCodigo(){ return Math.random().toString(36).slice(2,8).toUpperCase()+'-'+Math.random().toString(36).slice(2,6).toUpperCase(); }
  function origenApp(){ return `${location.origin}${location.pathname}`; }
  function guardarLocal(){ if(typeof window.guardarEstadoEnLocalSeguro==='function') window.guardarEstadoEnLocalSeguro(); else if(typeof window.guardarEstadoLocal==='function') window.guardarEstadoLocal(); }

  function renderSelector(){
    asegurarModelo(); const el=document.getElementById('lista-espacios-trabajo'); const modalEl=document.getElementById('modal-lista-espacios-trabajo'); if(!el && !modalEl)return;
    const perfiles=estado.perfilesIdentidad.filter(Boolean);
    const orgs=estado.organizaciones.filter(Boolean);
    let html='';
    if(!perfiles.length){
      html+=`<button class="w-full text-left rounded-2xl p-4 bg-white" style="border:2px solid var(--line);" onclick="irA('home')"><b>🐄 Productor</b><span class="block text-xs mt-1" style="color:var(--sage);">Tu espacio de productor</span></button>`;
    } else perfiles.forEach(p=>{
      html+=`<button class="w-full text-left rounded-2xl p-4 bg-white" style="border:2px solid var(--line);" onclick="seleccionarEspacioTrabajo('perfil','${String(p.id).replace(/'/g,"\\'")}')"><b>${p.icono||'👤'} ${escapeHtml(p.nombre||p.rol||'Perfil')}</b><span class="block text-xs mt-1" style="color:var(--sage);">${escapeHtml(p.descripcion||p.rol||'Perfil personal')}</span></button>`;
    });
    orgs.forEach(o=>{
      html+=`<button class="w-full text-left rounded-2xl p-4 bg-white" style="border:2px solid var(--line);" onclick="seleccionarEspacioTrabajo('organizacion','${String(o.id).replace(/'/g,"\\'")}')"><b>🥛 ${escapeHtml(o.nombre||'Organización')}</b><span class="block text-xs mt-1" style="color:var(--sage);">${escapeHtml(o.tipoLabel||'Organización de trabajo')}</span></button>`;
    });
    const out=html||'<p class="text-sm" style="color:var(--sage);">No hay espacios disponibles.</p>'; if(el)el.innerHTML=out; if(modalEl)modalEl.innerHTML=out;
    const active=estado.contextoActivo; const label=document.getElementById('espacio-activo-label');
    if(label){ const o=orgs.find(x=>x.id===active.id); const p=perfiles.find(x=>x.id===active.id); label.textContent=active.tipo==='organizacion'?(o?.nombre||'Organización'):(p?.nombre||'Productor'); }
  }
  function escapeHtml(v){ return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }

  function abrirSelectorEspacios(){ asegurarModelo(); renderSelector(); const m=document.getElementById('modal-espacios-trabajo'); if(m){m.classList.remove('hidden');m.style.display='flex';} }
  function cerrarSelectorEspacios(){ const m=document.getElementById('modal-espacios-trabajo'); if(m){m.classList.add('hidden');m.style.removeProperty('display');} }
  function seleccionarEspacioTrabajo(tipo,id){
    asegurarModelo(); estado.contextoActivo={tipo,id}; guardarLocal(); cerrarSelectorEspacios();
    if(tipo==='organizacion') abrirOrganizacionHome(id); else { estado.rolActual='productor'; if(typeof window.cambiarPantallaProductor==='function') window.cambiarPantallaProductor('home'); }
    renderSelector();
  }
  function abrirEspacios(){ abrirSelectorEspacios(); }

  function abrirOrganizacionHome(orgId){
    const org=estado.organizaciones.find(o=>o.id===orgId); if(!org)return;
    const screen=document.getElementById('screen-organizacion-home'); if(!screen){mostrarToast?.('No se encontró la pantalla de organización.');return;}
    document.querySelectorAll('#app-productor .screen').forEach(s=>s.classList.remove('active')); screen.classList.add('active');
    renderOrganizacionHome(org); cargarMembresiasOrg(orgId); renderRecepcionesOrg(org);
  }
  function renderOrganizacionHome(org){
    const nombre=document.getElementById('org-home-nombre'); const meta=document.getElementById('org-home-meta'); const qr=document.getElementById('org-qr-canvas');
    if(nombre)nombre.textContent=org.nombre||'Organización';
    if(meta)meta.textContent=[org.codigoRegistro?'Código '+org.codigoRegistro:'',org.ubicacionTexto||'',org.lugarRecepcion?'Recepción: '+org.lugarRecepcion:''].filter(Boolean).join(' · ');
    const propietario=String(org.ownerUid||'')===String(uidActual()||'');
    const admin=document.getElementById('org-admin-actions'); if(admin)admin.classList.toggle('hidden',!propietario);
    if(qr && propietario) generarQRInvitacion(org.id);
    const badge=document.getElementById('org-miembros-contador'); if(badge) badge.textContent=Array.isArray(estado.membresiasOrganizacion)?estado.membresiasOrganizacion.filter(m=>m.orgId===org.id&&m.estatus==='activo').length:'0';
    const lista=document.getElementById('org-lista-miembros'); if(lista){ const ms=estado.membresiasOrganizacion.filter(m=>m.orgId===org.id); lista.innerHTML=ms.length?ms.map(m=>`<div class="flex items-center justify-between bg-white rounded-xl p-3" style="border:1px solid var(--line);"><div><b>${escapeHtml(m.nombre||m.email||m.uid||'Colaborador')}</b><div class="text-xs" style="color:var(--sage);">${escapeHtml(m.rol||'colaborador')}</div></div><span class="text-xs font-bold" style="color:var(--green);">${m.estatus==='activo'?'Activo':'Pendiente'}</span></div>`).join(''):'<p class="text-sm" style="color:var(--sage);">Todavía no hay colaboradores vinculados.</p>'; }
  }
  async function cargarMembresiasOrg(orgId){
    if(typeof window.firebaseLeerMembresiasOrganizacion!=='function')return;
    const ms=await window.firebaseLeerMembresiasOrganizacion(orgId); if(Array.isArray(ms)&&ms.length){ asegurarModelo(); ms.forEach(m=>{const i=estado.membresiasOrganizacion.findIndex(x=>x.id===m.id); if(i>=0)estado.membresiasOrganizacion[i]=m; else estado.membresiasOrganizacion.push(m);}); guardarLocal(); const org=estado.organizaciones.find(o=>o.id===orgId); if(org)renderOrganizacionHome(org); }
  }
  async function crearOrganizacionLecheria(){
    asegurarModelo();
    const nombre=valor('org-reg-nombre'), codigo=valor('org-reg-codigo'), ubicacion=valor('org-reg-ubicacion'), recepcion=valor('org-reg-recepcion');
    if(!nombre||!codigo||!ubicacion||!recepcion){mostrarToast?.('Completa nombre, código, ubicación y lugar de recepción.');return;}
    const uid=uidActual(); if(!uid){mostrarToast?.('Para registrar una organización necesitas entrar con Google o Facebook.');return;}
    const orgId=generarId('org'); const org={id:orgId,nombre,tipo:'lecheria',tipoLabel:'Lechería / recepción de leche',codigoRegistro:codigo.toUpperCase().trim(),ubicacionTexto:ubicacion,lugarRecepcion:recepcion,ownerUid:uid,creadoEn:new Date().toISOString(),activo:true};
    const ok=await window.firebaseGuardarOrganizacion?.(orgId,org); if(!ok){mostrarToast?.('No se pudo guardar la lechería en Firebase. No se creó localmente para evitar una falsa organización.');return;}
    const mem={orgId,uid,rol:'propietario',permisos:['administrar_organizacion','administrar_miembros','registrar_recepcion','ver_reportes'],estatus:'activo',nombre:estado.productor?.nombre||'Propietario'};
    await window.firebaseGuardarMembresia?.(orgId,uid,mem);
    estado.organizaciones.push(org); estado.membresiasOrganizacion.push({...mem,id:orgId+'__'+uid}); estado.contextoActivo={tipo:'organizacion',id:orgId}; guardarLocal();
    ['org-reg-nombre','org-reg-codigo','org-reg-ubicacion','org-reg-recepcion'].forEach(id=>{const e=document.getElementById(id);if(e)e.value='';});
    mostrarToast?.('Lechería registrada correctamente.'); abrirOrganizacionHome(orgId);
  }
  async function registrarRecepcionOrg(){
    asegurarModelo(); const orgId=estado.contextoActivo?.id; const org=estado.organizaciones.find(o=>o.id===orgId); if(!org)return;
    const uid=uidActual(); if(!uid){mostrarToast?.('Necesitas iniciar sesión con Google/Facebook.');return;}
    const producer=valor('org-rec-productor'), litros=valor('org-rec-litros'), temperatura=valor('org-rec-temperatura'), notas=valor('org-rec-notas');
    if(!producer||!litros){mostrarToast?.('Indica productor y litros recibidos.');return;}
    const id=generarId('rec'); const data={productor:producer,litros:Number(litros)||0,temperatura:Number(temperatura)||null,notas,fecha:new Date().toISOString().slice(0,10),hora:new Date().toTimeString().slice(0,5)};
    const ok=await window.firebaseGuardarRecepcionOrganizacion?.(orgId,id,data); if(!ok){mostrarToast?.('No se pudo guardar: tu membresía no tiene permiso de registrar recepción o Firebase no está disponible.');return;}
    if(!Array.isArray(org.recepcionesLeche))org.recepcionesLeche=[];org.recepcionesLeche.unshift({id,...data,registradoPorUid:uid});guardarLocal();
    ['org-rec-productor','org-rec-litros','org-rec-temperatura','org-rec-notas'].forEach(id=>{const e=document.getElementById(id);if(e)e.value='';}); renderRecepcionesOrg(org);
    mostrarToast?.('Recepción registrada.');
  }
  async function renderRecepcionesOrg(org){
    const el=document.getElementById('org-lista-recepciones');if(!el)return; let rows=Array.isArray(org.recepcionesLeche)?org.recepcionesLeche:[];
    if(!rows.length && typeof window.firebaseLeerRecepcionesOrganizacion==='function'){rows=await window.firebaseLeerRecepcionesOrganizacion(org.id);org.recepcionesLeche=rows;guardarLocal();}
    el.innerHTML=rows.length?rows.slice(0,20).map(r=>`<div class="bg-white rounded-xl p-3" style="border:1px solid var(--line);"><div class="flex justify-between"><b>${escapeHtml(r.productor||'Productor')}</b><b>${Number(r.litros||0).toLocaleString()} L</b></div><div class="text-xs mt-1" style="color:var(--sage);">${escapeHtml(r.fecha||'')} ${escapeHtml(r.hora||'')}${r.temperatura!=null?' · '+escapeHtml(r.temperatura)+' °C':''}</div></div>`).join(''):'<p class="text-sm" style="color:var(--sage);">Todavía no hay recepciones registradas.</p>';
  }

  async function generarQRInvitacion(orgId){
    const org=estado.organizaciones.find(o=>o.id===orgId); if(!org)return; const uid=uidActual(); if(!uid)return;
    let inviteId=org.invitacionActualId||null; let url=org.invitacionActualUrl||'';
    if(!inviteId || !url || (org.invitacionExpiraEn && Date.parse(org.invitacionExpiraEn)<=Date.now())){
      inviteId=generarId('inv'); url=`${origenApp()}?org=${encodeURIComponent(orgId)}&invite=${encodeURIComponent(inviteId)}`;
      const expiraEn=new Date(Date.now()+7*86400000).toISOString();
      const ok=await window.firebaseCrearInvitacionOrganizacion?.(orgId,inviteId,{creadoPorUid:uid,activa:true,usoMaximo:3,usos:0,rolSugerido:'colaborador',permisos:['registrar_recepcion'],expiraEn,url});
      if(!ok)return;
      org.invitacionActualId=inviteId; org.invitacionActualUrl=url; org.invitacionExpiraEn=expiraEn; guardarLocal();
    }
    const hidden=document.getElementById('org-invite-url'); if(hidden)hidden.value=url;
    const text=document.getElementById('org-qr-texto'); if(text)text.textContent='Escanea este código para vincularte como colaborador. Válido para 3 personas y 7 días.';
    try{
      await cargarQRLibreria();
      const qr=window.qrcode(0,'M'); qr.addData(url); qr.make();
      const canvas=document.getElementById('org-qr-canvas'); if(canvas){const ctx=canvas.getContext('2d');const size=220;canvas.width=size;canvas.height=size;ctx.fillStyle='#fff';ctx.fillRect(0,0,size,size);const n=qr.getModuleCount(),cell=size/n;ctx.fillStyle='#111';for(let r=0;r<n;r++)for(let c=0;c<n;c++)if(qr.isDark(r,c))ctx.fillRect(Math.round(c*cell),Math.round(r*cell),Math.ceil(cell),Math.ceil(cell));}
    }catch(e){const img=document.getElementById('org-qr-img');if(img){img.src='https://api.qrserver.com/v1/create-qr-code/?size=220x220&data='+encodeURIComponent(url);img.classList.remove('hidden');} }
  }
  let qrLoader=null;
  function cargarQRLibreria(){ if(window.qrcode)return Promise.resolve(); if(qrLoader)return qrLoader; qrLoader=new Promise((resolve,reject)=>{const s=document.createElement('script');s.src='https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.min.js';s.onload=resolve;s.onerror=reject;document.head.appendChild(s);});return qrLoader; }
  async function compartirInvitacionOrg(){const url=valor('org-invite-url');if(!url)return;const msg=`Únete a ${document.getElementById('org-home-nombre')?.textContent||'esta organización'} en MiRanch. Escanea o abre este enlace para vincularte como colaborador:\n${url}`;try{if(navigator.share)await navigator.share({title:'Invitación MiRanch',text:msg,url});else{await navigator.clipboard?.writeText(url);window.open('https://wa.me/?text='+encodeURIComponent(msg),'_blank');}}catch(e){}}
  async function copiarInvitacionOrg(){const url=valor('org-invite-url');if(!url)return;try{await navigator.clipboard.writeText(url);mostrarToast?.('Enlace de invitación copiado.');}catch(e){mostrarToast?.('No se pudo copiar automáticamente. Mantén presionado el enlace para copiarlo.');}}
  async function mostrarInvitacionPendiente(){
    const params=new URLSearchParams(location.search); let orgId=params.get('org'), inviteId=params.get('invite');
    if(orgId&&inviteId){ localStorage.setItem('miranchPendingOrgInvite',JSON.stringify({orgId,inviteId})); history.replaceState({},'',location.pathname); }
    if(!orgId||!inviteId){ try{ const pendiente=JSON.parse(localStorage.getItem('miranchPendingOrgInvite')||'null'); orgId=pendiente?.orgId||null; inviteId=pendiente?.inviteId||null; }catch(e){} }
    if(!orgId||!inviteId||!uidActual())return;
    const inv=await window.firebaseLeerInvitacionOrganizacion?.(orgId,inviteId); const org=await window.firebaseLeerOrganizacion?.(orgId); if(!inv||!org)return;
    let m=document.getElementById('modal-invitacion-organizacion'); if(!m){m=document.createElement('div');m.id='modal-invitacion-organizacion';m.className='hidden';m.style='position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:220;align-items:flex-end;';m.innerHTML='<div class="w-full bg-white rounded-t-3xl p-6 space-y-3"><h2 class="font-display text-xl font-bold">Invitación a organización</h2><p id="org-invite-prompt" class="text-sm" style="color:var(--sage);"></p><div class="flex gap-2"><button id="org-invite-accept" class="flex-1 btn-primario-plano" style="background:var(--pine);">Aceptar</button><button id="org-invite-cancel" class="flex-1 btn-primario-plano" style="background:var(--slate);">Ahora no</button></div></div>';document.body.appendChild(m);}
    document.getElementById('org-invite-prompt').textContent=`${org.nombre} te invita como colaborador. Debes entrar con Google/Facebook para vincular esta invitación a tu identidad.`;
    m.classList.remove('hidden');m.style.display='flex';
    document.getElementById('org-invite-cancel').onclick=()=>{m.classList.add('hidden');m.style.removeProperty('display');};
    document.getElementById('org-invite-accept').onclick=async()=>{const u=uidActual();if(!u){mostrarToast?.('Primero entra con Google o Facebook y después acepta la invitación.');return;}const ok=await window.firebaseAceptarInvitacionOrganizacion?.(orgId,inviteId,{nombre:estado.productor?.nombre||u});if(ok){asegurarModelo();estado.organizaciones=estado.organizaciones.some(x=>x.id===orgId)?estado.organizaciones:[...estado.organizaciones,org];estado.membresiasOrganizacion.push({id:orgId+'__'+u,orgId,uid:u,rol:inv.rolSugerido||'colaborador',permisos:inv.permisos||['registrar_recepcion'],estatus:'activo',nombre:estado.productor?.nombre||u});guardarLocal();localStorage.removeItem('miranchPendingOrgInvite');m.classList.add('hidden');m.style.removeProperty('display');abrirOrganizacionHome(orgId);mostrarToast?.('Ya estás vinculado a la organización.');}else mostrarToast?.('La invitación ya no está disponible o alcanzó su límite.');};
  }
  let streamQR=null, timerQR=null;
  async function abrirEscanerInvitacionOrg(){
    let m=document.getElementById('modal-escaner-org');
    if(!m){m=document.createElement('div');m.id='modal-escaner-org';m.className='hidden';m.style='position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:230;align-items:center;justify-content:center;padding:1rem;';m.innerHTML='<div class="w-full max-w-sm bg-white rounded-3xl p-5 space-y-3"><div class="flex items-center justify-between"><h3 class="font-display text-xl font-bold">Escanear QR</h3><button id="cerrar-escaner-org" style="color:var(--sage);"><i class="fa-solid fa-xmark text-xl"></i></button></div><video id="video-escaner-org" autoplay playsinline muted style="width:100%;aspect-ratio:1;border-radius:20px;background:#111;object-fit:cover;"></video><p id="estado-escaner-org" class="text-xs" style="color:var(--sage);">Apunta la cámara al código QR de la organización.</p><button id="foto-escaner-org" class="w-full btn-primario-plano" style="background:var(--slate);"><i class="fa-solid fa-image"></i> Usar una foto del QR</button><input id="input-foto-escaner-org" class="hidden" accept="image/*" type="file"/></div>';document.body.appendChild(m);}
    m.classList.remove('hidden');m.style.display='flex';
    const close=()=>{m.classList.add('hidden');m.style.removeProperty('display');if(streamQR){streamQR.getTracks().forEach(t=>t.stop());streamQR=null;}if(timerQR)cancelAnimationFrame(timerQR);};
    document.getElementById('cerrar-escaner-org').onclick=close;
    const input=document.getElementById('input-foto-escaner-org');document.getElementById('foto-escaner-org').onclick=()=>input.click();
    input.onchange=async()=>{const f=input.files?.[0];if(!f)return;try{const bmp=await createImageBitmap(f);const ok=await procesarCodigoQR(bmp);if(ok)close();}catch(e){mostrarToast?.('No se pudo leer la imagen del QR.');}};
    try{
      if(!('BarcodeDetector' in window)){document.getElementById('estado-escaner-org').textContent='Este navegador no permite lectura directa. Usa una foto del QR.';return;}
      const detector=new BarcodeDetector({formats:['qr_code']}); streamQR=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'},width:{ideal:720},height:{ideal:720}},audio:false});
      const video=document.getElementById('video-escaner-org');video.srcObject=streamQR;await video.play();
      const loop=async()=>{if(!streamQR)return;try{const hits=await detector.detect(video);if(hits?.length){const ok=procesarURLInvitacion(hits[0].rawValue);if(ok){close();return;}}}catch(e){}timerQR=requestAnimationFrame(loop);};loop();
    }catch(e){document.getElementById('estado-escaner-org').textContent='No se pudo abrir la cámara. Usa una foto del QR.';}
  }
  async function procesarCodigoQR(source){try{const detector=new BarcodeDetector({formats:['qr_code']});const hits=await detector.detect(source);if(hits?.length)return procesarURLInvitacion(hits[0].rawValue);}catch(e){}return false;}
  function procesarURLInvitacion(raw){try{const u=new URL(String(raw));const orgId=u.searchParams.get('org'),inviteId=u.searchParams.get('invite');if(!orgId||!inviteId)return false;localStorage.setItem('miranchPendingOrgInvite',JSON.stringify({orgId,inviteId}));mostrarToast?.('QR reconocido. Entra con Google/Facebook para aceptar la invitación.');mostrarInvitacionPendiente();return true;}catch(e){return false;}}

  function valor(id){return String(document.getElementById(id)?.value||'').trim();}

  window.IRANCH_ROLES_ORG=ROLES; window.IRANCH_PERMISOS_TV=PERMISOS_TV; window.IRANCH_PLANTILLAS_PERMISOS=PLANTILLAS_PERMISOS;
  window.iranchNormalizarCorreo=normalizarCorreo; window.iranchCorreoValido=correoValido; window.iranchCrearIdentidadOrganizacional=crearIdentidadOrganizacional;
  window.iranchPlantillaPermisos=plantillaPermisos; window.iranchPuede=puede; window.iranchPuedeCrearSubcuentasTV=puedeCrearSubcuentasTV; window.iranchPuedeVerPruebaAsignada=puedeVerPruebaAsignada;
  window.abrirSelectorEspacios=abrirSelectorEspacios; window.abrirEspacios=abrirEspacios; window.cerrarSelectorEspacios=cerrarSelectorEspacios;
  window.seleccionarEspacioTrabajo=seleccionarEspacioTrabajo; window.abrirOrganizacionHome=abrirOrganizacionHome; window.crearOrganizacionLecheria=crearOrganizacionLecheria;
  window.compartirInvitacionOrg=compartirInvitacionOrg; window.registrarRecepcionOrg=registrarRecepcionOrg; window.abrirEscanerInvitacionOrg=abrirEscanerInvitacionOrg; window.copiarInvitacionOrg=copiarInvitacionOrg; window.generarQRInvitacion=generarQRInvitacion;
  window.renderSelectorEspacios=renderSelector; window.mostrarInvitacionPendienteOrganizacion=mostrarInvitacionPendiente;
  window.addEventListener('miranch:auth-state',()=>{setTimeout(()=>{try{mostrarInvitacionPendiente();}catch(e){}},250);});
  window.addEventListener('load',()=>{setTimeout(()=>{asegurarModelo();renderSelector();mostrarInvitacionPendiente();},500);});
})();
