// Guardia de seguridad para acciones exclusivas del administrador completo.
// No depende de que el botón esté oculto: bloquea también llamadas directas a
// las funciones expuestas en window.
function requiereAdministradorCompleto(silencioso = false){
  const permitido = typeof window.iranchPuedeAdministrarCompleto === 'function'
    ? window.iranchPuedeAdministrarCompleto()
    : false;
  if (!permitido){
    if (!silencioso && typeof mostrarToast === 'function') mostrarToast('Esta función es solo para el administrador');
    return false;
  }
  return true;
}

(function(){
// MiRanch — módulo extraído automáticamente. Se ejecuta como script clásico para conservar compatibilidad con funciones globales.
// ================= REPORTES Y ANÁLISIS DE PRODUCCIÓN (admin) =================
// Como los datos pesados de cada rancho viven en su propio documento de Firestore
// (no en el documento global que el admin ya tiene cargado), para poder cruzar
// datos de TODOS los productores hay que traer, una vez, los datos de cada cuenta.
let cacheReportesRegionales = {};
let datosComparativoProductores = [];
async function cargarDatosRegionales(){
if (!requiereAdministradorCompleto()) return;
const boton = document.getElementById('btn-cargar-reportes');
const estadoTxt = document.getElementById('rep-estado-carga');
const cuentas = estado.cuentasProductores.filter(c => c.tipo !== 'punto');
if (boton) boton.disabled = true;
let cargadas = 0;
for (const c of cuentas){
if (estadoTxt) estadoTxt.textContent = `${tr('reportes_admin__cargando')} ${cargadas + 1}/${cuentas.length}…`;
if (typeof window.firebaseLeerCuenta === 'function' && navigator.onLine){
try {
const datos = await window.firebaseLeerCuenta(c.id);
cacheReportesRegionales[c.id] = datos || { hato: c.hato || [], salud: c.salud || [] };
} catch(e){ cacheReportesRegionales[c.id] = { hato: c.hato || [], salud: c.salud || [] }; }
} else {
cacheReportesRegionales[c.id] = { hato: c.hato || [], salud: c.salud || [] };
}
cargadas++;
}
if (boton) boton.disabled = false;
if (estadoTxt) estadoTxt.textContent = `✓ ${tr('reportes_admin__datos_actualizados_de')} ${cargadas} ${tr('cuentas_productores_alta__cuenta_s')}`;
actualizarReportesRegionales();
}
function actualizarReportesRegionales(){
if (!requiereAdministradorCompleto()) return;
const cont = document.getElementById('reportes-indicadores');
if (!cont) return;
const filtroEstado = valor('rep-estado').trim().toLowerCase();
const filtroMunicipio = valor('rep-municipio').trim().toLowerCase();
const filtroTipo = valor('rep-tipo');
const filtroSalud = valor('rep-salud');
const cuentas = estado.cuentasProductores.filter(c => {
if (c.tipo === 'punto') return false;
if (filtroTipo && c.tipo !== filtroTipo) return false;
if (filtroEstado && (c.estadoMx || '').toLowerCase() !== filtroEstado) return false;
if (filtroMunicipio && (c.municipio || '').toLowerCase() !== filtroMunicipio) return false;
return true;
});
let nacimientos = 0, compras = 0, bajas = 0, siniigaActivos = 0, siniigaPendientes = 0, alertasCefpp = 0;
const filasTabla = [];
// Guarda un resumen por productor (tamaño del hato, % de bajas, alertas por
// animal) para poder comparar a uno solo contra el promedio del grupo que se
// acaba de cargar — usa los mismos datos de arriba, no vuelve a pedir nada.
datosComparativoProductores = [];
cuentas.forEach(c => {
const datos = cacheReportesRegionales[c.id] || { hato: c.hato || [], salud: c.salud || [] };
const hato = Array.isArray(datos.hato) ? datos.hato : [];
const salud = Array.isArray(datos.salud) ? datos.salud : [];
let saludFiltrada = salud.filter(r => r.estadoCEFPP);
if (filtroSalud === 'enfermo') saludFiltrada = salud.filter(r => (r.tipo === 'enfermedad' || r.tipo === 'muerte_subita' || r.tipo === 'sospecha_exotica') && !r.recuperado);
if (filtroSalud === 'cefpp') saludFiltrada = salud.filter(r => r.estadoCEFPP);
const propiosNacimientos = hato.filter(a => a.madre).length;
const propiasCompras = hato.filter(a => !a.madre).length;
const propiasBajas = hato.filter(a => a.estatus === 'vendido' || a.estatus === 'finado' || a.motivoBaja).length;
const propiosActivosSiniiga = hato.filter(a => a.arete).length;
const propiosPendientesSiniiga = hato.filter(a => !a.arete).length;
const propiasCefpp = saludFiltrada.length;
nacimientos += propiosNacimientos; compras += propiasCompras; bajas += propiasBajas;
siniigaActivos += propiosActivosSiniiga; siniigaPendientes += propiosPendientesSiniiga; alertasCefpp += propiasCefpp;
filasTabla.push({ nombre: c.nombre, municipio: c.municipio || '—', animales: hato.length, cefpp: propiasCefpp });
datosComparativoProductores.push({
id: c.id, nombre: c.nombre,
tamanoHato: hato.length,
porcentajeBajas: hato.length > 0 ? (propiasBajas / hato.length) * 100 : 0,
alertasPorAnimal: hato.length > 0 ? (propiasCefpp / hato.length) : 0,
});
});
renderSelectorComparativoProductor();
cont.innerHTML = [
{ etiqueta: tr('reportes_admin__nacimientos'), valor: nacimientos, color:'var(--green)' },
{ etiqueta: tr('reportes_admin__compras'), valor: compras, color:'var(--blue)' },
{ etiqueta: tr('reportes_admin__bajas'), valor: bajas, color:'var(--red)' },
{ etiqueta: tr('reportes_admin__siniiga_activos'), valor: siniigaActivos, color:'var(--teal)' },
{ etiqueta: tr('reportes_admin__siniiga_pendientes'), valor: siniigaPendientes, color:'var(--yellow)' },
{ etiqueta: tr('reportes_admin__alertas_sanitarias'), valor: alertasCefpp, color:'var(--purple)' },
].map(t => `
<div class="bg-white rounded-2xl p-4" style="border:2px solid var(--line); border-top:6px solid ${t.color};">
<p class="text-2xl font-bold">${t.valor}</p>
<p class="text-sm" style="color:var(--sage);">${t.etiqueta}</p>
</div>`).join('');
const contFolios = document.getElementById('reportes-folios');
if (contFolios){
const folios = cuentas.filter(c => c.folio).map(c => ({ folio: c.folio, nombre: c.nombre, vence: c.vencimientoFierro || '—' }));
contFolios.innerHTML = folios.length === 0
? `<p class="text-xs text-center py-2" style="color:var(--sage);">${tr('reportes_admin__sin_folios_registrados')}</p>`
: folios.map(f => `<div class="flex items-center justify-between py-1" style="border-top:1px solid var(--line);"><span class="text-sm font-bold">${f.folio}</span><span class="text-xs" style="color:var(--sage);">${f.nombre} · ${tr('editar_datos_productor__vencimiento_credencial_fierro')}: ${f.vence}</span></div>`).join('');
}
const contTabla = document.getElementById('reportes-tabla');
if (contTabla){
contTabla.innerHTML = filasTabla.length === 0
? `<p class="text-xs text-center py-2" style="color:var(--sage);">${tr('reportes_admin__pulsa_actualizar_datos_para_ver')}</p>`
: filasTabla.map(f => `
<div class="flex items-center justify-between py-1" style="border-top:1px solid var(--line);">
<div><span class="text-sm font-bold">${f.nombre}</span><span class="text-xs" style="color:var(--sage);"> · ${f.municipio}</span></div>
<div class="text-xs" style="color:var(--sage);">${f.animales} ${tr('mensajes_veterinario_productor__animales_registrados') || 'animales'}${f.cefpp > 0 ? ` · ⚠️ ${f.cefpp}` : ''}</div>
</div>`).join('');
}
}
// ================= COMPARATIVO POR PRODUCTOR (benchmarking) =================
// Compara a UN productor contra el promedio del grupo que ya se cargó arriba
// — tamaño de hato, % de bajas y alertas sanitarias por animal. Usa los
// mismos datos ya descargados (no vuelve a pedir nada a Firebase), así que
// solo funciona con lo que ya se haya "Actualizado" en esta pantalla.
function renderSelectorComparativoProductor(){
if (!requiereAdministradorCompleto()) return;
const select = document.getElementById('rep-productor-comparar');
if (!select) return;
const seleccionActual = select.value;
select.innerHTML = '<option value="">Selecciona un productor…</option>' + datosComparativoProductores.map(d => `<option value="${d.id}">${d.nombre}</option>`).join('');
if (seleccionActual && datosComparativoProductores.some(d => d.id === seleccionActual)) select.value = seleccionActual;
renderComparativoProductor();
}
function promedioGrupo(campo){
if (datosComparativoProductores.length === 0) return 0;
return datosComparativoProductores.reduce((s, d) => s + d[campo], 0) / datosComparativoProductores.length;
}
function barraComparativa(etiqueta, valorProductor, valorPromedio, sufijo, invertido){
const maximo = Math.max(valorProductor, valorPromedio, 0.0001);
const pctProductor = Math.min(100, (valorProductor / maximo) * 100);
const pctPromedio = Math.min(100, (valorPromedio / maximo) * 100);
// "invertido" = para métricas donde MENOS es mejor (bajas, alertas) — se
// pinta verde si el productor está por debajo del promedio, rojo si arriba.
const mejorQuePromedio = invertido ? valorProductor <= valorPromedio : valorProductor >= valorPromedio;
const color = mejorQuePromedio ? 'var(--green)' : 'var(--red)';
return `<div class="mb-3">
<p class="text-xs font-bold mb-1">${etiqueta}</p>
<div style="background:var(--parchment); border-radius:8px; height:18px; position:relative; margin-bottom:2px;">
<div style="background:${color}; height:100%; border-radius:8px; width:${pctProductor}%;"></div>
</div>
<p class="text-xs" style="color:var(--sage);">Este productor: <strong>${valorProductor.toFixed(1)}${sufijo}</strong> · Promedio del grupo: ${valorPromedio.toFixed(1)}${sufijo}</p>
</div>`;
}
function renderComparativoProductor(){
if (!requiereAdministradorCompleto()) return;
const cont = document.getElementById('reportes-comparativo');
if (!cont) return;
const id = valor('rep-productor-comparar');
if (!id){ cont.innerHTML = ''; return; }
const d = datosComparativoProductores.find(x => x.id === id);
if (!d){ cont.innerHTML = ''; return; }
if (datosComparativoProductores.length < 2){
cont.innerHTML = `<p class="text-xs text-center py-2" style="color:var(--sage);">Se necesita más de un productor cargado para poder comparar contra un promedio.</p>`;
return;
}
cont.innerHTML = `
${barraComparativa('Tamaño del hato', d.tamanoHato, promedioGrupo('tamanoHato'), ' animales', false)}
${barraComparativa('% de bajas del hato', d.porcentajeBajas, promedioGrupo('porcentajeBajas'), '%', true)}
${barraComparativa('Alertas sanitarias por animal', d.alertasPorAnimal, promedioGrupo('alertasPorAnimal'), '', true)}
<p class="text-xs mt-1" style="color:var(--sage);"><i class="fa-solid fa-circle-info"></i> Verde = mejor que el promedio del grupo cargado; rojo = por debajo. Es un comparativo simple, no toma en cuenta el tamaño del rancho ni el tipo de ganado.</p>`;
}
// ================= MÉTRICAS DE INTERACCIÓN (solo admin general, nunca comité) =================
let graficasMetricas = {};
async function dibujarGraficaCircular(idCanvas, etiquetas, valores, colores){
await cargarChartJsSiNecesario();
const canvas = document.getElementById(idCanvas);
if (!canvas || !window.Chart) return;
if (graficasMetricas[idCanvas]) graficasMetricas[idCanvas].destroy();
const total = valores.reduce((a,b) => a+b, 0);
const datosFinal = total === 0 ? [1] : valores;
const etiquetasFinal = total === 0 ? [tr('metricas_admin__sin_datos_aun')] : etiquetas;
const coloresFinal = total === 0 ? ['#E5E1D8'] : colores;
graficasMetricas[idCanvas] = new Chart(canvas.getContext('2d'), {
type: 'pie',
data: { labels: etiquetasFinal, datasets: [{ data: datosFinal, backgroundColor: coloresFinal }] },
options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } } } },
});
}
function renderMetricasInteraccion(){
if (!requiereAdministradorCompleto()) return;
const eventos = estado.eventosUso;
const logins = eventos.filter(e => e.tipo === 'login');
const accesos = eventos.filter(e => e.tipo === 'acceso');
const whatsapp = eventos.filter(e => e.tipo === 'whatsapp');
const qr = accesos.filter(a => a.subtipo === 'qr').length;
const directo = accesos.filter(a => a.subtipo === 'directo').length;
const cont = document.getElementById('metricas-resumen');
if (cont) cont.innerHTML = [
{ etiqueta: tr('metricas_admin__inicios_de_sesion'), valor: logins.length, color:'var(--green)' },
{ etiqueta: tr('metricas_admin__accesos_por_qr'), valor: qr, color:'var(--blue)' },
{ etiqueta: tr('metricas_admin__mensajes_por_whatsapp'), valor: whatsapp.length, color:'var(--purple)' },
].map(t => `
<div class="bg-white rounded-2xl p-3 text-center" style="border:2px solid var(--line); border-top:6px solid ${t.color};">
<p class="text-xl font-bold">${t.valor}</p>
<p class="text-xs" style="color:var(--sage);">${t.etiqueta}</p>
</div>`).join('');
const franjas = [0,0,0,0];
logins.forEach(e => {
if (e.hora < 6) franjas[0]++;
else if (e.hora < 12) franjas[1]++;
else if (e.hora < 18) franjas[2]++;
else franjas[3]++;
});
dibujarGraficaCircular('grafica-metricas-horario',
[tr('metricas_admin__madrugada'), tr('metricas_admin__manana'), tr('metricas_admin__tarde'), tr('metricas_admin__noche')],
franjas, ['#5C7DBE','#6B9B6E','#F2A741','#8B5CF6']);
const dias = [0,0,0,0,0,0,0];
logins.forEach(e => dias[e.diaSemana]++);
dibujarGraficaCircular('grafica-metricas-dia',
[tr('metricas_admin__domingo'), tr('metricas_admin__lunes'), tr('metricas_admin__martes'), tr('metricas_admin__miercoles'), tr('metricas_admin__jueves'), tr('metricas_admin__viernes'), tr('metricas_admin__sabado')],
dias, ['#E0685A','#F2A741','#F6D861','#6B9B6E','#5C7DBE','#8B5CF6','#C98BAE']);
dibujarGraficaCircular('grafica-metricas-qr',
[tr('metricas_admin__via_codigo_qr'), tr('metricas_admin__acceso_directo')],
[qr, directo], ['#3C6B4F','#B7A98F']);
const porTipoWhatsapp = {};
whatsapp.forEach(w => { const clave = w.subtipo || 'otro'; porTipoWhatsapp[clave] = (porTipoWhatsapp[clave] || 0) + 1; });
const ETIQUETAS_WHATSAPP = {
compartir_app: tr('metricas_admin__compartir_la_app'), compartir_cuenta_nueva: tr('metricas_admin__cuenta_nueva_creada'),
recuperar_contrasena: tr('metricas_admin__recuperar_contrasena'), recordatorio_vigencia: tr('metricas_admin__recordatorio_de_vigencia'), otro: tr('metricas_admin__otro'),
};
dibujarGraficaCircular('grafica-metricas-whatsapp',
Object.keys(porTipoWhatsapp).map(k => ETIQUETAS_WHATSAPP[k] || k),
Object.values(porTipoWhatsapp), ['#25D366','#5C7DBE','#F2A741','#E0685A','#8B5CF6']);
}
function renderTodoAdmin(){
const adminCompleto = requiereAdministradorCompleto(true);
if (!adminCompleto){
  renderGridAdminHome();
  aplicarVistaSegunRol();
  if (estado.vistaVeterinario) renderListaVetProductores();
  if (estado.vistaVeterinario) renderListaVetNotas();
  renderBoletinesAdmin();
  renderResumenAdmin();
  return;
}
llenarSelectorEstados('adm');
establecerValor('adm-apellidopaterno', estado.productor.apellidoPaterno || '');
establecerValor('adm-apellidomaterno', estado.productor.apellidoMaterno || '');
establecerValor('adm-nombres', estado.productor.nombres || '');
establecerValor('adm-domicilio', estado.productor.domicilio || 'Conocido');
establecerValor('adm-localidad', estado.productor.localidad || '');
establecerValor('adm-correo', estado.productor.correoElectronico || '');
establecerValor('adm-predio', estado.productor.predio || '');
establecerValor('adm-upp', estado.productor.upp);
establecerValor('adm-actualizacionupp', estado.productor.actualizacionUPP || '');
establecerValor('adm-folio', estado.productor.folio);
establecerValor('adm-vencimientofierro', estado.productor.vencimientoFierro || '');
establecerValor('adm-estado', estado.productor.estado);
cargarMunicipiosSelector('adm', estado.productor.municipio || '');
establecerValor('adm-ejido', estado.productor.ejido);
establecerValor('adm-curp', estado.productor.curp || '');
establecerValor('adm-actividad', estado.productor.actividad);
const spanGpsAdm = document.getElementById('adm-gps-texto');
if (spanGpsAdm) spanGpsAdm.textContent = (estado.productor.latitudUPP && estado.productor.longitudUPP) ? `Ubicación registrada (${estado.productor.latitudUPP.toFixed(5)}, ${estado.productor.longitudUPP.toFixed(5)})` : 'Registrar ubicación GPS';
renderTogglesModulos();
renderListaOrdenMas();
renderListaOrdenGraficas();
renderListaTrabajadores();
renderListaTareasAdmin();
renderListaPlanSanitario();
renderTogglesCampos();
renderTogglesVentanasExtra();
renderListaBanners();
renderListaPredios();
renderGridAdminHome();
aplicarVistaSegunRol();
if (estado.vistaVeterinario) renderListaVetProductores();
if (estado.vistaVeterinario) renderListaVetNotas();
document.getElementById('texto-btn-push').textContent = estado.pushActivado ? tr('notificaciones_push_reales__notificaciones_activadas') : tr('admin_configuracion__activar_notificaciones_push');
renderBoletinesAdmin();
renderResumenAdmin();
if (adminCompleto) {
  renderListaUsuarios();
  renderInfoSistema();
}
}
function renderResumenAdmin(){
const cont = document.getElementById('resumen-admin');
const p = estado.productor;
cont.innerHTML = `
<div><p style="color:var(--sage);">${tr('mensajes_veterinario_productor__productor_configurado')}</p><p class="font-bold text-base">${p.nombre || '<span style="color:var(--line);">Sin configurar</span>'}</p></div>
<div><p style="color:var(--sage);">${tr('mensajes_veterinario_productor__animales_registrados')}</p><p class="font-bold text-base">${estado.animales.length}</p></div>
${(typeof window.iranchPuedeAdministrarCompleto === 'function' && window.iranchPuedeAdministrarCompleto()) ? `<div><p style="color:var(--sage);">${tr('mensajes_veterinario_productor__usuarios_del_sistema')}</p><p class="font-bold text-base">${estado.usuarios.length}</p></div>` : ''}
<div><p style="color:var(--sage);">${tr('mensajes_veterinario_productor__boletines_publicados')}</p><p class="font-bold text-base">${estado.boletines.length}</p></div>`;
}
function renderListaUsuarios(){
if (!requiereAdministradorCompleto()) return;
const cont = document.getElementById('lista-usuarios');
if (!cont) return;
const colorRol = { admin:'var(--slate)', productor:'var(--green)', veterinario:'var(--purple)', capturista:'var(--teal)' };
cont.innerHTML = estado.usuarios.map((u, i) => `
<div class="item-registro" style="border-left:6px solid ${colorRol[u.rol]};">
<div class="flex items-center justify-between">
<div>
<p class="font-bold">${u.nombre}</p>
<p class="text-sm font-mono" style="color:var(--sage);">${tr('mensajes_veterinario_productor__usuario_rol').replace('%VAR%', u.usuario).replace('%VAR%', u.rol)}</p>
</div>
<button onclick="eliminarUsuario(${i})" style="color:var(--red);"><i class="fa-solid fa-trash"></i></button>
</div>
<div class="flex items-center gap-2 mt-3">
<input type="text" placeholder="${tr('mensajes_veterinario_productor__nueva_contrasena')}" id="clave-${i}" style="flex:1; padding:.5rem .75rem; font-size:.9rem;">
<button onclick="cambiarClave(${i})" class="btn-primario-plano" style="min-height:auto; padding:.5rem 1rem; background:var(--blue); font-size:.85rem;">
<i class="fa-solid fa-key"></i>
</button>
</div>
</div>`).join('');
}
function agregarUsuario(){
if (!requiereAdministradorCompleto()) return;
const nombre = valor('nu-nombre'), usuario = valor('nu-usuario').trim().toLowerCase(), clave = valor('nu-clave'), rol = valor('nu-rol');
if (!usuario || !clave) return;
estado.usuarios.push({ nombre: nombre || usuario, usuario, clave, rol });
limpiarCampos(['nu-nombre','nu-usuario','nu-clave']);
renderListaUsuarios();
renderResumenAdmin();
mostrarToast(tr('mensajes_veterinario_productor__usuario_creado'));
}
function eliminarUsuario(i){
if (!requiereAdministradorCompleto()) return;
const [borrado] = estado.usuarios.splice(i, 1);
renderListaUsuarios();
renderResumenAdmin();
mostrarToast(tr('mensajes_veterinario_productor__usuario_eliminado'), () => {
estado.usuarios.splice(i, 0, borrado);
renderListaUsuarios();
renderResumenAdmin();
mostrarToast(tr('mensajes_veterinario_productor__usuario_restaurado'));
});
}
function cambiarClave(i){
if (!requiereAdministradorCompleto()) return;
const nueva = valor('clave-' + i);
if (!nueva) return;
estado.usuarios[i].clave = nueva;
renderListaUsuarios();
mostrarToast(tr('mensajes_veterinario_productor__contrasena_actualizada'));
}
function fijarRelojSimulado(){
if (!requiereAdministradorCompleto()) return;
const fecha = valor('reloj-fecha-input');
if (!fecha){ mostrarToast(tr('cuentas_productores_alta__elige_una_fecha_primero')); return; }
estado.relojSimulado = fecha;
renderCuentas();
verificarVigenciaProductor();
mostrarToast(tr('cuentas_productores_alta__reloj_de_pruebas_fijado_en') + ' ' + fecha);
}
function limpiarRelojSimulado(){
if (!requiereAdministradorCompleto()) return;
estado.relojSimulado = null;
establecerValor('reloj-fecha-input', '');
renderCuentas();
verificarVigenciaProductor();
mostrarToast(tr('cuentas_productores_alta__usando_la_fecha_real_del'));
}
function seleccionarTipoCuenta(tipo){
if (!requiereAdministradorCompleto()) return;
establecerValor('cta-tipo', tipo);
const btnLeche = document.getElementById('cta-tipo-btn-leche');
const btnCarne = document.getElementById('cta-tipo-btn-carne');
if (btnLeche) btnLeche.classList.toggle('active', tipo === 'leche');
if (btnCarne) btnCarne.classList.toggle('active', tipo === 'carne');
}
function seleccionarTipoRegistro(tipo){
establecerValor('reg-tipo', tipo);
const btnLeche = document.getElementById('reg-tipo-btn-leche');
const btnCarne = document.getElementById('reg-tipo-btn-carne');
const btnPunto = document.getElementById('reg-tipo-btn-punto');
const btnMvz = document.getElementById('reg-tipo-btn-mvz');
const btnCefp = document.getElementById('reg-tipo-btn-cefp');
if (btnLeche) btnLeche.classList.toggle('active', tipo === 'leche');
if (btnCarne) btnCarne.classList.toggle('active', tipo === 'carne');
if (btnPunto) btnPunto.classList.toggle('active', tipo === 'punto');
if (btnMvz) btnMvz.classList.toggle('active', tipo === 'mvz');
if (btnCefp) btnCefp.classList.toggle('active', tipo === 'cefp');
const esPunto = tipo === 'punto';
const esMvz = tipo === 'mvz';
const esCefp = tipo === 'cefp';
const grupoLocal = document.getElementById('reg-grupo-local');
const grupoProductor = document.getElementById('reg-grupo-productor');
const grupoUbicacion = document.getElementById('reg-grupo-ubicacion');
const grupoMvz = document.getElementById('reg-grupo-mvz');
const grupoCefp = document.getElementById('reg-grupo-cefp');
const labelNombre = document.getElementById('reg-nombre-label');
if (grupoLocal) grupoLocal.classList.toggle('hidden', !esPunto);
if (grupoProductor) grupoProductor.classList.toggle('hidden', esPunto || esMvz || esCefp);
if (grupoUbicacion) grupoUbicacion.classList.toggle('hidden', !esPunto);
if (grupoMvz) grupoMvz.classList.toggle('hidden', !esMvz);
if (grupoCefp) grupoCefp.classList.toggle('hidden', !esCefp);
if (labelNombre) labelNombre.textContent = esPunto ? tr('login_seleccion_rol__nombre_de_la_persona_encargada') : (esMvz ? tr('login_seleccion_rol__nombre_del_veterinario') : (esCefp ? 'Nombre completo' : tr('admin_cuentas_productores__nombre_del_productor')));
}
function agregarCuentaProductor(){
if (!requiereAdministradorCompleto()) return;
const nombre = valor('cta-nombre').trim();
const predio = valor('cta-predio').trim();
const upp = valor('cta-upp').trim();
const tipo = valor('cta-tipo');
const telefono = valor('cta-telefono').trim();
const ip = valor('cta-ip').trim();
const diasVigencia = parseInt(valor('cta-dias-vigencia'), 10) || 365;
if (!nombre || !predio || !upp || !telefono || !ip){ mostrarToast(tr('admin_cuentas_productores__completa_telefono_e_ip')); return; }
if (estado.cuentasProductores.some(c => c.upp.toLowerCase() === upp.toLowerCase())){
mostrarToast(tr('cuentas_productores_alta__ya_existe_una_cuenta_registrada')); return;
}
const usuario = generarUsuarioDesdeNombre(nombre);
const clave = generarContrasenaProvisional();
const fechaAlta = hoyISO();
const cuenta = {
id: 'cta_' + Date.now(),
nombre, predio, upp, tipo, telefono, ip,
usuario, clave,
fechaAlta,
suscripcion: { diasVigencia, fechaVencimiento: sumarDiasISO(fechaAlta, diasVigencia) },
hato: [], salud: [], pesajes: [], reproduccion: [], 
};
estado.cuentasProductores.push(cuenta);
estado.usuarios.push({ nombre: nombre + ' ' + tr('cuentas_productores_alta__productor'), usuario, clave, rol:'productor' });
limpiarCampos(['cta-nombre','cta-predio','cta-upp','cta-telefono','cta-ip']);
seleccionarTipoCuenta('leche');
establecerValor('cta-dias-vigencia', 365);
renderCuentas();
renderListaUsuarios();
renderResumenAdmin();
mostrarToast(`Cuenta creada — usuario: ${usuario} · contraseña: ${clave}`);
mostrarPanelCompartirCuenta(nombre, usuario, clave, telefono);
}
function mostrarPanelCompartirCuenta(nombre, usuario, clave, telefono){
if (!requiereAdministradorCompleto()) return;
const panel = document.getElementById('panel-compartir-cuenta-nueva');
if (!panel) return;
const mensaje = tr('admin_cuentas_productores__mensaje_bienvenida_cuenta').replace('%VAR%', usuario).replace('%VAR%', clave);
const telLimpio = (telefono || '').replace(/\D/g,'');
panel.classList.remove('hidden');
panel.innerHTML = `
<div class="rounded-2xl p-4 mt-2" style="background:var(--parchment); border:2px solid var(--line);">
<p class="text-sm font-bold mb-2">${tr('admin_cuentas_productores__cuenta_creada_compartir')} ${nombre}</p>
<button onclick="compartirCuentaPorWhatsApp('${telLimpio}', ${JSON.stringify(mensaje)})" class="w-full btn-primario-plano" style="background:#25D366;">
<i class="fa-brands fa-whatsapp"></i><span>${tr('admin_cuentas_productores__compartir_por_whatsapp')}</span>
</button>
</div>`;
}
function compartirCuentaPorWhatsApp(telefono, mensaje){
if (!requiereAdministradorCompleto()) return;
const texto = encodeURIComponent(mensaje);
const numero = telefono && telefono.length >= 10 ? (telefono.length === 10 ? '52' + telefono : telefono) : '';
window.open(`https://wa.me/${numero}?text=${texto}`, '_blank');
registrarEvento('whatsapp', 'compartir_cuenta_nueva');
}
function eliminarCuentaProductor(id){
if (!requiereAdministradorCompleto()) return;
const i = estado.cuentasProductores.findIndex(c => c.id === id);
if (i === -1) return;
const [borrada] = estado.cuentasProductores.splice(i, 1);
if (estado.cuentaActivaId === id){
estado.cuentaActivaId = null;
estado.animales = HATO_DEMO; estado.salud = SALUD_DEMO;
estado.pesajes = PESAJES_DEMO; estado.reproduccion = REPRODUCCION_DEMO;
}
renderCuentas();
mostrarToast(tr('cuentas_productores_alta__cuenta_eliminada'), () => {
estado.cuentasProductores.splice(i, 0, borrada);
renderCuentas();
mostrarToast(tr('cuentas_productores_alta__cuenta_restaurada'));
});
}
function ajustarVigenciaCuenta(id, dias){
if (!requiereAdministradorCompleto()) return;
const cuenta = estado.cuentasProductores.find(c => c.id === id);
if (!cuenta) return;
cuenta.suscripcion.fechaVencimiento = sumarDiasISO(cuenta.suscripcion.fechaVencimiento, dias);
renderCuentas();
}
function sincronizarSuscripcionSiEsCuentaActiva(cuenta){
if (!requiereAdministradorCompleto(true)) return;
if (estado.cuentaActivaId && estado.cuentaActivaId === cuenta.id){
estado.productor.suscripcion = { ...cuenta.suscripcion };
if (typeof verificarVigenciaProductor === 'function') verificarVigenciaProductor();
}
}
function establecerFechaVencimientoCuenta(id, fechaISO){
if (!requiereAdministradorCompleto()) return;
const cuenta = estado.cuentasProductores.find(c => c.id === id);
if (!cuenta || !fechaISO) return;
cuenta.suscripcion.fechaVencimiento = fechaISO;
sincronizarSuscripcionSiEsCuentaActiva(cuenta);
renderCuentas();
guardarEstadoLocal();
mostrarToast(tr('cuentas_productores_alta__vigencia_actualizada'));
}
function renovarCuenta365(id){
if (!requiereAdministradorCompleto()) return;
const cuenta = estado.cuentasProductores.find(c => c.id === id);
if (!cuenta) return;
cuenta.suscripcion.fechaVencimiento = sumarDiasISO(hoyISO(), cuenta.suscripcion.diasVigencia || 365);
sincronizarSuscripcionSiEsCuentaActiva(cuenta);
renderCuentas();
guardarEstadoLocal();
mostrarToast(tr('cuentas_productores_alta__cuenta_renovada_por') + ' ' + (cuenta.suscripcion.diasVigencia || 365) + ' ' + tr('cuentas_productores_alta__dias_desde_hoy'));
}
function marcarCuentaVencidaAhora(id){
if (!requiereAdministradorCompleto()) return;
const cuenta = estado.cuentasProductores.find(c => c.id === id);
if (!cuenta) return;
cuenta.suscripcion.fechaVencimiento = sumarDiasISO(hoyISO(), -1);
sincronizarSuscripcionSiEsCuentaActiva(cuenta);
renderCuentas();
guardarEstadoLocal();
mostrarToast(tr('cuentas_productores_alta__cuenta_marcada_como_vencida_para'));
}
async function usarCuentaParaPruebas(id){
if (!requiereAdministradorCompleto()) return;
const cuenta = estado.cuentasProductores.find(c => c.id === id);
if (!cuenta) return;
estado.cuentaActivaId = cuenta.id;
estado.productor.nombre = cuenta.nombre;
estado.productor.predio = cuenta.predio;
estado.productor.upp = cuenta.upp;
estado.productor.suscripcion = { fechaAlta: cuenta.fechaAlta, diasVigencia: cuenta.suscripcion.diasVigencia, fechaVencimiento: cuenta.suscripcion.fechaVencimiento };
estado.tipoGanado = cuenta.tipo;
await cargarDatosDeCuentaConFirestore(cuenta);
activarEscuchaCuentaActiva();
mostrarApp('productor');
mostrarToast(`Probando la app como ${cuenta.nombre} (${estatusCuenta(cuenta).estatus})`);
}
function enlaceWhatsApp(cuenta, dias){
const nombreCorto = cuenta.nombre.split(' ')[0];
const mensaje = dias < 0
? `Hola ${nombreCorto}, tu suscripción a MiRanch venció hace ${Math.abs(dias)} día(s). ¿Renovamos tu acceso?`
: `Hola ${nombreCorto}, tu suscripción a MiRanch vence en ${dias} día(s). ¿Renovamos tu acceso?`;
const soloDigitos = (cuenta.telefono || '').replace(/[^0-9]/g, '');
const base = soloDigitos ? `https://wa.me/${soloDigitos}` : 'https://wa.me/';
return `${base}?text=${encodeURIComponent(mensaje)}`;
}
function contarNuevasCuentas(rango){
if (!requiereAdministradorCompleto()) return;
const hoy = fechaHoy();
return estado.cuentasProductores.filter(c => {
const dias = diasEntreISO(hoyISO(), c.fechaAlta);
if (rango === 'dia') return c.fechaAlta === hoyISO();
if (rango === 'semana') return dias >= 0 && dias < 7;
if (rango === 'mes') return dias >= 0 && dias < 30;
if (rango === 'anio') return dias >= 0 && dias < 365;
return true; 
}).length;
}
function renderMetricasCuentas(){
if (!requiereAdministradorCompleto()) return;
if (!requiereAdministradorCompleto()) return;
const cont = document.getElementById('metricas-cuentas');
if (!cont) return;
const tarjetas = [
{ label: tr('csv_extra4__hoy'), valor: contarNuevasCuentas('dia') },
{ label: tr('cuentas_productores_alta__esta_semana'), valor: contarNuevasCuentas('semana') },
{ label: tr('cuentas_productores_alta__este_mes'), valor: contarNuevasCuentas('mes') },
{ label: tr('cuentas_productores_alta__este_ano'), valor: contarNuevasCuentas('anio') },
{ label: tr('csv_extra7__total'), valor: contarNuevasCuentas('total') },
{ label: tr('csv_extra7__vencidas'), valor: estado.cuentasProductores.filter(c => estatusCuenta(c).estatus === 'vencida').length },
];
cont.innerHTML = tarjetas.map(t => `
<div class="rounded-2xl p-3" style="background:var(--parchment);">
<p class="text-2xl font-display font-bold" style="color:var(--pine);">${t.valor}</p>
<p class="text-xs font-bold" style="color:var(--sage);">${t.label}</p>
</div>`).join('');
}
function renderProximosAVencer(){
if (!requiereAdministradorCompleto()) return;
if (!requiereAdministradorCompleto()) return;
const cont = document.getElementById('lista-proximos-vencer');
if (!cont) return;
const filtroTipo = (valor('pav-filtro-tipo') || '').toLowerCase();
const diasMax = parseInt(valor('pav-filtro-dias') || '15', 10);
const filtroEstado = (valor('pav-filtro-estado') || '').trim().toLowerCase();
const filtroMunicipio = (valor('pav-filtro-municipio') || '').trim().toLowerCase();
const proximos = estado.cuentasProductores
.map(c => ({ cuenta: c, dias: diasEntreISO(c.suscripcion.fechaVencimiento, hoyISO()) }))
.filter(x => x.dias >= 0 && x.dias <= diasMax)
.filter(x => !filtroTipo || x.cuenta.tipo === filtroTipo)
.filter(x => !filtroEstado || (x.cuenta.estadoMx || '').toLowerCase().includes(filtroEstado))
.filter(x => !filtroMunicipio || (x.cuenta.municipio || '').toLowerCase().includes(filtroMunicipio))
.sort((a, b) => a.dias - b.dias);
if (proximos.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-circle-check"></i><p>${tr('cuentas_productores_alta__no_hay_cuentas_por_vencer')}</p></div>`;
return;
}
cont.innerHTML = proximos.map(({ cuenta, dias }) => `
<div class="item-registro" style="border-left:6px solid var(--yellow);">
<div class="flex items-center justify-between gap-3">
<div>
<p class="font-bold">${cuenta.nombre} <span class="text-xs px-2 py-0.5 rounded-full ml-1" style="background:var(--yellow); color:#3A2A0B;">${dias === 0 ? tr('csv_extra7__vence_hoy') : `${dias} día(s)`}</span></p>
<p class="text-sm" style="color:var(--sage);">${tr('cuentas_productores_alta__upp').replace('%VAR%', cuenta.predio).replace('%VAR%', cuenta.upp)}</p>
</div>
<a href="${enlaceWhatsApp(cuenta, dias)}" onclick="registrarEvento('whatsapp','recordatorio_vigencia')" target="_blank" rel="noopener" class="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style="background:#25D366; color:#fff;"><i class="fa-brands fa-whatsapp"></i></a>
</div>
</div>`).join('');
}
function renderListadoCuentas(){
if (!requiereAdministradorCompleto()) return;
const cont = document.getElementById('lista-cuentas-productores');
const contador = document.getElementById('contador-cuentas-total');
if (!cont) return;
const filtroTipo = valor('cta-filtro-tipo') || '';
const filtroEstatus = valor('cta-filtro-estatus') || '';
const filtroEstado = (valor('cta-filtro-estado') || '').trim().toLowerCase();
const filtroMunicipio = (valor('cta-filtro-municipio') || '').trim().toLowerCase();
const orden = valor('cta-filtro-orden') || 'nombre';
let cuentas = estado.cuentasProductores
.filter(c => !filtroTipo || c.tipo === filtroTipo)
.filter(c => !filtroEstatus || estatusCuenta(c).estatus === filtroEstatus)
.filter(c => !filtroEstado || (c.estadoMx || '').toLowerCase().includes(filtroEstado))
.filter(c => !filtroMunicipio || (c.municipio || '').toLowerCase().includes(filtroMunicipio));
if (orden === 'nombre') cuentas = cuentas.sort((a,b) => (a.nombre||'').localeCompare(b.nombre||''));
else if (orden === 'alta_reciente') cuentas = cuentas.sort((a,b) => (b.fechaAlta||'').localeCompare(a.fechaAlta||''));
else if (orden === 'alta_antigua') cuentas = cuentas.sort((a,b) => (a.fechaAlta||'').localeCompare(b.fechaAlta||''));
else if (orden === 'vence_pronto') cuentas = cuentas.sort((a,b) => estatusCuenta(a).dias - estatusCuenta(b).dias);
if (contador) contador.textContent = cuentas.length + ' ' + tr('cuentas_productores_alta__cuenta_s') + (cuentas.length !== estado.cuentasProductores.length ? ` (de ${estado.cuentasProductores.length})` : '');
if (estado.cuentasProductores.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-id-card-clip"></i><p>${tr('cuentas_productores_alta__aun_no_hay_cuentas_de')}</p></div>`;
return;
}
if (cuentas.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-filter-circle-xmark"></i><p>Ninguna cuenta coincide con el filtro.</p></div>`;
return;
}
const ETIQUETAS = { activa: tr('csv_extra7__activa'), por_vencer: tr('cuentas_productores_alta__por_vencer'), vencida: tr('csv_extra7__vencida') };
const COLORES = { activa:'var(--green)', por_vencer:'var(--yellow)', vencida:'var(--red)' };
const TIPOS = { leche: tr('admin_cuentas_productores__lechera'), carne: tr('admin_cuentas_productores__carne') };
cont.innerHTML = cuentas.map(c => {
const { estatus, dias } = estatusCuenta(c);
return `
<div class="item-registro" style="border-left:6px solid ${COLORES[estatus]};">
<div class="flex items-center justify-between gap-2">
<div>
<p class="font-bold">${c.nombre} <span class="text-xs px-2 py-0.5 rounded-full ml-1" style="background:${COLORES[estatus]}; color:#fff;">${ETIQUETAS[estatus]}</span></p>
<p class="text-sm" style="color:var(--sage);">${tr('cuentas_productores_alta__upp_2').replace('%VAR%', c.predio).replace('%VAR%', c.upp).replace('%VAR%', TIPOS[c.tipo] || c.tipo)}</p>
</div>
<button onclick="eliminarCuentaProductor('${c.id}')" style="color:var(--red);"><i class="fa-solid fa-trash"></i></button>
</div>
<p class="text-sm font-mono mt-2" style="color:var(--sage);">Usuario: ${c.usuario} · Contraseña: ••••••••</p>
<p class="text-xs mt-1" style="color:var(--sage);">${tr('cuentas_productores_alta__alta_vence').replace('%VAR%', c.fechaAlta).replace('%VAR%', c.suscripcion.fechaVencimiento).replace('%VAR%', dias >= 0 ? dias + ' día(s) restantes' : Math.abs(dias) + ' día(s) vencida')}</p>
<div class="flex flex-wrap gap-2 mt-3">
<button onclick="usarCuentaParaPruebas('${c.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--green); color:#fff;"><i class="fa-solid fa-flask"></i> ${tr('cuentas_productores_alta__probar_acceso')}</button>
<button onclick="renovarCuenta365('${c.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--blue); color:#fff;"><i class="fa-solid fa-rotate"></i> ${tr('cuentas_productores_alta__renovar')}</button>
<button onclick="ajustarVigenciaCuenta('${c.id}', 30)" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--parchment); color:var(--pine); border:2px solid var(--line);">${tr('cuentas_productores_alta__30_dias')}</button>
<button onclick="ajustarVigenciaCuenta('${c.id}', -30)" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--parchment); color:var(--pine); border:2px solid var(--line);">${tr('cuentas_productores_alta__30_dias_2')}</button>
<button onclick="marcarCuentaVencidaAhora('${c.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--parchment); color:var(--red); border:2px solid var(--line);">${tr('cuentas_productores_alta__vencer_ahora')}</button>
</div>
<div class="flex items-center gap-2 mt-3">
<input type="date" id="fecha-venc-${c.id}" value="${c.suscripcion.fechaVencimiento}" style="flex:1; padding:.5rem .75rem; font-size:.85rem;">
<button onclick="establecerFechaVencimientoCuenta('${c.id}', valor('fecha-venc-${c.id}'))" class="btn-primario-plano" style="min-height:auto; padding:.5rem 1rem; background:var(--slate); font-size:.85rem;"><i class="fa-solid fa-calendar-check"></i></button>
</div>
</div>`;
}).join('');
}
function renderCuentas(){
if (!requiereAdministradorCompleto()) return;
const realHoy = new Date();
const pad = n => String(n).padStart(2,'0');
const realISO = `${realHoy.getFullYear()}-${pad(realHoy.getMonth()+1)}-${pad(realHoy.getDate())}`;
const elReal = document.getElementById('cuentas-fecha-real');
const elSim = document.getElementById('cuentas-fecha-simulada');
if (elReal) elReal.textContent = realISO;
if (elSim) elSim.textContent = hoyISO() + ' ' + (estado.relojSimulado ? tr('cuentas_productores_alta__simulada') : tr('cuentas_productores_alta__real'));
const inputReloj = document.getElementById('reloj-fecha-input');
if (inputReloj && estado.relojSimulado) inputReloj.value = estado.relojSimulado;
renderMetricasCuentas();
renderProximosAVencer();
renderListadoCuentas();
}
function renderInfoSistema(){
if (!requiereAdministradorCompleto()) return;
const cont = document.getElementById('info-sistema');
if (!cont) return;
const tarjetas = [
{ label: tr('mensajes_veterinario_productor__animales_registrados'), valor: estado.animales.length, color:'var(--blue)' },
{ label: tr('cuentas_productores_alta__registros_de_salud'), valor: estado.salud.length, color:'var(--purple)' },
{ label: tr('cuentas_productores_alta__registros_reproductivos'), valor: estado.reproduccion.length, color:'var(--pink)' },
{ label: tr('cuentas_productores_alta__pesajes_registrados'), valor: estado.pesajes.length, color:'var(--green)' },
{ label: tr('cuentas_productores_alta__potreros_registrados'), valor: estado.potreros.length, color:'var(--teal)' },
{ label: tr('cuentas_productores_alta__costos_registrados'), valor: estado.costos.length, color:'var(--orange)' },
];
cont.innerHTML = tarjetas.map(t => `
<div class="bg-white rounded-2xl p-4" style="border:2px solid var(--line); border-top:6px solid ${t.color};">
<p class="text-2xl font-bold">${t.valor}</p>
<p class="text-sm" style="color:var(--sage);">${t.label}</p>
</div>`).join('');
renderAuditoriaTransferencias();
}
function renderAuditoriaTransferencias(){
if (!requiereAdministradorCompleto()) return;
const cont = document.getElementById('lista-auditoria-transferencias');
if (!cont) return;
if (estado.auditoriaTransferencias.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-clipboard-list"></i><p>${tr('cuentas_productores_alta__aun_no_se_han_autorizado')}</p></div>`;
return;
}
const ordenado = [...estado.auditoriaTransferencias].sort((a,b) => (b.fecha + b.hora).localeCompare(a.fecha + a.hora));
cont.innerHTML = ordenado.map(a => `
<div class="item-registro">
<p class="font-bold">Arete ${a.arete}</p>
<p class="text-sm" style="color:var(--sage);">${tr('cuentas_productores_alta__upp_upp').replace('%VAR%', a.productorOrigen).replace('%VAR%', a.uppOrigen).replace('%VAR%', a.productorDestino).replace('%VAR%', a.uppDestino)}</p>
<p class="text-xs" style="color:var(--sage);">${a.fecha} ${a.hora}</p>
</div>`).join('');
}
function guardarProductor(){
if (!requiereAdministradorCompleto()) return;
if (!marcarCamposFaltantes([{ id:'adm-nombres', etiqueta:'Nombre(s)' }])) return;
const apellidoPaterno = valor('adm-apellidopaterno').trim();
const apellidoMaterno = valor('adm-apellidomaterno').trim();
const nombres = valor('adm-nombres').trim();
const nombreCompleto = [nombres, apellidoPaterno, apellidoMaterno].filter(Boolean).join(' ');
estado.productor = {
...estado.productor,
apellidoPaterno, apellidoMaterno, nombres, nombre: nombreCompleto || estado.productor.nombre,
domicilio: valor('adm-domicilio').trim() || 'Conocido',
localidad: valor('adm-localidad').trim(), correoElectronico: valor('adm-correo').trim(),
predio: valor('adm-predio'), upp: valor('adm-upp'), actualizacionUPP: valor('adm-actualizacionupp'),
folio: valor('adm-folio'), vencimientoFierro: valor('adm-vencimientofierro'),
estado: valor('adm-estado'), municipio: leerMunicipioSeleccionado('adm'),
ejido: valor('adm-ejido'), actividad: valor('adm-actividad'), curp: valor('adm-curp').toUpperCase(),
};
guardarEstadoLocal();
}
function llenarSelectorEstados(prefijo){
const sel = document.getElementById(prefijo + '-estado');
if (!sel || sel.dataset.lleno) return;
sel.innerHTML = '<option value="">Selecciona...</option>' + ESTADOS_MEXICO.map(e => `<option value="${e}">${e}</option>`).join('');
sel.dataset.lleno = '1';
}
function cargarMunicipiosSelector(prefijo, municipioActual){
const selEstado = document.getElementById(prefijo + '-estado');
const selMun = document.getElementById(prefijo + '-municipio');
const inputManual = document.getElementById(prefijo + '-municipio-manual');
if (!selEstado || !selMun) return;
const estadoElegido = selEstado.value;
const lista = MUNICIPIOS_MEXICO[estadoElegido];
if (!estadoElegido){
selMun.innerHTML = '<option value="">Selecciona el estado primero</option>';
if (inputManual) inputManual.classList.add('hidden');
return;
}
if (!lista || lista.length === 0){
selMun.innerHTML = '<option value="__manual__">Escribir municipio...</option>';
selMun.value = '__manual__';
if (inputManual){ inputManual.classList.remove('hidden'); inputManual.value = municipioActual || ''; }
return;
}
selMun.innerHTML = '<option value="">Selecciona...</option>' + lista.map(m => `<option value="${m}">${m}</option>`).join('') + '<option value="__manual__">Otro (no aparece en la lista)</option>';
if (municipioActual && lista.includes(municipioActual)){
selMun.value = municipioActual;
if (inputManual) inputManual.classList.add('hidden');
} else if (municipioActual){
selMun.value = '__manual__';
if (inputManual){ inputManual.classList.remove('hidden'); inputManual.value = municipioActual; }
} else if (inputManual){
inputManual.classList.add('hidden');
}
}
function mostrarMunicipioManual(prefijo){
const selMun = document.getElementById(prefijo + '-municipio');
const inputManual = document.getElementById(prefijo + '-municipio-manual');
if (!selMun || !inputManual) return;
inputManual.classList.toggle('hidden', selMun.value !== '__manual__');
if (selMun.value === '__manual__') inputManual.focus();
}
function leerMunicipioSeleccionado(prefijo){
const selMun = document.getElementById(prefijo + '-municipio');
if (!selMun) return '';
if (selMun.value === '__manual__') return valor(prefijo + '-municipio-manual').trim();
return selMun.value;
}
function previsualizarNombreCompleto(prefijo){
// Solo referencia visual; el nombre completo real se arma al guardar.
}
function registrarUbicacionUPP(prefijo){
if (!navigator.geolocation){ mostrarToast('Tu navegador no permite obtener ubicación'); return; }
const span = document.getElementById(prefijo + '-gps-texto');
const campoCoords = document.getElementById(prefijo + '-gps-coords');
if (span) span.textContent = 'Obteniendo...';
navigator.geolocation.getCurrentPosition(
pos => {
estado.productor.latitudUPP = pos.coords.latitude;
estado.productor.longitudUPP = pos.coords.longitude;
const texto = `${pos.coords.latitude.toFixed(5)}, ${pos.coords.longitude.toFixed(5)}`;
if (campoCoords){ campoCoords.value = texto; if (span) span.textContent = 'GPS'; }
else if (span) span.textContent = `Ubicación registrada (${texto})`;
if (prefijo === 'adm') guardarProductor();
guardarEstadoLocal();
mostrarToast('Ubicación GPS registrada');
},
() => {
if (span) span.textContent = campoCoords ? 'GPS' : 'Registrar ubicación GPS';
mostrarToast('No se pudo obtener tu ubicación. Revisa los permisos.');
},
{ enableHighAccuracy: true, timeout: 8000 }
);
}


  window['cargarDatosRegionales'] = cargarDatosRegionales;
  window['actualizarReportesRegionales'] = actualizarReportesRegionales;
  window['renderSelectorComparativoProductor'] = renderSelectorComparativoProductor;
  window['promedioGrupo'] = promedioGrupo;
  window['barraComparativa'] = barraComparativa;
  window['renderComparativoProductor'] = renderComparativoProductor;
  window['dibujarGraficaCircular'] = dibujarGraficaCircular;
  window['renderMetricasInteraccion'] = renderMetricasInteraccion;
  window['renderTodoAdmin'] = renderTodoAdmin;
  window['renderResumenAdmin'] = renderResumenAdmin;
  window['renderListaUsuarios'] = renderListaUsuarios;
  window['agregarUsuario'] = agregarUsuario;
  window['eliminarUsuario'] = eliminarUsuario;
  window['cambiarClave'] = cambiarClave;
  window['fijarRelojSimulado'] = fijarRelojSimulado;
  window['limpiarRelojSimulado'] = limpiarRelojSimulado;
  window['seleccionarTipoCuenta'] = seleccionarTipoCuenta;
  window['seleccionarTipoRegistro'] = seleccionarTipoRegistro;
  window['agregarCuentaProductor'] = agregarCuentaProductor;
  window['mostrarPanelCompartirCuenta'] = mostrarPanelCompartirCuenta;
  window['compartirCuentaPorWhatsApp'] = compartirCuentaPorWhatsApp;
  window['eliminarCuentaProductor'] = eliminarCuentaProductor;
  window['ajustarVigenciaCuenta'] = ajustarVigenciaCuenta;
  window['sincronizarSuscripcionSiEsCuentaActiva'] = sincronizarSuscripcionSiEsCuentaActiva;
  window['establecerFechaVencimientoCuenta'] = establecerFechaVencimientoCuenta;
  window['renovarCuenta365'] = renovarCuenta365;
  window['marcarCuentaVencidaAhora'] = marcarCuentaVencidaAhora;
  window['usarCuentaParaPruebas'] = usarCuentaParaPruebas;
  window['enlaceWhatsApp'] = enlaceWhatsApp;
  window['contarNuevasCuentas'] = contarNuevasCuentas;
  window['renderMetricasCuentas'] = renderMetricasCuentas;
  window['renderProximosAVencer'] = renderProximosAVencer;
  window['renderListadoCuentas'] = renderListadoCuentas;
  window['renderCuentas'] = renderCuentas;
  window['renderInfoSistema'] = renderInfoSistema;
  window['renderAuditoriaTransferencias'] = renderAuditoriaTransferencias;
  window['guardarProductor'] = guardarProductor;
  window['llenarSelectorEstados'] = llenarSelectorEstados;
  window['cargarMunicipiosSelector'] = cargarMunicipiosSelector;
  window['mostrarMunicipioManual'] = mostrarMunicipioManual;
  window['leerMunicipioSeleccionado'] = leerMunicipioSeleccionado;
  window['previsualizarNombreCompleto'] = previsualizarNombreCompleto;
  window['registrarUbicacionUPP'] = registrarUbicacionUPP;
})();
