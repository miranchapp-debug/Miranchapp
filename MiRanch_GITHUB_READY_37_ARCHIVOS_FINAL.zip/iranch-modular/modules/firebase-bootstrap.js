  // ================= CONEXIÓN A FIREBASE / FIRESTORE (MiRanch) =================
  // Arquitectura: un documento GLOBAL (config, boletines, índice liviano de cuentas)
  // + un documento POR CUENTA (colección "miranchapp_cuentas") con los datos pesados
  // de cada rancho (hato, salud, tareas, potreros, etc.). Así cada dispositivo solo
  // descarga lo global + los datos de la cuenta con la que inició sesión, no los de
  // todos los demás productores.
  import { initializeApp } from "https://www.gstatic.com/firebasejs/12.17.1/firebase-app.js";
  import {
    getAuth, GoogleAuthProvider, FacebookAuthProvider, signInWithRedirect, getRedirectResult, signOut, onAuthStateChanged
  } from "https://www.gstatic.com/firebasejs/12.17.1/firebase-auth.js";
  import {
    getFirestore, doc, setDoc, getDoc, updateDoc, onSnapshot, collection, query, where, orderBy, limit, getDocs, increment, deleteField, runTransaction
  } from "https://www.gstatic.com/firebasejs/12.17.1/firebase-firestore.js";
  import {
    getStorage, ref as refStorage, uploadString, uploadBytes, getDownloadURL
  } from "https://www.gstatic.com/firebasejs/12.17.1/firebase-storage.js";

  const firebaseConfig = {
    apiKey: "AIzaSyCBt2t5rfWUSNXRfe2H_8EE4hctkJZ3Cec",
    authDomain: "miranchapp-84b03.firebaseapp.com",
    projectId: "miranchapp-84b03",
    storageBucket: "miranchapp-84b03.firebasestorage.app",
    messagingSenderId: "778549608333",
    appId: "1:778549608333:web:fb630f12a1ee300e6f07c4",
    measurementId: "G-SD2L2JKN5V"
  };

  const app = initializeApp(firebaseConfig);
  // Todo el arranque de Firebase (Firestore + Auth + Storage) va dentro de un
  // try/catch general: si cualquier cosa aquí falla (config equivocada, origen no
  // autorizado en Firebase Console, sin conexión, Storage no habilitado, etc.),
  // la app NUNCA debe quedarse esperando indefinidamente algo que nunca va a
  // llegar — en el peor de los casos sigue funcionando en modo local (localStorage)
  // y el login sigue pudiendo validar contra lo que ya haya guardado en este
  // dispositivo, en vez de dejar el botón girando para siempre.
  try {
  const db = getFirestore(app);
  const auth = getAuth(app);
  // Storage se inicializa aparte y con su propio try/catch: si el proyecto de
  // Firebase todavía no tiene Storage habilitado/configurado en la consola, esto
  // podía lanzar un error que interrumpía TODO lo que sigue en este script —
  // incluido lo que deja lista la conexión a Firestore (login, cuentas, etc.) —
  // dejando la app entera sin poder validar contraseñas aunque el problema real
  // fuera solo de Storage. Ahora un fallo aquí solo desactiva la subida de fotos
  // a Storage (se sigue guardando la imagen comprimida localmente como respaldo)
  // y no bloquea nada más.
  let storage = null;
  try { storage = getStorage(app); }
  catch(e){ console.error('No se pudo inicializar Firebase Storage (¿está habilitado en Firebase Console > Storage?). La app sigue funcionando normal, solo las fotos no se subirán a Storage:', e); }
  const refGlobal = doc(db, "miranchapp", "estadoGlobal");
  const refCuenta = (cuentaId) => doc(db, "miranchapp_cuentas", cuentaId);
  const refCuentaMeta = (cuentaId) => doc(db, 'miranchapp_cuenta_meta', cuentaId);
  // Contadores locales de diagnóstico. No escriben telemetría en Firestore y no son una factura:
  // sirven para comparar versiones y detectar listeners/lecturas inesperadas durante QA.
  const firebaseStats = { reads: 0, writes: 0, listenerStarts: 0, listenerDocs: 0, lastReset: new Date().toISOString() };
  const contarLectura = (n=1) => { firebaseStats.reads += Number(n)||0; };
  const contarEscritura = (n=1) => { firebaseStats.writes += Number(n)||0; };
  const contarListener = () => { firebaseStats.listenerStarts++; };
  const contarListenerDocs = (n=1) => { firebaseStats.listenerDocs += Number(n)||0; };
  window.iRanchDiagnosticoFirebase = function(reset=false){
    if (reset){ firebaseStats.reads=0; firebaseStats.writes=0; firebaseStats.listenerStarts=0; firebaseStats.listenerDocs=0; firebaseStats.lastReset=new Date().toISOString(); }
    return { ...firebaseStats, nota:'Contadores locales de operaciones iniciadas/recibidas por MiRanch; no sustituyen la consola de uso de Firebase.' };
  };
  window.firebaseLeerMetaCuenta = async function(cuentaId){
    if (!cuentaId) return null;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return null;
      const snap = await getDoc(refCuentaMeta(cuentaId));
      contarLectura();
      return snap.exists() ? (snap.data() || {}) : null;
    } catch(e){ console.warn('No se pudo leer la metadata modular de la cuenta:', e); return null; }
  };
  window.firebaseGuardarMetaCuenta = async function(cuentaId, meta){
    if (!cuentaId) return false;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return false;
      contarEscritura();
      await setDoc(refCuentaMeta(cuentaId), { cuentaId, ...(meta || {}), actualizado: new Date().toISOString() }, { merge:true });
      return true;
    } catch(e){ console.warn('No se pudo guardar la metadata modular de la cuenta:', e); return false; }
  };
  window.firebaseEliminarDominiosLegacy = async function(cuentaId, dominios){
    if (!cuentaId || !Array.isArray(dominios) || !dominios.length) return false;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return false;
      const cambios = {};
      dominios.forEach(d => { cambios[d] = deleteField(); });
      contarEscritura();
      await updateDoc(refCuenta(cuentaId), cambios);
      return true;
    } catch(e){ console.warn('No se pudieron retirar los dominios migrados del documento legado:', e); return false; }
  };

  // Autenticación federada real. Google/Facebook identifican a la persona; el perfil,
  // teléfono y organizaciones de MiRanch se resuelven después en la capa de identidad.
  // Si la persona todavía no inicia sesión, Firebase queda sin usuario y MiRanch puede
  // seguir mostrando la interfaz local; las operaciones de nube requieren sesión real.
  let usuarioAutenticado = null;
  let resolverAuthInicial = null;
  const listoAuth = new Promise((resolve) => { resolverAuthInicial = resolve; });
  const proveedorGoogle = new GoogleAuthProvider();
  proveedorGoogle.setCustomParameters({ prompt: 'select_account' });
  const proveedorFacebook = new FacebookAuthProvider();

  window.firebaseIniciarSesionGoogle = async function(){
    try { await signInWithRedirect(auth, proveedorGoogle); return true; }
    catch(e){ window.dispatchEvent(new CustomEvent('miranch:auth-error',{detail:e})); return false; }
  };
  window.firebaseIniciarSesionFacebook = async function(){
    try { await signInWithRedirect(auth, proveedorFacebook); return true; }
    catch(e){ window.dispatchEvent(new CustomEvent('miranch:auth-error',{detail:e})); return false; }
  };
  window.firebaseCerrarSesionFederada = async function(){
    try { await signOut(auth); return true; }
    catch(e){ console.warn('No se pudo cerrar la sesión de Firebase:', e); return false; }
  };
  window.firebaseObtenerUsuarioActual = function(){ return usuarioAutenticado; };
  onAuthStateChanged(auth, (user) => {
    usuarioAutenticado = user || null;
    if (resolverAuthInicial){ resolverAuthInicial(usuarioAutenticado); resolverAuthInicial = null; }
    window.dispatchEvent(new CustomEvent('miranch:auth-state',{detail:user || null}));
  });
  getRedirectResult(auth).then(() => {
    // onAuthStateChanged es la única fuente del evento de sesión; así evitamos
    // procesar dos veces el mismo retorno de Google/Facebook.
  }).catch((e) => {
    console.warn('Resultado de autenticación federada no disponible:', e);
    window.dispatchEvent(new CustomEvent('miranch:auth-error',{detail:e}));
  });

  window.firebaseLeerGlobal = async function(){
    try {
      await listoAuth;
      if (!usuarioAutenticado) return null;
      const snap = await getDoc(refGlobal);
      contarLectura();
      if (!snap.exists()) return null;
      const contenido = snap.data();
      return { datos: JSON.parse(contenido.datos || '{}'), actualizado: contenido.actualizado || null };
    } catch(e){
      console.warn('No se pudo leer el estado global de Firestore:', e);
      return null;
    }
  };

  window.firebaseGuardarGlobal = async function(datos){
    try {
      await listoAuth;
      if (!usuarioAutenticado) return false;
      contarEscritura();
      await setDoc(refGlobal, { datos: JSON.stringify(datos), actualizado: new Date().toISOString() });
      return true;
    } catch(e){
      console.warn('No se pudo guardar el estado global en Firestore (puede que no haya conexión):', e);
      return false;
    }
  };

  window.firebaseGuardarCuenta = async function(cuentaId, datos){
    if (!cuentaId) return false;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return false;
      contarEscritura();
      await setDoc(refCuenta(cuentaId), { datos: JSON.stringify(datos), actualizado: new Date().toISOString() });
      return true;
    } catch(e){
      console.warn('No se pudo guardar los datos de la cuenta en Firestore:', e);
      return false;
    }
  };


  // Almacenamiento modular preparado: cada dominio de alto crecimiento puede
  // vivir en un documento independiente. NO se activa por defecto hasta que
  // las reglas de Firestore del proyecto contemplen la colección nueva.
  const refCuentaDominio = (cuentaId, dominio) => doc(db, 'miranchapp_cuenta_dominios', `${cuentaId}__${dominio}`);
  window.firebaseGuardarDominioCuenta = async function(cuentaId, dominio, datos){
    if (!cuentaId || !dominio) return false;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return false;
      contarEscritura();
      await setDoc(refCuentaDominio(cuentaId, dominio), {
        cuentaId,
        dominio,
        datos: JSON.stringify(datos ?? []),
        actualizado: new Date().toISOString()
      });
      return true;
    } catch(e){
      console.warn(`No se pudo guardar el dominio ${dominio} de la cuenta en Firestore:`, e);
      return false;
    }
  };
  window.firebaseLeerDominioCuenta = async function(cuentaId, dominio){
    if (!cuentaId || !dominio) return null;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return null;
      const snap = await getDoc(refCuentaDominio(cuentaId, dominio));
      contarLectura();
      if (!snap.exists()) return null;
      const contenido = snap.data();
      return { datos: JSON.parse(contenido.datos || '[]'), actualizado: contenido.actualizado || null };
    } catch(e){
      console.warn(`No se pudo leer el dominio ${dominio} de la cuenta en Firestore:`, e);
      return null;
    }
  };
  window.firebaseMigrarDominiosCuenta = async function(cuentaId, cuenta){
    if (!cuentaId || !cuenta) return false;
    const dominios = dominiosCrecimientoParaCuenta(cuenta);
    for (const dominio of dominios){
      const claveEstado = MAPA_CLAVE_ESTADO[dominio] || dominio;
      const datos = cuenta[dominio] ?? estado[claveEstado] ?? [];
      const ok = await window.firebaseGuardarDominioCuenta(cuentaId, dominio, datos);
      if (!ok) return false;
    }
    actualizarMetadatosStorageLocal(cuentaId, { migracionDominios: true, dominios: construirIndiceDominiosCuenta(cuenta) });
    return true;
  };

  window.firebaseLeerCuenta = async function(cuentaId){
    if (!cuentaId) return null;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return null;
      const snap = await getDoc(refCuenta(cuentaId));
      contarLectura();
      if (!snap.exists()) return null;
      const contenido = snap.data();
      const datos = JSON.parse(contenido.datos || '{}');
      if (contenido.resumenMensajes && typeof contenido.resumenMensajes === 'object') datos.resumenMensajes = contenido.resumenMensajes;
      return datos;
    } catch(e){
      console.warn('No se pudo leer los datos de la cuenta en Firestore:', e);
      return null;
    }
  };

  // Documento aparte para la "cola de administración" (solicitudes de
  // registro/pago/transferencias, avisos TB) — SOLO lo escuchan en vivo las
  // cuentas de administración (dueño, veterinario, comité, etc.), no los 300+
  // productores. Un productor normal no necesita enterarse al instante de
  // cada solicitud que manda cualquier otro — así se evita que cada celular
  // conectado reciba un aviso de Firestore por algo que no le corresponde.
  const refColaAdmin = doc(db, "miranchapp", "colaAdministracion");
  window.firebaseGuardarColaAdmin = async function(datos){
    try {
      await listoAuth;
      if (!usuarioAutenticado) return false;
      const copia = { ...(datos || {}) };
      const resumenMensajes = copia.resumenMensajes && typeof copia.resumenMensajes === 'object' ? copia.resumenMensajes : {};
      delete copia.resumenMensajes;
      contarEscritura();
      await setDoc(refColaAdmin, {
        datos: JSON.stringify(copia),
        resumenMensajes,
        actualizado: new Date().toISOString()
      });
      return true;
    } catch(e){
      console.warn('No se pudo guardar la cola de administración en Firestore:', e);
      return false;
    }
  };
  window.firebaseEscucharColaAdmin = function(callback){
    let cancelar = () => {};
    let cancelado = false;
    listoAuth.then(() => {
      if (cancelado || !usuarioAutenticado) return;
      contarListener();
      cancelar = onSnapshot(refColaAdmin, (snap) => {
        if (!snap.exists()) return;
        try {
          const contenido = snap.data();
          contarListenerDocs();
          const datos = JSON.parse(contenido.datos || '{}');
          if (contenido.resumenMensajes && typeof contenido.resumenMensajes === 'object') datos.resumenMensajes = contenido.resumenMensajes;
          callback(datos, contenido.actualizado);
        } catch(e){ console.warn('Error leyendo la cola de administración en tiempo real', e); }
      }, (err) => console.warn('Error de escucha de la cola de administración en Firestore', err));
    });
    return () => { cancelado = true; try { cancelar(); } catch(e) {} };
  };
  // Para cuentas de productor: una lectura SUELTA (no una escucha permanente)
  // — se usa para revisar, cuando a la persona le interese (ej. al abrir "Mi
  // suscripción"), si ya le resolvieron algo que ella misma mandó. No se
  // queda "apuntada" a recibir cada cambio de ahí en adelante.
  window.firebaseActualizarResumenChat = async function(cuentaId, entrada){
    if (!cuentaId || !entrada || typeof entrada !== 'object') return false;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return false;
      contarEscritura();
      await updateDoc(refColaAdmin, {
        [`resumenMensajes.${cuentaId}`]: entrada,
        actualizado: new Date().toISOString()
      });
      return true;
    } catch(e){
      console.warn('No se pudo actualizar el resumen del chat directamente en Firestore:', e);
      return false;
    }
  };
  window.firebaseLeerColaAdmin = async function(){
    try {
      await listoAuth;
      if (!usuarioAutenticado) return null;
      const snap = await getDoc(refColaAdmin);
      contarLectura();
      if (!snap.exists()) return null;
      return JSON.parse(snap.data().datos);
    } catch(e){
      console.warn('No se pudo leer la cola de administración en Firestore:', e);
      return null;
    }
  };

  // Sube adjuntos del chat a Storage y deja Firestore con un enlace pequeño.
  // Esto evita que una foto, PDF o nota de voz convierta el documento del chat
  // en un documento gigante y mantiene el historial muy por debajo del límite.
  window.firebaseSubirAdjuntoChat = async function(cuentaId, mensajeId, dataUrl, nombre){
    if (!cuentaId || !mensajeId || !dataUrl || !storage || !String(dataUrl).startsWith('data:')) return null;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return null;
      const ext = (String(nombre || '').split('.').pop() || 'bin').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8) || 'bin';
      const ruta = `chat/${cuentaId}/${mensajeId}.${ext}`;
      const referencia = refStorage(storage, ruta);
      await uploadString(referencia, dataUrl, 'data_url');
      return await getDownloadURL(referencia);
    } catch(e){
      console.warn('No se pudo subir el adjunto del chat a Storage; se conserva respaldo local:', e);
      return null;
    }
  };

  // ================= CHAT v2: MENSAJES INDEPENDIENTES =================
  // La versión anterior guardaba TODO el historial en un solo documento. Eso
  // hacía que cada mensaje reescribiera la conversación completa y que el
  // documento creciera sin parar. Chat v2 conserva la compatibilidad con el
  // documento legado, pero los mensajes nuevos viven como documentos
  // independientes: 1 escritura por mensaje, sin reescribir todo el hilo.
  // La bandeja sigue usando el resumen liviano, y solo la conversación abierta
  // mantiene una escucha en tiempo real.
  const refMensajesLegacy = (cuentaId) => doc(db, "miranchapp_mensajes", cuentaId);
  const refChatMeta = (cuentaId) => doc(db, "miranchapp_chat_meta", cuentaId);
  const refChatColeccion = (cuentaId) => collection(db, 'miranchapp_chat_mensajes', cuentaId, 'mensajes');
  const refChatMensaje = (cuentaId, mensajeId) => doc(refChatColeccion(cuentaId), String(mensajeId).replace(/[^a-zA-Z0-9_-]/g,'_'));
  const CHAT_V2_LIMITE_EN_VIVO = 80;
  const chatsMigradosSesion = new Set();

  async function asegurarChatV2(cuentaId){
    if (!cuentaId || chatsMigradosSesion.has(cuentaId)) return true;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return false;
      const metaSnap = await getDoc(refChatMeta(cuentaId));
      if (metaSnap.exists() && metaSnap.data().version === 2){
        chatsMigradosSesion.add(cuentaId);
        return true;
      }
      // Migración no destructiva: el historial viejo se lee una sola vez y
      // cada mensaje se convierte en un documento independiente.
      const legacy = await getDoc(refMensajesLegacy(cuentaId));
      const hiloViejo = legacy.exists() ? (() => { try { return JSON.parse(legacy.data().datos || '[]'); } catch(e){ return []; } })() : [];
      if (Array.isArray(hiloViejo) && hiloViejo.length){
        for (const m of hiloViejo){
          if (!m || !m.id) continue;
          await setDoc(refChatMensaje(cuentaId, m.id), { ...m, cuentaId, ts: m.ts || `${m.fecha || ''}T${m.hora || '00:00'}:00`, version: 2 });
        }
      }
      const ultimo = Array.isArray(hiloViejo) && hiloViejo.length ? hiloViejo[hiloViejo.length-1] : null;
      contarEscritura();
          await setDoc(refChatMeta(cuentaId), {
        cuentaId, version: 2, migrado: true,
        ultimoTs: ultimo ? (ultimo.ts || `${ultimo.fecha || ''}T${ultimo.hora || '00:00'}:00`) : null,
        actualizado: new Date().toISOString()
      }, { merge: true });
      chatsMigradosSesion.add(cuentaId);
      return true;
    } catch(e){
      // Si las reglas actuales todavía no permiten las colecciones nuevas,
      // devolvemos false y el sistema conserva el almacenamiento legado.
      console.warn('Chat v2 no disponible; se conserva compatibilidad con chat legado:', e);
      return false;
    }
  }

  window.firebaseGuardarMensajes = async function(cuentaId, hilo){
    if (!cuentaId || !Array.isArray(hilo) || !hilo.length) return false;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return false;
      const listoV2 = await asegurarChatV2(cuentaId);
      const ultimo = hilo[hilo.length - 1];
      if (ultimo && ultimo.id){
        const ts = ultimo.ts || `${ultimo.fecha || ''}T${ultimo.hora || '00:00'}:00`;
        let remoto = { ...ultimo, cuentaId, ts, version: 2 };
        if (remoto.archivoDatos && String(remoto.archivoDatos).startsWith('data:')){
          const url = await window.firebaseSubirAdjuntoChat(cuentaId, ultimo.id, remoto.archivoDatos, remoto.archivoNombre);
          if (url){ remoto.archivoDatos = url; remoto.archivoUrl = url; remoto.archivoLocal = true; }
        }
        if (listoV2){
          contarEscritura();
          await setDoc(refChatMensaje(cuentaId, ultimo.id), remoto, { merge: true });
          // Meta liviana: permite mostrar el badge sin descargar el historial.
          // El contador es independiente para cada lado de la conversación.
          const campoNoLeidos = ultimo.de === 'productor' ? 'noLeidosAdmin' : 'noLeidosProductor';
          contarEscritura();
          await setDoc(refChatMeta(cuentaId), {
            cuentaId, version: 2, ultimoMensajeId: ultimo.id, ultimoTs: ts, ultimoDe: ultimo.de || null,
            [campoNoLeidos]: increment(1), actualizado: new Date().toISOString()
          }, { merge: true });
          return true;
        }
        // Fallback seguro mientras las reglas de Firebase no contemplen Chat v2.
        const hiloRemoto = hilo.map(m => {
          if (m && m.id === ultimo.id && remoto.archivoDatos !== ultimo.archivoDatos) return { ...m, archivoDatos: remoto.archivoDatos, archivoUrl: remoto.archivoUrl };
          return m;
        });
        await setDoc(refMensajesLegacy(cuentaId), { datos: JSON.stringify(hiloRemoto), actualizado: new Date().toISOString() });
      }
      return true;
    } catch(e){
      console.warn('No se pudo guardar la conversación en Firestore:', e);
      return false;
    }
  };

  window.firebaseEscucharMensajes = function(cuentaId, callback){
    if (!cuentaId) return () => {};
    let cancelar = () => {};
    let cancelado = false;
    listoAuth.then(async () => {
      if (cancelado || !usuarioAutenticado) return;
      const listoV2 = await asegurarChatV2(cuentaId);
      if (cancelado) return;
      if (!listoV2){
        contarListener();
        cancelar = onSnapshot(refMensajesLegacy(cuentaId), (snap) => {
          if (!snap.exists()) return;
          try { const contenido = snap.data(); callback(JSON.parse(contenido.datos || '[]'), contenido.actualizado, null); }
          catch(e){ console.warn('Error leyendo la conversación en tiempo real', e); }
        }, (err) => console.warn('Error de escucha del chat legado', err));
        return;
      }
      let ultimoHilo = [];
      let ultimaMeta = null;
      const emitir = () => callback(ultimoHilo, new Date().toISOString(), ultimaMeta);
      const q = query(refChatColeccion(cuentaId), orderBy('ts','desc'), limit(CHAT_V2_LIMITE_EN_VIVO));
      contarListener();
      const cancelarMensajes = onSnapshot(q, (snap) => {
        try {
          ultimoHilo = snap.docs.map(d => d.data()).sort((a,b) => String(a.ts||'').localeCompare(String(b.ts||'')));
          emitir();
        } catch(e){ console.warn('Error leyendo la conversación Chat v2 en Firestore', e); }
      }, (err) => console.warn('Error de escucha del chat v2 en Firestore', err));
      contarListener();
      const cancelarMeta = onSnapshot(refChatMeta(cuentaId), (snap) => {
        ultimaMeta = snap.exists() ? snap.data() : null;
        emitir();
      }, (err) => console.warn('Error leyendo estado del chat en Firestore', err));
      cancelar = () => { cancelarMensajes(); cancelarMeta(); };
    }).catch(e => console.warn('No se pudo activar Chat v2:', e));
    return () => { cancelado = true; cancelar(); };
  };

  // Listener ultraligero para el badge: solo escucha un documento de meta.
  // El historial de hasta 80 mensajes se abre únicamente cuando la conversación
  // está realmente visible. Esto evita que cada productor conectado pague
  // decenas de lecturas solo por mantener un contador de mensajes.
  window.firebaseEscucharChatMeta = function(cuentaId, callback){
    if (!cuentaId || typeof callback !== 'function') return () => {};
    let cancelar = () => {};
    let cancelado = false;
    let respaldoLegadoConsultado = false;
    listoAuth.then(async () => {
      if (cancelado || !usuarioAutenticado) return;
      // El badge NO migra el chat. Si ya existe v2 escucha únicamente el
      // documento meta; si aún no existe, hace una lectura única del legado
      // para calcular el badge y deja la migración para cuando la conversación
      // se abra de verdad. Esto evita cientos de escrituras ocultas al iniciar sesión.
      contarListener();
      cancelar = onSnapshot(refChatMeta(cuentaId), async (snap) => {
        contarListenerDocs();
        const meta = snap.exists() ? (snap.data() || {}) : null;
        callback(meta);
        if (respaldoLegadoConsultado || (meta && meta.version === 2)) return;
        respaldoLegadoConsultado = true;
        try {
          const legacy = await getDoc(refMensajesLegacy(cuentaId));
          contarLectura();
          if (cancelado || !legacy.exists()) return;
          const hilo = JSON.parse(legacy.data().datos || '[]');
          const ultimo = hilo.length ? hilo[hilo.length - 1] : null;
          callback({ version:1, ultimoTs:ultimo?.ts || null, ultimoDe:ultimo?.de || null,
            noLeidosProductor:hilo.filter(m => m.de !== 'productor' && !m.leido).length,
            noLeidosAdmin:hilo.filter(m => m.de === 'productor' && !m.leido).length });
        } catch(e){ console.warn('No se pudo calcular el badge del chat legado:', e); }
      }, (err) => console.warn('Error leyendo meta del chat en Firestore', err));
    }).catch(e => console.warn('No se pudo activar el resumen del chat:', e));
    return () => { cancelado = true; try { cancelar(); } catch(e) {} };
  };

  window.firebaseLeerMensajes = async function(cuentaId){
    if (!cuentaId) return null;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return null;
      const listoV2 = await asegurarChatV2(cuentaId);
      if (listoV2){
        const q = query(refChatColeccion(cuentaId), orderBy('ts','desc'), limit(CHAT_V2_LIMITE_EN_VIVO));
        const snap = await getDocs(q);
        contarLectura(snap.size);
        return snap.docs.map(d => d.data()).sort((a,b)=>String(a.ts||'').localeCompare(String(b.ts||'')));
      }
      const snap = await getDoc(refMensajesLegacy(cuentaId));
      if (!snap.exists()) return null;
      return JSON.parse(snap.data().datos || '[]');
    } catch(e){
      console.warn('No se pudo leer la conversación en Firestore:', e);
      return null;
    }
  };
  window.firebaseMarcarChatLeido = async function(cuentaId, rol, ts){
    if (!cuentaId || !ts) return false;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return false;
      const campo = rol === 'productor' ? 'ultimoLeidoProductor' : 'ultimoLeidoAdmin';
      const campoNoLeidos = rol === 'productor' ? 'noLeidosProductor' : 'noLeidosAdmin';
      contarEscritura();
          await setDoc(refChatMeta(cuentaId), { cuentaId, version: 2, [campo]: ts, [campoNoLeidos]: 0, actualizado: new Date().toISOString() }, { merge: true });
      return true;
    } catch(e){
      console.warn('No se pudo actualizar la lectura del chat:', e);
      return false;
    }
  };



  // ================= BANDEJAS DE FLUJOS ENTRE ROLES =================
  // Los flujos que cruzan cuentas no se guardan en el documento privado de un
  // productor. Cada destinatario dispone de una bandeja propia y cada solicitud,
  // aviso o informe es un documento independiente para entrega en tiempo real.
  const refBandejaFlujos = destinatario => collection(db, 'miranchapp_flujos', String(destinatario || 'general'), 'items');
  const refFlujo = (destinatario, flujoId) => doc(refBandejaFlujos(destinatario), String(flujoId));
  window.firebaseEnviarFlujo = async function(destinatario, flujoId, tipo, payload, extra={}){
    if (!destinatario || !flujoId || !tipo) return false;
    // Construimos el sobre antes de cualquier await para que el contenido no
    // cambie a mitad de una operación si la interfaz modifica el mismo objeto
    // mientras Firebase espera la autenticación.
    const documentoFlujo = {
      id:String(flujoId), tipo, destinatario:String(destinatario),
      payload: payload == null ? {} : JSON.parse(JSON.stringify(payload)),
      estatus: extra.estatus || 'pendiente',
      enviadoPor: extra.enviadoPor || null,
      actualizado: new Date().toISOString(),
      ...extra
    };
    try {
      await listoAuth; if (!usuarioAutenticado) return false;
      contarEscritura();
      await setDoc(refFlujo(destinatario, flujoId), documentoFlujo, {merge:true});
      return true;
    } catch(e){ console.warn(`No se pudo enviar el flujo ${tipo}:`, e); return false; }
  };
  window.firebaseActualizarFlujo = async function(destinatario, flujoId, cambios={}){
    if (!destinatario || !flujoId) return false;
    try { await listoAuth; if (!usuarioAutenticado) return false; contarEscritura(); await updateDoc(refFlujo(destinatario, flujoId), {...cambios, actualizado:new Date().toISOString()}); return true; }
    catch(e){ console.warn(`No se pudo actualizar el flujo ${flujoId}:`,e); return false; }
  };
  window.firebaseEscucharBandejaFlujos = function(destinatario, callback){
    if (!destinatario || typeof callback !== 'function') return ()=>{};
    let cancelar=()=>{}, activo=true;
    listoAuth.then(()=>{
      if(!activo || !usuarioAutenticado) return;
      contarListener();
      // Las bandejas son de trabajo reciente; limitar la consulta evita que un
      // comité con años de expedientes vuelva a descargar todo su histórico cada
      // vez que abre sesión. El histórico ya queda conservado en el estado local
      // y los documentos antiguos siguen en Firestore para consultas explícitas.
      const consultaBandeja=query(refBandejaFlujos(destinatario), orderBy('actualizado','desc'), limit(100));
      cancelar=onSnapshot(consultaBandeja, snap=>{ contarListenerDocs(snap.size); callback(snap.docs.map(d=>d.data()).sort((a,b)=>String(a.actualizado||'').localeCompare(String(b.actualizado||'')))); }, err=>console.warn(`Error escuchando bandeja ${destinatario}:`,err));
    });
    return ()=>{activo=false; try{cancelar();}catch(e){}};
  };

  // Documento de ARCHIVO HISTÓRICO por cuenta (colección "miranchapp_archivo")
  // — aquí se mueven los registros viejos de producción de leche, salud,
  // pesajes y movimientos (los que más rápido crecen con el tiempo) para que
  // el documento principal de la cuenta nunca se acerque al límite de 1 MB de
  // Firestore. Casi nadie lo consulta día a día, así que casi no genera
  // tráfico — solo se lee cuando alguien pide ver el historial completo.
  const refArchivo = (cuentaId) => doc(db, "miranchapp_archivo", cuentaId);
  window.firebaseGuardarArchivo = async function(cuentaId, datosArchivo){
    if (!cuentaId) return false;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return false;
      await setDoc(refArchivo(cuentaId), { datos: JSON.stringify(datosArchivo), actualizado: new Date().toISOString() });
      return true;
    } catch(e){
      console.warn('No se pudo guardar el archivo histórico en Firestore:', e);
      return false;
    }
  };
  window.firebaseLeerArchivo = async function(cuentaId){
    if (!cuentaId) return null;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return null;
      const snap = await getDoc(refArchivo(cuentaId));
      if (!snap.exists()) return null;
      return JSON.parse(snap.data().datos);
    } catch(e){
      console.warn('No se pudo leer el archivo histórico en Firestore:', e);
      return null;
    }
  };


  // Archivo histórico por bloques: a diferencia del archivo legado (un solo
  // documento por cuenta), cada mes/categoría se guarda en su propio bloque.
  // Así el historial puede crecer durante años sin volver a chocar con el
  // límite de tamaño de un único documento y el productor NO tiene que
  // descargar archivos para que la aplicación siga funcionando.
  const refArchivoBloque = (cuentaId, campo, periodo) => doc(db, 'miranchapp_archivo_bloques', `${cuentaId}__${campo}__${periodo}`);
  const refArchivoIndice = cuentaId => doc(db, 'miranchapp_archivo_indices', cuentaId);
  window.firebaseGuardarArchivoBloque = async function(cuentaId, campo, periodo, registros){
    if (!cuentaId || !campo || !periodo) return false;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return false;
      await setDoc(refArchivoBloque(cuentaId, campo, periodo), {
        cuentaId, campo, periodo,
        datos: JSON.stringify(registros || []),
        actualizado: new Date().toISOString()
      });
      return true;
    } catch(e){
      console.warn(`No se pudo guardar el bloque histórico ${campo}/${periodo}:`, e);
      return false;
    }
  };
  window.firebaseLeerArchivoBloque = async function(cuentaId, campo, periodo){
    if (!cuentaId || !campo || !periodo) return null;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return null;
      const snap = await getDoc(refArchivoBloque(cuentaId, campo, periodo));
      if (!snap.exists()) return null;
      const contenido = snap.data();
      return JSON.parse(contenido.datos || '[]');
    } catch(e){
      console.warn(`No se pudo leer el bloque histórico ${campo}/${periodo}:`, e);
      return null;
    }
  };
  window.firebaseLeerIndiceArchivo = async function(cuentaId){
    if (!cuentaId) return null;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return null;
      const snap = await getDoc(refArchivoIndice(cuentaId));
      return snap.exists() ? (snap.data() || {}) : null;
    } catch(e){ console.warn('No se pudo leer el índice del archivo histórico:', e); return null; }
  };
  window.firebaseGuardarIndiceArchivo = async function(cuentaId, indice){
    if (!cuentaId) return false;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return false;
      await setDoc(refArchivoIndice(cuentaId), { ...indice, actualizado: new Date().toISOString() });
      return true;
    } catch(e){ console.warn('No se pudo guardar el índice del archivo histórico:', e); return false; }
  };

  window.firebaseEscucharGlobal = function(callback){
    if (typeof callback !== 'function') return () => {};
    let cancelar = () => {};
    let cancelado = false;
    listoAuth.then(() => {
      if (cancelado || !usuarioAutenticado) return;
      contarListener();
      cancelar = onSnapshot(refGlobal, (snap) => {
        if (!snap.exists()) return;
        try {
          const contenido = snap.data();
          const datos = JSON.parse(contenido.datos);
          callback(datos, contenido.actualizado);
        } catch(e){ console.warn('Error leyendo datos globales en tiempo real de Firestore', e); }
      }, (err) => console.warn('Error de escucha global en Firestore', err));
    });
    return () => { cancelado = true; cancelar(); };
  };

  // Devuelve una función para cancelar la escucha (se usa al cambiar de cuenta activa,
  // para dejar de escuchar los datos de la cuenta anterior).
  window.firebaseEscucharCuenta = function(cuentaId, callback){
    if (!cuentaId) return () => {};
    let cancelar = () => {};
    let cancelado = false;
    listoAuth.then(() => {
      if (cancelado || !usuarioAutenticado) return;
      contarListener();
      cancelar = onSnapshot(refCuenta(cuentaId), (snap) => {
        if (!snap.exists()) return;
        try {
          const contenido = snap.data();
          const datos = JSON.parse(contenido.datos);
          callback(datos, contenido.actualizado);
        } catch(e){ console.warn('Error leyendo datos de la cuenta en tiempo real de Firestore', e); }
      }, (err) => console.warn('Error de escucha de cuenta en Firestore', err));
    });
    return () => { cancelado = true; try { cancelar(); } catch(e) {} };
  };

  // Escucha modular: solo se activa para la cuenta actualmente abierta y para
  // los dominios que ya fueron migrados. Así un cambio remoto en Producción,
  // Salud, Pesajes o Movimientos llega sin necesitar volver a descargar el
  // documento completo de la cuenta. Devuelve una sola función para cancelar
  // todas las escuchas y evitar fugas al cambiar de productor.
  window.firebaseEscucharDominiosCuenta = function(cuentaId, dominios, callback){
    if (!cuentaId || !Array.isArray(dominios) || !dominios.length) return () => {};
    const cancelaciones = [];
    let activo = true;
    listoAuth.then(() => {
      if (!activo || !usuarioAutenticado) return;
      dominios.forEach(dominio => {
        contarListener();
        const cancelar = onSnapshot(refCuentaDominio(cuentaId, dominio), (snap) => {
          if (!snap.exists()) return;
          try {
            const contenido = snap.data();
            const datos = JSON.parse(contenido.datos || '[]');
            callback(dominio, datos, contenido.actualizado || null);
          } catch(e){ console.warn(`Error leyendo el dominio ${dominio} en tiempo real`, e); }
        }, (err) => console.warn(`Error de escucha del dominio ${dominio} en Firestore`, err));
        cancelaciones.push(cancelar);
      });
    });
    return () => {
      activo = false;
      cancelaciones.splice(0).forEach(fn => { try { fn(); } catch(e) {} });
    };
  };

  // Sube una imagen comprimida (dataURL "data:image/jpeg;base64,...") a Firebase
  // Storage en la ruta indicada y regresa la downloadURL pública. Así Firestore
  // solo guarda el link (documento liviano) en vez de la imagen completa en base64.
  // Si no hay conexión o Storage no está habilitado, regresa null y quien llama
  // decide si se queda con la imagen en base64 como respaldo local.
  // ================= IDENTIDAD / ORGANIZACIONES / MEMBRESÍAS =================
  const refPersona = (personaId) => doc(db, 'miranchapp_personas', String(personaId));
  const refOrg = (orgId) => doc(db, 'miranchapp_organizaciones', String(orgId));
  const refMembresia = (orgId, uid) => doc(db, 'miranchapp_membresias', `${orgId}__${uid}`);
  const refInvitacionOrg = (orgId, invitacionId) => doc(db, 'miranchapp_invitaciones_org', `${orgId}__${invitacionId}`);
  const refRecepcionOrg = (orgId, recepcionId) => doc(db, 'miranchapp_organizacion_recepciones', `${orgId}__${recepcionId}`);
  const refIdentidadAuth = (uid) => doc(db, 'miranchapp_identidades_auth', String(uid));

  function exigirSesionFederada(){ return listoAuth.then(() => !!usuarioAutenticado); }
  function uidActual(){ return usuarioAutenticado?.uid || null; }

  window.firebaseBuscarIdentidadAuth = async function(){
    await listoAuth;
    if (!usuarioAutenticado) return null;
    try {
      const snap = await getDoc(refIdentidadAuth(usuarioAutenticado.uid)); contarLectura();
      return snap.exists() ? { id:snap.id, ...(snap.data()||{}) } : null;
    } catch(e){ console.warn('No se pudo buscar la identidad MiRanch:',e); return null; }
  };
  window.firebaseGuardarIdentidadAuth = async function(datos){
    if (!await exigirSesionFederada()) return false;
    const uid=uidActual(); if (!uid) return false;
    try { contarEscritura(); await setDoc(refIdentidadAuth(uid), { uid, ...(datos||{}), actualizado:new Date().toISOString() }, {merge:true}); return true; }
    catch(e){ console.warn('No se pudo guardar la identidad de autenticación:',e); return false; }
  };
  window.firebaseGuardarPersona = async function(personaId, datos){
    if (!personaId || !await exigirSesionFederada()) return false;
    try { contarEscritura(); await setDoc(refPersona(personaId), { id:personaId, ...(datos||{}), actualizado:new Date().toISOString() }, {merge:true}); return true; }
    catch(e){ console.warn('No se pudo guardar la persona MiRanch:',e); return false; }
  };
  window.firebaseBuscarPersonaPorTelefono = async function(telefonoNormalizado){
    if (!telefonoNormalizado || !await exigirSesionFederada()) return null;
    try {
      const tel=String(telefonoNormalizado).replace(/\D/g,'');
      const q=query(collection(db,'miranchapp_personas'), where('telefono','==',tel), limit(1));
      const snap=await getDocs(q); contarLectura(snap.size);
      const hit=snap.docs[0] || null;
      return hit ? {id:hit.id,...(hit.data()||{})} : null;
    } catch(e){ console.warn('No se pudo verificar el teléfono en MiRanch:',e); return null; }
  };
  window.firebaseGuardarOrganizacion = async function(orgId, datos){
    if (!orgId || !await exigirSesionFederada()) return false;
    try { contarEscritura(); await setDoc(refOrg(orgId), { id:orgId, ...(datos||{}), actualizado:new Date().toISOString() }, {merge:true}); return true; }
    catch(e){ console.warn('No se pudo guardar la organización MiRanch:',e); return false; }
  };
  window.firebaseLeerOrganizacion = async function(orgId){
    if (!orgId || !await exigirSesionFederada()) return null;
    try { const snap=await getDoc(refOrg(orgId)); contarLectura(); return snap.exists()?{id:snap.id,...(snap.data()||{})}:null; }
    catch(e){ console.warn('No se pudo leer la organización MiRanch:',e); return null; }
  };
  window.firebaseGuardarMembresia = async function(orgId, uid, datos){
    if (!orgId || !uid || !await exigirSesionFederada()) return false;
    try { contarEscritura(); await setDoc(refMembresia(orgId,uid), { orgId, uid, ...(datos||{}), actualizado:new Date().toISOString() }, {merge:true}); return true; }
    catch(e){ console.warn('No se pudo guardar la membresía de organización:',e); return false; }
  };
  window.firebaseLeerMembresiasOrganizacion = async function(orgId){
    if (!orgId || !await exigirSesionFederada()) return [];
    try { const q=query(collection(db,'miranchapp_membresias'), where('orgId','==',orgId), limit(200)); const snap=await getDocs(q); contarLectura(snap.size); return snap.docs.map(d=>({id:d.id,...(d.data()||{})})).filter(x=>x.orgId===orgId); }
    catch(e){ console.warn('No se pudieron leer las membresías:',e); return []; }
  };
  window.firebaseGuardarRecepcionOrganizacion = async function(orgId, recepcionId, datos){
    if (!orgId || !recepcionId || !await exigirSesionFederada()) return false;
    try { const mem=await getDoc(refMembresia(orgId,uidActual())); contarLectura(); if(!mem.exists() || !Array.isArray(mem.data()?.permisos) || !mem.data().permisos.includes('registrar_recepcion')) return false; contarEscritura(); await setDoc(refRecepcionOrg(orgId,recepcionId),{orgId,recepcionId,registradoPorUid:uidActual(),...(datos||{}),creadoEn:new Date().toISOString()},{merge:true}); return true; }
    catch(e){ console.warn('No se pudo guardar la recepción de leche de la organización:',e); return false; }
  };
  window.firebaseLeerRecepcionesOrganizacion = async function(orgId){
    if(!orgId || !await exigirSesionFederada()) return [];
    try { const q=query(collection(db,'miranchapp_organizacion_recepciones'),where('orgId','==',orgId),limit(100)); const snap=await getDocs(q); contarLectura(snap.size); return snap.docs.map(d=>({id:d.id,...(d.data()||{})})); }
    catch(e){ console.warn('No se pudieron leer las recepciones de la organización:',e); return []; }
  };
  window.firebaseCrearInvitacionOrganizacion = async function(orgId, invitacionId, datos){
    if (!orgId || !invitacionId || !await exigirSesionFederada()) return false;
    try { contarEscritura(); await setDoc(refInvitacionOrg(orgId,invitacionId), { orgId, invitacionId, ...(datos||{}), actualizado:new Date().toISOString() }, {merge:true}); return true; }
    catch(e){ console.warn('No se pudo crear la invitación de organización:',e); return false; }
  };
  window.firebaseLeerInvitacionOrganizacion = async function(orgId, invitacionId){
    if (!orgId || !invitacionId || !await exigirSesionFederada()) return null;
    try { const snap=await getDoc(refInvitacionOrg(orgId,invitacionId)); contarLectura(); return snap.exists()?{id:snap.id,...(snap.data()||{})}:null; }
    catch(e){ console.warn('No se pudo leer la invitación:',e); return null; }
  };
  window.firebaseAceptarInvitacionOrganizacion = async function(orgId, invitacionId, datos={}){
    if (!orgId || !invitacionId || !await exigirSesionFederada()) return false;
    const uid=uidActual();
    try {
      const refI=refInvitacionOrg(orgId,invitacionId); const inv=await getDoc(refI); contarLectura();
      if (!inv.exists()) return false; const d=inv.data()||{};
      if (d.activa===false || (d.expiraEn && Date.parse(d.expiraEn)<Date.now())) return false;
      const limite=Number(d.usoMaximo||3); const usos=Number(d.usos||0); if (usos>=limite) return false;
      contarEscritura();
      await setDoc(refMembresia(orgId,uid), {orgId,uid,rol:d.rolSugerido||'colaborador',permisos:Array.isArray(d.permisos)?d.permisos:[],estatus:'activo',aceptadoEn:new Date().toISOString(),...(datos||{})},{merge:true});
      await updateDoc(refI,{usos:increment(1),ultimoUsoEn:new Date().toISOString()});
      return true;
    } catch(e){ console.warn('No se pudo aceptar la invitación de organización:',e); return false; }
  };


  // Referidos: una activación directa cuenta una sola vez por persona. La recompensa
  // se mantiene en el ledger del invitador y nunca se calcula en el cliente como saldo.
  window.firebaseRegistrarActivacionReferido = async function(invitadorId, nuevoUid, datos={}){
    if(!invitadorId || !nuevoUid || String(invitadorId)===String(nuevoUid)) return false;
    try{
      await listoAuth; if(!usuarioAutenticado) return false;
      const refInv=doc(db,'miranchapp_referral_codes',String(invitadorId));
      const refAct=doc(db,'miranchapp_referrals',`${String(invitadorId)}__${String(nuevoUid)}`);
      const refLedger=doc(db,'miranchapp_referral_ledger',String(invitadorId));
      await runTransaction(db, async tx=>{
        const [invSnap,actSnap,ledSnap]=await Promise.all([tx.get(refInv),tx.get(refAct),tx.get(refLedger)]);
        if(actSnap.exists()) return;
        const inv=invSnap.exists()?invSnap.data():{}; const led=ledSnap.exists()?ledSnap.data():{};
        const directos=Math.max(0,Number(led.directos||0)); const recompensa=Math.max(0,Number(led.recompensaDias||0));
        const nuevoDirectos=directos+1; const bloques=Math.floor(nuevoDirectos/5); const prevBloques=Math.floor(directos/5); const diasOtorgados=Math.min(30,Math.max(0,(bloques-prevBloques)*5));
        tx.set(refAct,{invitadorId:String(invitadorId),nuevoUid:String(nuevoUid),nombre:String(datos.nombre||''),activadoEn:new Date().toISOString(),estatus:'verificado'},{merge:true});
        tx.set(refInv,{codigo:String(invitadorId),directos:nuevoDirectos,ultimaActivacion:new Date().toISOString()},{merge:true});
        tx.set(refLedger,{directos:nuevoDirectos,recompensaDias:Math.min(30,recompensa+diasOtorgados),maxRecompensaDias:30,ultimoBloque:nuevoDirectos>=5?Math.floor(nuevoDirectos/5):0,actualizadoEn:new Date().toISOString()},{merge:true});
      });
      return true;
    }catch(e){ console.warn('No se pudo registrar referido:',e); return false; }
  };

  window.firebaseSubirImagen = async function(ruta, dataUrl){
    if (!ruta || !dataUrl || !storage) return null;
    try {
      await listoAuth;
      if (!usuarioAutenticado) return null;
      const referencia = refStorage(storage, ruta);
      await uploadString(referencia, dataUrl, 'data_url');
      return await getDownloadURL(referencia);
    } catch(e){
      console.error('No se pudo subir la imagen a Firebase Storage (¿sin conexión o Storage no habilitado en Firebase Console?):', e);
      return null;
    }
  };
  } catch(errorArranqueFirebase){
    // Si algo en todo el bloque de arriba falló de forma inesperada (config
    // incorrecta, origen no autorizado, red bloqueada, etc.), se registra el
    // error exacto en consola y se libera igual la señal "firebase-listo" para
    // que el resto de la app (login incluido) deje de esperar y pase a modo
    // local en vez de quedarse colgada.
    console.error('Fallo general al inicializar Firebase — la app sigue en modo local (localStorage):', errorArranqueFirebase);
  }
  window.firebaseListo = true;
  window.dispatchEvent(new Event('firebase-listo'));

