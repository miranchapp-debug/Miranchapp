(function(){
// MiRanch — módulo extraído automáticamente. Se ejecuta como script clásico para conservar compatibilidad con funciones globales.
// ================= MENSAJES CON EL PRODUCTOR (hilos + boletín segmentado) =================
let hiloAbiertoCuentaId = null;
// Recuerda, por cada contenedor de chat, si la persona ya pidió ver el
// historial completo (en vez del límite de los últimos 200 mensajes) — así
// no se vuelve a esconder solo si llega un mensaje nuevo mientras lo está
// viendo.
const mostrarTodoElHilo = {};
let pendienteAdjuntoProductor = null;
let pendienteAdjuntoAdmin = null;
let pendienteAdjuntoSegmentado = null;

function hiloDe(cuentaId){
if (!cuentaId) return [];
if (!Array.isArray(estado.mensajesPorProductor[cuentaId])) estado.mensajesPorProductor[cuentaId] = [];
return estado.mensajesPorProductor[cuentaId];
}

function procesarArchivoAdjunto(archivo){
return new Promise((resolve) => {
if (!archivo){ resolve(null); return; }
const lector = new FileReader();
lector.onload = e => {
if (archivo.type.startsWith('image/')){
const img = new Image();
img.onload = () => {
const anchoObjetivo = 700;
const escala = Math.min(1, anchoObjetivo / img.width);
const canvas = document.createElement('canvas');
canvas.width = img.width * escala;
canvas.height = img.height * escala;
canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
resolve({ nombre: archivo.name, tipo: 'imagen', datos: canvas.toDataURL('image/webp', 0.72) });
};
img.src = e.target.result;
} else {
if (archivo.size > 1500000){ mostrarToast(tr('mensajes_admin__archivo_demasiado_pesado')); resolve(null); return; }
resolve({ nombre: archivo.name, tipo: 'archivo', datos: e.target.result });
}
};
lector.readAsDataURL(archivo);
});
}

async function adjuntarArchivoMensaje(archivo, de){
const adjunto = await procesarArchivoAdjunto(archivo);
if (!adjunto) return;
if (de === 'productor'){
pendienteAdjuntoProductor = adjunto;
const p = document.getElementById('adjunto-preview-productor');
p.textContent = `📎 ${adjunto.nombre}`; p.classList.remove('hidden');
} else {
pendienteAdjuntoAdmin = adjunto;
const p = document.getElementById('adjunto-preview-admin');
p.textContent = `📎 ${adjunto.nombre}`; p.classList.remove('hidden');
}
}

function copiarEnlaceChatDirecto(){
const enlace = window.location.origin + window.location.pathname + '?abrir=chat';
if (navigator.clipboard && navigator.clipboard.writeText){
navigator.clipboard.writeText(enlace).then(() => mostrarToast('Enlace copiado — al abrirlo entra directo al chat')).catch(() => mostrarToast(enlace));
} else {
mostrarToast(enlace);
}
}
function nuevoIdMensajeChat(){ return 'msg_' + Date.now() + '_' + Math.random().toString(36).slice(2,8); }
function activarAtajosChat(){
['msg-productor-texto','msg-admin-texto'].forEach(id => {
const el = document.getElementById(id);
if (!el || el.dataset.iranchChatEnter) return;
el.dataset.iranchChatEnter = '1';
el.addEventListener('keydown', e => {
if (e.key === 'Enter' && !e.shiftKey){ e.preventDefault(); const de = id === 'msg-productor-texto' ? 'productor' : 'veterinario'; enviarMensaje(de); }
});
});
}


setTimeout(activarAtajosChat, 0);

async function enviarMensaje(de){
const idInput = de === 'productor' ? 'msg-productor-texto' : 'msg-admin-texto';
const texto = valor(idInput).trim();
const adjunto = de === 'productor' ? pendienteAdjuntoProductor : pendienteAdjuntoAdmin;
if (!texto && !adjunto) return;
const cuentaId = de === 'productor' ? estado.cuentaActivaId : hiloAbiertoCuentaId;
if (!cuentaId) return;
const ahora = new Date();
const mensaje = {
id: nuevoIdMensajeChat(), de, texto,
archivoNombre: adjunto ? adjunto.nombre : null, archivoDatos: adjunto ? adjunto.datos : null,
fecha: hoyISO(), hora: ahora.toTimeString().slice(0,5), ts: ahora.toISOString(), leido: false,
};
hiloDe(cuentaId).push(mensaje);
establecerValor(idInput, '');
if (de === 'productor'){ pendienteAdjuntoProductor = null; document.getElementById('adjunto-preview-productor').classList.add('hidden'); }
else { pendienteAdjuntoAdmin = null; document.getElementById('adjunto-preview-admin').classList.add('hidden'); }
renderMensajes(de);
guardarEstadoLocal();
await finalizarEnvioMensaje(cuentaId, mensaje, de);
}
// Guarda un mensaje ya agregado a hiloDe(cuentaId) en su documento de
// Firestore y actualiza el resumen liviano — lo usan todas las formas de
// mandar algo al chat (texto, ubicación, nota de voz, compartir un reporte).
async function finalizarEnvioMensaje(cuentaId, mensaje, de){
if (typeof window.firebaseGuardarMensajes === 'function') await window.firebaseGuardarMensajes(cuentaId, hiloDe(cuentaId));
await actualizarResumenMensajes(cuentaId, mensaje, de);
}
// Actualiza el resumen liviano (último mensaje + contador de no leídos) que
// sí vive en la cola de administración — así se arma la bandeja de entrada
// sin tener que cargar los chats completos de todos los productores.
async function actualizarResumenMensajes(cuentaId, mensaje, de){
if (!estado.resumenMensajes[cuentaId]) estado.resumenMensajes[cuentaId] = { noLeidosAdmin: 0, noLeidosProductor: 0 };
const entrada = estado.resumenMensajes[cuentaId];
entrada.ultimoTexto = mensaje.texto || (mensaje.archivoNombre ? '📎 ' + mensaje.archivoNombre : '');
entrada.ultimaFecha = mensaje.fecha; entrada.ultimaHora = mensaje.hora; entrada.deQuien = de;
if (de === 'productor') entrada.noLeidosAdmin = (entrada.noLeidosAdmin || 0) + 1;
else entrada.noLeidosProductor = (entrada.noLeidosProductor || 0) + 1;
if (de === 'admin'){
// Quien administra sí tiene la copia completa y al día de la cola (la
// escucha en vivo) — puede guardar directo.
if (typeof window.firebaseGuardarColaAdmin === 'function') await window.firebaseGuardarColaAdmin(construirPayloadColaAdmin());
} else if (typeof window.firebaseGuardarColaAdmin === 'function'){
// Optimización importante: el productor ya no necesita LEER la cola completa
// de administración para actualizar solo su resumen. Firestore puede actualizar
// el campo anidado de su propia conversación directamente. Eso elimina 1 lectura
// de un documento grande por cada mensaje enviado por productor.
try {
const directo = typeof window.firebaseActualizarResumenChat === 'function'
  ? await window.firebaseActualizarResumenChat(cuentaId, entrada)
  : false;
if (!directo) throw new Error('actualización directa no disponible');
} catch(e){
// Compatibilidad: si la cola todavía no existe o las reglas no permiten la
// actualización directa, usamos el camino anterior como respaldo.
if (typeof window.firebaseLeerColaAdmin === 'function'){
const remoto = await window.firebaseLeerColaAdmin();
if (remoto){
const resumenRemoto = (remoto.resumenMensajes && typeof remoto.resumenMensajes === 'object') ? remoto.resumenMensajes : {};
estado.resumenMensajes = { ...resumenRemoto, [cuentaId]: entrada };
}
}
await window.firebaseGuardarColaAdmin(construirPayloadColaAdmin());
}
}
guardarEstadoLocal();
}
function compartirUbicacion(de){
if (!navigator.geolocation){ mostrarToast('Tu navegador no permite compartir ubicación'); return; }
const cuentaId = de === 'productor' ? estado.cuentaActivaId : hiloAbiertoCuentaId;
if (!cuentaId) return;
mostrarToast('Obteniendo tu ubicación...');
navigator.geolocation.getCurrentPosition(
pos => {
const { latitude, longitude } = pos.coords;
const ahora = new Date();
const mensaje = {
id: nuevoIdMensajeChat(), de, texto: '📍 Ubicación compartida',
archivoNombre: null, archivoDatos: null,
enlaceUrl: `https://www.google.com/maps?q=${latitude},${longitude}`,
fecha: hoyISO(), hora: ahora.toTimeString().slice(0,5), ts: ahora.toISOString(), leido: false,
};
hiloDe(cuentaId).push(mensaje);
guardarEstadoLocal();
renderMensajes(de);
finalizarEnvioMensaje(cuentaId, mensaje, de);
},
() => mostrarToast('No se pudo obtener tu ubicación. Revisa los permisos del navegador.'),
{ enableHighAccuracy: true, timeout: 8000 }
);
}
let mediaRecorderChat = null;
let chunksAudioChat = [];
let timerGrabacionChat = null;
async function iniciarNotaVoz(de){
if (!navigator.mediaDevices || !window.MediaRecorder){ mostrarToast('Tu navegador no permite grabar audio'); return; }
try {
const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
chunksAudioChat = [];
mediaRecorderChat = new MediaRecorder(stream);
mediaRecorderChat.ondataavailable = e => { if (e.data.size > 0) chunksAudioChat.push(e.data); };
mediaRecorderChat.onstop = () => {
stream.getTracks().forEach(t => t.stop());
const blob = new Blob(chunksAudioChat, { type: 'audio/webm' });
const lector = new FileReader();
lector.onload = () => enviarNotaVoz(de, lector.result);
lector.readAsDataURL(blob);
};
mediaRecorderChat.start();
const btn = document.getElementById('btn-nota-voz-' + de);
if (btn){ btn.classList.add('grabando'); btn.innerHTML = '<i class="fa-solid fa-stop"></i>'; btn.setAttribute('onclick', `detenerNotaVoz('${de}')`); }
mostrarToast('Grabando nota de voz (máx. 60s)... toca de nuevo para enviar');
timerGrabacionChat = setTimeout(() => detenerNotaVoz(de), 60000);
} catch (e){
mostrarToast('No se pudo acceder al micrófono. Revisa los permisos.');
}
}
function detenerNotaVoz(de){
if (timerGrabacionChat){ clearTimeout(timerGrabacionChat); timerGrabacionChat = null; }
if (mediaRecorderChat && mediaRecorderChat.state !== 'inactive') mediaRecorderChat.stop();
const btn = document.getElementById('btn-nota-voz-' + de);
if (btn){ btn.classList.remove('grabando'); btn.innerHTML = '<i class="fa-solid fa-microphone"></i>'; btn.setAttribute('onclick', `iniciarNotaVoz('${de}')`); }
}
function enviarNotaVoz(de, datosAudio){
const cuentaId = de === 'productor' ? estado.cuentaActivaId : hiloAbiertoCuentaId;
if (!cuentaId) return;
const ahora = new Date();
const mensaje = {
id: nuevoIdMensajeChat(), de, texto: '',
archivoNombre: 'nota_de_voz.webm', archivoDatos: datosAudio,
fecha: hoyISO(), hora: ahora.toTimeString().slice(0,5), ts: ahora.toISOString(), leido: false,
};
hiloDe(cuentaId).push(mensaje);
guardarEstadoLocal();
renderMensajes(de);
finalizarEnvioMensaje(cuentaId, mensaje, de);
}

function mezclarHilosChat(hiloActual, hiloRemoto){
const mapa = new Map();
[...(Array.isArray(hiloActual) ? hiloActual : []), ...(Array.isArray(hiloRemoto) ? hiloRemoto : [])].forEach(m => { if (m && m.id) mapa.set(m.id, { ...mapa.get(m.id), ...m }); });
return [...mapa.values()].sort((a,b) => String(a.ts || `${a.fecha||''}T${a.hora||''}`).localeCompare(String(b.ts || `${b.fecha||''}T${b.hora||''}`)));
}

function renderMensajes(vista){
if (vista === 'productor'){
const hilo = hiloDe(estado.cuentaActivaId);
hilo.forEach(m => { if (m.de === 'veterinario') m.leido = true; });
pintarHilo('lista-mensajes-productor', hilo, 'productor', estado.cuentaActivaId, valor('chat-productor-buscar'));
actualizarBadgeChatProductor();
} else {
if (hiloAbiertoCuentaId) abrirHiloMensajes(hiloAbiertoCuentaId, true);
renderListaConversacionesAdmin();
actualizarBadgeChatAdmin();
}
}

function aplicarLecturasChat(hilo, vista, cuentaId){
const meta = estado.chatMetaPorProductor && estado.chatMetaPorProductor[cuentaId];
if (!meta || !Array.isArray(hilo)) return hilo;
const tsLeido = vista === 'productor' ? meta.ultimoLeidoAdmin : meta.ultimoLeidoProductor;
if (!tsLeido) return hilo;
return hilo.map(m => m && m.ts && String(m.ts) <= String(tsLeido) && m.de === vista ? { ...m, leido:true } : m);
}
const chatUltimaLecturaEnviada = {};
function marcarChatComoLeido(cuentaId, vista, hilo){
if (!cuentaId || !Array.isArray(hilo) || typeof window.firebaseMarcarChatLeido !== 'function') return;
const entrantes = hilo.filter(m => m && m.de !== vista && m.ts);
const ultimo = entrantes.length ? entrantes[entrantes.length - 1].ts : null;
if (!ultimo || chatUltimaLecturaEnviada[`${cuentaId}:${vista}`] === ultimo) return;
chatUltimaLecturaEnviada[`${cuentaId}:${vista}`] = ultimo;
window.firebaseMarcarChatLeido(cuentaId, vista === 'productor' ? 'productor' : 'admin', ultimo);
}

function pintarHilo(idCont, hilo, vista, cuentaId, filtro){
const cont = document.getElementById(idCont);
if (!cont) return;
const hiloConLecturas = aplicarLecturasChat(hilo, vista, cuentaId);
const hiloFiltrado = filtro ? hiloConLecturas.filter(m => (m.texto || '').toLowerCase().includes(filtro.toLowerCase())) : hiloConLecturas;
if (hiloFiltrado.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-comments"></i><p>${filtro ? 'Sin resultados para "' + filtro + '"' : tr('mensajes_veterinario_productor__aun_no_hay_mensajes')}</p></div>`;
return;
}
// Con una conversación de miles de mensajes acumulados durante años, armar
// TODOS de un jalón en el HTML puede congelar el celular cada vez que llega
// uno nuevo (se vuelve a pintar completo). Por default solo se muestran los
// últimos 200 — con un botón arriba para traer más si hace falta ver algo
// viejo. Al buscar, si se busca algo específico, sí se busca en todo el
// historial (no solo en los últimos 200), para no dejar resultados fuera.
const LIMITE_MENSAJES_VISIBLES = 200;
mostrarTodoElHilo[idCont] = mostrarTodoElHilo[idCont] || false;
const hayMasOcultos = !filtro && !mostrarTodoElHilo[idCont] && hiloFiltrado.length > LIMITE_MENSAJES_VISIBLES;
const hiloMostrado = hayMasOcultos ? hiloFiltrado.slice(-LIMITE_MENSAJES_VISIBLES) : hiloFiltrado;
cont.classList.add('chat-fondo');
let fechaAnterior = null;
const REACCIONES = ['👍','❤️','👀'];
const botonVerMasHTML = hayMasOcultos
? `<div style="text-align:center; margin-bottom:10px;"><button onclick="mostrarTodoElHilo['${idCont}']=true; pintarHilo('${idCont}', hiloDe('${cuentaId}'), '${vista}', '${cuentaId}', valor('${idCont === 'lista-mensajes-productor' ? 'chat-productor-buscar' : 'chat-hilo-buscar'}'));" class="text-xs font-bold px-3 py-2 rounded-full" style="background:rgba(0,0,0,0.08); color:var(--ink);">Ver ${hiloFiltrado.length - LIMITE_MENSAJES_VISIBLES} mensaje(s) anteriores</button></div>`
: '';
cont.innerHTML = botonVerMasHTML + hiloMostrado.map(m => {
const esMio = m.de === vista;
const checkHTML = esMio ? `<i class="fa-solid ${m.leido ? 'fa-check-double leido' : 'fa-check'} burbuja-check" title="${m.leido ? 'Leído' : 'Enviado'}"></i>` : '';
let separador = '';
if (m.fecha !== fechaAnterior){
fechaAnterior = m.fecha;
separador = `<div style="display:flex; justify-content:center; margin:10px 0;"><span style="background:rgba(0,0,0,0.08); color:var(--sage); font-size:.65rem; font-weight:700; padding:.2rem .7rem; border-radius:999px;">${m.fecha}</span></div>`;
}
const esAudio = m.archivoDatos && m.archivoDatos.startsWith('data:audio');
const esImagen = m.archivoDatos && m.archivoDatos.startsWith('data:image');
const adjuntoHTML = m.archivoDatos
? (esAudio
? `<audio controls src="${m.archivoDatos}" style="max-width:210px; margin-top:.3rem; height:36px;"></audio>`
: (esImagen
? `<img src="${m.archivoDatos}" style="max-width:100%; border-radius:10px; margin-top:.3rem;"/>`
: `<a href="${m.archivoDatos}" download="${m.archivoNombre}" style="color:inherit; text-decoration:underline; font-size:.8rem;"><i class="fa-solid fa-paperclip mr-1"></i>${m.archivoNombre}</a>`))
: '';
const reaccionesHTML = `<div class="burbuja-reacciones">${REACCIONES.map(r => `<button onclick="reaccionarMensaje('${cuentaId}','${vista}','${m.id}','${r}')" class="btn-reaccion ${m.reaccion === r ? 'activa' : ''}">${r}</button>`).join('')}</div>`;
return `${separador}<div style="display:flex; justify-content:${esMio ? 'flex-end' : 'flex-start'}; margin-bottom:6px;">
<div class="burbuja-msg ${esMio ? 'burbuja-mia' : 'burbuja-otro'}">
${m.texto ? `<p class="text-sm">${m.texto}</p>` : ''}
${adjuntoHTML}
${m.enlaceUrl ? `<a href="${m.enlaceUrl}" target="_blank" style="color:inherit; text-decoration:underline; font-size:.8rem; display:block; margin-top:.2rem;"><i class="fa-solid fa-link mr-1"></i>${m.texto && m.texto.includes('📍') ? 'Ver ubicación en el mapa' : m.enlaceUrl}</a>` : ''}
${m.reaccion ? `<span class="reaccion-fija">${m.reaccion}</span>` : ''}
${reaccionesHTML}
<div class="burbuja-meta">
<span class="burbuja-hora">${m.hora}</span>
${checkHTML}
</div>
</div>
</div>`;
}).join('');
cont.scrollTop = cont.scrollHeight;
}
function reaccionarMensaje(cuentaId, vista, msgId, emoji){
const hilo = hiloDe(cuentaId);
const m = hilo.find(x => x.id === msgId);
if (!m) return;
m.reaccion = (m.reaccion === emoji) ? null : emoji;
guardarEstadoLocal();
if (vista === 'productor') renderMensajes('productor');
else pintarHilo('lista-hilo-mensajes', hiloDe(cuentaId), 'veterinario', cuentaId, valor('chat-hilo-buscar'));
}

function cambiarSubtabMensajes(sub){
document.getElementById('msg-subtab-conversaciones').classList.toggle('active', sub === 'conversaciones');
document.getElementById('msg-subtab-segmentado').classList.toggle('active', sub === 'segmentado');
document.getElementById('panel-msg-conversaciones').classList.toggle('hidden', sub !== 'conversaciones');
document.getElementById('panel-msg-segmentado').classList.toggle('hidden', sub !== 'segmentado');
if (sub === 'conversaciones') renderListaConversacionesAdmin();
else { actualizarContadorSegmentado(); renderSelectPlantillas(); renderListaMensajesProgramados(); }
}

// ================= BOTÓN DE CHAT FLOTANTE (badge + accesos directos) =================
function actualizarBadgeChatProductor(){
const badge = document.getElementById('badge-chat-productor');
if (!badge) return;
const meta = estado.chatMetaPorProductor?.[estado.cuentaActivaId];
const hilo = hiloDe(estado.cuentaActivaId);
const noLeidos = Number.isFinite(Number(meta?.noLeidosProductor))
  ? Number(meta.noLeidosProductor)
  : hilo.filter(m => m.de !== 'productor' && !m.leido).length;
badge.textContent = noLeidos > 9 ? '9+' : noLeidos;
badge.classList.toggle('hidden', noLeidos === 0);
}
function actualizarBadgeChatAdmin(){
const badge = document.getElementById('badge-chat-admin');
if (!badge) return;
// Se usa el resumen liviano (ya viene con la cola de administración, que el
// admin escucha en vivo), no los chats completos de los 300 productores.
let total = 0;
Object.values(estado.resumenMensajes || {}).forEach(r => { total += r.noLeidosAdmin || 0; });
badge.textContent = total > 9 ? '9+' : total;
badge.classList.toggle('hidden', total === 0);
}
// Envía la tabla/gráfica que se iba a exportar directo al chat, como texto, sin
// necesidad de descargar ningún archivo Excel/CSV/PDF.
function compartirExportacionPorChat(){
if (!exportPendiente) return;
const fn = EXPORT_REGISTRY[exportPendiente];
if (!fn){ cerrarMenuExportar(); return; }
const cfg = fn();
if (!cfg || !cfg.filas || cfg.filas.length === 0){
mostrarToast(tr('exportacion_pie_pagina__no_hay_registros_para_exportar'));
cerrarMenuExportar();
return;
}
let cuentaDestino, de;
if (estado.rolActual === 'admin'){
if (!hiloAbiertoCuentaId){ mostrarToast(tr('chat_flotante__abre_una_conversacion_primero')); cerrarMenuExportar(); return; }
cuentaDestino = hiloAbiertoCuentaId; de = 'veterinario';
} else {
if (!estado.cuentaActivaId){ mostrarToast(tr('chat_flotante__inicia_sesion_con_una_cuenta')); cerrarMenuExportar(); return; }
cuentaDestino = estado.cuentaActivaId; de = 'productor';
}
const filasTexto = cfg.filas.slice(0, 15).map(f => f.join(' · ')).join('\n');
const extra = cfg.filas.length > 15 ? `\n… (+${cfg.filas.length - 15} ${tr('chat_flotante__mas_filas')})` : '';
const texto = `📊 ${cfg.titulo}\n${cfg.encabezados.join(' · ')}\n${filasTexto}${extra}`;
const ahora = new Date();
const mensaje = { id:nuevoIdMensajeChat(), de, texto, archivoNombre: null, archivoDatos: null, fecha: hoyISO(), hora: ahora.toTimeString().slice(0,5), leido: false };
hiloDe(cuentaDestino).push(mensaje);
if (estado.rolActual === 'productor'){ renderMensajes('productor'); actualizarBadgeChatProductor(); }
else { renderListaConversacionesAdmin(); actualizarBadgeChatAdmin(); }
finalizarEnvioMensaje(cuentaDestino, mensaje, de);
cerrarMenuExportar();
mostrarToast(tr('chat_flotante__enviado_al_chat'));
}
function coloresAvatar(){
return ['#2E7D5B','#C0562B','#3B6FA0','#8B4A9C','#B5862A','#4A7A8C','#A03B5C'];
}
function colorAvatarPara(texto){
const colores = coloresAvatar();
let hash = 0;
for (let i = 0; i < (texto || '').length; i++) hash = texto.charCodeAt(i) + ((hash << 5) - hash);
return colores[Math.abs(hash) % colores.length];
}
function avatarHtml(nombre, foto, tam){
tam = tam || 48;
if (foto){
return `<img src="${foto}" alt="${nombre}" style="width:${tam}px; height:${tam}px; border-radius:999px; object-fit:cover; flex-shrink:0;"/>`;
}
const inicial = (nombre || '?').trim().charAt(0).toUpperCase();
return `<div style="width:${tam}px; height:${tam}px; border-radius:999px; background:${colorAvatarPara(nombre||'')}; color:#fff; display:flex; align-items:center; justify-content:center; font-weight:800; font-size:${Math.round(tam*0.42)}px; flex-shrink:0;">${inicial}</div>`;
}
function renderListaConversacionesAdmin(){
const cont = document.getElementById('lista-conversaciones-admin');
if (!cont) return;
const filtro = (valor('chat-buscar-conversacion') || '').toLowerCase();
const resumenPrevio = estado.resumenMensajes || {};
const verificados = new Set(estado.contactosVerificadosChat || []);
// Solo se muestra gente que ya se confirmó por "Buscar amigos" (encontrada
// entre los contactos reales del celular) o con quien ya hubiera una
// conversación empezada — nunca el directorio completo de todos los
// productores del sistema. Así, una cuenta recién creada no puede navegar
// y escribirle a cualquiera de la nada.
const cuentas = estado.cuentasProductores
.filter(c => c.tipo !== 'punto')
.filter(c => verificados.has(c.id) || resumenPrevio[c.id])
.filter(c => !filtro || (c.nombre || '').toLowerCase().includes(filtro));
if (cuentas.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-comments"></i><p>Todavía no tienes contactos — usa "Buscar amigos" para encontrar productores que ya usan la app.</p></div>`;
return;
}
// La bandeja de entrada se arma con el resumen liviano (último mensaje +
// contador), no con los chats completos — el admin no tiene los 300 chats
// cargados, solo el de la conversación que tenga abierta en ese momento.
const resumen = estado.resumenMensajes || {};
const conMensajes = [], sinMensajes = [];
cuentas.forEach(c => (resumen[c.id] ? conMensajes : sinMensajes).push(c));
const ordenar = lista => lista.sort((a,b) => {
const ra = resumen[a.id], rb = resumen[b.id];
if (!ra && !rb) return (a.nombre||'').localeCompare(b.nombre||'');
if (!ra) return 1; if (!rb) return -1;
return ((rb.ultimaFecha||'')+(rb.ultimaHora||'')).localeCompare((ra.ultimaFecha||'')+(ra.ultimaHora||''));
});
const listaFinal = [...ordenar(conMensajes), ...ordenar(sinMensajes)];
cont.innerHTML = listaFinal.map(c => {
const r = resumen[c.id];
const noLeidos = r ? (r.noLeidosAdmin || 0) : 0;
return `
<button class="w-full text-left flex items-center gap-3 py-2.5" onclick="abrirHiloMensajes('${c.id}')" style="border-bottom:1px solid var(--line);">
${avatarHtml(c.nombre, null, 50)}
<div class="flex-1 min-w-0">
<div class="flex items-center justify-between gap-2">
<p class="font-bold truncate">${c.nombre || ''}</p>
${r ? `<span class="text-xs flex-shrink-0" style="color:var(--sage);">${r.ultimaHora || ''}</span>` : ''}
</div>
<div class="flex items-center justify-between gap-2">
<p class="text-sm truncate" style="color:var(--sage);">${r ? (r.ultimoTexto || '') : tr('mensajes_veterinario_productor__aun_no_hay_mensajes')}</p>
${noLeidos > 0 ? `<span class="text-xs font-bold px-2 py-0.5 rounded-full flex-shrink-0" style="background:var(--green); color:#fff; min-width:20px; text-align:center;">${noLeidos}</span>` : ''}
</div>
</div>
</button>`;
}).join('');
}

let cancelarEscuchaHiloAdmin = () => {};
function abrirHiloMensajes(cuentaId, esRefresco){
hiloAbiertoCuentaId = cuentaId;
const cuenta = estado.cuentasProductores.find(c => c.id === cuentaId);
document.getElementById('hilo-nombre-productor').textContent = cuenta ? cuenta.nombre : '';
const avatarCont = document.getElementById('hilo-avatar-nombre');
if (avatarCont) avatarCont.innerHTML = avatarHtml(cuenta ? cuenta.nombre : '', null, 40) + `<div><p class="font-display text-base font-bold" id="hilo-nombre-productor" style="color:#fff;">${cuenta ? cuenta.nombre : ''}</p><p class="subt">Productor</p></div>`;
const hilo = hiloDe(cuentaId);
hilo.forEach(m => { if (m.de === 'productor') m.leido = true; });
pintarHilo('lista-hilo-mensajes', hilo, 'veterinario', cuentaId, valor('chat-hilo-buscar'));
if (!esRefresco){
establecerValor('chat-hilo-buscar', '');
const modal = document.getElementById('modal-hilo-mensajes');
modal.classList.remove('hidden'); modal.style.display = 'flex';
ocultarFabsFlotantes(true);
// Se escucha en vivo SOLO esta conversación mientras está abierta — al
// abrir otra, o al cerrar, se deja de escuchar la anterior. Así el admin
// nunca está "apuntado" a recibir avisos de los 300 chats a la vez,
// solo del que tiene abierto en ese momento.
cancelarEscuchaHiloAdmin();
if (typeof window.firebaseEscucharMensajes === 'function'){
cancelarEscuchaHiloAdmin = window.firebaseEscucharMensajes(cuentaId, (hiloRemoto, actualizadoChat, metaChat) => {
estado.mensajesPorProductor[cuentaId] = mezclarHilosChat(estado.mensajesPorProductor[cuentaId], hiloRemoto);
estado.chatMetaPorProductor[cuentaId] = metaChat || estado.chatMetaPorProductor[cuentaId] || null;
marcarChatComoLeido(cuentaId, 'admin', estado.mensajesPorProductor[cuentaId]);
if (hiloAbiertoCuentaId === cuentaId){
hiloDe(cuentaId).forEach(m => { if (m.de === 'productor') m.leido = true; });
pintarHilo('lista-hilo-mensajes', hiloDe(cuentaId), 'veterinario', cuentaId, valor('chat-hilo-buscar'));
if (estado.resumenMensajes[cuentaId]) estado.resumenMensajes[cuentaId].noLeidosAdmin = 0;
if (typeof window.firebaseGuardarColaAdmin === 'function') window.firebaseGuardarColaAdmin(construirPayloadColaAdmin());
renderListaConversacionesAdmin();
}
});
}
}
// En cuanto se abre, se marca leído y se avisa (guardado directo — el admin
// sí tiene la copia completa y al día de la cola de administración).
if (estado.resumenMensajes[cuentaId]) estado.resumenMensajes[cuentaId].noLeidosAdmin = 0;
if (typeof window.firebaseGuardarColaAdmin === 'function') window.firebaseGuardarColaAdmin(construirPayloadColaAdmin());
guardarEstadoLocal();
renderListaConversacionesAdmin();
}
function cerrarHiloMensajes(){
const modal = document.getElementById('modal-hilo-mensajes');
modal.classList.add('hidden'); modal.style.removeProperty('display');
ocultarFabsFlotantes(false);
hiloAbiertoCuentaId = null;
cancelarEscuchaHiloAdmin();
cancelarEscuchaHiloAdmin = () => {};
}

function productoresQueCumplenFiltro(){
const est = valor('seg-estado').trim().toLowerCase();
const mun = valor('seg-municipio').trim().toLowerCase();
const tipo = valor('seg-tipo');
return estado.cuentasProductores.filter(c => {
if (tipo && c.tipo !== tipo) return false;
if (est && (c.estadoMx || '').toLowerCase() !== est) return false;
if (mun && (c.municipio || '').toLowerCase() !== mun) return false;
return true;
});
}
function actualizarContadorSegmentado(){
const el = document.getElementById('seg-contador');
if (el) el.textContent = productoresQueCumplenFiltro().length;
}
async function adjuntarArchivoSegmentado(archivo){
const adjunto = await procesarArchivoAdjunto(archivo);
if (!adjunto) return;
pendienteAdjuntoSegmentado = adjunto;
const p = document.getElementById('seg-adjunto-preview');
p.textContent = `📎 ${adjunto.nombre}`; p.classList.remove('hidden');
}
function renderSelectPlantillas(){
const sel = document.getElementById('seg-plantilla');
if (!sel) return;
sel.innerHTML = `<option value="">${tr('mensajes_admin__usar_plantilla')}</option>` +
estado.plantillasMensajes.map(p => `<option value="${p.id}">${p.nombre}</option>`).join('');
}
function usarPlantillaMensaje(id){
if (!id) return;
const p = estado.plantillasMensajes.find(x => x.id === id);
if (p) establecerValor('seg-texto', p.texto);
}
function guardarComoPlantilla(){
const texto = valor('seg-texto').trim();
if (!texto){ mostrarToast(tr('mensajes_admin__escribe_un_mensaje_para_guardarlo')); return; }
const nombre = texto.slice(0, 30) + (texto.length > 30 ? '…' : '');
estado.plantillasMensajes.push({ id: 'pla_' + Date.now(), nombre, texto });
renderSelectPlantillas();
mostrarToast(tr('mensajes_admin__plantilla_guardada'));
}
function enviarMensajeSegmentado(programar){
const texto = valor('seg-texto').trim();
if (!texto && !pendienteAdjuntoSegmentado){ mostrarToast(tr('mensajes_admin__escribe_un_mensaje_para_guardarlo')); return; }
const destinatarios = productoresQueCumplenFiltro();
if (destinatarios.length === 0){ mostrarToast(tr('mensajes_admin__nadie_cumple_estos_filtros')); return; }
const datosEnvio = {
texto, archivoNombre: pendienteAdjuntoSegmentado ? pendienteAdjuntoSegmentado.nombre : null,
archivoDatos: pendienteAdjuntoSegmentado ? pendienteAdjuntoSegmentado.datos : null,
enlaceUrl: valor('seg-enlace').trim() || null,
};
if (programar){
const fecha = valor('seg-fecha'); const hora = valor('seg-hora') || '09:00';
if (!fecha){ mostrarToast(tr('mensajes_admin__elige_fecha_para_programar')); return; }
estado.mensajesProgramados.push({
id: 'prog_' + Date.now(), fecha, hora, enviado: false,
filtros: { estado: valor('seg-estado').trim(), municipio: valor('seg-municipio').trim(), tipo: valor('seg-tipo') },
...datosEnvio,
});
mostrarToast(tr('mensajes_admin__mensaje_programado'));
renderListaMensajesProgramados();
} else {
despacharMensajeATodos(destinatarios, datosEnvio);
mostrarToast(`✓ ${tr('mensajes_admin__mensaje_enviado_a')} ${destinatarios.length}`);
}
establecerValor('seg-texto', ''); establecerValor('seg-enlace', '');
pendienteAdjuntoSegmentado = null;
document.getElementById('seg-adjunto-preview').classList.add('hidden');
}
async function despacharMensajeATodos(destinatarios, datosEnvio){
const ahora = new Date();
const guardadosThread = [];
destinatarios.forEach(c => {
const mensaje = {
id: nuevoIdMensajeChat(), de: 'veterinario', texto: datosEnvio.texto,
archivoNombre: datosEnvio.archivoNombre, archivoDatos: datosEnvio.archivoDatos, enlaceUrl: datosEnvio.enlaceUrl,
fecha: hoyISO(), hora: ahora.toTimeString().slice(0,5), ts: ahora.toISOString(), leido: false,
};
hiloDe(c.id).push(mensaje);
if (!estado.resumenMensajes[c.id]) estado.resumenMensajes[c.id] = { noLeidosAdmin: 0, noLeidosProductor: 0 };
const r = estado.resumenMensajes[c.id];
r.ultimoTexto = mensaje.texto || (mensaje.archivoNombre ? '📎 ' + mensaje.archivoNombre : '');
r.ultimaFecha = mensaje.fecha; r.ultimaHora = mensaje.hora; r.deQuien = 'veterinario';
r.noLeidosProductor = (r.noLeidosProductor || 0) + 1;
// Cada conversación se guarda en su propio documento — cada productor
// destinatario recibe el aviso solo de SU hilo, nadie más.
if (typeof window.firebaseGuardarMensajes === 'function') guardadosThread.push(window.firebaseGuardarMensajes(c.id, hiloDe(c.id)));
});
renderListaConversacionesAdmin();
guardarEstadoLocal();
await Promise.all(guardadosThread);
// El resumen sí es un solo guardado (viene de la cola de administración,
// que quien envía el boletín ya escucha en vivo).
if (typeof window.firebaseGuardarColaAdmin === 'function') await window.firebaseGuardarColaAdmin(construirPayloadColaAdmin());
}
function renderListaMensajesProgramados(){
const cont = document.getElementById('lista-mensajes-programados');
if (!cont) return;
if (estado.mensajesProgramados.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-2" style="color:var(--sage);">${tr('mensajes_admin__no_hay_envios_programados')}</p>`;
return;
}
cont.innerHTML = estado.mensajesProgramados.map(m => `
<div class="flex items-center justify-between py-2" style="border-top:2px solid var(--line);">
<div><p class="text-sm font-medium">${m.texto.slice(0,40)}${m.texto.length>40?'…':''}</p><p class="text-xs" style="color:var(--sage);">${m.fecha} ${m.hora} ${m.enviado ? '· ✓ ' + tr('mensajes_admin__enviado') : ''}</p></div>
${!m.enviado ? `<button onclick="eliminarMensajeProgramado('${m.id}')" style="color:var(--red);"><i class="fa-solid fa-trash"></i></button>` : ''}
</div>`).join('');
}
function eliminarMensajeProgramado(id){
estado.mensajesProgramados = estado.mensajesProgramados.filter(m => m.id !== id);
guardarEstadoLocal();
renderListaMensajesProgramados();
}
function revisarMensajesProgramadosDebidos(){
const ahora = new Date();
const hoy = hoyISO();
let huboEnvios = false;
estado.mensajesProgramados.forEach(m => {
if (m.enviado) return;
const momento = new Date(`${m.fecha}T${m.hora}:00`);
if (momento > ahora) return;
const filtroTemp = { estado: m.filtros.estado, municipio: m.filtros.municipio, tipo: m.filtros.tipo };
const destinatarios = estado.cuentasProductores.filter(c => {
if (filtroTemp.tipo && c.tipo !== filtroTemp.tipo) return false;
if (filtroTemp.estado && (c.estadoMx || '').toLowerCase() !== filtroTemp.estado.toLowerCase()) return false;
if (filtroTemp.municipio && (c.municipio || '').toLowerCase() !== filtroTemp.municipio.toLowerCase()) return false;
return true;
});
despacharMensajeATodos(destinatarios, m);
m.enviado = true;
huboEnvios = true;
});
if (huboEnvios){ renderListaMensajesProgramados(); guardarEstadoLocal(); }
}


  window['hiloDe'] = hiloDe;
  window['procesarArchivoAdjunto'] = procesarArchivoAdjunto;
  window['adjuntarArchivoMensaje'] = adjuntarArchivoMensaje;
  window['copiarEnlaceChatDirecto'] = copiarEnlaceChatDirecto;
  window['nuevoIdMensajeChat'] = nuevoIdMensajeChat;
  window['activarAtajosChat'] = activarAtajosChat;
  window['enviarMensaje'] = enviarMensaje;
  window['finalizarEnvioMensaje'] = finalizarEnvioMensaje;
  window['actualizarResumenMensajes'] = actualizarResumenMensajes;
  window['compartirUbicacion'] = compartirUbicacion;
  window['iniciarNotaVoz'] = iniciarNotaVoz;
  window['detenerNotaVoz'] = detenerNotaVoz;
  window['enviarNotaVoz'] = enviarNotaVoz;
  window['mezclarHilosChat'] = mezclarHilosChat;
  window['renderMensajes'] = renderMensajes;
  window['aplicarLecturasChat'] = aplicarLecturasChat;
  window['marcarChatComoLeido'] = marcarChatComoLeido;
  window['pintarHilo'] = pintarHilo;
  window['reaccionarMensaje'] = reaccionarMensaje;
  window['cambiarSubtabMensajes'] = cambiarSubtabMensajes;
  window['actualizarBadgeChatProductor'] = actualizarBadgeChatProductor;
  window['actualizarBadgeChatAdmin'] = actualizarBadgeChatAdmin;
  window['compartirExportacionPorChat'] = compartirExportacionPorChat;
  window['coloresAvatar'] = coloresAvatar;
  window['colorAvatarPara'] = colorAvatarPara;
  window['avatarHtml'] = avatarHtml;
  window['renderListaConversacionesAdmin'] = renderListaConversacionesAdmin;
  window['abrirHiloMensajes'] = abrirHiloMensajes;
  window['cerrarHiloMensajes'] = cerrarHiloMensajes;
  window['productoresQueCumplenFiltro'] = productoresQueCumplenFiltro;
  window['actualizarContadorSegmentado'] = actualizarContadorSegmentado;
  window['adjuntarArchivoSegmentado'] = adjuntarArchivoSegmentado;
  window['renderSelectPlantillas'] = renderSelectPlantillas;
  window['usarPlantillaMensaje'] = usarPlantillaMensaje;
  window['guardarComoPlantilla'] = guardarComoPlantilla;
  window['enviarMensajeSegmentado'] = enviarMensajeSegmentado;
  window['despacharMensajeATodos'] = despacharMensajeATodos;
  window['renderListaMensajesProgramados'] = renderListaMensajesProgramados;
  window['eliminarMensajeProgramado'] = eliminarMensajeProgramado;
  window['revisarMensajesProgramadosDebidos'] = revisarMensajesProgramadosDebidos;
  Object.defineProperty(window, 'hiloAbiertoCuentaId', { configurable:true, get:()=>hiloAbiertoCuentaId, set:(valor)=>{ hiloAbiertoCuentaId=valor; } });
})();
