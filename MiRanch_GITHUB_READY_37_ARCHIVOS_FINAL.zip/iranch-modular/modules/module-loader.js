// MiRanch — cargador de módulos clásicos bajo demanda.
const IRANCH_MODULE_PROMESAS = new Map();
function cargarModuloIRanch(nombre){
  if (IRANCH_MODULE_PROMESAS.has(nombre)) return IRANCH_MODULE_PROMESAS.get(nombre);
  const rutas = {
    'producer-core':'./iranch-modular/modules/producer-core.js',
    queseria:'./iranch-modular/modules/queseria.js',
    tb:'./iranch-modular/modules/tb.js',
    chat:'./iranch-modular/modules/chat.js',
    'admin-reports':'./iranch-modular/modules/admin-reports.js',
    ocr:'./iranch-modular/modules/ocr.js',
    voice:'./iranch-modular/modules/voice.js',
    organization:'./iranch-modular/modules/organization.js'
  };
  const src=rutas[nombre];
  if(!src) return Promise.reject(new Error('Módulo MiRanch desconocido: '+nombre));
  const p=new Promise((resolve,reject)=>{
    const sc=document.createElement('script');
    sc.src=src;
    sc.async=false;
    sc.onload=()=>resolve(true);
    sc.onerror=()=>{
      IRANCH_MODULE_PROMESAS.delete(nombre);
      sc.remove();
      reject(new Error('No se pudo cargar el módulo MiRanch: '+nombre));
    };
    document.head.appendChild(sc);
  });
  IRANCH_MODULE_PROMESAS.set(nombre,p);
  return p;
}
window.cargarModuloIRanch=cargarModuloIRanch;
