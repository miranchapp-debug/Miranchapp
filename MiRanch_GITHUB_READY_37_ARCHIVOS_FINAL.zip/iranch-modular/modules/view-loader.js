// MiRanch — cargador seguro de vistas modulares
// Arquitectura modular activa: las vistas de Productor, Administración y Quesería
// viven en archivos HTML independientes y se montan bajo demanda.
const IRANCH_VIEW_CACHE = new Map();
const IRANCH_VIEW_PROMESAS = new Map();

export async function cargarVistaIRanch(nombre, selector) {
  const destino = typeof selector === 'string' ? document.querySelector(selector) : selector;
  if (!destino) throw new Error(`Destino de vista no encontrado: ${selector}`);
  if (IRANCH_VIEW_CACHE.has(nombre)) {
    destino.replaceWith(IRANCH_VIEW_CACHE.get(nombre).cloneNode(true));
    return document.getElementById(destino.id);
  }
  if (!IRANCH_VIEW_PROMESAS.has(nombre)) {
    const fuente = destino.dataset.iranchViewSource;
    IRANCH_VIEW_PROMESAS.set(nombre, fetch(fuente, { cache: 'no-store' }).then(r => {
      if (!r.ok) throw new Error(`No se pudo cargar la vista ${nombre}: HTTP ${r.status}`);
      return r.text();
    }).then(html => {
      const tpl = document.createElement('template');
      tpl.innerHTML = html.trim();
      const nodo = tpl.content.firstElementChild;
      if (!nodo) throw new Error(`Vista ${nombre} vacía`);
      if (!nodo.id || nodo.id !== destino.id) {
        throw new Error(`Vista ${nombre} inválida: se esperaba el contenedor #${destino.id}`);
      }
      IRANCH_VIEW_CACHE.set(nombre, nodo);
      return nodo;
    }));
  }
  const nodo = await IRANCH_VIEW_PROMESAS.get(nombre);
  const copia = nodo.cloneNode(true);
  destino.replaceWith(copia);
  return copia;
}

export function vistaIRanchEstaPreparada(nombre) {
  return IRANCH_VIEW_CACHE.has(nombre);
}

window.cargarVistaIRanch = cargarVistaIRanch;
window.vistaIRanchEstaPreparada = vistaIRanchEstaPreparada;
