// MiRanch — núcleo de navegación y ciclo de sesión del productor.
function logoActivo(){
return (estado.configuracion && estado.configuracion.logoPersonalizado) || LOGO_QUESERIA_B64;
}
function aplicarLogoPersonalizado(){
document.querySelectorAll('img[data-logo-role="horizontal"]').forEach(img => { img.src = logoActivo(); });
}
function verificarVigenciaProductor(){
const overlay = document.getElementById('overlay-suscripcion-vencida');
if (!overlay) return true;
const susc = estado.productor.suscripcion;
if (!susc || !validarFechaISO(susc.fechaVencimiento)){ overlay.classList.add('hidden'); return true; }
const dias = diasEntreISO(susc.fechaVencimiento, hoyISO());
const vencida = dias < 0;
overlay.classList.toggle('hidden', !vencida);
if (vencida){
const [y,m,d] = susc.fechaVencimiento.split('-');
const elFecha = document.getElementById('overlay-fecha-vencimiento');
if (elFecha) elFecha.textContent = `${d}/${m}/${y}`;
}
return !vencida;
}
async function cerrarSesion(){
if (typeof detenerEscuchaBandejaRol === 'function') detenerEscuchaBandejaRol();
detenerEscuchaGlobalIRanch();
if (typeof detenerEscuchaColaAdminIRanch === 'function') detenerEscuchaColaAdminIRanch();
if (typeof detenerListenersDominiosCuenta === 'function') detenerListenersDominiosCuenta();
if (typeof window.firebaseCerrarSesionFederada === 'function') { try { await window.firebaseCerrarSesionFederada(); } catch(e) {} }
restaurarDeModoDemoSiHaceFalta();
document.getElementById('app-productor').classList.add('hidden');
document.getElementById('app-admin').classList.add('hidden');
document.getElementById('screen-tipo-ganado').classList.remove('active');
document.getElementById('screen-codigo-trabajador').classList.remove('active');
sesionRolAutenticado = null;
estado.rolActual = null;
estado.modoTrabajador = false;
estado.trabajadorActualId = null;
estado.cuentaActivaId = null;
estado.modoVeterinario = false;
estado.vistaVeterinario = false;
estado.veterinarioActivoId = null;
estado.modoCapturista = false;
estado.modoAlmita = false;
estado.modoMedicoCampoTB = false;
estado.medicoComiteActivoId = null;
estado.modoCapturistaTB = false;
estado.modoComite = false;
if (typeof activarEscuchaCuentaActiva === 'function') activarEscuchaCuentaActiva();
limpiarDatosDeCuentaActiva();
estado.animales = HATO_DEMO;
estado.salud = SALUD_DEMO;
estado.pesajes = PESAJES_DEMO;
estado.reproduccion = REPRODUCCION_DEMO;
estado.relojSimulado = null;
estado.productor.suscripcion = { fechaAlta: hoyISO(), diasVigencia: 365, fechaVencimiento: sumarDiasISO(hoyISO(), 365) };
document.getElementById('screen-login').classList.add('active');
guardarEstadoLocal();
renderCuentasGuardadas();
const fabVoz = document.getElementById('fab-comando-voz');
if (fabVoz) fabVoz.classList.add('hidden');
const fabMas = document.getElementById('fab-mas-productor');
if (fabMas) fabMas.classList.add('hidden');
const btnChat = document.getElementById('btn-chat-flotante-productor');
if (btnChat) btnChat.classList.add('hidden');
}
let historialPantallas = [];
function irA(nombre){
if (!verificarVigenciaProductor()) return;
const cuentaGate=typeof cuentaActivaProductiva==='function'?cuentaActivaProductiva():null;
if(cuentaGate&&typeof cuentaTieneUPP==='function'&&!cuentaTieneUPP(cuentaGate)){
 const gate=typeof estadoGateUPPMiRanch==='function'?estadoGateUPPMiRanch(cuentaGate):{obligatorio:false};
 const permitidas=new Set(['home','espacios','organizacion-home','organizacion-nueva','suscripcion','datos-productor','editar-productor','escaneo-documentos','mensajes','boletines']);
 if(gate.obligatorio&&!permitidas.has(nombre)){if(typeof mostrarOnboardingUPP==='function')mostrarOnboardingUPP(true);mostrarToast('Completa la UPP para habilitar esta función productiva.');return;}
}
if (estado.modoTrabajador && nombre === 'graficas'){ mostrarToast(tr('trabajadores__acceso_no_disponible')); nombre = 'home'; }
const actual = document.querySelector('#app-productor .screen.active');
const actualId = actual ? actual.id.replace('screen-', '') : null;
if (actualId && actualId !== nombre && document.getElementById('screen-' + nombre)){
historialPantallas.push(actualId);
if (historialPantallas.length > 30) historialPantallas.shift();
registrarPasoHistorialNavegador();
}
cambiarPantallaProductor(nombre);
if (typeof asegurarDominiosPantallaProductor === 'function') {
  asegurarDominiosPantallaProductor(nombre).then(() => {
    if (typeof cambiarPantallaProductor === 'function' && document.querySelector('#app-productor .screen.active')?.id === 'screen-' + nombre) cambiarPantallaProductor(nombre);
  }).catch(e => console.warn('MiRanch: no se pudieron preparar los datos de la pantalla', nombre, e));
}
}
function volverAtras(destinoRespaldo){
let anterior = historialPantallas.pop();
while (anterior && !document.getElementById('screen-' + anterior)) anterior = historialPantallas.pop();
cambiarPantallaProductor(anterior || destinoRespaldo || 'home');
}
// El deslizamiento de 'atrás' del celular (o el botón físico de atrás en
// Android) dispara el evento 'popstate' del navegador — sin esto, como la app
// nunca registraba pasos en el historial del navegador, ese gesto sacaba a la
// persona de la app por completo (o la regresaba a la pantalla de carga
// inicial) en vez de solo regresar una pantalla, como el botón normal de
// 'Volver' ya hace. Se registra un paso cada vez que se cambia de pantalla, y
// al recibir 'popstate' se usa la misma pila de historial que ya existía —
// nunca dependiendo del navegador para saber a dónde regresar.
let sincronizandoHistorialNavegador = false;
function registrarPasoHistorialNavegador(){
if (sincronizandoHistorialNavegador) return;
try { history.pushState({ appNav: true }, ''); } catch(e){}
}
window.addEventListener('popstate', () => {
sincronizandoHistorialNavegador = true;
try {
if (estado.rolActual === 'admin') volverAtrasAdmin('home');
else volverAtras('home');
registrarPasoHistorialNavegador();
} finally {
sincronizandoHistorialNavegador = false;
}
});
function cambiarPantallaProductor(nombre){
document.querySelectorAll('#app-productor .screen').forEach(s => s.classList.remove('active'));
document.getElementById('screen-' + nombre).classList.add('active');
document.querySelectorAll('#app-productor .navbar-item').forEach(b => b.classList.remove('active'));
const nav = document.querySelector('[data-nav="' + nombre + '"]');
if (nav) nav.classList.add('active');
if (nombre === 'graficas') actualizarGraficas();
if (nombre === 'notificaciones') { renderIndicadores(); renderAnimalesEnfermos(); renderNotificaciones(); }
if (nombre === 'boletines') renderBoletines();
if (nombre === 'tareas') renderMisTareas();
if (nombre === 'mensajes') renderMensajes('productor');
if (nombre === 'calendario') renderCalendario();
if (nombre === 'engorda') renderEngorda();
if (nombre === 'tareas') renderMisTareas();
if (nombre === 'visitas') renderVisitasVet();
if (nombre === 'transferencias') renderSolicitudesTransferencia();
if (nombre === 'pruebascampoproductor') renderPruebasCampoCompartidas();
if (nombre === 'solicitudaretes') renderSolicitudAretesProductor();
if (nombre === 'trabajadores') renderListaTrabajadores();
if (nombre === 'bitacoravoz') renderBitacoraVoz();
if (nombre === 'suscripcion') renderMiSuscripcion();
if (nombre === 'home') renderTiles();
const fabChatProd = document.getElementById('btn-chat-flotante-productor');
const fabMasProd = document.querySelector('#app-productor button[onclick="toggleFab()"]');
const enChatProductor = nombre === 'mensajes';
if (fabChatProd) fabChatProd.classList.toggle('hidden', enChatProductor);
if (fabMasProd) fabMasProd.classList.toggle('hidden', enChatProductor);
if (enChatProductor){
const fabMenu = document.getElementById('fab-menu');
const fabSheet = document.getElementById('fab-sheet');
if (fabMenu) fabMenu.classList.add('hidden');
if (fabSheet) fabSheet.classList.add('hidden');
}
window.scrollTo(0,0);
}
function pintarPrevisualizacionFondoHome(){
const cont = document.getElementById('previsualizacion-fondo-home');
if (!cont) return;
cont.style.backgroundImage = `url('${estado.configuracion.fondoHome || fondoHomeSemanal()}')`;
cont.style.backgroundSize = 'cover';
cont.style.backgroundPosition = 'center';
}
function subirFondoHome(archivo){
if (!archivo) return;
const estadoTxt = document.getElementById('estado-fondo-home');
if (estadoTxt) estadoTxt.textContent = tr('inicio_productor__clima_cargando');
const lector = new FileReader();
lector.onload = e => {
const img = new Image();
img.onload = () => {
const anchoObjetivo = 640;
const escala = Math.min(1, anchoObjetivo / img.width);
const canvas = document.createElement('canvas');
canvas.width = img.width * escala;
canvas.height = img.height * escala;
const ctx = canvas.getContext('2d');
ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
const dataUrl = canvas.toDataURL('image/webp', 0.62);
estado.configuracion.fondoHome = dataUrl;
pintarPrevisualizacionFondoHome();
renderTarjetaDatosGenerales();
if (estadoTxt) estadoTxt.textContent = '✓ ' + (Math.round(dataUrl.length * 0.75 / 1024)) + ' KB';
};
img.src = e.target.result;
};
lector.readAsDataURL(archivo);
}
function restaurarFondoHomeDefault(){
estado.configuracion.fondoHome = null;
pintarPrevisualizacionFondoHome();
renderTarjetaDatosGenerales();
}
function pintarPrevisualizacionFondoHeader(){
const cont = document.getElementById('previsualizacion-fondo-header');
if (!cont) return;
cont.style.backgroundImage = `url('${estado.configuracion.fondoHeader || FONDO_HEADER_DEFAULT}')`;
cont.style.backgroundSize = 'cover';
cont.style.backgroundPosition = 'center';
}
function subirFondoHeader(archivo){
if (!archivo) return;
const estadoTxt = document.getElementById('estado-fondo-header');
if (estadoTxt) estadoTxt.textContent = tr('inicio_productor__clima_cargando');
const lector = new FileReader();
lector.onload = e => {
const img = new Image();
img.onload = () => {
const anchoObjetivo = 800;
const escala = Math.min(1, anchoObjetivo / img.width);
const canvas = document.createElement('canvas');
canvas.width = img.width * escala;
canvas.height = img.height * escala;
const ctx = canvas.getContext('2d');
ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
const dataUrl = canvas.toDataURL('image/webp', 0.62);
estado.configuracion.fondoHeader = dataUrl;
pintarPrevisualizacionFondoHeader();
aplicarFondoHeaderProductor();
if (estadoTxt) estadoTxt.textContent = '✓ ' + (Math.round(dataUrl.length * 0.75 / 1024)) + ' KB';
};
img.src = e.target.result;
};
lector.readAsDataURL(archivo);
}
function restaurarFondoHeaderDefault(){
estado.configuracion.fondoHeader = null;
pintarPrevisualizacionFondoHeader();
aplicarFondoHeaderProductor();
}
function pintarPrevisualizacionLogo(){
const cont = document.getElementById('previsualizacion-logo');
if (!cont) return;
cont.style.backgroundImage = `url('${logoActivo()}')`;
cont.style.backgroundSize = 'contain';
cont.style.backgroundPosition = 'center';
cont.style.backgroundRepeat = 'no-repeat';
}
function subirLogoPersonalizado(archivo){
if (!archivo) return;
const estadoTxt = document.getElementById('estado-logo');
if (estadoTxt) estadoTxt.textContent = tr('inicio_productor__clima_cargando');
const lector = new FileReader();
lector.onload = e => {
const img = new Image();
img.onload = () => {
const anchoObjetivo = 300;
const escala = Math.min(1, anchoObjetivo / img.width);
const canvas = document.createElement('canvas');
canvas.width = img.width * escala;
canvas.height = img.height * escala;
canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
estado.configuracion.logoPersonalizado = canvas.toDataURL('image/webp', 0.85);
pintarPrevisualizacionLogo();
aplicarLogoPersonalizado();
if (estadoTxt) estadoTxt.textContent = '✓ ' + (Math.round(estado.configuracion.logoPersonalizado.length * 0.75 / 1024)) + ' KB';
};
img.src = e.target.result;
};
lector.readAsDataURL(archivo);
}
function restaurarLogoDefault(){
estado.configuracion.logoPersonalizado = null;
pintarPrevisualizacionLogo();
aplicarLogoPersonalizado();
const estadoTxt = document.getElementById('estado-logo');
if (estadoTxt) estadoTxt.textContent = '';
}

