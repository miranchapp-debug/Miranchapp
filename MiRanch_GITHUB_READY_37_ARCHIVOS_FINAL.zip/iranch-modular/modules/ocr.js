(function(){
// MiRanch — módulo extraído automáticamente. Se ejecuta como script clásico para conservar compatibilidad con funciones globales.
// ================= ALTA RÁPIDA POR ESCANEO DE DOCUMENTOS (OCR en el navegador) =================
// Usa Tesseract.js (se carga solo cuando hace falta, desde CDN) para leer el texto
// de la foto y unas reglas/expresiones regulares para adivinar los campos. La
// lectura automática de documentos fotografiados con celular NUNCA es 100%
// confiable (luz, ángulo, letra) — por eso todo lo que se detecta se muestra en
// campos editables para que el productor/veterinario lo revise antes de guardar,
// nunca se guarda nada de forma automática y silenciosa.
let tesseractCargando = null;
function cargarTesseractSiNecesario(){
if (window.Tesseract) return Promise.resolve();
if (tesseractCargando) return tesseractCargando;
tesseractCargando = new Promise((resolve, reject) => {
const script = document.createElement('script');
script.src = 'https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js';
script.onload = () => resolve();
script.onerror = () => { tesseractCargando = null; reject(new Error('No se pudo descargar el lector de texto — revisa tu conexión a internet')); };
document.head.appendChild(script);
});
return tesseractCargando;
}
// Deja el lector de texto (y su paquete de idioma español, ~10-15 MB la primera
// vez) descargándose solo, en cuanto se abre la pantalla de escaneo — así, para
// cuando la persona ya tomó la foto y está lista para extraer datos, es más
// probable que ya esté listo o casi listo, en vez de tener que esperar toda esa
// descarga justo en ese momento. En conexiones malas puede tardar o fallar de
// todas formas — eso ya no se puede evitar del todo, pero al menos no se suma
// al tiempo de espera del botón.
function precargarTesseractEnSegundoPlano(){
cargarTesseractSiNecesario().catch(() => {});
}
// Todas las lecturas de texto pasan por esta misma "fila" — así, aunque se
// tomen varias fotos seguidas (frente y reverso casi al mismo tiempo, por
// ejemplo), nunca corren dos lecturas de Tesseract A LA VEZ. Antes, al hacer
// la lectura automática al tomar la foto, si la segunda foto se tomaba
// mientras la primera todavía se estaba leyendo, arrancaban DOS procesos de
// lectura simultáneos — eso agotaba la memoria del celular y cerraba la
// página de golpe. Ahora la segunda espera a que termine la primera antes de
// empezar, en vez de correr encimada.
let colaLecturaOCR = Promise.resolve();
function encolarLecturaOCR(tarea){
const resultado = colaLecturaOCR.then(tarea, tarea);
colaLecturaOCR = resultado.catch(() => {});
return resultado;
}

function abrirCapturaDocumento(inputId){
  const input = document.getElementById(inputId);
  if (!input) return;
  // Vaciar el input antes de abrir la cámara: Android/iOS no siempre disparan
  // change si el usuario vuelve a elegir exactamente la misma foto.
  try { input.value = ''; } catch(e){}
  input.dataset.iranchEsperandoCaptura = '1';
  try { input.click(); }
  catch(e){ mostrarToast('No se pudo abrir la cámara. Usa el botón de adjuntar foto del navegador.'); }
}
async function evaluarNitidezImagenOCR(dataUrl){
  try{
    const img=await cargarImagenOCR(dataUrl);
    const w=Math.min(520,img.width), h=Math.max(1,Math.round(img.height*(w/img.width)));
    const c=document.createElement('canvas'); c.width=w; c.height=h;
    const ctx=c.getContext('2d',{willReadFrequently:true}); ctx.drawImage(img,0,0,w,h);
    const d=ctx.getImageData(0,0,w,h).data; let suma=0,suma2=0,n=0;
    for(let y=1;y<h;y+=2) for(let x=1;x<w;x+=2){
      const i=(y*w+x)*4,l=i-4,u=((y-1)*w+x)*4;
      const g=d[i]*.299+d[i+1]*.587+d[i+2]*.114;
      const gl=d[l]*.299+d[l+1]*.587+d[l+2]*.114, gu=d[u]*.299+d[u+1]*.587+d[u+2]*.114;
      const e=Math.abs(g-gl)+Math.abs(g-gu); suma+=e; suma2+=e*e; n++;
    }
    const media=suma/Math.max(1,n); const varianza=Math.max(0,suma2/Math.max(1,n)-media*media);
    return {media,varianza};
  }catch(e){ return null; }
}
function cargarImagenOCR(dataUrl){
  return new Promise((resolve,reject)=>{ const i=new Image(); i.onload=()=>resolve(i); i.onerror=reject; i.src=dataUrl; });
}
function canvasDesdeImagenOCR(img,maxPx=2200){
  const escala=Math.min(1,maxPx/Math.max(img.width,img.height));
  const w=Math.max(1,Math.round(img.width*escala)), h=Math.max(1,Math.round(img.height*escala));
  const c=document.createElement('canvas'); c.width=w; c.height=h;
  c.getContext('2d',{willReadFrequently:true}).drawImage(img,0,0,w,h);
  return c;
}
function grisDesdeCanvasOCR(canvas){
  const ctx=canvas.getContext('2d',{willReadFrequently:true}), im=ctx.getImageData(0,0,canvas.width,canvas.height), g=new Float32Array(canvas.width*canvas.height);
  for(let i=0,p=0;i<im.data.length;i+=4,p++) g[p]=im.data[i]*.299+im.data[i+1]*.587+im.data[i+2]*.114;
  return {ctx,im,g,w:canvas.width,h:canvas.height};
}
function percentilOCR(arr,q){
  const paso=Math.max(1,Math.floor(arr.length/12000)), a=[];
  for(let i=0;i<arr.length;i+=paso) a.push(arr[i]);
  a.sort((x,y)=>x-y); return a[Math.min(a.length-1,Math.max(0,Math.floor((a.length-1)*q)))] || 0;
}
function ordenarPuntosOCR(p){
  const c={x:p.reduce((s,v)=>s+v.x,0)/4,y:p.reduce((s,v)=>s+v.y,0)/4};
  return p.slice().sort((a,b)=>Math.atan2(a.y-c.y,a.x-c.x)-Math.atan2(b.y-c.y,b.x-c.x)).reduce((acc,v)=>{
    if(!acc.length) return [v]; const last=acc[acc.length-1]; return acc.concat([v]);
  },[]);
}
function distanciaOCR(a,b){ return Math.hypot(a.x-b.x,a.y-b.y); }
function areaCuadrilateroOCR(p){ let a=0; for(let i=0;i<4;i++){const q=p[i],r=p[(i+1)%4];a+=q.x*r.y-r.x*q.y;} return Math.abs(a)/2; }
function soporteBordeOCR(edges,w,h,a,b){
  const n=80; let hit=0, total=0;
  for(let i=0;i<=n;i++){
    const x=Math.round(a.x+(b.x-a.x)*i/n), y=Math.round(a.y+(b.y-a.y)*i/n);
    const r=3;
    for(let k=-r;k<=r;k++){
      const nx=Math.round(x+(b.y-a.y)*k/Math.max(1,distanciaOCR(a,b))), ny=Math.round(y-(b.x-a.x)*k/Math.max(1,distanciaOCR(a,b)));
      if(nx>=0&&ny>=0&&nx<w&&ny<h){ total++; if(edges[ny*w+nx]) hit++; }
    }
  }
  return hit/Math.max(1,total);
}
function detectarCuadrilateroDocumentoOCR(canvas){
  // Detector ligero inspirado en los escáneres móviles: reducción, Sobel y
  // esquinas Harris. No pretende ser OpenCV; solo decide si hay un rectángulo
  // documental suficientemente claro para aplicar una homografía segura.
  const max=640;
  const sc=Math.min(1,max/Math.max(canvas.width,canvas.height));
  const w=Math.max(1,Math.round(canvas.width*sc)), h=Math.max(1,Math.round(canvas.height*sc));
  const small=document.createElement('canvas'); small.width=w; small.height=h;
  small.getContext('2d').drawImage(canvas,0,0,w,h);
  const z=grisDesdeCanvasOCR(small), {g}=z, mag=new Float32Array(w*h), edges=new Uint8Array(w*h), corners=[];
  for(let y=1;y<h-1;y++) for(let x=1;x<w-1;x++){
    const p=y*w+x;
    const gx=(-g[p-w-1]-2*g[p-1]-g[p+w-1]+g[p-w+1]+2*g[p+1]+g[p+w+1]);
    const gy=(-g[p-w-1]-2*g[p-w]-g[p-w+1]+g[p+w-1]+2*g[p+w]+g[p+w+1]);
    mag[p]=Math.hypot(gx,gy);
  }
  const umbral=Math.max(35,percentilOCR(mag,.78));
  for(let p=0;p<mag.length;p++) edges[p]=mag[p]>=umbral?1:0;
  const R=new Float32Array(w*h);
  for(let y=3;y<h-3;y++) for(let x=3;x<w-3;x++){
    const p=y*w+x; let ix2=0,iy2=0,ixy=0;
    for(let yy=-2;yy<=2;yy++) for(let xx=-2;xx<=2;xx++){
      const q=(y+yy)*w+(x+xx); let gx=0,gy=0;
      gx=(g[q-w+1]-g[q-w-1])+2*(g[q+1]-g[q-1])+(g[q+w+1]-g[q+w-1]);
      gy=(g[q+w-1]-g[q-w-1])+2*(g[q+w]-g[q-w])+(g[q+w+1]-g[q-w+1]);
      ix2+=gx*gx; iy2+=gy*gy; ixy+=gx*gy;
    }
    const det=ix2*iy2-ixy*ixy, tr=ix2+iy2; R[p]=det-0.04*tr*tr;
  }
  const rMax=percentilOCR(R,.995), minDist=Math.max(20,Math.min(w,h)*.12);
  for(let y=10;y<h-10;y+=2) for(let x=10;x<w-10;x+=2){
    const p=y*w+x; if(R[p]<rMax || R[p]<=0) continue;
    let local=true; for(let yy=-4;yy<=4&&local;yy++) for(let xx=-4;xx<=4;xx++) if(R[(y+yy)*w+x+xx]>R[p]){local=false;break;}
    if(!local) continue;
    corners.push({x,y,score:R[p]});
  }
  const quads=[];
  const zonas=[p=>p.x<w*.5&&p.y<h*.5,p=>p.x>=w*.5&&p.y<h*.5,p=>p.x>=w*.5&&p.y>=h*.5,p=>p.x<w*.5&&p.y>=h*.5];
  const candidatos=zonas.map(fn=>corners.filter(fn).sort((a,b)=>b.score-a.score).slice(0,12));
  if(candidatos.some(a=>!a.length)) return null;
  const combos=(i,acc)=>{ if(i===4){ quads.push(acc.slice()); return; } for(const p of candidatos[i]){ if(acc.every(q=>distanciaOCR(p,q)>minDist*.55)) combos(i+1,acc.concat([p])); } };
  combos(0,[]);
  let mejor=null, mejorScore=-Infinity;
  for(const q0 of quads){
    const q=q0.map(p=>({x:p.x/sc,y:p.y/sc}));
    const ord=ordenarPuntosOCR(q); if(ord.length!==4) continue;
    const area=areaCuadrilateroOCR(ord), ratio=area/(canvas.width*canvas.height); if(ratio<.28) continue;
    let conv=true; for(let i=0;i<4;i++){const a=ord[i],b=ord[(i+1)%4],c=ord[(i+2)%4];const cr=(b.x-a.x)*(c.y-b.y)-(b.y-a.y)*(c.x-b.x);if(cr<=0){conv=false;break;}}
    if(!conv) continue;
    let support=0; for(let i=0;i<4;i++){const a=ord[i],b=ord[(i+1)%4]; const aa={x:a.x*sc,y:a.y*sc},bb={x:b.x*sc,y:b.y*sc}; support+=soporteBordeOCR(edges,w,h,aa,bb);}
    const spread=Math.min(1,ratio/.55), score=support*55+spread*35;
    if(score>mejorScore){mejorScore=score; mejor={puntos:ord,confidence:score/90};}
  }
  return mejor && mejor.confidence>=.52 ? mejor : null;
}
async function detectarYEnderezarDocumentoOCR(dataUrl){
  try{
    const img=await cargarImagenOCR(dataUrl), c=canvasDesdeImagenOCR(img,2400);
    const deteccion=detectarCuadrilateroDocumentoOCR(c);
    if(!deteccion) return {dataUrl,detectado:false,confidence:0};
    // Reutiliza la misma homografía de la interfaz manual: aquí los puntos ya
    // vienen detectados automáticamente. Se conserva la foto original intacta.
    const temp={naturalWidth:c.width,naturalHeight:c.height};
    const ctxTemp=c.getContext('2d');
    // recortarYEnderezarImagen espera un objeto Image; fabricamos uno desde el canvas.
    const canvasFinal=document.createElement('canvas');
    const [tl,tr,br,bl]=deteccion.puntos;
    const ancho=Math.min(1800,Math.max(700,Math.round(Math.max(distanciaOCR(tl,tr),distanciaOCR(bl,br)))));
    const alto=Math.min(2600,Math.max(500,Math.round(ancho*Math.max(distanciaOCR(tl,bl),distanciaOCR(tr,br))/Math.max(1,distanciaOCR(tl,tr)))));
    canvasFinal.width=ancho; canvasFinal.height=alto;
    const h=calcularHomografia([{x:0,y:0},{x:ancho,y:0},{x:ancho,y:alto},{x:0,y:alto}],deteccion.puntos);
    const src=c.getContext('2d',{willReadFrequently:true}).getImageData(0,0,c.width,c.height), out=canvasFinal.getContext('2d').createImageData(ancho,alto);
    for(let Y=0;Y<alto;Y++) for(let X=0;X<ancho;X++){
      const s=aplicarHomografia(h,X,Y), rgb=muestrearPixelBilineal(src,s.x,s.y), i=(Y*ancho+X)*4;
      out.data[i]=rgb[0];out.data[i+1]=rgb[1];out.data[i+2]=rgb[2];out.data[i+3]=255;
    }
    canvasFinal.getContext('2d').putImageData(out,0,0);
    return {dataUrl:canvasFinal.toDataURL('image/jpeg',.94),detectado:true,confidence:deteccion.confidence};
  }catch(e){ console.warn('Autoescáner OCR omitido',e); return {dataUrl,detectado:false,confidence:0}; }
}
function aplicarMejorasImagenOCR(canvas,modo='color'){ 
  const {ctx,im,g,w,h}=grisDesdeCanvasOCR(canvas), px=im.data;
  // Corrección de iluminación: resta una estimación de fondo de baja frecuencia
  // para quitar sombras y variaciones de exposición sin borrar trazos pequeños.
  const paso=Math.max(8,Math.floor(Math.min(w,h)/45)), bg=new Float32Array(w*h);
  for(let y=0;y<h;y+=paso) for(let x=0;x<w;x+=paso){
    let s=0,n=0; const r=paso*2;
    for(let yy=Math.max(0,y-r);yy<=Math.min(h-1,y+r);yy+=Math.max(2,Math.floor(paso/2))) for(let xx=Math.max(0,x-r);xx<=Math.min(w-1,x+r);xx+=Math.max(2,Math.floor(paso/2))){s+=g[yy*w+xx];n++;}
    bg[y*w+x]=s/Math.max(1,n);
  }
  function fondo(x,y){ const x0=Math.floor(x/paso)*paso,y0=Math.floor(y/paso)*paso,x1=Math.min(w-1,x0+paso),y1=Math.min(h-1,y0+paso),fx=(x-x0)/Math.max(1,paso),fy=(y-y0)/Math.max(1,paso); const a=bg[y0*w+x0]||128,b=bg[y0*w+x1]||a,c=bg[y1*w+x0]||a,d=bg[y1*w+x1]||a; return (a*(1-fx)+b*fx)*(1-fy)+(c*(1-fx)+d*fx)*fy; }
  const base=modo==='binario'?'binario':modo==='nitida'?'nitida':'contraste';
  const gris=new Uint8Array(w*h);
  for(let p=0;p<g.length;p++){ const y=Math.floor(p/w),x=p-y*w; let v=g[p], f=fondo(x,y); v=Math.max(0,Math.min(255,128+(v-f)*1.35)); gris[p]=v; }
  // Filtro mediana 3x3 para ruido ISO/sal y pimienta.
  const den=new Uint8Array(gris);
  for(let y=1;y<h-1;y++) for(let x=1;x<w-1;x++){ const a=[]; for(let yy=-1;yy<=1;yy++) for(let xx=-1;xx<=1;xx++) a.push(gris[(y+yy)*w+x+xx]); a.sort((m,n)=>m-n); den[y*w+x]=a[4]; }
  // Unsharp mask ligero + control de rango dinámico.
  const fin=new Uint8Array(den);
  for(let y=1;y<h-1;y++) for(let x=1;x<w-1;x++){ const p=y*w+x; const blur=(den[p-1]+den[p+1]+den[p-w]+den[p+w])/4; let v=den[p]+(den[p]-blur)*1.55; v=1.12*(v-128)+128; fin[p]=Math.max(0,Math.min(255,Math.round(v))); }
  if(base==='binario'){
    // Umbral local adaptativo mediante imagen integral: mismo objetivo que los
    // escáneres profesionales, pero sin el costo O(n*r²) de recorrer una ventana
    // completa para cada píxel.
    const iw=w+1, integral=new Uint32Array(iw*(h+1));
    for(let y=1;y<=h;y++){
      let fila=0;
      for(let x=1;x<=w;x++){ fila+=fin[(y-1)*w+x-1]; integral[y*iw+x]=integral[(y-1)*iw+x]+fila; }
    }
    const r=18;
    for(let y=0;y<h;y++) for(let x=0;x<w;x++){
      const x0=Math.max(0,x-r),x1=Math.min(w-1,x+r),y0=Math.max(0,y-r),y1=Math.min(h-1,y+r);
      const A=integral[y0*iw+x0],B=integral[y0*iw+x1+1],C=integral[(y1+1)*iw+x0],D=integral[(y1+1)*iw+x1+1];
      const media=(D-B-C+A)/Math.max(1,(x1-x0+1)*(y1-y0+1));
      const v=fin[y*w+x]>(media-8)?255:0; const p=(y*w+x)*4; px[p]=px[p+1]=px[p+2]=v;
    }
  } else {
    for(let p=0;p<fin.length;p++){ const v=fin[p]; px[p*4]=px[p*4+1]=px[p*4+2]=v; }
  }
  ctx.putImageData(im,0,0); return canvas;
}
function puntuarTextoOCR(texto, tipoDocumento){
  const t = normalizarParaBuscarEtiqueta(String(texto || ''));
  if (!t) return -999;
  const palabras = ['NOMBRE','PRODUCTOR','UPP','MUNICIPIO','ESTADO','LOCALIDAD','DOMICILIO','FECHA','FOLIO','SENASICA','TUBERCULOSIS','TUBERCULINA','IDENTIFICADOR','VIGENTE','SEXO','RAZA','REEMO','PROPIETARIO','UNIDAD','PREDIO','PECUARIA','FIERRO','CURP'];
  const hits = palabras.reduce((n,p) => n + (t.includes(p) ? 1 : 0), 0);
  const letras = (t.match(/[A-ZÁÉÍÓÚÑ]/g) || []).length;
  const numeros = (t.match(/\d/g) || []).length;
  const raros = (t.match(/[^A-ZÁÉÍÓÚÑ0-9\s.,:;\/()-]/g) || []).length;
  let score = hits * 18 + Math.min(30, letras / 18) + Math.min(15, numeros / 10) - Math.min(25, raros / 8);
  if (tipoDocumento === 'tabla' && /IDENTIFICADOR/.test(t)) score += 20;
  if (tipoDocumento === 'credencial' && /CREDENCIAL/.test(t)) score += 20;
  if (tipoDocumento === 'formulario' && (/SENASICA/.test(t) || /PRODUCTOR/.test(t))) score += 15;
  return score;
}
function crearVariantePreprocesadaOCR(dataUrl, modo='contraste'){
  return new Promise(async (resolve,reject)=>{
    try{
      const img=await cargarImagenOCR(dataUrl), c=canvasDesdeImagenOCR(img,modo==='nitida'?2400:2100);
      aplicarMejorasImagenOCR(c,modo);
      resolve(c.toDataURL('image/jpeg',modo==='binario'?.9:.94));
    }catch(e){reject(e);}
  });
}
async function generarVariantesOCR(dataUrl, tipoDocumento, puntajeInicial){
  const variantes=[{dataUrl, etiqueta:'base'}];
  const rescate=tipoDocumento==='tabla'||puntajeInicial<85;
  if(!rescate) return variantes;
  try{variantes.push({dataUrl:await crearVariantePreprocesadaOCR(dataUrl,'nitida'),etiqueta:'nitida-iluminacion-denoise'});}catch(e){}
  try{variantes.push({dataUrl:await crearVariantePreprocesadaOCR(dataUrl,'contraste'),etiqueta:'contraste-iluminacion'});}catch(e){}
  if(tipoDocumento==='tabla'||puntajeInicial<45) try{variantes.push({dataUrl:await crearVariantePreprocesadaOCR(dataUrl,'binario'),etiqueta:'binarizacion-adaptativa'});}catch(e){}
  return variantes;
}
function rotarDataUrlOCR(dataUrl, grados){
  return new Promise((resolve,reject)=>{
    const img = new Image();
    img.onload = () => {
      const ang = ((grados % 360) + 360) % 360;
      const canvas = document.createElement('canvas');
      const swap = ang === 90 || ang === 270;
      canvas.width = swap ? img.height : img.width;
      canvas.height = swap ? img.width : img.height;
      const ctx = canvas.getContext('2d');
      ctx.translate(canvas.width/2, canvas.height/2);
      ctx.rotate(ang*Math.PI/180);
      ctx.drawImage(img, -img.width/2, -img.height/2);
      resolve(canvas.toDataURL('image/jpeg', .9));
    };
    img.onerror = reject; img.src = dataUrl;
  });
}
// Tesseract, dejado en automático (su comportamiento por defecto), intenta
// adivinar solo cómo está acomodado el texto en la imagen — con documentos
// reales (logos, bordes, fotografía de la persona, QR) eso lo confunde y
// empeora la lectura. Indicarle de antemano cómo está distribuido el texto
// según el TIPO de documento (una tarjeta con bloques sueltos no se lee
// igual que una constancia en párrafos, ni que una tabla) mejora la
// precisión sin tocar nada de velocidad ni pesar más la descarga — es un
// parámetro del mismo Tesseract, no un motor distinto.
// 'credencial' → bloques de texto cortos y una columna principal (PSM 6) — en
//   este formato oficial resultó más estable que el modo disperso para leer
//   CURP, folio, actividad y UPP aun cuando la foto trae logo/QR/retrato.
// 'formulario' → texto en párrafos/renglones seguidos, un solo bloque
//   (PSM 6) — constancias UPP, documentos oficiales tipo carta.
// 'tabla' → filas de datos alineadas (PSM 6 también funciona bien para
//   tablas simples de una sola columna ancha, mejor que el automático).
const MODO_SEGMENTACION_OCR = { credencial: '6', formulario: '6', tabla: '6', tabla_id: '11' };
async function extraerTextoDeImagen(dataUrl, onEstado, tipoDocumento){
return encolarLecturaOCR(async () => {
try { if (onEstado) onEstado('descargando'); await cargarTesseractSiNecesario(); }
catch(e){ throw new Error('No se pudo descargar el lector de texto — revisa tu conexión a internet e inténtalo de nuevo'); }
if (onEstado) onEstado('leyendo');
const psm = MODO_SEGMENTACION_OCR[tipoDocumento] || null;
async function intentarLectura(imagen, psmAUsar){
  const parametrosExtra = psmAUsar ? { tessedit_pageseg_mode: psmAUsar } : {};
  if (tipoDocumento === 'tabla_id') parametrosExtra.tessedit_char_whitelist = '0123456789';
  try {
    const resultado = await window.Tesseract.recognize(imagen, 'spa', {
      langPath: 'https://cdn.jsdelivr.net/npm/@tesseract.js-data/spa@1.0.0/4.0.0_fast/',
      ...parametrosExtra,
    });
    return (resultado && resultado.data && resultado.data.text) || '';
  } catch(e){
    const resultado = await window.Tesseract.recognize(imagen, 'spa', parametrosExtra);
    return (resultado && resultado.data && resultado.data.text) || '';
  }
}
let imagenElegida = dataUrl;
// Autoescáner previo al OCR: detecta el documento, corrige perspectiva y después
// trabaja sobre una copia; la fotografía original nunca se modifica ni se pierde.
try{
  if (onEstado) onEstado('preprocesando');
  const auto = await detectarYEnderezarDocumentoOCR(dataUrl);
  if (auto.detectado) imagenElegida = auto.dataUrl;
} catch(e){ console.warn('Autoescáner no disponible; continúa OCR normal',e); }
let texto = await intentarLectura(imagenElegida, psm);
let mejorPuntaje = puntuarTextoOCR(texto, tipoDocumento);
// Segunda estrategia de imagen: una foto puede tener texto visible para el ojo
// pero poco contraste para Tesseract. Probamos un enfoque suave y, en tablas o
// lecturas pobres, binarización. Se conserva siempre la variante con mejor
// puntuación semántica, no simplemente la que devolvió más caracteres.
const variantes = await generarVariantesOCR(imagenElegida, tipoDocumento, mejorPuntaje);
for (const v of variantes.slice(1)){
  try{
    const t=await intentarLectura(v.dataUrl, psm);
    const score=puntuarTextoOCR(t,tipoDocumento);
    if(score > mejorPuntaje + 2){ imagenElegida=v.dataUrl; texto=t; mejorPuntaje=score; }
  }catch(e){ console.warn('Variante OCR omitida',v.etiqueta,e); }
}
// Corrección automática de orientación. La constancia PGN que acabamos de probar
// puede llegar fotografiada de lado; longitud de texto por sí sola NO detecta el
// error porque una foto girada todavía produce cientos de caracteres basura.
// Cuando la foto es horizontal y el documento esperado es formulario, probamos
// 90° y 270° y conservamos la orientación con mejor puntuación semántica.
if ((tipoDocumento === 'formulario' && mejorPuntaje < 70) || (tipoDocumento === 'tabla' && mejorPuntaje < 85) || mejorPuntaje < 20){
  const imgInfo = await new Promise(resolve=>{ const im=new Image(); im.onload=()=>resolve({w:im.width,h:im.height}); im.onerror=()=>resolve(null); im.src=imagenElegida; });
  const deberiaProbarGiro = imgInfo && ((tipoDocumento === 'formulario' && imgInfo.w > imgInfo.h*1.12) || (tipoDocumento === 'tabla' && imgInfo.w > imgInfo.h*1.05 && mejorPuntaje < 85) || mejorPuntaje < 20);
  if (deberiaProbarGiro){
    for (const ang of [90,270]){
      try{
        const candidata = await rotarDataUrlOCR(imagenElegida, ang);
        const textoCandidato = await intentarLectura(candidata, psm);
        const puntaje = puntuarTextoOCR(textoCandidato, tipoDocumento);
        if (puntaje > mejorPuntaje + 3){ imagenElegida = candidata; texto = textoCandidato; mejorPuntaje = puntaje; }
      }catch(e){ console.warn('No se pudo probar orientación OCR', ang, e); }
    }
  }
}
// Segundo intento con segmentación automática cuando la lectura específica quedó
// pobre. Esto recupera fotos recortadas de forma distinta sin obligar al usuario
// a repetir la captura.
if (psm && (texto.trim().length < 12 || mejorPuntaje < 22)){
  const textoAutomatico = await intentarLectura(imagenElegida, null);
  if (puntuarTextoOCR(textoAutomatico, tipoDocumento) > mejorPuntaje || textoAutomatico.trim().length > texto.trim().length*1.35) texto = textoAutomatico;
}
return texto;
});
}
// ================= AJUSTE DE ESQUINAS ESTILO ESCÁNER (recorte + enderezado) =================
// Después de tomar cualquier foto de documento, se muestra un recuadro de 4
// puntos arrastrables sobre la foto para marcar las esquinas reales del
// documento. Al confirmar, se recorta y se "endereza" matemáticamente (como
// si se hubiera tomado la foto de frente) usando matemáticas puras de
// JavaScript (una transformación de perspectiva/homografía) — sin ninguna
// librería externa ni descarga extra, para no repetir el mismo problema que
// tuvimos con el paquete de idioma pesado de Tesseract en señal débil.
// Con honestidad: los 4 puntos NO arrancan detectados automáticamente por
// visión de computadora (eso sí necesitaría una librería pesada tipo
// OpenCV.js, ~8MB) — arrancan en un recuadro con margen fijo, y la persona
// siempre confirma o ajusta antes de continuar. Lo que sí es real y
// funciona siempre: el recorte y enderezado en sí, una vez marcadas las
// esquinas — que es lo que más ayuda a que el lector de texto lea bien.
let resolverAjusteEsquinas = null;
let esquinasActuales = null;
let geometriaAjusteEsquinas = { left:0, top:0, escala:1 };
let puntoEsquinaArrastrando = null;
let arrastreEsquinasListo = false;
function mostrarModalAjustarEsquinas(archivo){
return new Promise((resolve) => {
resolverAjusteEsquinas = resolve;
const modal = document.getElementById('modal-ajustar-esquinas');
const imgEl = document.getElementById('ajustar-esquinas-img');
const lector = new FileReader();
lector.onload = () => {
imgEl.onload = () => {
modal.classList.remove('hidden');
if (!arrastreEsquinasListo){ inicializarArrastreEsquinas(); arrastreEsquinasListo = true; }
const margen = 0.06;
const w = imgEl.naturalWidth, h = imgEl.naturalHeight;
esquinasActuales = [
{ x: w*margen, y: h*margen }, { x: w*(1-margen), y: h*margen },
{ x: w*(1-margen), y: h*(1-margen) }, { x: w*margen, y: h*(1-margen) },
];
requestAnimationFrame(() => { actualizarGeometriaAjusteEsquinas(); dibujarEsquinasAjuste(); });
};
imgEl.src = lector.result;
};
lector.onerror = () => { modal.classList.add('hidden'); resolve(null); };
lector.readAsDataURL(archivo);
});
}
function actualizarGeometriaAjusteEsquinas(){
const imgEl = document.getElementById('ajustar-esquinas-img');
const cont = document.getElementById('ajustar-esquinas-lienzo-cont');
const rectImg = imgEl.getBoundingClientRect();
const rectCont = cont.getBoundingClientRect();
geometriaAjusteEsquinas = {
left: rectImg.left - rectCont.left, top: rectImg.top - rectCont.top,
escala: rectImg.width / (imgEl.naturalWidth || 1),
};
}
function dibujarEsquinasAjuste(){
const puntosDom = document.querySelectorAll('.ajustar-esquinas-punto');
const g = geometriaAjusteEsquinas;
const coords = [];
esquinasActuales.forEach((p, i) => {
const sx = g.left + p.x * g.escala, sy = g.top + p.y * g.escala;
if (puntosDom[i]){ puntosDom[i].style.left = sx + 'px'; puntosDom[i].style.top = sy + 'px'; }
coords.push(sx + ',' + sy);
});
const poligono = document.getElementById('ajustar-esquinas-poligono');
if (poligono) poligono.setAttribute('points', coords.join(' '));
}
function inicializarArrastreEsquinas(){
const cont = document.getElementById('ajustar-esquinas-lienzo-cont');
cont.addEventListener('pointerdown', (ev) => {
if (!ev.target.classList || !ev.target.classList.contains('ajustar-esquinas-punto')) return;
puntoEsquinaArrastrando = parseInt(ev.target.dataset.punto, 10);
try { ev.target.setPointerCapture(ev.pointerId); } catch(e){}
});
cont.addEventListener('pointermove', (ev) => {
if (puntoEsquinaArrastrando == null) return;
const rectCont = cont.getBoundingClientRect();
const imgEl = document.getElementById('ajustar-esquinas-img');
const g = geometriaAjusteEsquinas;
let nx = (ev.clientX - rectCont.left - g.left) / (g.escala || 1);
let ny = (ev.clientY - rectCont.top - g.top) / (g.escala || 1);
nx = Math.max(0, Math.min(imgEl.naturalWidth, nx));
ny = Math.max(0, Math.min(imgEl.naturalHeight, ny));
esquinasActuales[puntoEsquinaArrastrando] = { x: nx, y: ny };
dibujarEsquinasAjuste();
});
const soltarPunto = () => { puntoEsquinaArrastrando = null; };
cont.addEventListener('pointerup', soltarPunto);
cont.addEventListener('pointercancel', soltarPunto);
window.addEventListener('resize', () => { if (!document.getElementById('modal-ajustar-esquinas').classList.contains('hidden')){ actualizarGeometriaAjusteEsquinas(); dibujarEsquinasAjuste(); } });
}
function cancelarAjusteEsquinas(){
document.getElementById('modal-ajustar-esquinas').classList.add('hidden');
if (resolverAjusteEsquinas) resolverAjusteEsquinas(null);
resolverAjusteEsquinas = null;
}
function confirmarAjusteEsquinas(){
const modal = document.getElementById('modal-ajustar-esquinas');
const imgEl = document.getElementById('ajustar-esquinas-img');
try {
const esquinasOrdenadas = ordenarEsquinasCuadrilatero(esquinasActuales);
const canvasResultado = recortarYEnderezarImagen(imgEl, esquinasOrdenadas);
canvasResultado.toBlob((blob) => {
modal.classList.add('hidden');
if (resolverAjusteEsquinas) resolverAjusteEsquinas(blob || null);
resolverAjusteEsquinas = null;
}, 'image/jpeg', 0.9);
} catch(e){
console.warn('No se pudo recortar/enderezar, se usa la foto completa sin recortar', e);
mostrarToast('No se pudo procesar el recorte — se usa la foto completa');
modal.classList.add('hidden');
if (resolverAjusteEsquinas) resolverAjusteEsquinas(null);
resolverAjusteEsquinas = null;
}
}
// Ordena las 4 esquinas (arrastradas en cualquier orden) como
// arriba-izquierda, arriba-derecha, abajo-derecha, abajo-izquierda —
// necesario para que el recorte no salga volteado si alguien arrastró un
// punto "de más" sobre otro.
function ordenarEsquinasCuadrilatero(puntos){
const suma = puntos.map(p => p.x + p.y);
const resta = puntos.map(p => p.x - p.y);
const tl = puntos[suma.indexOf(Math.min(...suma))];
const br = puntos[suma.indexOf(Math.max(...suma))];
const tr = puntos[resta.indexOf(Math.max(...resta))];
const bl = puntos[resta.indexOf(Math.min(...resta))];
return [tl, tr, br, bl];
}
function distanciaPuntos(a, b){ return Math.hypot(a.x - b.x, a.y - b.y); }
// Resuelve un sistema de 8 ecuaciones lineales (eliminación de Gauss con
// pivote parcial) — es la matemática detrás de "estirar" un cuadrilátero
// torcido hasta volverlo un rectángulo derecho (transformación de
// perspectiva/homografía), sin depender de ninguna librería externa.
function resolverSistemaLineal8x8(A, b){
const n = 8;
const M = A.map((fila, i) => fila.concat([b[i]]));
for (let col = 0; col < n; col++){
let filaMax = col;
for (let r = col+1; r < n; r++) if (Math.abs(M[r][col]) > Math.abs(M[filaMax][col])) filaMax = r;
const tmp = M[col]; M[col] = M[filaMax]; M[filaMax] = tmp;
if (Math.abs(M[col][col]) < 1e-10) continue;
for (let r = 0; r < n; r++){
if (r === col) continue;
const factor = M[r][col] / M[col][col];
for (let c = col; c <= n; c++) M[r][c] -= factor * M[col][c];
}
}
const x = new Array(n);
for (let i = 0; i < n; i++) x[i] = M[i][i] ? M[i][n] / M[i][i] : 0;
return x;
}
function calcularHomografia(origen, destino){
const A = []; const b = [];
for (let i = 0; i < 4; i++){
const { x, y } = origen[i]; const X = destino[i].x, Y = destino[i].y;
A.push([x, y, 1, 0, 0, 0, -x*X, -y*X]); b.push(X);
A.push([0, 0, 0, x, y, 1, -x*Y, -y*Y]); b.push(Y);
}
return resolverSistemaLineal8x8(A, b); // 8 valores; el 9no término de la matriz siempre es 1
}
function aplicarHomografia(h, x, y){
const denom = h[6]*x + h[7]*y + 1;
if (Math.abs(denom) < 1e-9) return { x: -1, y: -1 };
return { x: (h[0]*x + h[1]*y + h[2]) / denom, y: (h[3]*x + h[4]*y + h[5]) / denom };
}
function muestrearPixelBilineal(datosImg, x, y){
const w = datosImg.width, h = datosImg.height;
if (x < 0 || y < 0 || x >= w-1 || y >= h-1) return [255,255,255];
const x0 = Math.floor(x), y0 = Math.floor(y), x1 = x0+1, y1 = y0+1;
const fx = x-x0, fy = y-y0;
const d = datosImg.data;
const px = (xx,yy,c) => d[(yy*w+xx)*4+c];
const r = [0,0,0];
for (let c = 0; c < 3; c++){
const arriba = px(x0,y0,c)*(1-fx) + px(x1,y0,c)*fx;
const abajo = px(x0,y1,c)*(1-fx) + px(x1,y1,c)*fx;
r[c] = arriba*(1-fy) + abajo*fy;
}
return r;
}
// Recorta y endereza la imagen usando las 4 esquinas marcadas — para cada
// píxel del resultado final (ya rectangular) calcula de qué píxel de la
// foto original viene (transformación inversa) y toma un promedio suave de
// los 4 píxeles más cercanos (muestreo bilineal) para que no se vea
// "picada". El ancho de salida se limita a 1400px — de sobra para que el
// lector de texto trabaje bien, sin tardar más de lo necesario en un
// celular de gama media.
function recortarYEnderezarImagen(imgEl, esquinas){
const [tl, tr, br, bl] = esquinas;
const anchoBruto = Math.max(distanciaPuntos(tl,tr), distanciaPuntos(bl,br));
const altoBruto = Math.max(distanciaPuntos(tl,bl), distanciaPuntos(tr,br));
if (anchoBruto < 20 || altoBruto < 20) throw new Error('El recuadro marcado es demasiado pequeño');
const anchoFinal = Math.min(1400, Math.max(200, Math.round(anchoBruto)));
const altoFinal = Math.max(200, Math.round(anchoFinal * (altoBruto / anchoBruto)));
const canvasOrigen = document.createElement('canvas');
canvasOrigen.width = imgEl.naturalWidth; canvasOrigen.height = imgEl.naturalHeight;
canvasOrigen.getContext('2d').drawImage(imgEl, 0, 0);
const datosOrigen = canvasOrigen.getContext('2d').getImageData(0, 0, canvasOrigen.width, canvasOrigen.height);
const destino = [{x:0,y:0},{x:anchoFinal,y:0},{x:anchoFinal,y:altoFinal},{x:0,y:altoFinal}];
const h = calcularHomografia(destino, esquinas); // mapea destino -> fuente (para muestrear hacia atrás)
const canvasDestino = document.createElement('canvas');
canvasDestino.width = anchoFinal; canvasDestino.height = altoFinal;
const ctxDestino = canvasDestino.getContext('2d');
const datosDestino = ctxDestino.createImageData(anchoFinal, altoFinal);
for (let Y = 0; Y < altoFinal; Y++){
for (let X = 0; X < anchoFinal; X++){
const { x: sx, y: sy } = aplicarHomografia(h, X, Y);
const rgb = muestrearPixelBilineal(datosOrigen, sx, sy);
const idx = (Y*anchoFinal + X) * 4;
datosDestino.data[idx] = rgb[0]; datosDestino.data[idx+1] = rgb[1]; datosDestino.data[idx+2] = rgb[2]; datosDestino.data[idx+3] = 255;
}
}
ctxDestino.putImageData(datosDestino, 0, 0);
return canvasDestino;
}
// Convierte el Blob recortado/enderezado en un File y lo pone de vuelta en
// el <input type="file"> — así todo el resto del código (que siempre relee
// el archivo directo del input) recibe automáticamente la versión ya
// corregida, sin tener que tocar ninguna otra función.
function reemplazarArchivoDeInput(inputEl, blob, nombreOriginal){
try {
const archivoNuevo = new File([blob], (nombreOriginal || 'documento') + '_recortado.jpg', { type: 'image/jpeg' });
const dt = new DataTransfer();
dt.items.add(archivoNuevo);
inputEl.files = dt.files;
return archivoNuevo;
} catch(e){
console.warn('No se pudo reemplazar el archivo del input (navegador sin soporte de DataTransfer)', e);
return null;
}
}
async function previsualizarEscaneo(inputEl, idPreview, funcionExtraerAuto){
let archivo = inputEl.files && inputEl.files[0];
if (!archivo){ mostrarToast('No se recibió la foto. Tómala nuevamente.'); return; }
if (!String(archivo.type || '').startsWith('image/')){ mostrarToast('El archivo seleccionado no es una imagen.'); return; }
const img = document.getElementById(idPreview);
try {
  // Primero mostramos la foto inmediatamente. Así nunca parece que la cámara
  // “no capturó” mientras se procesa el recorte.
  const preview = await comprimirArchivoImagen(archivo, 1200, 0.82);
  if (img){ img.src = preview; img.classList.remove('hidden'); }
  const mapaAjustePreview={
    'esc-cred-frente-preview':'esc-cred-frente-ajustar',
    'esc-cred-reverso-preview':'esc-cred-reverso-ajustar',
    'esc-upp-preview':'esc-upp-ajustar',
    'esc-siniiga-preview':'esc-siniiga-ajustar',
    'pc-ocr-formato-preview':'pc-ocr-formato-ajustar'
  };
  const btnAjuste=document.getElementById(mapaAjustePreview[idPreview]);
  if(btnAjuste) btnAjuste.classList.remove('hidden');
  guardarBorradorEscaneoDoc();
  const nitidez = await evaluarNitidezImagenOCR(preview);
  if (nitidez && nitidez.varianza < 70) mostrarToast('La foto parece desenfocada. Puedes continuar, pero para una lectura confiable conviene tomarla otra vez más cerca y con buena luz.');
} catch(e){
  console.warn('No se pudo crear vista previa de la foto', e);
  mostrarToast('La foto llegó, pero el navegador no pudo procesarla. Tómala otra vez en JPG.');
  return;
}
// NO bloqueamos la lectura esperando el recuadro de esquinas. En celulares esto
// hacía que el usuario tomara la foto y luego pareciera que "no pasó nada" hasta
// que confirmara/cancelara otro paso. La lectura empieza inmediatamente con la
// fotografía original; el enderezado queda como mejora opcional mediante el botón
// "Enderezar documento". Si se aplica, vuelve a ejecutar el lector automáticamente.
if (typeof funcionExtraerAuto === 'function') funcionExtraerAuto();
}
async function ajustarYLeerEscaneo(inputId, previewId, funcionExtraerAuto){
  const input=document.getElementById(inputId);
  if(!input || !input.files || !input.files[0]){ mostrarToast('Primero toma o selecciona la foto del documento'); return; }
  try{
    const blob=await mostrarModalAjustarEsquinas(input.files[0]);
    if(!blob) return;
    const archivoNuevo=reemplazarArchivoDeInput(input,blob,input.files[0].name);
    if(!archivoNuevo){ mostrarToast('El navegador no permite sustituir la foto; conserva la original y vuelve a tomarla si hace falta'); return; }
    const img=document.getElementById(previewId);
    const preview=await comprimirArchivoImagen(archivoNuevo,1200,.82);
    if(img){ img.src=preview; img.classList.remove('hidden'); }
    guardarBorradorEscaneoDoc();
    if(typeof funcionExtraerAuto==='function') await funcionExtraerAuto();
  }catch(e){ console.warn('No se pudo enderezar el documento',e); mostrarToast('No se pudo enderezar la foto; se conserva la original'); }
}
// ================= BORRADOR LOCAL DEL ESCANEO DE DOCUMENTOS =================
// Guarda cada foto (ya comprimida por el propio preview en base64) y cada dato
// extraído/corregido en localStorage al instante, para no perder nada si la
// página se recarga a medio proceso (ej. al volver de la cámara nativa).
const CLAVE_BORRADOR_ESCANEO_DOC = 'miRanchAppBorradorEscaneoDocumentos';
let temporizadorBorradorEscaneoDoc = null;
function programarGuardadoBorradorEscaneoDoc(){
  clearTimeout(temporizadorBorradorEscaneoDoc);
  temporizadorBorradorEscaneoDoc = setTimeout(()=>{ temporizadorBorradorEscaneoDoc=null; guardarBorradorEscaneoDoc(); }, 350);
}
const MAPA_PREVIEWS_ESCANEO = {
'esc-cred-frente-preview': 'credFrente',
'esc-cred-reverso-preview': 'credReverso',
'esc-upp-preview': 'uppFoto',
'esc-siniiga-preview': 'siniigaFoto',
};
const CAMPOS_BORRADOR_ESCANEO = ['esc-cred-nombre','esc-cred-curp','esc-cred-folio','esc-cred-upp','esc-cred-actividad','esc-cred-domicilio','esc-cred-localidad','esc-cred-municipio','esc-cred-fierro','esc-cred-vigencia','esc-upp-numero','esc-upp-predio','esc-upp-finalidad','esc-upp-municipioestado','esc-upp-localidad','esc-upp-domicilio','esc-upp-referencias'];
function guardarBorradorEscaneoDoc(){
const pasoActivo = ['credencial','upp','siniiga','confirmar'].find(p => !document.getElementById('esc-paso-' + p)?.classList.contains('hidden')) || 'credencial';
const datos = {
paso: pasoActivo,
imagenes: {}, campos: {},
textosCrudos: {
credencial: document.getElementById('esc-cred-texto-crudo')?.textContent || '',
upp: document.getElementById('esc-upp-texto-crudo')?.textContent || '',
siniiga: document.getElementById('esc-siniiga-texto-crudo')?.textContent || '',
},
resultadosVisibles: {
credencial: !!(document.getElementById('esc-cred-resultado') && !document.getElementById('esc-cred-resultado').classList.contains('hidden')),
upp: !!(document.getElementById('esc-upp-resultado') && !document.getElementById('esc-upp-resultado').classList.contains('hidden')),
siniiga: !!(document.getElementById('esc-siniiga-resultado') && !document.getElementById('esc-siniiga-resultado').classList.contains('hidden')),
},
filasSINIIGATemp, fierroImagenEscaneoTemp,
guardadoEn: new Date().toISOString(),
};
Object.entries(MAPA_PREVIEWS_ESCANEO).forEach(([idImg, clave]) => {
const img = document.getElementById(idImg);
if (img && !img.classList.contains('hidden') && img.src && img.src.startsWith('data:')) datos.imagenes[clave] = img.src;
});
CAMPOS_BORRADOR_ESCANEO.forEach(id => { const el = document.getElementById(id); if (el) datos.campos[id] = el.value; });
try { localStorage.setItem(CLAVE_BORRADOR_ESCANEO_DOC, JSON.stringify(datos)); }
catch(e){ console.warn('No se pudo guardar el borrador de escaneo (el celular puede estar quedándose sin espacio local por fotos muy pesadas)', e); }
}
function limpiarBorradorEscaneoDoc(){
try { localStorage.removeItem(CLAVE_BORRADOR_ESCANEO_DOC); } catch(e){}
}
function restaurarBorradorEscaneoDoc(){
let datos = null;
try { datos = JSON.parse(localStorage.getItem(CLAVE_BORRADOR_ESCANEO_DOC) || 'null'); } catch(e){ datos = null; }
if (!datos) return;
Object.entries(MAPA_PREVIEWS_ESCANEO).forEach(([idImg, clave]) => {
if (datos.imagenes && datos.imagenes[clave]){
const img = document.getElementById(idImg);
if (img){
  img.src = datos.imagenes[clave]; img.classList.remove('hidden');
  const mapaAjuste={credFrente:'esc-cred-frente-ajustar',credReverso:'esc-cred-reverso-ajustar',uppFoto:'esc-upp-ajustar',siniigaFoto:'esc-siniiga-ajustar'};
  const b=document.getElementById(mapaAjuste[clave]); if(b) b.classList.remove('hidden');
}
}
});
Object.keys(datos.campos || {}).forEach(id => establecerValor(id, datos.campos[id]));
if (datos.textosCrudos){
if (datos.textosCrudos.credencial) document.getElementById('esc-cred-texto-crudo').textContent = datos.textosCrudos.credencial;
if (datos.textosCrudos.upp) document.getElementById('esc-upp-texto-crudo').textContent = datos.textosCrudos.upp;
if (datos.textosCrudos.siniiga) document.getElementById('esc-siniiga-texto-crudo').textContent = datos.textosCrudos.siniiga;
}
if (datos.resultadosVisibles){
if (datos.resultadosVisibles.credencial) document.getElementById('esc-cred-resultado').classList.remove('hidden');
if (datos.resultadosVisibles.upp) document.getElementById('esc-upp-resultado').classList.remove('hidden');
if (datos.resultadosVisibles.siniiga) document.getElementById('esc-siniiga-resultado').classList.remove('hidden');
}
filasSINIIGATemp = datos.filasSINIIGATemp || [];
fierroImagenEscaneoTemp = datos.fierroImagenEscaneoTemp || null;
if (filasSINIIGATemp.length > 0) renderFilasSINIIGA();
if (fierroImagenEscaneoTemp) renderVistaFierroGuardado('esc');
const huboAlgo = Object.keys(datos.imagenes || {}).length > 0 || Object.values(datos.campos || {}).some(v => v) || filasSINIIGATemp.length > 0;
if (huboAlgo) mostrarToast('Se restauró lo que ya habías escaneado — sigue donde ibas');
if (datos.paso) cambiarPasoEscaneo(datos.paso);
}
document.addEventListener('input', e => { if (e.target && CAMPOS_BORRADOR_ESCANEO.includes(e.target.id)) programarGuardadoBorradorEscaneoDoc(); });
function cambiarPasoEscaneo(paso){
['credencial','upp','siniiga','confirmar'].forEach(p => {
document.getElementById('esc-paso-' + p).classList.toggle('hidden', p !== paso);
const tab = document.getElementById('esc-tab-' + p);
tab.style.background = p === paso ? 'var(--pine)' : '';
tab.style.color = p === paso ? '#fff' : '';
});
if (paso === 'confirmar') actualizarResumenImportarEscaneo();
}
function abrirEscaneoDocumentos(){
cambiarPasoEscaneo('credencial');
irA('escaneo-documentos');
restaurarBorradorEscaneoDoc();
precargarTesseractEnSegundoPlano();
}
// ---- Paso 1: Credencial del productor ----
function extraerCURP(texto){
// El OCR suele confundir O/0, I/1, S/5 y B/8 en documentos oficiales.
// Para CURP solo corregimos esas ambigüedades EN LAS POSICIONES donde el
// formato de CURP permite una letra o un número; nunca alteramos el texto
// crudo que ve la persona.
const bruto = String(texto || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
const corregir = (s) => {
  const chars = s.split('');
  const letras = new Set([0,1,2,3,10,12,13,14,15]);
  const numeros = new Set([4,5,6,7,8,9,17]);
  letras.forEach(i => { if (chars[i] === '0') chars[i] = 'O'; else if (chars[i] === '1') chars[i] = 'I'; else if (chars[i] === '5') chars[i] = 'S'; else if (chars[i] === '8') chars[i] = 'B'; });
  numeros.forEach(i => { if (chars[i] === 'O') chars[i] = '0'; else if (chars[i] === 'I' || chars[i] === 'L') chars[i] = '1'; else if (chars[i] === 'S') chars[i] = '5'; else if (chars[i] === 'B') chars[i] = '8'; });
  return chars.join('');
};
for (let i = 0; i <= Math.max(0, bruto.length - 18); i++){
  const candidato = corregir(bruto.slice(i, i + 18));
  if (/^[A-Z]{4}\d{6}[HM][A-Z]{5}[A-Z0-9]\d$/.test(candidato)) return candidato;
}
return '';
}
// Respaldo para cuando el OCR no logra leer bien la palabra "UPP" como
// etiqueta (letras borrosas, mala luz, etc.) pero el número en sí sí se
// alcanza a leer — la clave UPP/PSG sigue un patrón reconocible de dígitos
// (ej. 10-023-0001) aunque la etiqueta de al lado haya salido ilegible.
function normalizarUPP(valor){
const bruto = String(valor || '').toUpperCase().replace(/[^A-Z0-9]/g,'');
const soloNumeros = bruto.replace(/[^0-9]/g,'');
return /^\d{12}$/.test(soloNumeros) ? soloNumeros : '';
}
function extraerUPPPorPatron(texto){
const limpio = String(texto || '').replace(/[–—]/g,'-');
const patrones = [
  /\b(\d{2}[-\s]?\d{3}[-\s]?\d{4}[-\s]?\d{3})\b/,
  /\b(\d{12})\b/,
  /\b(\d{2}[-\s]?\d{3}[-\s]?\d{3,4})\b/
];
for (const patron of patrones){
  const m = limpio.match(patron);
  if (m){
    const upp = normalizarUPP(m[1]);
    if (upp) return upp;
  }
}
return '';
}
function extraerNumeroTrasEtiqueta(texto, etiquetas){
// En formatos oficiales es común que la etiqueta comparta renglón con otro
// texto ("Título de Fierro de Herrar   Firma...") y el número quede abajo.
// Por eso primero buscamos un número en la misma línea y luego en las dos
// siguientes, pero rechazando renglones que claramente pertenecen a otro campo.
const lineas = String(texto || '').split(/\n+/).map(l=>l.trim()).filter(Boolean);
const etqs = [...etiquetas].sort((a,b)=>b.length-a.length).map(e=>normalizarParaBuscarEtiqueta(e));
for(let i=0;i<lineas.length;i++){
  const norm=normalizarParaBuscarEtiqueta(lineas[i]);
  for(const etq of etqs){
    const pos=norm.indexOf(etq); if(pos<0) continue;
    const resto=lineas[i].slice(pos + etq.length);
    const mismo=resto.match(/\b\d{4,}\b/); if(mismo) return mismo[0];
    for(let j=i+1;j<=Math.min(i+2,lineas.length-1);j++){
      const siguiente=lineas[j];
      const nNorm=normalizarParaBuscarEtiqueta(siguiente);
      if (/^(CC|EC|FOLIO|PROPIETARIO|NOMBRE|MUNICIPIO|ESTADO|DOMICILIO|LOCALIDAD)\b/.test(nNorm)) continue;
      const m=siguiente.match(/\b\d{4,}\b/); if(m) return m[0];
    }
  }
}
return '';
}
function extraerFechaISOTexto(texto, etiquetas=[]){
const valorFecha = extraerTrasEtiqueta(texto, etiquetas, etiquetas);
const m = String(valorFecha || '').match(/(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/);
if (!m) return '';
return `${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`;
}
// Letras/números que Tesseract confunde con frecuencia al leer sellos y
// encabezados de documentos oficiales en mayúsculas (0↔O, 1↔I, 5↔S, 8↔B,
// 6↔G) — se usan SOLO para encontrar DÓNDE está la etiqueta dentro del texto
// leído (ej. reconocer "D0MICILI0" como "DOMICILIO"), nunca para cambiar el
// valor real que se extrae y se muestra en el campo.
function normalizarParaBuscarEtiqueta(s){
return s.toUpperCase()
.replace(/0/g, 'O').replace(/1/g, 'I').replace(/5/g, 'S').replace(/8/g, 'B').replace(/6/g, 'G')
.replace(/[ÁÀÄ]/g,'A').replace(/[ÉÈË]/g,'E').replace(/[ÍÌÏ]/g,'I').replace(/[ÓÒÖ]/g,'O').replace(/[ÚÙÜ]/g,'U');
}
// tercer parámetro opcional: TODAS las etiquetas que pueden aparecer en este
// mismo documento (no solo las que se están buscando ahorita) — sirve para
// saber dónde CORTAR el valor si dos campos quedaron pegados en el mismo
// renglón del OCR (ej. "NOMBRE: JUAN CURP: ABCD..." ya no se lleva "CURP:
// ABCD..." como si fuera parte del nombre).
function extraerTrasEtiqueta(texto, etiquetas, etiquetasVecinas){
const lineas = texto.split(/\n+/).map(l => l.trim()).filter(Boolean);
// Las etiquetas se revisan de la más larga a la más corta: por ejemplo, si se
// busca "ACTIVIDAD" y también "TIPO DE ACTIVIDAD", antes se topaba primero con
// "ACTIVIDAD" (que también está contenida dentro de "TIPO DE ACTIVIDAD") y
// cortaba mal el texto, dejando basura como "TIPO DE : GANADERO" en vez de
// "GANADERO". Al revisar primero la etiqueta más larga y específica, esto ya
// no pasa. Mismo problema existía con "PREDIO"/"NOMBRE DEL PREDIO" y con
// "FINALIDAD"/"FINALIDAD ZOOTÉCNICA".
const etiquetasOrdenadas = [...etiquetas].sort((a, b) => b.length - a.length);
const etiquetasParaCorte = [...new Set([...(etiquetasVecinas || []), ...etiquetas])]
.sort((a, b) => b.length - a.length)
.map(e => ({ original: e, normalizada: normalizarParaBuscarEtiqueta(e) }));
for (let i = 0; i < lineas.length; i++){
const normalizadaLinea = normalizarParaBuscarEtiqueta(lineas[i]);
for (const etq of etiquetasOrdenadas){
const etqNormalizada = normalizarParaBuscarEtiqueta(etq);
const posicion = normalizadaLinea.indexOf(etqNormalizada);
if (posicion === -1) continue;
let resto = lineas[i].slice(posicion + etq.length).replace(/^[:\s.\-\[\]{}()|!]+/, '').trim();
// Corta el valor si más adelante en el mismo renglón aparece la etiqueta
// de OTRO campo del mismo documento (evita que se mezclen dos datos).
const restoNormalizado = normalizarParaBuscarEtiqueta(resto);
let cortarEn = -1;
for (const otra of etiquetasParaCorte){
if (otra.normalizada === etqNormalizada) continue;
const pos = restoNormalizado.indexOf(otra.normalizada);
if (pos !== -1 && (cortarEn === -1 || pos < cortarEn)) cortarEn = pos;
}
if (cortarEn !== -1) resto = resto.slice(0, cortarEn).replace(/[:\s.-]+$/, '').trim();
if (resto && resto.length > 1) return resto.replace(/^[\[\]{}()|!]+/,'').trim();
const siguienteEsOtraEtiqueta = lineas[i+1] && etiquetasParaCorte.some(e => normalizarParaBuscarEtiqueta(lineas[i+1]).includes(e.normalizada));
if (lineas[i+1] && !siguienteEsOtraEtiqueta) return lineas[i+1].trim().replace(/^[\[\]{}()|!]+/,'').trim();
}
}
return '';
}
let credencialLecturaEnCurso = false;
let credencialLecturaPendiente = false;
async function extraerDatosCredencial(){
if (credencialLecturaEnCurso){ credencialLecturaPendiente = true; return; }
credencialLecturaEnCurso = true;
try {
const frenteArchivo = document.getElementById('esc-cred-frente-input')?.files?.[0];
const reversoArchivo = document.getElementById('esc-cred-reverso-input')?.files?.[0];
if (!frenteArchivo && !reversoArchivo){ mostrarToast('Toma al menos una foto (frente o reverso)'); return; }
const boton = document.getElementById('esc-cred-btn-extraer');
boton.disabled = true; boton.textContent = 'Leyendo...';
const cambiarEstadoBoton = estado => { boton.textContent = estado === 'descargando' ? 'Descargando lector de texto...' : 'Leyendo...'; };
try {
let textoFrente = '', textoReverso = '';
if (frenteArchivo) textoFrente = await extraerTextoDeImagen(await comprimirParaOCR(frenteArchivo), cambiarEstadoBoton, 'credencial');
if (reversoArchivo) textoReverso = await extraerTextoDeImagen(await comprimirParaOCR(reversoArchivo), cambiarEstadoBoton, 'credencial');
const textoCompleto = textoFrente + '\n' + textoReverso;
const etiquetasFrenteCred = ['FOLIO PRODUCTOR', 'FOLIO DEL PRODUCTOR', 'OLIO PRODUCTOR', 'ACT. PRIM', 'CT. PRIM', 'ACT. SEC', 'CT. SEC', 'NOMBRE DEL PRODUCTOR', 'NOMBRE DEL TITULAR', 'NOMBRE COMPLETO', 'NOMBRE(S)', 'NOMBRE', 'OMBRE', 'TITULAR', 'FOLIO', 'OLIO', 'NO. DE FOLIO', 'FOLIO DEL PADRON', 'UPP', 'U.P.P.', 'PP', 'UNIDAD DE PRODUCCION PECUARIA', 'ACTIVIDAD', 'TIPO DE ACTIVIDAD'];
const etiquetasReversoCred = ['TÍTULO DE FIERRO DE HERRAR', 'TITULO DE FIERRO DE HERRAR', 'TITULO DE FIERRA DE HERRAR', 'DOMICILIO', 'DOMICILLO', 'DOMICILIO PARTICULAR', 'DIRECCIÓN', 'DIRECCION', 'LOCALIDAD', 'MUNICIPIO'];
establecerValor('esc-cred-curp', extraerCURP(textoCompleto));
establecerValor('esc-cred-nombre', extraerTrasEtiqueta(textoFrente, ['NOMBRE DEL PRODUCTOR', 'NOMBRE DEL TITULAR', 'NOMBRE COMPLETO', 'NOMBRE(S)', 'NOMBRE', 'OMBRE', 'TITULAR'], etiquetasFrenteCred));
const folioCred = extraerTrasEtiqueta(textoFrente, ['FOLIO PRODUCTOR', 'FOLIO DEL PRODUCTOR', 'OLIO PRODUCTOR'], etiquetasFrenteCred) || extraerTrasEtiqueta(textoFrente, ['FOLIO', 'NO. DE FOLIO'], etiquetasFrenteCred);
establecerValor('esc-cred-folio', folioCred);
const uppCred = normalizarUPP(extraerTrasEtiqueta(textoFrente, ['UPP','U.P.P.'], etiquetasFrenteCred)) || extraerUPPPorPatron(textoFrente);
establecerValor('esc-cred-upp', uppCred);
const actPrim = extraerTrasEtiqueta(textoFrente, ['ACT. PRIM', 'CT. PRIM'], etiquetasFrenteCred);
const actSec = extraerTrasEtiqueta(textoFrente, ['ACT. SEC', 'CT. SEC'], etiquetasFrenteCred);
establecerValor('esc-cred-actividad', actPrim || actSec || extraerTrasEtiqueta(textoFrente, ['ACTIVIDAD', 'TIPO DE ACTIVIDAD'], etiquetasFrenteCred));
establecerValor('esc-cred-domicilio', extraerTrasEtiqueta(textoReverso, ['DOMICILIO', 'DOMICILLO', 'DOMICILIO PARTICULAR', 'DIRECCIÓN', 'DIRECCION'], etiquetasReversoCred));
establecerValor('esc-cred-localidad', extraerTrasEtiqueta(textoReverso, ['LOCALIDAD'], etiquetasReversoCred));
establecerValor('esc-cred-municipio', extraerTrasEtiqueta(textoReverso, ['MUNICIPIO'], etiquetasReversoCred));
establecerValor('esc-cred-fierro', extraerNumeroTrasEtiqueta(textoReverso, ['TÍTULO DE FIERRO DE HERRAR','TITULO DE FIERRO DE HERRAR','TITULO DE FIERRA DE HERRAR']));
establecerValor('esc-cred-vigencia', extraerTrasEtiqueta(textoFrente, ['VIGENCIA'], etiquetasFrenteCred));
document.getElementById('esc-cred-texto-crudo').textContent = textoCompleto.trim() || '(no se detectó texto legible)';
document.getElementById('esc-cred-resultado').classList.remove('hidden');
guardarBorradorEscaneoDoc();
mostrarToast('Listo — revisa los datos, la lectura automática puede tener errores');
} catch(e){
mostrarToast('No se pudo leer la foto: ' + e.message);
} finally {
boton.disabled = false; boton.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles"></i> Extraer datos de la credencial';
}
} finally {
credencialLecturaEnCurso = false;
// Si mientras leía llegó otra foto (ej. tomaron el reverso justo durante la
// lectura del frente), se vuelve a leer una vez más al terminar — así se
// toman en cuenta las dos fotos sin haber corrido nada encimado.
if (credencialLecturaPendiente){ credencialLecturaPendiente = false; extraerDatosCredencial(); }
}
}
function iniciarRecorteDesdeEscaneo(){
const archivo = document.getElementById('esc-cred-reverso-input')?.files?.[0];
if (!archivo){ mostrarToast('Primero toma la foto del reverso de la credencial'); return; }
// Antes esto cargaba la foto ORIGINAL sin comprimir (varios MB, resolución
// completa de la cámara) para el recorte — justo la foto trasera, que se toma
// después de la delantera y después de correr el OCR sobre ella, era la que más
// memoria acumulada tenía en ese momento y la que más frecuentemente hacía que
// el navegador recargara la página de golpe (lo que se sentía como "me saca de
// la cuenta"). Ahora se comprime primero, a color (no la versión en blanco y
// negro que usa el OCR) — sigue siendo grande de sobra para recortar bien la
// figura del fierro a mano.
comprimirParaRecorte(archivo, 1800).then(dataUrlComprimido => {
const img = new Image();
img.onload = () => {
document.getElementById('esc-fierro-recorte-cont').classList.remove('hidden');
const canvas = document.getElementById('esc-fierro-canvas');
const wrap = document.getElementById('esc-fierro-lienzo-wrap');
const anchoMax = Math.min(wrap.clientWidth || 340, 480);
const escala = anchoMax / img.width;
canvas.width = anchoMax; canvas.height = img.height * escala;
canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
RECORTE_FIERRO_ESTADO['esc'] = { imgOriginal: img, escala, rect: null, arrastrando: false, inicioX: 0, inicioY: 0 };
activarArrastreRecorteFierro('esc');
sugerirRecorteFierroAutomatico('esc');
};
img.onerror = () => mostrarToast('No se pudo abrir la foto para recortar — vuelve a tomarla');
img.src = dataUrlComprimido;
}).catch(() => mostrarToast('No se pudo abrir la foto para recortar — vuelve a tomarla'));
}
// ---- Paso 2: Constancia UPP ----
let uppLecturaEnCurso = false;
let uppLecturaPendiente = false;
async function extraerDatosConstanciaUPP(){
if (uppLecturaEnCurso){ uppLecturaPendiente = true; return; }
uppLecturaEnCurso = true;
try {
const archivo = document.getElementById('esc-upp-input')?.files?.[0];
if (!archivo){ mostrarToast('Primero toma la foto de la constancia'); return; }
const boton = document.getElementById('esc-upp-btn-extraer');
boton.disabled = true; boton.textContent = 'Leyendo...';
try {
const texto = await extraerTextoDeImagen(await comprimirParaOCR(archivo), estado => { boton.textContent = estado === 'descargando' ? 'Descargando lector de texto...' : 'Leyendo...'; }, 'formulario');
const etiquetasUPP = ['DATOS PRODUCTOR UPP', 'NOMBRE (DEL RANCHO)', 'NOMBRE DEL RANCHO', 'NOMBRE DEL PREDIO', 'NOMBRE DEL PREDIO PECUARIO', 'PREDIO', 'UNIDAD DE PRODUCCIÓN PECUARIA', 'UNIDAD DE PRODUCCION PECUARIA', 'UNIDAD DE PRODUCCIÓN', 'FINALIDAD ZOOTÉCNICA', 'FINALIDAD ZOOTECNICA', 'FINALIDAD', 'LOCALIDAD/PARAJE', 'LOCALIDAD', 'MUNICIPIO', 'ESTADO', 'CÓMO LLEGAR AL PREDIO', 'COMO LLEGAR AL PREDIO', 'OMO LLEGAR AL PREDIO', 'REFERENCIA', 'LOCALIZACIÓN', 'LOCALIZACION', 'UBICACIÓN', 'DOMICILIO DEL PREDIO', 'CALLE Y NÚMERO', 'COLONIA'];
const uppNumero = extraerUPPPorPatron(texto);
establecerValor('esc-upp-numero', uppNumero);
establecerValor('esc-upp-predio', extraerTrasEtiqueta(texto, ['NOMBRE (DEL RANCHO)', 'NOMBRE DEL RANCHO', 'NOMBRE DEL PREDIO', 'PREDIO', 'UNIDAD DE PRODUCCIÓN'], etiquetasUPP));
establecerValor('esc-upp-finalidad', extraerTrasEtiqueta(texto, ['FINALIDAD ZOOTÉCNICA', 'FINALIDAD ZOOTECNICA', 'FINALIDAD'], etiquetasUPP));
// El campo es "Municipio / Estado" (los dos datos juntos) — antes solo se
// quedaba con el que apareciera primero en el texto (municipio O estado, no
// ambos). Ahora se buscan por separado y se combinan si los dos se
// encontraron, para no perder el que quedaba descartado.
const municipioUPP = extraerTrasEtiqueta(texto, ['MUNICIPIO'], etiquetasUPP);
const estadoUPP = extraerTrasEtiqueta(texto, ['ESTADO'], etiquetasUPP);
const localidadUPP = extraerTrasEtiqueta(texto, ['LOCALIDAD/PARAJE','LOCALIDAD'], etiquetasUPP);
const domicilioUPP = extraerTrasEtiqueta(texto, ['CALLE Y NÚMERO'], etiquetasUPP);
const coloniaUPP = extraerTrasEtiqueta(texto, ['COLONIA'], etiquetasUPP);
const llegadaUPP = extraerTrasEtiqueta(texto, ['CÓMO LLEGAR AL PREDIO','COMO LLEGAR AL PREDIO','OMO LLEGAR AL PREDIO'], etiquetasUPP);
establecerValor('esc-upp-municipioestado', [municipioUPP, estadoUPP].filter(Boolean).join(', '));
establecerValor('esc-upp-localidad', localidadUPP);
establecerValor('esc-upp-domicilio', [domicilioUPP, coloniaUPP].filter(Boolean).join(', '));
establecerValor('esc-upp-referencias', llegadaUPP || extraerTrasEtiqueta(texto, ['REFERENCIA', 'LOCALIZACIÓN', 'LOCALIZACION', 'UBICACIÓN'], etiquetasUPP));
document.getElementById('esc-upp-texto-crudo').textContent = texto.trim() || '(no se detectó texto legible)';
document.getElementById('esc-upp-resultado').classList.remove('hidden');
guardarBorradorEscaneoDoc();
mostrarToast('Listo — revisa los datos, la lectura automática puede tener errores');
} catch(e){
mostrarToast('No se pudo leer la foto: ' + e.message);
} finally {
boton.disabled = false; boton.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles"></i> Extraer datos de la constancia';
}
} finally {
uppLecturaEnCurso = false;
if (uppLecturaPendiente){ uppLecturaPendiente = false; extraerDatosConstanciaUPP(); }
}
}
// ---- Paso 3: Documento SINIIGA ----
// Convierte el prefijo "00" de un identificador SINIIGA por "MX", como lo exige
// el estándar de aretes oficiales (ej. 001023001675 -> MX1023001675).
function convertirAreteMX(id){
if (!id) return id;
const limpio = String(id).replace(/\s+/g, '');
return limpio.startsWith('00') ? 'MX' + limpio.slice(2) : limpio;
}
let filasSINIIGATemp = [];
async function extraerIdentificadoresSINIIGADirigidos(dataUrl){
  return new Promise((resolve) => {
    try{
      const img=new Image();
      img.onload=async()=>{
        const encontrados=new Map();
        // El formato oficial suele mantener la columna de identificadores en la
        // zona izquierda, pero el encuadre de la fotografía cambia. En lugar de
        // depender de un solo recorte fijo, probamos 3 ventanas ligeramente
        // distintas y dos segmentaciones. Todos los resultados se deduplican.
        const perfiles=[
          {x:.12,y:.27,w:.28,h:.38},
          {x:.14,y:.30,w:.22,h:.34},
          {x:.10,y:.24,w:.34,h:.45},
          {x:.15,y:.28,w:.24,h:.42}
        ];
        for(const perfil of perfiles){
          const sx=Math.round(img.width*perfil.x), sy=Math.round(img.height*perfil.y);
          const sw=Math.round(img.width*perfil.w), sh=Math.round(img.height*perfil.h);
          const canvas=document.createElement('canvas');
          canvas.width=Math.max(1000,Math.min(1800,sw*3));
          canvas.height=Math.max(1200,Math.min(2400,sh*3));
          const ctx=canvas.getContext('2d'); ctx.drawImage(img,sx,sy,sw,sh,0,0,canvas.width,canvas.height);
          const imagen=canvas.toDataURL('image/jpeg',0.94);
          for (const psm of ['4','6','11']){
            try{
              const texto=await encolarLecturaOCR(async()=>{
                const r=await window.Tesseract.recognize(imagen,'spa',{ tessedit_pageseg_mode:psm, tessedit_char_whitelist:'0123456789' });
                return (r&&r.data&&r.data.text)||'';
              });
              String(texto||'').split(/\s+/).forEach(t=>{
                let n=String(t).replace(/[^0-9]/g,'');
                if(/^\d{11}$/.test(n)) n='0'+n;
                if(/^\d{12}$/.test(n) && n.startsWith('00')) encontrados.set(n,(encontrados.get(n)||0)+1);
              });
            }catch(e){ console.warn('Rescate de identificadores SINIIGA falló',psm,e); }
            if(encontrados.size>=20) break;
          }
          if(encontrados.size>=20) break;
        }
        // El OCR numérico puede crear candidatos de una fila con un cero de
        // más/menos. En un concentrado oficial, los identificadores del mismo
        // documento comparten normalmente el mismo prefijo regional. Si existe
        // un prefijo claramente dominante, descartamos candidatos aislados que
        // pertenezcan a otro prefijo espurio. Esto evita convertir un error de
        // lectura como 000024... en un animal real cuando el conjunto verdadero
        // es 0010....
        const entradas=[...encontrados.entries()];
        const prefijos=new Map();
        entradas.forEach(([id,c])=>{ const pref=id.slice(0,4); prefijos.set(pref,(prefijos.get(pref)||0)+c); });
        let prefijoDominante='', cuentaDominante=0;
        prefijos.forEach((c,p)=>{ if(c>cuentaDominante){cuentaDominante=c;prefijoDominante=p;} });
        const candidatos=entradas
          .filter(([id,c])=>!prefijoDominante || cuentaDominante<3 || id.startsWith(prefijoDominante))
          .sort((a,b)=>b[1]-a[1])
          .map(([id])=>id);
        resolve(candidatos);
      };
      img.onerror=()=>resolve([]); img.src=dataUrl;
    }catch(e){ resolve([]); }
  });
}
function fusionarIdentificadoresSINIIGA(filas, ids){
  const mapa=new Map((filas||[]).map(f=>[f.identificador,f]));
  (ids||[]).forEach(id=>{
    let limpio=String(id||'').replace(/[^0-9]/g,'');
    if (/^0\d{10}$/.test(limpio)) limpio=limpio.padStart(12,'0');
    const mx=convertirAreteMX(limpio);
    if (!/^MX\d{10}$/.test(mx)) return;
    if (!mapa.has(mx)) mapa.set(mx,{identificador:mx,estatus:'VIGENTE',sexo:'H',raza:'SIN RAZA REGISTRADA',fechaNacimiento:'',fechaAretado:'',tipoMovimiento:'',folioRemo:null});
  });
  return [...mapa.values()];
}
function normalizarCandidatoIdentificadorSINIIGA(valor){
  let n=String(valor||'').toUpperCase().replace(/[OoQq]/g,'0').replace(/[IiLl|]/g,'1').replace(/[Ss]/g,'5').replace(/[^0-9]/g,'');
  if (/^\d{11}$/.test(n)) n='0'+n;
  if (/^\d{12}$/.test(n) && n.startsWith('00')) return convertirAreteMX(n);
  return '';
}
function parsearFilasSINIIGA(texto){
const lineas = texto.split(/\n+/).map(l => l.trim()).filter(Boolean);
const filas = [];
lineas.forEach(linea => {
// La cabecera del Concentrado trae la UPP (12 dígitos) y puede parecer un
// identificador animal. Nunca debe convertirse en una fila del hato.
const lineaNorm = normalizarParaBuscarEtiqueta(linea);
if (/\bU\.?\s*P\.?\s*P\.?\b/.test(lineaNorm) || /^PRODUCTOR\s*[:]/.test(lineaNorm)) return;
const tokensId = linea.match(/[A-Za-z0-9|OoQqIiLlSs]{10,15}/g) || [];
let idNormalizado = '';
for (const tok of tokensId){ const c = normalizarCandidatoIdentificadorSINIIGA(tok); if (c){ idNormalizado=c; break; } }
if (!idNormalizado) return;
const fechas = linea.match(/\d{1,2}\/\d{1,2}\/\d{2,4}/g) || [];
// El Concentrado SINIIGA oficial trae la fecha de nacimiento como mes-año,
// sin día (ej. "06-2016") — se busca por separado porque no la detecta el
// patrón de fecha completa de arriba. Si lo que se encontró en realidad es
// un pedazo de una fecha completa ya capturada (ej. "11/2021" dentro de
// "05/11/2021"), no cuenta como una fecha mes-año aparte.
let mesAnioMatch = linea.match(/\b(0?[1-9]|1[0-2])[-\/](20\d{2}|19\d{2})\b/);
if (mesAnioMatch && fechas.some(f => f.includes(mesAnioMatch[0]))) mesAnioMatch = null;
const mayus = linea.toUpperCase();
const estatusMatch = mayus.match(/VIGENTE|CANCELADO|BAJA|INACTIVO|VENTA/);
const sexoMatch = mayus.match(/\bHEMBRA\b|\bMACHO\b/);
const movMatch = mayus.match(/REARETADO|INCREMENTO NATURAL|INCREMENTO POR COMPRA|TRASPASO|ALTA|BAJA|VENTA/);
// Folio REEMO: con etiqueta si la trae, o por posición (última columna de la
// fila) si el documento es una tabla sin repetir la etiqueta en cada renglón.
const folioConEtiqueta = linea.match(/\breemo[:\s]*([0-9]{3,})\b/i);
let folioRemo = folioConEtiqueta ? folioConEtiqueta[1] : null;
if (!folioRemo){
const tokens = linea.trim().split(/\s+/);
const ultimo = tokens[tokens.length - 1];
if (ultimo !== '-' && /^\d{3,}$/.test(ultimo) && ultimo !== idNormalizado) folioRemo = ultimo;
}
const fechaNacimientoTexto = mesAnioMatch ? `01/${mesAnioMatch[1].padStart(2,'0')}/${mesAnioMatch[2]}` : (fechas[0] || '');
filas.push({
identificador: idNormalizado,
estatus: estatusMatch ? estatusMatch[0] : 'VIGENTE',
sexo: sexoMatch ? (sexoMatch[0] === 'HEMBRA' ? 'H' : 'M') : 'H',
raza: 'SIN RAZA REGISTRADA',
fechaNacimiento: fechaNacimientoTexto,
fechaAretado: fechas[1] || fechas[0] || '',
tipoMovimiento: movMatch ? movMatch[0] : '',
folioRemo,
});
});
return filas;
}
let siniigaLecturaEnCurso = false;
let siniigaLecturaPendiente = false;
async function extraerTablaSINIIGA(){
if (siniigaLecturaEnCurso){ siniigaLecturaPendiente = true; return; }
siniigaLecturaEnCurso = true;
try {
const archivo = document.getElementById('esc-siniiga-input')?.files?.[0];
if (!archivo){ mostrarToast('Primero toma la foto del documento'); return; }
const boton = document.getElementById('esc-siniiga-btn-extraer');
boton.disabled = true; boton.textContent = 'Leyendo...';
try {
const dataUrlOCR = await comprimirParaOCR(archivo, 1800);
const texto = await extraerTextoDeImagen(dataUrlOCR, estado => { boton.textContent = estado === 'descargando' ? 'Descargando lector de texto...' : 'Leyendo...'; }, 'tabla');
filasSINIIGATemp = parsearFilasSINIIGA(texto);
const mVig = String(texto||'').match(/VIGENTES?\s*[:.]?\s*(\d{1,3})/i);
const cantidadEsperada = mVig ? parseInt(mVig[1],10) : 0;
if (cantidadEsperada > 0 && filasSINIIGATemp.length < cantidadEsperada || filasSINIIGATemp.length < 8){
  boton.textContent = 'Rescatando identificadores...';
  const idsDirigidos = await extraerIdentificadoresSINIIGADirigidos(dataUrlOCR);
  const porId = new Map(filasSINIIGATemp.map(f=>[f.identificador,f]));
  const base = idsDirigidos.map(id => porId.get(convertirAreteMX(id)) || {identificador:convertirAreteMX(id),estatus:'VIGENTE',sexo:'H',raza:'SIN RAZA REGISTRADA',fechaNacimiento:'',fechaAretado:'',tipoMovimiento:'',folioRemo:null});
  filasSINIIGATemp = base.length ? base : fusionarIdentificadoresSINIIGA(filasSINIIGATemp, idsDirigidos);
}
document.getElementById('esc-siniiga-texto-crudo').textContent = texto.trim() || '(no se detectó texto legible)';
document.getElementById('esc-siniiga-resultado').classList.remove('hidden');
renderFilasSINIIGA();
if (filasSINIIGATemp.length === 0) mostrarToast('No se reconoció ninguna fila automáticamente — agrégalas a mano con el botón "Fila"');
else mostrarToast(`${filasSINIIGATemp.length} fila(s) detectada(s) — revisa cada una, la lectura automática puede fallar`);
} catch(e){
mostrarToast('No se pudo leer la foto: ' + e.message);
} finally {
boton.disabled = false; boton.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles"></i> Extraer tabla de animales';
}
} finally {
siniigaLecturaEnCurso = false;
if (siniigaLecturaPendiente){ siniigaLecturaPendiente = false; extraerTablaSINIIGA(); }
}
}
function agregarFilaSINIIGAManual(){
filasSINIIGATemp.push({ identificador:'', estatus:'VIGENTE', sexo:'H', raza:'SIN RAZA REGISTRADA', fechaNacimiento:'', fechaAretado:'', tipoMovimiento:'' });
document.getElementById('esc-siniiga-resultado').classList.remove('hidden');
renderFilasSINIIGA();
}
function actualizarFilaSINIIGA(indice, campo, val){
if (!filasSINIIGATemp[indice]) return;
filasSINIIGATemp[indice][campo] = campo === 'identificador' ? convertirAreteMX(val.trim()) : val;
document.getElementById('esc-siniiga-conteo').textContent = filasSINIIGATemp.length;
programarGuardadoBorradorEscaneoDoc();
}
function eliminarFilaSINIIGA(indice){
filasSINIIGATemp.splice(indice, 1);
renderFilasSINIIGA();
}
function renderFilasSINIIGA(){
document.getElementById('esc-siniiga-conteo').textContent = filasSINIIGATemp.length;
const cont = document.getElementById('esc-siniiga-filas');
cont.innerHTML = filasSINIIGATemp.map((f, i) => `
<div class="bg-white rounded-xl p-2" style="border:2px solid ${f.estatus === 'VIGENTE' ? 'var(--green)' : 'var(--line)'};">
<div class="flex items-center justify-between gap-2">
<input class="campo-mayusculas text-xs font-bold" oninput="forzarMayusculas(this); actualizarFilaSINIIGA(${i},'identificador',this.value)" placeholder="Identificador" style="border:none; padding:.2rem;" type="text" value="${f.identificador}"/>
<button onclick="eliminarFilaSINIIGA(${i})" style="color:var(--red);"><i class="fa-solid fa-trash"></i></button>
</div>
${f.folioRemo ? `<p class="text-xs font-bold" style="color:var(--red);"><i class="fa-solid fa-triangle-exclamation"></i> Folio REEMO ${f.folioRemo} — no se importará aunque diga vigente</p>` : ''}
<div class="grid grid-cols-2 gap-1 mt-1">
<select onchange="actualizarFilaSINIIGA(${i},'estatus',this.value); renderFilasSINIIGA();" style="font-size:.72rem; padding:.3rem;">
<option ${f.estatus==='VIGENTE'?'selected':''} value="VIGENTE">VIGENTE</option>
<option ${f.estatus==='CANCELADO'?'selected':''} value="CANCELADO">CANCELADO</option>
<option ${f.estatus==='BAJA'?'selected':''} value="BAJA">BAJA</option>
<option ${f.estatus==='INACTIVO'?'selected':''} value="INACTIVO">INACTIVO</option>
</select>
<select onchange="actualizarFilaSINIIGA(${i},'sexo',this.value)" style="font-size:.72rem; padding:.3rem;">
<option ${f.sexo==='H'?'selected':''} value="H">Hembra</option>
<option ${f.sexo==='M'?'selected':''} value="M">Macho</option>
</select>
<input oninput="actualizarFilaSINIIGA(${i},'fechaNacimiento',this.value)" style="font-size:.72rem; padding:.3rem;" type="date" value="${fechaAISOSiPosible(f.fechaNacimiento)}"/>
<input oninput="actualizarFilaSINIIGA(${i},'fechaAretado',this.value)" style="font-size:.72rem; padding:.3rem;" type="date" value="${fechaAISOSiPosible(f.fechaAretado)}"/>
<input class="campo-mayusculas col-span-2" oninput="forzarMayusculas(this); actualizarFilaSINIIGA(${i},'raza',this.value)" placeholder="Raza" style="font-size:.72rem; padding:.3rem;" type="text" value="${f.raza}"/>
</div>
</div>`).join('');
}
// El OCR entrega fechas en formato dd/mm/aaaa (como vienen impresas); los <input
// type="date"> del navegador necesitan aaaa-mm-dd, así que se convierten si es
// posible — si no cuadra el formato, se deja vacío para que se escriba a mano.
function fechaAISOSiPosible(texto){
if (!texto) return '';
const m = texto.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/);
if (!m) return '';
let [, d, mo, y] = m;
if (y.length === 2) y = '20' + y;
return `${y.padStart(4,'0')}-${mo.padStart(2,'0')}-${d.padStart(2,'0')}`;
}
// ================= OCR DEL FORMATO DE PRUEBA SENASICA =================
// El formato oficial de campo tiene otra estructura distinta a la credencial/UPP.
// Este lector NO inventa datos: solo llena campos que aparecen realmente en la foto
// y deja al MVZ la revisión final. Si ya hay un productor seleccionado, los campos
// de propietario solo se completan cuando están vacíos; una discrepancia se avisa.
function extraerFechaFlexible(texto, etiquetas){
  const v = extraerTrasEtiqueta(texto, etiquetas, etiquetas);
  const m = String(v || '').match(/(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})/);
  if (!m) return '';
  let y = m[3]; if (y.length === 2) y = '20' + y;
  return `${y}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`;
}
function extraerHoraFlexible(texto, etiquetas){
  const v = extraerTrasEtiqueta(texto, etiquetas, etiquetas);
  const m = String(v || '').match(/\b(\d{1,2}):([0-5]\d)\b/);
  return m ? `${m[1].padStart(2,'0')}:${m[2]}` : '';
}
function establecerOCRPruebaSinPisar(id, valorNuevo, conflictos){
  const el = document.getElementById(id);
  const nuevo = String(valorNuevo || '').trim();
  if (!el || !nuevo) return;
  const actual = String(el.value || '').trim();
  if (!actual){ establecerValor(id, nuevo); return; }
  if (actual.toUpperCase() !== nuevo.toUpperCase()) conflictos.push(`${id}: ${actual} ≠ ${nuevo}`);
}
async function extraerDatosFormatoPruebaCampo(){
  const archivo = document.getElementById('pc-ocr-formato-input')?.files?.[0];
  if (!archivo){ mostrarToast('Primero toma una foto del formato SENASICA'); return; }
  const boton = document.getElementById('pc-ocr-formato-btn');
  if (boton) { boton.disabled = true; boton.textContent = 'Leyendo formato...'; }
  try{
    const texto = await extraerTextoDeImagen(await comprimirParaOCR(archivo, 1800), estadoOCR => {
      if (boton) boton.textContent = estadoOCR === 'descargando' ? 'Descargando lector...' : 'Leyendo formato...';
    }, 'formulario');
    const conflictos = [];
    const normal = normalizarParaBuscarEtiqueta(texto);
    if (/TUBERCULOSIS|TUBERCULINA|PLIEGUE CAUDAL/.test(normal)) establecerValor('pc-tipo-prueba','TB');
    const folio = extraerNumeroTrasEtiqueta(texto, ['FOLIO', 'FOLIO No', 'FOLIO NO', 'FOLIO DE PRUEBA']);
    const cc = extraerNumeroTrasEtiqueta(texto, ['CC No', 'CC NO', 'CCC No', 'CCC NO', 'EC No', 'EC NO', 'CCC No.']);
    const dosis = extraerNumeroTrasEtiqueta(texto, ['DOSIS']);
    const lote = extraerTrasEtiqueta(texto, ['LOTE NO', 'LOTE'], ['LOTE NO','LOTE','DOSIS','FECHA']);
    const fechaInyeccion = extraerFechaFlexible(texto, ['FECHA DE INYECCIÓN','FECHA DE INYECCION']);
    const fechaLectura = extraerFechaFlexible(texto, ['FECHA DE LECTURA']);
    const fechaCaducidad = extraerFechaFlexible(texto, ['FECHA DE CADUCIDAD']);
    const fechaMuestra = extraerFechaFlexible(texto, ['FECHA DE RESULTADO DE LABORATORIO']);
    const horaInyeccion = extraerHoraFlexible(texto, ['HORA']);
    const tipoAplicacion = /PLIEGUE CAUDAL/.test(normal) ? 'caudal' : (/CERVICAL SIMPLE/.test(normal) ? 'cervical' : '');
    establecerOCRPruebaSinPisar('pc-of-folio-tb', folio, conflictos);
    establecerOCRPruebaSinPisar('pc-of-cc-no', cc, conflictos);
    establecerOCRPruebaSinPisar('pc-dosis', dosis === '10' || dosis === '50' ? dosis : '', conflictos);
    establecerOCRPruebaSinPisar('pc-lote', lote, conflictos);
    establecerOCRPruebaSinPisar('pc-fecha-inyeccion', fechaInyeccion, conflictos);
    establecerOCRPruebaSinPisar('pc-fecha-lectura', fechaLectura, conflictos);
    establecerOCRPruebaSinPisar('pc-fecha-caducidad', fechaCaducidad, conflictos);
    establecerOCRPruebaSinPisar('pc-fecha-muestra', fechaMuestra, conflictos);
    establecerOCRPruebaSinPisar('pc-hora-inyeccion', horaInyeccion, conflictos);
    establecerOCRPruebaSinPisar('pc-of-tipo-aplicacion', tipoAplicacion, conflictos);
    // Propietario/UPP: se toman solo si el formato realmente trae un valor legible.
    const nombre = extraerTrasEtiqueta(texto, ['PROPIETARIO','NOMBRE DEL PROPIETARIO'], ['PROPIETARIO','NOMBRE DEL PROPIETARIO','UNIDAD DE PRODUCCIÓN','MUNICIPIO','ESTADO']);
    const upp = extraerUPPPorPatron(texto);
    const domicilio = extraerTrasEtiqueta(texto, ['DOMICILIO'], ['DOMICILIO','MUNICIPIO','ESTADO','CÓDIGO POSTAL']);
    const localidad = extraerTrasEtiqueta(texto, ['LOCALIDAD'], ['LOCALIDAD','MUNICIPIO','ESTADO']);
    const municipio = extraerTrasEtiqueta(texto, ['MUNICIPIO'], ['MUNICIPIO','ESTADO']);
    const estadoMx = extraerTrasEtiqueta(texto, ['ESTADO'], ['ESTADO','UNIDAD DE PRODUCCIÓN']);
    establecerOCRPruebaSinPisar('pc-of-nombres', nombre, conflictos);
    establecerOCRPruebaSinPisar('pc-of-clave-upp', normalizarUPP(upp), conflictos);
    establecerOCRPruebaSinPisar('pc-of-domicilio', domicilio, conflictos);
    establecerOCRPruebaSinPisar('pc-of-localidad', localidad, conflictos);
    establecerOCRPruebaSinPisar('pc-of-municipio', municipio, conflictos);
    establecerOCRPruebaSinPisar('pc-of-estado', estadoMx, conflictos);
    const crudo = document.getElementById('pc-ocr-formato-texto');
    if (crudo) crudo.textContent = texto.trim() || '(no se detectó texto legible)';
    const resultado = document.getElementById('pc-ocr-formato-resultado');
    if (resultado) resultado.classList.remove('hidden');
    guardarBorradorPruebaCampoActivo?.();
    if (conflictos.length){
      mostrarToast(`OCR leído con ${conflictos.length} dato(s) en conflicto — revisa los campos marcados en el formulario.`);
    } else {
      mostrarToast('Formato leído — revisa los datos antes de guardar');
    }
  }catch(e){
    mostrarToast('No se pudo leer el formato: ' + e.message);
  }finally{
    if (boton){ boton.disabled = false; boton.innerHTML = '<i class="fa-solid fa-camera-retro"></i> Leer formato SENASICA'; }
  }
}

function validarConsistenciaDocumentosMiRanch(){
  const credUPP=normalizarUPP(valor('esc-cred-upp')), uppUPP=normalizarUPP(valor('esc-upp-numero'));
  const nombreCred=valor('esc-cred-nombre').toUpperCase(), nombreActual=String(estado.productor?.nombre||'').toUpperCase();
  const fierro=valor('esc-cred-fierro'); const avisos=[];
  if(credUPP&&uppUPP&&credUPP!==uppUPP) avisos.push(`UPP distinta entre documentos: ${credUPP} / ${uppUPP}`);
  if(nombreCred&&nombreActual&&nombreCred!==nombreActual&&!nombreActual.includes(nombreCred)&&!nombreCred.includes(nombreActual)) avisos.push('El nombre leído de la credencial no coincide exactamente con el nombre actual.');
  // El domicilio del productor y la ubicación de la UPP NO se comparan: pueden ser municipios distintos.
  return {ok:avisos.length===0,avisos,identidad:{nombre:nombreCred,upp:credUPP||uppUPP,fierroNumero:fierro||''}};
}
// ---- Paso 4: Confirmar e importar ----
function actualizarResumenImportarEscaneo(){
const soloVigentes = document.getElementById('esc-solo-vigentes')?.checked;
const aImportar = soloVigentes ? filasSINIIGATemp.filter(f => f.estatus === 'VIGENTE' && !f.folioRemo) : filasSINIIGATemp;
document.getElementById('esc-resumen-importar').textContent = `${aImportar.length} de ${filasSINIIGATemp.length} animal(es) se importarán al hato.`;
}
async function confirmarImportacionEscaneo(){
const validacionDocs=validarConsistenciaDocumentosMiRanch();
if(!estado.productor.documentosOCR||typeof estado.productor.documentosOCR!=='object') estado.productor.documentosOCR={};
estado.productor.documentosOCR.validacion=validacionDocs;
if(validacionDocs.avisos.length) mostrarToast('Hay datos que requieren revisión antes de guardar: '+validacionDocs.avisos.join(' · '));
// 1) Actualiza los datos del propietario/UPP con lo revisado en los pasos 1 y 2.
const nombreCred = valor('esc-cred-nombre').trim();
if (nombreCred) establecerValor('ed-nombres', nombreCred);
if (valor('esc-cred-curp')) establecerValor('ed-curp', valor('esc-cred-curp'));
// El folio de productor y el número de fierro de herrar son campos distintos.
if (valor('esc-cred-folio')) estado.productor.folioProductor = valor('esc-cred-folio');
const uppCredencial = normalizarUPP(valor('esc-cred-upp'));
const uppConstancia = normalizarUPP(valor('esc-upp-numero'));
if (uppCredencial && uppConstancia && uppCredencial !== uppConstancia){
  mostrarToast(`⚠️ Los documentos muestran UPP diferentes (${uppCredencial} y ${uppConstancia}). No se reemplazó la UPP de la cuenta; revísala antes de guardar.`);
} else if (uppCredencial || uppConstancia){
  establecerValor('ed-upp', uppCredencial || uppConstancia);
}
if (valor('esc-cred-actividad')) establecerValor('ed-actividad', valor('esc-cred-actividad'));
// La credencial puede traer datos vinculados al fierro/UPP. No se usan para
// sobrescribir el domicilio personal del productor ni se compara su municipio
// con el municipio de la UPP. Se conserva todo como evidencia OCR separada.
if (!estado.productor.documentosOCR || typeof estado.productor.documentosOCR!=='object') estado.productor.documentosOCR={};
estado.productor.documentosOCR.credencial={
  nombre:valor('esc-cred-nombre'), curp:valor('esc-cred-curp'), folioProductor:valor('esc-cred-folio'),
  upp:normalizarUPP(valor('esc-cred-upp')), actividad:valor('esc-cred-actividad'),
  domicilioDocumento:valor('esc-cred-domicilio'), localidadDocumento:valor('esc-cred-localidad'),
  municipioDocumento:valor('esc-cred-municipio'), numeroFierro:valor('esc-cred-fierro'),
  vigencia:valor('esc-cred-vigencia')
};
if (valor('esc-cred-fierro')) estado.productor.folioFierro=valor('esc-cred-fierro');
if (valor('esc-upp-domicilio')) {
  estado.productor.domicilioUPP=valor('esc-upp-domicilio');
  const c=estado.cuentasProductores.find(x=>x&&x.id===estado.cuentaActivaId); if(c)c.domicilioUPP=valor('esc-upp-domicilio');
}
if (valor('esc-upp-localidad')) establecerValor('ed-localidad', valor('esc-upp-localidad'));
if (valor('esc-upp-predio')) establecerValor('ed-predio', valor('esc-upp-predio'));
if (valor('esc-upp-referencias')) establecerValor('ed-comollegar', valor('esc-upp-referencias'));
if (valor('esc-upp-municipioestado')){
  const partes = valor('esc-upp-municipioestado').split(',').map(x=>x.trim()).filter(Boolean);
  if (partes[0]) establecerValor('ed-municipiopredio', partes[0]);
  if (partes[1]) establecerValor('ed-estadopredio', partes.slice(1).join(', '));
}
const vigenciaCred = valor('esc-cred-vigencia').trim();
if (vigenciaCred){
  estado.productor.vencimientoFierro = vigenciaCred;
  if (estado.cuentaActivaId){ const cuenta=estado.cuentasProductores.find(c=>c.id===estado.cuentaActivaId); if(cuenta) cuenta.vencimientoFierro=vigenciaCred; }
}
if (fierroImagenEscaneoTemp){
// Nunca metas la foto completa del fierro directamente al documento de la
// cuenta. Primero intenta subirla a Storage; si no hay señal,
// subirImagenOGuardarLocal() deja una referencia IndexedDB pequeña.
const baseFierroId = estado.cuentaActivaId || 'local_' + Date.now();
const rutaFierro = `fierros/${baseFierroId}_original.jpg`;
const subidaFierro = await subirImagenOGuardarLocal(rutaFierro, fierroImagenEscaneoTemp);
const referenciaFierro = subidaFierro.url;
let fierroProcesadoRef=null, fierroSvgRef=null;
try{
  if(typeof window.ocr2ProcesarFiguraFierro==='function'){
    const derivado=await window.ocr2ProcesarFiguraFierro(fierroImagenEscaneoTemp);
    if(derivado?.png){ const r=await subirImagenOGuardarLocal(`fierros/${baseFierroId}_procesado.png`,derivado.png); fierroProcesadoRef=r.url; }
    if(derivado?.svg){ const svgData='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(derivado.svg); const r=await subirImagenOGuardarLocal(`fierros/${baseFierroId}_representacion.svg`,svgData); fierroSvgRef=r.url; }
  }
}catch(e){ console.warn('MiRanch: no se pudo generar derivado del fierro',e); }
estado.productor.fierroImagen = referenciaFierro;
estado.productor.fierroImagenProcesada=fierroProcesadoRef; estado.productor.fierroRepresentacionSVG=fierroSvgRef;
if (estado.cuentaActivaId){
const cuenta = estado.cuentasProductores.find(c => c.id === estado.cuentaActivaId);
if (cuenta) { cuenta.fierroImagen=referenciaFierro; cuenta.fierroImagenProcesada=fierroProcesadoRef; cuenta.fierroRepresentacionSVG=fierroSvgRef; cuenta.folioFierro=valor('esc-cred-fierro')||cuenta.folioFierro||''; }
}
}
// 2) Importa al hato los animales revisados (filtrando por VIGENTE si se pidió),
// comprimiendo y subiendo a Storage la foto si el animal ya trae una asignada.
const soloVigentes = document.getElementById('esc-solo-vigentes')?.checked;
const aImportar = (soloVigentes ? filasSINIIGATemp.filter(f => f.estatus === 'VIGENTE' && !f.folioRemo) : filasSINIIGATemp).filter(f => f.identificador);
let importados = 0, omitidosPorDuplicado = 0;
aImportar.forEach(f => {
if (estado.animales.some(a => a.arete === f.identificador)){ omitidosPorDuplicado++; return; }
const fechaISO = fechaAISOSiPosible(f.fechaNacimiento);
estado.animales.push({
arete: f.identificador, chip:'', nombre:'',
raza: f.raza || 'SIN RAZA REGISTRADA', sexo: f.sexo === 'M' ? 'Macho' : 'Hembra',
fecha: fechaISO || hoyISO(), estatus:'Activo',
madre:'', padre:'', potrero:'', motivoBaja: f.folioRemo ? ('Folio REEMO ' + f.folioRemo) : '', foto:null,
proposito:'', engordaDiasObjetivo:null, engordaPesoMeta:null, engordaInicio:null,
engordaFinalizado:false, engordaDiasFinal:null,
fechaAretado: f.fechaAretado || '', tipoMovimientoSiniiga: f.tipoMovimiento || '',
color:'', senasParticulares:'', numeroManejo:'',
});
importados++;
});
guardarEdicionProductor();
mostrarToast(`Importado: ${importados} animal(es) al hato${omitidosPorDuplicado ? ` (${omitidosPorDuplicado} ya existían y se omitieron)` : ''}`);
mostrarBannerNotificacion('Documentos y fotos guardados', 3500, 'fa-cloud-arrow-up');
filasSINIIGATemp = []; fierroImagenEscaneoTemp = null;
renderHato(); renderResumenProductor();
}
function abrirEdicionProductor(){
const p = estado.productor;
llenarSelectorEstados('ed');
establecerValor('ed-apellidopaterno', p.apellidoPaterno || '');
establecerValor('ed-apellidomaterno', p.apellidoMaterno || '');
establecerValor('ed-nombres', p.nombres || (!p.apellidoPaterno && !p.apellidoMaterno ? p.nombre : '') || '');
establecerValor('ed-domicilio', p.domicilio || 'Conocido');
establecerValor('ed-localidad', p.localidad || '');
establecerValor('ed-correo', p.correoElectronico || '');
establecerValor('ed-cp', p.codigoPostal || '');
establecerValor('ed-telefono', p.telefono || '');
establecerValor('ed-poblacion', p.poblacion || '');
establecerValor('ed-colonia', p.colonia || '');
establecerValor('ed-predio', p.predio || '');
establecerValor('ed-upp', p.upp || '');
establecerValor('ed-actualizacionupp', p.actualizacionUPP || '');
establecerValor('ed-folio', p.folio || '');
establecerValor('ed-municipiopredio', p.municipioPredio || '');
establecerValor('ed-estadopredio', p.estadoPredio || '');
establecerValor('ed-comollegar', p.comoLlegar || '');
establecerValor('ed-estado', p.estado || '');
cargarMunicipiosSelector('ed', p.municipio || '');
establecerValor('ed-curp', p.curp || '');
establecerValor('ed-rfc', p.rfc || '');
const spanGps = document.getElementById('ed-gps-texto');
const campoGpsCoords = document.getElementById('ed-gps-coords');
const tieneGps = p.latitudUPP && p.longitudUPP;
if (campoGpsCoords) campoGpsCoords.value = tieneGps ? `${p.latitudUPP.toFixed(5)}, ${p.longitudUPP.toFixed(5)}` : '';
if (spanGps) spanGps.textContent = 'GPS';
renderVistaFierroGuardado('ed');
document.getElementById('ed-fierro-recorte-cont')?.classList.add('hidden');
renderCamposPersonalizadosFormulario('ed-campos-personalizados', p.camposPersonalizados);
document.querySelectorAll('#app-productor .screen').forEach(s => s.classList.remove('active'));
document.getElementById('screen-editar-productor').classList.add('active');
window.scrollTo(0,0);
}
// Avisa cuando CURP (18) o UPP (12) no tienen la longitud exacta que deben
// tener — se marca en rojo mientras esté incompleto, y se quita el aviso en
// cuanto se completa. No bloquea guardar (la persona puede estar
// completándolo poco a poco), solo avisa.
function validarLongitudCampo(input, longitudEsperada, nombreCampo){
const valor = (input.value || '').trim();
if (valor.length === 0){ quitarErrorCampo(input.id); return; }
if (valor.length !== longitudEsperada){
marcarErrorCampo(input.id, `${nombreCampo} — faltan ${longitudEsperada - valor.length} caracter(es), debe tener ${longitudEsperada}`);
} else {
quitarErrorCampo(input.id);
}
}
function guardarEdicionProductor(){
if (!marcarCamposFaltantes([{ id:'ed-nombres', etiqueta:'Nombre(s)' }])) return;
const apellidoPaterno = valor('ed-apellidopaterno').trim();
const apellidoMaterno = valor('ed-apellidomaterno').trim();
const nombres = valor('ed-nombres').trim();
const nombreCompleto = [nombres, apellidoPaterno, apellidoMaterno].filter(Boolean).join(' ');
estado.productor = {
...estado.productor,
apellidoPaterno, apellidoMaterno, nombres, nombre: nombreCompleto || estado.productor.nombre,
domicilio: valor('ed-domicilio').trim() || 'Conocido',
localidad: valor('ed-localidad').trim(), correoElectronico: valor('ed-correo').trim(),
codigoPostal: valor('ed-cp').trim(), telefono: valor('ed-telefono').trim(),
poblacion: valor('ed-poblacion').trim(), colonia: valor('ed-colonia').trim(),
predio: valor('ed-predio'), upp: valor('ed-upp'), actualizacionUPP: valor('ed-actualizacionupp'),
folio: valor('ed-folio'), municipioPredio: valor('ed-municipiopredio').trim(), estadoPredio: valor('ed-estadopredio').trim(),
comoLlegar: valor('ed-comollegar').trim(),
estado: valor('ed-estado'), municipio: leerMunicipioSeleccionado('ed'),
curp: valor('ed-curp').toUpperCase(), rfc: valor('ed-rfc').toUpperCase(),
camposPersonalizados: leerCamposPersonalizadosFormulario('ed-campos-personalizados'),
};
if (estado.cuentaActivaId){
const cuenta = estado.cuentasProductores.find(c => c.id === estado.cuentaActivaId);
if (cuenta){
cuenta.nombre = estado.productor.nombre; cuenta.predio = estado.productor.predio; cuenta.folioProductor = estado.productor.folioProductor || cuenta.folioProductor || '';
cuenta.estadoMx = estado.productor.estado; cuenta.municipio = estado.productor.municipio;
cuenta.folio = estado.productor.folio; cuenta.telefono = estado.productor.telefono || cuenta.telefono;
cuenta.curp = estado.productor.curp; cuenta.rfc = estado.productor.rfc;
cuenta.apellidoPaterno = estado.productor.apellidoPaterno; cuenta.apellidoMaterno = estado.productor.apellidoMaterno; cuenta.nombres = estado.productor.nombres;
cuenta.domicilio = estado.productor.domicilio; cuenta.localidad = estado.productor.localidad;
cuenta.correoElectronico = estado.productor.correoElectronico; cuenta.codigoPostal = estado.productor.codigoPostal;
cuenta.latitud = estado.productor.latitudUPP; cuenta.longitud = estado.productor.longitudUPP;
}
}
guardarEstadoLocal();
renderResumenProductor();
irA('datos-productor');
mostrarToast(tr('edicion_datos_productor__datos_del_productor_actualizados'));
}
function quitarPrefijoLetra(texto){ return (texto || '').replace(/^[A-Z]\.\s*/, ''); }
const ETIQUETAS_MODULOS = {
hato:tr('hato_inventario_animales__estatus_del_hato'), graficas:tr('nav_graficas'), boletines:tr('boletines_informativos__boletines_informativos'), reporte:tr('notificaciones__reporte_y_notificaciones'),
moduloA:quitarPrefijoLetra(tr('edicion_datos_productor__a_registro_e_identificacion_animal')), moduloB:quitarPrefijoLetra(tr('edicion_datos_productor__b_salud_sanidad_y_manejo')),
moduloC:quitarPrefijoLetra(tr('edicion_datos_productor__c_reproduccion_y_maternidad')), moduloD:quitarPrefijoLetra(tr('edicion_datos_productor__d_pesajes_y_productividad')),
moduloE:quitarPrefijoLetra(tr('edicion_datos_productor__e_mapeo_geografico')), moduloF:quitarPrefijoLetra(tr('edicion_datos_productor__f_administracion_costos_y_reportes')),
moduloG:quitarPrefijoLetra(tr('edicion_datos_productor__g_produccion_de_leche_solo')),
moduloH:quitarPrefijoLetra(tr('edicion_datos_productor__h_tanque_y_entrega_de')),
moduloI:quitarPrefijoLetra(tr('edicion_datos_productor__i_alimentacion_lechera_solo_ganado')),
moduloJ:quitarPrefijoLetra(tr('edicion_datos_productor__j_becerros_de_reemplazo_solo')),
};
const ETIQUETAS_CAMPOS = { nombre:tr('editar_datos_productor__nombre'), predio:tr('editar_datos_productor__nombre_del_predio'), upp:'UPP', actualizacionUPP:tr('editar_datos_productor__ultima_actualizacion_upp'), folio:tr('edicion_datos_productor__folio_de_fierro_de_herrar'), vencimientoFierro:tr('editar_datos_productor__vencimiento_credencial_fierro'), estado:tr('editar_datos_productor__estado'), municipio:tr('editar_datos_productor__municipio'), ejido:tr('editar_datos_productor__ejido_parcela'), curp:'CURP', actividad:tr('editar_datos_productor__actividad_pecuaria'), animales:tr('edicion_datos_productor__numero_de_animales_activos') };
function renderTogglesModulos(){
const cont = document.getElementById('lista-toggles-modulos');
const clavesEnOrdenMas = new Set(estado.ordenMas.map(c => c === 'hato' ? 'hato' : 'modulo' + c));
cont.innerHTML = Object.entries(ETIQUETAS_MODULOS).filter(([clave]) => !clavesEnOrdenMas.has(clave)).map(([clave, etiqueta]) => `
<div class="flex items-center justify-between py-2">
<span class="font-medium">${etiqueta}</span>
<label class="switch">
<input type="checkbox" ${estado.visibilidad[clave] ? 'checked' : ''} onchange="toggleModulo('${clave}', this.checked)">
<span class="switch-slider"></span>
</label>
</div>`).join('');
}
const ETIQUETAS_MODULOS_TRABAJADOR = { moduloA: ETIQUETAS_MODULOS.moduloA, moduloB: ETIQUETAS_MODULOS.moduloB,
moduloC: ETIQUETAS_MODULOS.moduloC, moduloD: ETIQUETAS_MODULOS.moduloD, moduloE: ETIQUETAS_MODULOS.moduloE,
moduloG: ETIQUETAS_MODULOS.moduloG, moduloH: ETIQUETAS_MODULOS.moduloH, moduloI: ETIQUETAS_MODULOS.moduloI,
moduloJ: ETIQUETAS_MODULOS.moduloJ };
function renderTogglesPermisosTrabajador(){
const cont = document.getElementById('lista-permisos-trabajador');
if (!cont) return;
cont.innerHTML = Object.entries(ETIQUETAS_MODULOS_TRABAJADOR).map(([clave, etiqueta]) => `
<div class="flex items-center justify-between py-2">
<span class="font-medium">${etiqueta}</span>
<label class="switch">
<input type="checkbox" ${estado.permisosTrabajador[clave] ? 'checked' : ''} onchange="toggleModuloTrabajador('${clave}', this.checked)">
<span class="switch-slider"></span>
</label>
</div>`).join('');
}
function toggleModuloTrabajador(clave, activo){
estado.permisosTrabajador[clave] = activo;
}
const ETIQUETAS_ORDEN_MAS = { hato:tr('hato_inventario_animales__estatus_del_hato'), A:nombreModulo('A'), B:nombreModulo('B'), C:nombreModulo('C'), D:nombreModulo('D'), E:nombreModulo('E'), F:nombreModulo('F'), G:nombreModulo('G'), H:nombreModulo('H'), I:nombreModulo('I'), J:nombreModulo('J'), K:nombreModulo('K') };
const ETIQUETAS_ICONOS_BOTONES = { ...ETIQUETAS_ORDEN_MAS,
calendario: tr('menu_mas_productor__calendario_de_eventos'),
visitas: tr('menu_mas_productor__bitacora_de_visitas_veterinarias'),
engorda: tr('menu_mas_productor__manejo_de_engorda_y_corral'),
tareas: tr('menu_mas_productor__mis_tareas'),
transferencias: tr('menu_mas_productor__transferencias_de_aretes'),
adm_cuentas: 'Admin: Cuentas de productores',
adm_usuarios: 'Admin: Usuarios y contraseñas',
adm_productor: 'Admin/Vet: Datos del productor',
adm_boletines: 'Admin: Boletines informativos',
adm_config: 'Admin: Configuración de ventanas',
vet_boletines: 'Veterinario: Boletines',
vet_pacientes: 'Veterinario: Personas atendidas',
vet_notas: 'Veterinario: Mis notas',
vet_pruebascampo: 'Veterinario: Pruebas de campo',
q_recepcion: 'Punto/Quesería: Recibir leche',
q_reportes: 'Punto/Quesería: Panel de reportes',
q_productores: 'Punto/Quesería: Gestión de productores',
reg_leche: 'Registro: botón Lechera',
reg_carne: 'Registro: botón Carne',
reg_punto: 'Registro: botón Punto receptor de leche',
reg_mvz: 'Registro: botón MVZ',
reg_cefp: 'Registro: botón CEFPP',
};
function renderListaIconosBotones(){
const cont = document.getElementById('lista-iconos-botones');
if (!cont) return;
cont.innerHTML = Object.entries(ETIQUETAS_ICONOS_BOTONES).map(([clave, etiqueta]) => {
const url = (estado.iconosBotones && estado.iconosBotones[clave]) || '';
return `
<div class="flex items-center gap-2 py-1" style="border-top:2px solid var(--line);">
<div class="rounded-xl flex items-center justify-center flex-shrink-0" style="width:38px; height:38px; background:${url ? 'transparent' : 'var(--parchment)'}; background-image:${url ? `url('${url}')` : 'none'}; background-size:cover; background-position:center; border:2px solid var(--line);" id="prev-icono-${clave}"></div>
<div class="flex-1 min-w-0">
<p class="text-xs font-bold mb-1">${etiqueta}</p>
<input type="text" inputmode="url" placeholder="https://..." value="${url.replace(/"/g,'&quot;')}" class="w-full text-xs" style="border:2px solid var(--line); border-radius:10px; padding:6px 8px;" onchange="actualizarIconoBoton('${clave}', this.value)">
</div>
</div>`;
}).join('');
}
function actualizarIconoBoton(clave, valor){
estado.iconosBotones[clave] = (valor || '').trim();
const prev = document.getElementById('prev-icono-' + clave);
if (prev){
prev.style.background = valor ? `transparent url('${valor}') center/cover` : 'var(--parchment)';
}
aplicarIconosBotonesEstaticos();
if (typeof renderGridAdminHome === 'function') renderGridAdminHome();
mostrarToast('Ícono actualizado');
}
function renderListaOrdenMas(){
const cont = document.getElementById('lista-orden-mas');
if (!cont) return;
cont.innerHTML = estado.ordenMas.map((c, i) => {
const claveVis = c === 'hato' ? 'hato' : 'modulo' + c;
return `
<div class="flex items-center justify-between py-2" style="border-top:${i > 0 ? '2px solid var(--line)' : 'none'};">
<span class="font-medium text-sm">${ETIQUETAS_ORDEN_MAS[c] || c}</span>
<div class="flex items-center gap-1">
<label class="switch" style="width:40px; height:24px;">
<input type="checkbox" ${estado.visibilidad[claveVis] ? 'checked' : ''} onchange="toggleModulo('${claveVis}', this.checked)">
<span class="switch-slider"></span>
</label>
<button onclick="moverOrdenMas(${i}, -1)" ${i === 0 ? 'disabled style="opacity:.3;"' : ''} class="w-8 h-8 rounded-full flex items-center justify-center" style="background:var(--parchment);"><i class="fa-solid fa-chevron-up text-xs"></i></button>
<button onclick="moverOrdenMas(${i}, 1)" ${i === estado.ordenMas.length - 1 ? 'disabled style="opacity:.3;"' : ''} class="w-8 h-8 rounded-full flex items-center justify-center" style="background:var(--parchment);"><i class="fa-solid fa-chevron-down text-xs"></i></button>
</div>
</div>`;
}).join('');
}
function moverOrdenMas(i, delta){
const j = i + delta;
if (j < 0 || j >= estado.ordenMas.length) return;
[estado.ordenMas[i], estado.ordenMas[j]] = [estado.ordenMas[j], estado.ordenMas[i]];
renderListaOrdenMas();
}
const ETIQUETAS_GRAFICAS = {
indicadoresLeche:tr('edicion_datos_productor__indicadores_lecheros_comparativo_h'), crecimiento:tr('bitacora_visitas_veterinarias__crecimiento_y_desarrollo'), financiero:tr('edicion_datos_productor__estatus_financiero'),
sexo:tr('graficas__composicion_del_hato_por_sexo'), prenez:tr('edicion_datos_productor__tasa_de_prenez'), pesajes:tr('graficas__evolucion_de_pesajes'), costos:tr('graficas__costos_por_categoria'),
fechas:tr('graficas__proximas_fechas_importantes'), potreros:tr('edicion_datos_productor__ocupacion_de_potreros'), gastosingresos:tr('graficas__gastos_vs_ingresos_por_mes'),
edades:tr('edicion_datos_productor__edades_del_hato'), bajas:tr('graficas__bajas_por_causa'),
};
function renderListaOrdenGraficas(){
const cont = document.getElementById('lista-orden-graficas');
if (!cont) return;
cont.innerHTML = estado.ordenGraficas.map((c, i) => `
<div class="flex items-center justify-between py-2" style="border-top:${i > 0 ? '2px solid var(--line)' : 'none'};">
<span class="font-medium text-sm">${ETIQUETAS_GRAFICAS[c] || c}</span>
<div class="flex items-center gap-1">
<label class="switch" style="width:40px; height:24px;">
<input type="checkbox" ${estado.visibilidadGraficas[c] !== false ? 'checked' : ''} onchange="toggleGraficaVisible('${c}', this.checked)">
<span class="switch-slider"></span>
</label>
<button onclick="moverOrdenGraficas(${i}, -1)" ${i === 0 ? 'disabled style="opacity:.3;"' : ''} class="w-8 h-8 rounded-full flex items-center justify-center" style="background:var(--parchment);"><i class="fa-solid fa-chevron-up text-xs"></i></button>
<button onclick="moverOrdenGraficas(${i}, 1)" ${i === estado.ordenGraficas.length - 1 ? 'disabled style="opacity:.3;"' : ''} class="w-8 h-8 rounded-full flex items-center justify-center" style="background:var(--parchment);"><i class="fa-solid fa-chevron-down text-xs"></i></button>
</div>
</div>`).join('');
}
function moverOrdenGraficas(i, delta){
const j = i + delta;
if (j < 0 || j >= estado.ordenGraficas.length) return;
[estado.ordenGraficas[i], estado.ordenGraficas[j]] = [estado.ordenGraficas[j], estado.ordenGraficas[i]];
renderListaOrdenGraficas();
}
function toggleGraficaVisible(clave, val){
estado.visibilidadGraficas[clave] = val;
}
const NOMBRES_MESES_CORTOS = ['','Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
function agregarPlanSanitario(){
const nombre = valor('plan-nombre').trim();
if (!nombre){ mostrarToast(tr('plan_sanitario_anual__escribe_el_nombre_de_la')); return; }
estado.planSanitario.push({ id:'ps' + Date.now(), nombre, mes: Number(valor('plan-mes')), notas: valor('plan-notas') });
establecerValor('plan-nombre', '');
establecerValor('plan-notas', '');
renderListaPlanSanitario();
mostrarToast(tr('plan_sanitario_anual__campana_agregada_al_plan'));
}
function eliminarPlanSanitario(id){
const i = estado.planSanitario.findIndex(p => p.id === id);
if (i === -1) return;
const borrado = estado.planSanitario.splice(i, 1)[0];
renderListaPlanSanitario();
mostrarToast(tr('plan_sanitario_anual__campana_eliminada'), () => { estado.planSanitario.splice(i, 0, borrado); renderListaPlanSanitario(); mostrarToast(tr('plan_sanitario_anual__campana_restaurada')); });
}
function renderListaPlanSanitario(){
const cont = document.getElementById('lista-plan-sanitario');
if (!cont) return;
if (estado.planSanitario.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-2" style="color:var(--sage);">${tr('plan_sanitario_anual__aun_no_programas_campanas')}</p>`;
return;
}
const ordenado = estado.planSanitario.slice().sort((a,b) => a.mes - b.mes);
cont.innerHTML = ordenado.map(p => `
<div class="flex items-center justify-between py-2" style="border-top:2px solid var(--line);">
<div><p class="font-medium text-sm">${p.nombre}</p><p class="text-xs" style="color:var(--sage);">${NOMBRES_MESES_CORTOS[p.mes]}${p.notas ? ' · ' + p.notas : ''}</p></div>
<button onclick="eliminarPlanSanitario('${p.id}')" class="text-sm px-2 py-1" style="color:var(--red);"><i class="fa-solid fa-trash"></i></button>
</div>`).join('');
}
function exportarReporteSanitarioAnual(){
const anioActual = new Date().getFullYear();
const registros = estado.salud.filter(r => r.fecha && new Date(r.fecha).getFullYear() === anioActual);
if (registros.length === 0){ mostrarToast(`No hay registros de salud en ${anioActual}`); return; }
const encabezados = [tr('csv_extra__animal'),tr('gastos_rendimiento_animal__tipo'),tr('gastos_rendimiento_animal__producto_diagnostico'),tr('gastos_rendimiento_animal__fecha'),tr('gastos_rendimiento_animal__proxima'),tr('csv_extra__notas')];
const filas = registros.map(r => [r.animal, r.tipo, r.producto, r.fecha, r.proxima, r.notas]);
const csv = [encabezados, ...filas].map(f => f.map(v => `"${(v||'').toString().replace(/"/g,'""')}"`).join(',')).join('\n');
const blob = new Blob(['\ufeff' + csv], { type:'text/csv;charset=utf-8;' });
const url = URL.createObjectURL(blob);
const a = document.createElement('a');
a.href = url; a.download = `reporte-sanitario-${anioActual}.csv`;
a.click();
URL.revokeObjectURL(url);
mostrarToast(tr('plan_sanitario_anual__reporte_sanitario_anual_descargado'));
}
function generarCodigoTrabajador(){
return String(Math.floor(1000 + Math.random()*9000));
}
function trabajadoresDelAmbito(){
return estado.trabajadores.filter(t => (t.cuentaId || null) === (estado.cuentaActivaId || null));
}
async function agregarTrabajador(){
if (trabajadoresDelAmbito().length >= 2){ mostrarToast(tr('trabajadores__ya_tienes_el_maximo_de')); return; }
const nombre = valor('trabajador-nombre').trim();
if (!nombre){ mostrarToast(tr('trabajadores__escribe_el_nombre_del_trabajador')); return; }
const cuentaActiva = estado.cuentasProductores.find(c => c.id === estado.cuentaActivaId);
const usuarioBase = (cuentaActiva && cuentaActiva.usuario) || generarUsuarioDesdeNombre(estado.productor.nombre || nombre);
const numero = trabajadoresDelAmbito().length + 1;
let usuario = `${usuarioBase}_t${numero}`;
let intento = numero;
while (existeUsuarioDuplicado(usuario)){ intento++; usuario = `${usuarioBase}_t${intento}`; }
const clave = generarContrasenaProvisional();
const registro={ id:'t' + Date.now(), nombre, codigo: generarCodigoTrabajador(), usuario, clave, cuentaId: estado.cuentaActivaId || null };
try{if(typeof window.iranchAsegurarCredencialHash==='function')await window.iranchAsegurarCredencialHash(registro,clave); else throw new Error('motor de credenciales no disponible');}catch(e){mostrarToast('No se pudo crear la credencial segura. Comprueba que la app esté abierta por HTTPS.');return;}
estado.trabajadores.push(registro);
establecerValor('trabajador-nombre', '');
renderListaTrabajadores(); guardarEstadoLocal();
mostrarToast(`${tr('trabajadores__trabajador_agregado')} — ${tr('login_seleccion_rol__usuario')}: ${usuario} · ${tr('login_seleccion_rol__contrasena')}: ${clave}`);
}
function eliminarTrabajador(id){
const i = estado.trabajadores.findIndex(t => t.id === id);
if (i === -1) return;
const borrado = estado.trabajadores.splice(i, 1)[0];
renderListaTrabajadores();
mostrarToast(tr('trabajadores__trabajador_eliminado'), () => { estado.trabajadores.splice(i, 0, borrado); renderListaTrabajadores(); mostrarToast(tr('trabajadores__trabajador_restaurado')); });
}
function renderListaTrabajadores(){
const cont = document.getElementById('lista-trabajadores');
if (!cont) return;
const propios = trabajadoresDelAmbito();
if (propios.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-2" style="color:var(--sage);">${tr('trabajadores__aun_no_agregas_trabajadores')}</p>`;
} else {
cont.innerHTML = propios.map(t => `
<div class="flex items-center justify-between py-2" style="border-top:2px solid var(--line);">
<div><p class="font-medium text-sm">${t.nombre}</p><p class="text-xs" style="color:var(--sage);">${tr('login_seleccion_rol__usuario')}: <b style="color:var(--pine);">${t.usuario || '—'}</b> · ${tr('login_seleccion_rol__contrasena')}: <b style="color:var(--pine);">credencial segura</b></p></div>
<button onclick="eliminarTrabajador('${t.id}')" class="text-sm px-2 py-1" style="color:var(--red);"><i class="fa-solid fa-trash"></i></button>
</div>`).join('');
}
const sel = document.getElementById('tarea-asignado');
if (sel){
sel.innerHTML = '<option value="">General</option>' + propios.map(t => `<option value="${t.id}">${t.nombre}</option>`).join('');
}
}
function agregarTarea(){
const texto = valor('tarea-texto').trim();
if (!texto){ mostrarToast(tr('tareas__escribe_la_tarea')); return; }
const asignadoA = valor('tarea-asignado');
estado.tareas.unshift({ id:'k' + Date.now(), texto, asignadoA: asignadoA || null, fecha: new Date().toISOString().slice(0,10), hecha:false });
establecerValor('tarea-texto', '');
renderListaTareasAdmin();
mostrarToast(tr('tareas__tarea_asignada'));
}
function eliminarTarea(id){
const i = estado.tareas.findIndex(t => t.id === id);
if (i === -1) return;
estado.tareas.splice(i, 1);
guardarEstadoLocal();
renderListaTareasAdmin();
renderMisTareas();
}
function nombreTrabajador(id){
const t = estado.trabajadores.find(x => x.id === id);
return t ? t.nombre : 'General';
}
function renderListaTareasAdmin(){
const cont = document.getElementById('lista-tareas-admin');
if (!cont) return;
if (estado.tareas.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-2" style="color:var(--sage);">${tr('tareas__aun_no_asignas_tareas')}</p>`;
return;
}
cont.innerHTML = estado.tareas.map(t => `
<div class="flex items-center justify-between py-2" style="border-top:2px solid var(--line);">
<div>
<p class="text-sm font-semibold" style="${t.hecha ? 'text-decoration:line-through; opacity:.6;' : ''}">${t.texto}</p>
<p class="text-xs" style="color:var(--sage);">${tr('tareas__para').replace('%VAR%', nombreTrabajador(t.asignadoA)).replace('%VAR%', t.fecha).replace('%VAR%', t.hecha ? '· ✓ realizada' : '')}</p>
</div>
<button onclick="eliminarTarea('${t.id}')" class="text-sm px-2 py-1" style="color:var(--red);"><i class="fa-solid fa-trash"></i></button>
</div>`).join('');
}
function renderTogglesCampos(){
const cont = document.getElementById('lista-toggles-campos');
cont.innerHTML = Object.entries(ETIQUETAS_CAMPOS).map(([clave, etiqueta]) => `
<div class="flex items-center justify-between py-2">
<span class="font-medium">${etiqueta}</span>
<label class="switch">
<input type="checkbox" ${estado.camposProductor[clave] ? 'checked' : ''} onchange="toggleCampo('${clave}', this.checked)">
<span class="switch-slider"></span>
</label>
</div>`).join('');
}
function toggleModulo(clave, val){ estado.visibilidad[clave] = val; }
function toggleCampo(clave, val){ estado.camposProductor[clave] = val; }
function renderCamposPersonalizadosAdmin(){
const cont = document.getElementById('lista-campos-personalizados-def');
if (!cont) return;
if (estado.camposPersonalizadosDef.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-2" style="color:var(--sage);">Aún no agregas campos extra.</p>`;
return;
}
cont.innerHTML = estado.camposPersonalizadosDef.map(c => `
<div class="flex items-center justify-between py-1" style="border-top:2px solid var(--line);">
<span class="text-sm font-medium">${c.etiqueta}</span>
<button onclick="eliminarCampoPersonalizado('${c.id}')" style="color:var(--red);"><i class="fa-solid fa-trash-can"></i></button>
</div>`).join('');
}
function agregarCampoPersonalizado(){
const etiqueta = valor('nuevo-campo-personalizado').trim();
if (!etiqueta){ mostrarToast('Escribe el nombre del campo'); return; }
estado.camposPersonalizadosDef.push({ id: 'campo_' + Date.now(), etiqueta });
establecerValor('nuevo-campo-personalizado', '');
guardarEstadoLocal();
renderCamposPersonalizadosAdmin();
mostrarToast('Campo agregado');
}
function eliminarCampoPersonalizado(id){
estado.camposPersonalizadosDef = estado.camposPersonalizadosDef.filter(c => c.id !== id);
guardarEstadoLocal();
renderCamposPersonalizadosAdmin();
}
function renderCamposPersonalizadosFormulario(idCont, valores){
const cont = document.getElementById(idCont);
if (!cont) return;
if (estado.camposPersonalizadosDef.length === 0){ cont.innerHTML = ''; return; }
cont.innerHTML = estado.camposPersonalizadosDef.map(c => `
<div><label class="campo-label">${c.etiqueta}</label><input class="campo-personalizado-input" data-campo-id="${c.id}" type="text" value="${((valores && valores[c.id]) || '').toString().replace(/"/g,'&quot;')}"/></div>`).join('');
}
function leerCamposPersonalizadosFormulario(idCont){
const cont = document.getElementById(idCont);
if (!cont) return {};
const out = {};
cont.querySelectorAll('.campo-personalizado-input').forEach(inp => { out[inp.dataset.campoId] = inp.value; });
return out;
}
function renderTogglesVentanasExtra(){
const cont = document.getElementById('lista-ventanas-extra');
if (!cont) return;
if (estado.ventanasExtra.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-2" style="color:var(--sage);">${tr('ventanas_personalizadas__aun_no_agregas_ventanas_propias')}</p>`;
return;
}
cont.innerHTML = estado.ventanasExtra.map(v => `
<div class="flex items-center justify-between py-2">
<span class="font-medium">${v.nombre}</span>
<div class="flex items-center gap-2">
<label class="switch">
<input type="checkbox" ${v.visible ? 'checked' : ''} onchange="toggleVentanaExtra('${v.id}', this.checked)">
<span class="switch-slider"></span>
</label>
<button onclick="eliminarVentana('${v.id}')" class="text-sm px-2 py-1 rounded-full transition-transform active:scale-90" style="color:var(--red);">
<i class="fa-solid fa-trash"></i>
</button>
</div>
</div>`).join('');
}
function agregarVentana(){
const nombre = valor('nueva-ventana-nombre').trim();
if (!nombre){ mostrarToast(tr('ventanas_personalizadas__escribe_un_nombre_para_la')); return; }
estado.ventanasExtra.push({ id:'v' + Date.now(), nombre, icono:'fa-window-restore', visible:true, notas:[] });
establecerValor('nueva-ventana-nombre', '');
renderTogglesVentanasExtra();
renderTiles();
mostrarToast(tr('ventanas_personalizadas__ventana_agregada'));
}
function toggleVentanaExtra(id, val){
const v = estado.ventanasExtra.find(x => x.id === id);
if (v) v.visible = val;
renderTiles();
}
function eliminarVentana(id){
const i = estado.ventanasExtra.findIndex(x => x.id === id);
if (i === -1) return;
const borrada = estado.ventanasExtra.splice(i, 1)[0];
renderTogglesVentanasExtra();
renderTiles();
mostrarToast(tr('ventanas_personalizadas__ventana_eliminada'), () => {
estado.ventanasExtra.splice(i, 0, borrada);
renderTogglesVentanasExtra();
renderTiles();
mostrarToast(tr('ventanas_personalizadas__ventana_restaurada'));
});
}
let ventanaExtraActualId = null;
function abrirVentanaExtra(id){
ventanaExtraActualId = id;
const v = estado.ventanasExtra.find(x => x.id === id);
if (!v) return;
document.getElementById('titulo-ventana-extra').textContent = v.nombre;
renderNotasVentana();
irA('ventana-extra');
}
function renderNotasVentana(){
const v = estado.ventanasExtra.find(x => x.id === ventanaExtraActualId);
const cont = document.getElementById('lista-notas-ventana');
if (!v || !cont) return;
if (v.notas.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-note-sticky"></i><p>${tr('ventanas_personalizadas__sin_notas_todavia')}</p></div>`;
return;
}
cont.innerHTML = v.notas.slice().reverse().map((n, ri) => {
const i = v.notas.length - 1 - ri;
return `<div class="item-registro flex items-center justify-between gap-2">
<span class="text-sm">${n}</span>
<button onclick="eliminarNotaVentana(${i})" class="text-sm px-1" style="color:var(--sage);"><i class="fa-solid fa-xmark"></i></button>
</div>`;
}).join('');
}
function agregarNotaVentana(){
const v = estado.ventanasExtra.find(x => x.id === ventanaExtraActualId);
const texto = valor('nueva-nota-ventana').trim();
if (!v || !texto) return;
v.notas.push(texto);
establecerValor('nueva-nota-ventana', '');
guardarEstadoLocal();
renderNotasVentana();
}
function eliminarNotaVentana(i){
const v = estado.ventanasExtra.find(x => x.id === ventanaExtraActualId);
if (!v) return;
v.notas.splice(i, 1);
guardarEstadoLocal();
renderNotasVentana();
}
async function agregarBanner(){
const texto = valor('banner-texto').trim();
if (!texto){ mostrarToast(tr('banner_mensajes__escribe_un_texto_para_el')); return; }
const archivo = document.getElementById('banner-imagen')?.files?.[0];
let imagen = null;
if (archivo){
imagen = await new Promise(resolve => {
const lector = new FileReader();
lector.onload = () => resolve(lector.result);
lector.readAsDataURL(archivo);
});
}
estado.banners.push({
id: 'b' + Date.now(),
texto, imagen,
colorFondo: valor('banner-color-fondo') || '#1F3A2E',
colorTexto: valor('banner-color-texto') || '#FFFFFF',
tamanoTexto: valor('banner-tamano') || 'text-base',
fechaInicio: valor('banner-fecha-inicio'),
fechaFin: valor('banner-fecha-fin'),
activo: true,
});
limpiarCampos(['banner-texto','banner-fecha-inicio','banner-fecha-fin']);
establecerValor('banner-imagen', '');
renderListaBanners();
mostrarToast(tr('banner_mensajes__banner_programado'));
}
function toggleBanner(id, val){
const b = estado.banners.find(x => x.id === id);
if (b) b.activo = val;
renderListaBanners();
}
function eliminarBanner(id){
const i = estado.banners.findIndex(x => x.id === id);
if (i === -1) return;
const borrado = estado.banners.splice(i, 1)[0];
renderListaBanners();
mostrarToast(tr('banner_mensajes__banner_eliminado'), () => {
estado.banners.splice(i, 0, borrado);
renderListaBanners();
mostrarToast(tr('banner_mensajes__banner_restaurado'));
});
}
function renderListaBanners(){
const cont = document.getElementById('lista-banners');
if (!cont) return;
if (estado.banners.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-2" style="color:var(--sage);">${tr('banner_mensajes__aun_no_programas_banners')}</p>`;
return;
}
cont.innerHTML = estado.banners.map(b => `
<div class="flex items-center justify-between py-2" style="border-top:2px solid var(--line);">
<div>
<p class="font-medium text-sm">${b.texto}</p>
<p class="text-xs" style="color:var(--sage);">${b.fechaInicio || 'sin inicio'} — ${b.fechaFin || 'sin fin'}</p>
</div>
<div class="flex items-center gap-2">
<label class="switch">
<input type="checkbox" ${b.activo ? 'checked' : ''} onchange="toggleBanner('${b.id}', this.checked)">
<span class="switch-slider"></span>
</label>
<button onclick="eliminarBanner('${b.id}')" class="text-sm px-2 py-1 rounded-full transition-transform active:scale-90" style="color:var(--red);">
<i class="fa-solid fa-trash"></i>
</button>
</div>
</div>`).join('');
}
function bannerVigente(){
const hoy = new Date(); hoy.setHours(0,0,0,0);
return estado.banners.find(b => {
if (!b.activo) return false;
if (b.fechaInicio && new Date(b.fechaInicio) > hoy) return false;
if (b.fechaFin && new Date(b.fechaFin) < hoy) return false;
return true;
});
}
let bannerCerradoId = null;
function renderBannerHome(){
const cont = document.getElementById('banner-home');
if (!cont) return;
const b = bannerVigente();
if (b && b.id !== bannerCerradoId){
cont.innerHTML = `
<div class="rounded-2xl overflow-hidden" style="background:${b.colorFondo};">
${b.imagen ? `<img loading="lazy" decoding="async" src="${b.imagen}" class="w-full h-32 object-cover">` : ''}
<div class="p-4 flex items-center justify-between gap-2">
<p class="${b.tamanoTexto} font-bold" style="color:${b.colorTexto};">${b.texto}</p>
<button onclick="cerrarBanner('${b.id}')" class="flex-shrink-0" style="color:${b.colorTexto};"><i class="fa-solid fa-xmark"></i></button>
</div>
</div>`;
cont.classList.remove('hidden');
} else if (calcularNotificaciones().length > 0) {
cont.innerHTML = `
<button onclick="irA('notificaciones')" class="w-full rounded-2xl p-4 flex items-center gap-3 text-left" style="background:var(--yellow); color:#3A2A0B;">
<i class="fa-solid fa-bell"></i>
<span class="font-bold text-sm">${tr('banner_mensajes__tienes_notificaciones_pendientes_t')}</span>
</button>`;
cont.classList.remove('hidden');
} else {
cont.innerHTML = '';
cont.classList.add('hidden');
}
}
function cerrarBanner(id){
bannerCerradoId = id;
renderBannerHome();
}
async function agregarBoletin(){
const titulo = valor('bol-titulo'), texto = valor('bol-texto');
if (!titulo) return;
const archivo = document.getElementById('bol-imagen')?.files?.[0];
let imagen = null;
if (archivo){
imagen = await new Promise(resolve => {
const lector = new FileReader();
lector.onload = () => resolve(lector.result);
lector.readAsDataURL(archivo);
});
}
const hoy = new Date().toLocaleDateString('es-MX', { day:'2-digit', month:'short', year:'numeric' }).toUpperCase();
estado.boletines.unshift({ titulo, texto, fecha: hoy, imagen });
limpiarCampos(['bol-titulo','bol-texto']);
establecerValor('bol-imagen', '');
renderBoletinesAdmin();
mostrarToast(tr('banner_mensajes__boletin_publicado'));
}
function renderBoletinesAdmin(){
const cont = document.getElementById('lista-boletines-admin');
cont.innerHTML = estado.boletines.map((b, i) => `
<div class="item-registro flex items-center justify-between">
<div><p class="font-bold text-sm">${b.titulo}</p><p class="text-xs" style="color:var(--sage);">${b.fecha}</p></div>
<button onclick="eliminarBoletin(${i})" style="color:var(--red);"><i class="fa-solid fa-trash"></i></button>
</div>`).join('');
}
function eliminarBoletin(i){
const [borrado] = estado.boletines.splice(i,1);
renderBoletinesAdmin();
mostrarToast(tr('banner_mensajes__boletin_eliminado'), () => {
estado.boletines.splice(i, 0, borrado);
renderBoletinesAdmin();
mostrarToast(tr('banner_mensajes__boletin_restaurado'));
});
}
let toastTimeout = null;
let toastDeshacerFn = null;
function mostrarToast(mensaje, accionDeshacer){
if (typeof guardarEstadoLocal === 'function') guardarEstadoLocal();
let toast = document.getElementById('toast-confirmacion');
if (!toast){
toast = document.createElement('div');
toast.id = 'toast-confirmacion';
toast.className = 'fixed left-1/2 z-50 font-bold text-sm px-5 py-3 rounded-full shadow-2xl flex items-center gap-3';
toast.style.cssText = 'bottom:100px; transform:translateX(-50%) translateY(20px); background:var(--green); color:#fff; opacity:0; transition:opacity .2s, transform .2s;';
document.body.appendChild(toast);
}
toastDeshacerFn = accionDeshacer || null;
toast.style.background = accionDeshacer ? 'var(--ink)' : 'var(--green)';
toast.innerHTML = `<i class="fa-solid ${accionDeshacer ? 'fa-trash' : 'fa-circle-check'}"></i><span>${mensaje}</span>` +
(accionDeshacer ? `<button onclick=\"ejecutarDeshacer()\" class=\"font-extrabold rounded-full px-3 py-1 transition-transform active:scale-90\" style=\"background:rgba(255,255,255,0.18);\">${tr('confirmacion_visual_al__deshacer')}</button>` : '');
toast.style.opacity = '1';
toast.style.transform = 'translateX(-50%) translateY(0)';
clearTimeout(toastTimeout);
toastTimeout = setTimeout(() => {
toast.style.opacity = '0';
toast.style.transform = 'translateX(-50%) translateY(20px)';
toastDeshacerFn = null;
}, accionDeshacer ? 4500 : 2200);
}
function ejecutarDeshacer(){
if (toastDeshacerFn) toastDeshacerFn();
toastDeshacerFn = null;
const toast = document.getElementById('toast-confirmacion');
if (toast){ toast.style.opacity = '0'; toast.style.transform = 'translateX(-50%) translateY(20px)'; }
clearTimeout(toastTimeout);
}
// Banner chico de notificación, esquina inferior izquierda, con animación de
// "cortina" (se revela de izquierda a derecha) y que se oculta solo después de
// unos segundos. Pensado para avisos de fondo que no necesitan interrumpir a la
// persona (ej. "Foto subida", "Sincronizado") — a diferencia de mostrarToast(),
// que es para confirmaciones de una acción que la persona acaba de hacer.
let bannerNotificacionTimeout = null;
function mostrarBannerNotificacion(mensaje, duracionMs, icono){
let banner = document.getElementById('banner-notificacion-cortina');
if (!banner){
banner = document.createElement('div');
banner.id = 'banner-notificacion-cortina';
document.body.appendChild(banner);
}
clearTimeout(bannerNotificacionTimeout);
banner.classList.remove('ocultar');
banner.innerHTML = `<i class="fa-solid ${icono || 'fa-circle-check'}"></i><span>${mensaje}</span>`;
// Se fuerza un reflow antes de agregar la clase para que la animación de
// entrada se reproduzca de nuevo aunque el banner ya estuviera visible.
void banner.offsetWidth;
banner.classList.add('mostrar');
bannerNotificacionTimeout = setTimeout(() => {
banner.classList.remove('mostrar');
banner.classList.add('ocultar');
}, duracionMs || 3500);
}


  window['cargarTesseractSiNecesario'] = cargarTesseractSiNecesario;
  window['precargarTesseractEnSegundoPlano'] = precargarTesseractEnSegundoPlano;
  window['encolarLecturaOCR'] = encolarLecturaOCR;
  window['extraerTextoDeImagen'] = extraerTextoDeImagen;
  window['mostrarModalAjustarEsquinas'] = mostrarModalAjustarEsquinas;
  window['actualizarGeometriaAjusteEsquinas'] = actualizarGeometriaAjusteEsquinas;
  window['dibujarEsquinasAjuste'] = dibujarEsquinasAjuste;
  window['inicializarArrastreEsquinas'] = inicializarArrastreEsquinas;
  window['cancelarAjusteEsquinas'] = cancelarAjusteEsquinas;
  window['confirmarAjusteEsquinas'] = confirmarAjusteEsquinas;
  window['ordenarEsquinasCuadrilatero'] = ordenarEsquinasCuadrilatero;
  window['distanciaPuntos'] = distanciaPuntos;
  window['resolverSistemaLineal8x8'] = resolverSistemaLineal8x8;
  window['calcularHomografia'] = calcularHomografia;
  window['aplicarHomografia'] = aplicarHomografia;
  window['muestrearPixelBilineal'] = muestrearPixelBilineal;
  window['recortarYEnderezarImagen'] = recortarYEnderezarImagen;
  window['reemplazarArchivoDeInput'] = reemplazarArchivoDeInput;
  window['previsualizarEscaneo'] = previsualizarEscaneo;
  window['ajustarYLeerEscaneo'] = ajustarYLeerEscaneo;
  window['guardarBorradorEscaneoDoc'] = guardarBorradorEscaneoDoc;
  window['limpiarBorradorEscaneoDoc'] = limpiarBorradorEscaneoDoc;
  window['restaurarBorradorEscaneoDoc'] = restaurarBorradorEscaneoDoc;
  window['cambiarPasoEscaneo'] = cambiarPasoEscaneo;
  window['abrirEscaneoDocumentos'] = abrirEscaneoDocumentos;
  window['extraerCURP'] = extraerCURP;
  window['normalizarUPP'] = normalizarUPP;
  window['extraerUPPPorPatron'] = extraerUPPPorPatron;
  window['extraerNumeroTrasEtiqueta'] = extraerNumeroTrasEtiqueta;
  window['extraerFechaISOTexto'] = extraerFechaISOTexto;
  window['normalizarParaBuscarEtiqueta'] = normalizarParaBuscarEtiqueta;
  window['extraerTrasEtiqueta'] = extraerTrasEtiqueta;
  window['extraerDatosCredencial'] = extraerDatosCredencial;
  window['iniciarRecorteDesdeEscaneo'] = iniciarRecorteDesdeEscaneo;
  window['extraerDatosConstanciaUPP'] = extraerDatosConstanciaUPP;
  window['convertirAreteMX'] = convertirAreteMX;
  window['extraerIdentificadoresSINIIGADirigidos'] = extraerIdentificadoresSINIIGADirigidos;
  window['abrirCapturaDocumento'] = abrirCapturaDocumento;
  window['evaluarNitidezImagenOCR'] = evaluarNitidezImagenOCR;
  window['normalizarCandidatoIdentificadorSINIIGA'] = normalizarCandidatoIdentificadorSINIIGA;
  window['parsearFilasSINIIGA'] = parsearFilasSINIIGA;
  window['fusionarIdentificadoresSINIIGA'] = fusionarIdentificadoresSINIIGA;
  window['extraerTablaSINIIGA'] = extraerTablaSINIIGA;
  window['agregarFilaSINIIGAManual'] = agregarFilaSINIIGAManual;
  window['actualizarFilaSINIIGA'] = actualizarFilaSINIIGA;
  window['eliminarFilaSINIIGA'] = eliminarFilaSINIIGA;
  window['renderFilasSINIIGA'] = renderFilasSINIIGA;
  window['fechaAISOSiPosible'] = fechaAISOSiPosible;
  window['actualizarResumenImportarEscaneo'] = actualizarResumenImportarEscaneo;
  window['extraerDatosFormatoPruebaCampo'] = extraerDatosFormatoPruebaCampo;
  window['confirmarImportacionEscaneo'] = confirmarImportacionEscaneo;
  window['abrirEdicionProductor'] = abrirEdicionProductor;
  window['validarLongitudCampo'] = validarLongitudCampo;
  window['guardarEdicionProductor'] = guardarEdicionProductor;
  window['quitarPrefijoLetra'] = quitarPrefijoLetra;
  window['renderTogglesModulos'] = renderTogglesModulos;
  window['renderTogglesPermisosTrabajador'] = renderTogglesPermisosTrabajador;
  window['toggleModuloTrabajador'] = toggleModuloTrabajador;
  window['renderListaIconosBotones'] = renderListaIconosBotones;
  window['actualizarIconoBoton'] = actualizarIconoBoton;
  window['renderListaOrdenMas'] = renderListaOrdenMas;
  window['moverOrdenMas'] = moverOrdenMas;
  window['renderListaOrdenGraficas'] = renderListaOrdenGraficas;
  window['moverOrdenGraficas'] = moverOrdenGraficas;
  window['toggleGraficaVisible'] = toggleGraficaVisible;
  window['agregarPlanSanitario'] = agregarPlanSanitario;
  window['eliminarPlanSanitario'] = eliminarPlanSanitario;
  window['renderListaPlanSanitario'] = renderListaPlanSanitario;
  window['exportarReporteSanitarioAnual'] = exportarReporteSanitarioAnual;
  window['generarCodigoTrabajador'] = generarCodigoTrabajador;
  window['trabajadoresDelAmbito'] = trabajadoresDelAmbito;
  window['agregarTrabajador'] = agregarTrabajador;
  window['eliminarTrabajador'] = eliminarTrabajador;
  window['renderListaTrabajadores'] = renderListaTrabajadores;
  window['agregarTarea'] = agregarTarea;
  window['eliminarTarea'] = eliminarTarea;
  window['nombreTrabajador'] = nombreTrabajador;
  window['renderListaTareasAdmin'] = renderListaTareasAdmin;
  window['renderTogglesCampos'] = renderTogglesCampos;
  window['toggleModulo'] = toggleModulo;
  window['toggleCampo'] = toggleCampo;
  window['renderCamposPersonalizadosAdmin'] = renderCamposPersonalizadosAdmin;
  window['agregarCampoPersonalizado'] = agregarCampoPersonalizado;
  window['eliminarCampoPersonalizado'] = eliminarCampoPersonalizado;
  window['renderCamposPersonalizadosFormulario'] = renderCamposPersonalizadosFormulario;
  window['leerCamposPersonalizadosFormulario'] = leerCamposPersonalizadosFormulario;
  window['renderTogglesVentanasExtra'] = renderTogglesVentanasExtra;
  window['agregarVentana'] = agregarVentana;
  window['toggleVentanaExtra'] = toggleVentanaExtra;
  window['eliminarVentana'] = eliminarVentana;
  window['abrirVentanaExtra'] = abrirVentanaExtra;
  window['renderNotasVentana'] = renderNotasVentana;
  window['agregarNotaVentana'] = agregarNotaVentana;
  window['eliminarNotaVentana'] = eliminarNotaVentana;
  window['agregarBanner'] = agregarBanner;
  window['toggleBanner'] = toggleBanner;
  window['eliminarBanner'] = eliminarBanner;
  window['renderListaBanners'] = renderListaBanners;
  window['bannerVigente'] = bannerVigente;
  window['renderBannerHome'] = renderBannerHome;
  window['cerrarBanner'] = cerrarBanner;
  window['agregarBoletin'] = agregarBoletin;
  window['renderBoletinesAdmin'] = renderBoletinesAdmin;
  window['eliminarBoletin'] = eliminarBoletin;
  window['mostrarToast'] = mostrarToast;
  window['ejecutarDeshacer'] = ejecutarDeshacer;
  window['mostrarBannerNotificacion'] = mostrarBannerNotificacion;
  window['validarConsistenciaDocumentosMiRanch'] = validarConsistenciaDocumentosMiRanch;
  window['ocr2ProcesarFiguraFierro'] = ocr2ProcesarFiguraFierro;
})();


// ============================================================
// MiRanch OCR 2.0 — MOTOR DE CAPTURA DE ALTA PRECISIÓN
// ============================================================
// Esta capa se monta sobre el OCR existente sin eliminarlo. Añade:
// - control de calidad antes de leer (nitidez, exposición, reflejos, cobertura)
// - múltiples variantes de imagen y consenso entre lecturas
// - corrección contextual de campos mexicanos (CURP, UPP, fechas, arete)
// - lectura por zonas cuando una lectura global queda dudosa
// - procesamiento por lotes de varias hojas de inventario
// - deduplicación y fusión de renglones entre fotografías
// - reporte visual de calidad y progreso
// - conservación de la fotografía original como evidencia
// Nunca convierte una estimación en dato definitivo sin revisión humana.
const MIRANCH_OCR2 = {
  version: '2.0.0',
  maxVariantes: 10,
  maxImagenesLote: 20,
  calidadMinimaOCR: 58
};
function ocr2Clamp(v,a=0,b=1){ return Math.max(a,Math.min(b,v)); }
function ocr2NormalizarTexto(s){
  return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase();
}
async function ocr2CalidadImagen(dataUrl){
  try{
    const img=await cargarImagenOCR(dataUrl);
    const c=canvasDesdeImagenOCR(img,1000), ctx=c.getContext('2d',{willReadFrequently:true});
    const im=ctx.getImageData(0,0,c.width,c.height), d=im.data, w=c.width,h=c.height;
    let sum=0,sum2=0,lapSum=0,lap2=0,n=0,bright=0,dark=0,glare=0,edges=0;
    const gray=new Float32Array(w*h);
    for(let y=0;y<h;y++) for(let x=0;x<w;x++){
      const i=(y*w+x)*4, g=.299*d[i]+.587*d[i+1]+.114*d[i+2]; gray[y*w+x]=g;
      sum+=g; sum2+=g*g; n++;
      if(g>=248) bright++; if(g<=12) dark++;
      if(d[i]>247 && d[i+1]>247 && d[i+2]>247) glare++;
    }
    const mean=sum/n, variance=Math.max(0,sum2/n-mean*mean);
    for(let y=1;y<h-1;y+=2) for(let x=1;x<w-1;x+=2){
      const p=y*w+x, lap=gray[p-w]+gray[p-1]-4*gray[p]+gray[p+1]+gray[p+w];
      lapSum+=lap; lap2+=lap*lap; edges += Math.abs(lap)>28 ? 1:0;
    }
    const count=((Math.floor((w-1)/2))*(Math.floor((h-1)/2)));
    const lapVar=Math.max(0,lap2/Math.max(1,count)-Math.pow(lapSum/Math.max(1,count),2));
    const clipBright=bright/n, clipDark=dark/n, glareRatio=glare/n, edgeRatio=edges/Math.max(1,count);
    // La calidad no es un número de "certeza del OCR"; es una puerta de captura.
    const nitidez=ocr2Clamp((Math.log10(lapVar+1)-1.15)/2.0);
    const exposicion=1-ocr2Clamp(Math.max(0,clipBright-.018)*5 + Math.max(0,clipDark-.025)*2.2);
    const reflejo=1-ocr2Clamp(glareRatio*5.5);
    const contraste=ocr2Clamp((Math.sqrt(variance)/55),0,1);
    const score=Math.round(100*(.42*nitidez+.22*exposicion+.18*reflejo+.18*contraste));
    return {score,nitidez:Math.round(nitidez*100),exposicion:Math.round(exposicion*100),reflejo:Math.round(reflejo*100),contraste:Math.round(contraste*100),lapVar,clipBright,clipDark,glareRatio,edgeRatio,width:w,height:h};
  }catch(e){ return {score:0,error:String(e.message||e)}; }
}
function ocr2MensajeCalidad(q){
  if(!q) return 'No se pudo evaluar la calidad de la foto.';
  if(q.score>=82) return 'Excelente: la foto tiene buenas condiciones para una lectura de alta precisión.';
  if(q.score>=65) return 'Buena: se puede leer. El motor aplicará mejoras automáticas.';
  if(q.score>=50) return 'Regular: intentaremos rescatarla con varias técnicas, pero conviene una foto más nítida si algún dato queda dudoso.';
  return 'Baja: hay riesgo de perder caracteres. Toma la hoja completa, de frente, sin reflejos y con buena luz.';
}
function ocr2MostrarCalidad(q,extra=''){
  let box=document.getElementById('miranch-ocr2-calidad');
  if(!box){
    box=document.createElement('div'); box.id='miranch-ocr2-calidad';
    box.style.cssText='position:fixed;left:12px;right:12px;bottom:14px;z-index:9998;background:rgba(255,255,255,.97);border:2px solid var(--line,#ddd);border-radius:20px;padding:12px 14px;box-shadow:0 12px 40px rgba(0,0,0,.18);font-size:12px;';
    document.body.appendChild(box);
  }
  const s=q?.score??0, etiqueta=s>=82?'Excelente':s>=65?'Buena':s>=50?'Regular':'Baja';
  box.innerHTML=`<div style="display:flex;justify-content:space-between;gap:10px;align-items:center"><b style="font-size:13px">Calidad de captura · ${etiqueta}</b><b>${s}/100</b></div><div style="height:7px;border-radius:99px;background:var(--parchment,#eee);margin:7px 0;overflow:hidden"><div style="height:100%;width:${s}%;background:var(--green,#4c9959);border-radius:99px"></div></div><div style="color:var(--sage,#567);line-height:1.35">${ocr2MensajeCalidad(q)}${extra?' '+extra:''}</div>`;
  clearTimeout(ocr2MostrarCalidad._t); ocr2MostrarCalidad._t=setTimeout(()=>box.remove(),7000);
}
function ocr2CanvasToDataUrl(c){ return c.toDataURL('image/jpeg',.9); }
async function ocr2ProcesarVariante(dataUrl,modo){
  const img=await cargarImagenOCR(dataUrl);
  const c=canvasDesdeImagenOCR(img, modo==='up2x'?3000:2400);
  const {ctx,im,g,w,h}=grisDesdeCanvasOCR(c), px=im.data;
  // Reutiliza el preprocesador existente cuando está disponible.
  try{ aplicarMejorasImagenOCR(c,modo==='adaptive'?'binario':(modo==='sharp'?'nitida':'contraste')); }
  catch(e){}
  if(modo==='otsu' || modo==='adaptive' || modo==='invert'){
    const d=c.getContext('2d',{willReadFrequently:true}).getImageData(0,0,w,h), a=d.data;
    let hist=new Array(256).fill(0), total=w*h;
    for(let i=0;i<a.length;i+=4){ const v=Math.round(.299*a[i]+.587*a[i+1]+.114*a[i+2]); hist[v]++; }
    let sum=0; for(let i=0;i<256;i++) sum+=i*hist[i];
    let sumB=0,wB=0,max=0,thr=128;
    for(let i=0;i<256;i++){ wB+=hist[i]; if(!wB) continue; const wF=total-wB; if(!wF) break; sumB+=i*hist[i]; const mB=sumB/wB,mF=(sum-sumB)/wF; const between=wB*wF*(mB-mF)*(mB-mF); if(between>max){max=between;thr=i;} }
    for(let i=0;i<a.length;i+=4){ let v=Math.round(.299*a[i]+.587*a[i+1]+.114*a[i+2]); if(modo==='adaptive'){
      // umbral local aproximado usando promedio de vecindad barata en mosaicos.
      v=v>thr?255:0;
    } else v=v>thr?255:0; if(modo==='invert') v=255-v; a[i]=a[i+1]=a[i+2]=v; }
    c.getContext('2d').putImageData(d,0,0);
  }
  if(modo==='up2x'){
    const up=document.createElement('canvas'); up.width=Math.min(3200,w*1.5); up.height=Math.min(3600,h*1.5); up.getContext('2d').drawImage(c,0,0,up.width,up.height); return ocr2CanvasToDataUrl(up);
  }
  return ocr2CanvasToDataUrl(c);
}
async function ocr2GenerarVariantes(dataUrl,tipo){
  const variantes=[{dataUrl,etiqueta:'original'}];
  const modos=['sharp','contraste','binario','otsu','adaptive','invert','up2x'];
  for(const m of modos){ try{ variantes.push({dataUrl:await ocr2ProcesarVariante(dataUrl,m),etiqueta:m}); }catch(e){} }
  // Rotaciones solo si la calidad/lectura posterior lo necesita.
  return variantes.slice(0,MIRANCH_OCR2.maxVariantes);
}
function ocr2NormalizarCURP(v){
  let s=ocr2NormalizarTexto(v).replace(/[^A-Z0-9]/g,'');
  if(s.length!==18) return '';
  // Correcciones SOLO en posiciones alfabéticas/númericas apropiadas.
  const chars=s.split('');
  [0,1,2,3,5,6,7,8,9,11,12,13,14,15,16,17].forEach(i=>{ if(/[0-9]/.test(chars[i])) chars[i]={'0':'O','1':'I','5':'S','8':'B','6':'G'}[chars[i]]||chars[i]; });
  [4,10].forEach(i=>{ if(/[A-Z]/.test(chars[i])) chars[i]={'O':'0','I':'1','S':'5','B':'8','G':'6'}[chars[i]]||chars[i]; });
  s=chars.join(''); return /^[A-Z]{4}\d{6}[HM][A-Z]{5}[A-Z0-9]\d$/.test(s)?s:'';
}
function ocr2NormalizarUPP(v){
  let s=String(v||'').toUpperCase().replace(/[OoQq]/g,'0').replace(/[IiLl|]/g,'1').replace(/[Ss]/g,'5').replace(/[^0-9]/g,'');
  if(s.length===11) s='0'+s; return /^\d{12}$/.test(s)?s:'';
}
function ocr2NormalizarArete(v){
  let s=String(v||'').toUpperCase().replace(/[OoQq]/g,'0').replace(/[IiLl|]/g,'1').replace(/[Ss]/g,'5').replace(/[^0-9]/g,'');
  if(s.length<6 || s.length>15) return ''; return s;
}
function ocr2ValidarFechaISO(v){
  const m=String(v||'').match(/^(\d{4})-(\d{2})-(\d{2})$/); if(!m) return false;
  const d=new Date(`${m[1]}-${m[2]}-${m[3]}T00:00:00`); return !isNaN(d) && d.getFullYear()==+m[1] && d.getMonth()+1==+m[2] && d.getDate()==+m[3];
}
function ocr2ElegirConsenso(candidatos,normalizador){
  const mapa=new Map();
  for(const c of candidatos||[]){ const n=normalizador(c.valor); if(!n) continue; const peso=(Number(c.confianza)||0)/100 + (Number(c.score)||0)/200; const x=mapa.get(n)||{valor:n,peso:0,veces:0}; x.peso+=1+peso; x.veces++; mapa.set(n,x); }
  return [...mapa.values()].sort((a,b)=>b.peso-a.peso || b.veces-a.veces)[0]||null;
}
async function ocr2ReconocerUna(imagen,tipo){
  await cargarTesseractSiNecesario();
  const psm=MODO_SEGMENTACION_OCR[tipo]||null;
  const extra=psm?{tessedit_pageseg_mode:psm}:{};
  if(tipo==='tabla_id') extra.tessedit_char_whitelist='0123456789';
  let r;
  try{ r=await window.Tesseract.recognize(imagen,'spa',{langPath:'https://cdn.jsdelivr.net/npm/@tesseract.js-data/spa@1.0.0/4.0.0_fast/',...extra}); }
  catch(e){ r=await window.Tesseract.recognize(imagen,'spa',extra); }
  return {text:(r?.data?.text)||'',data:r?.data||{}};
}
function ocr2PuntuarLectura(t,tipo){
  let s=typeof puntuarTextoOCR==='function'?puntuarTextoOCR(t,tipo):0;
  const n=ocr2NormalizarTexto(t);
  if(/\bCURP\b/.test(n)) s+=8; if(/\bUPP\b/.test(n)) s+=8; if(/SINIIGA|REEMO/.test(n)) s+=7;
  if(tipo==='tabla' && (n.match(/\b\d{6,15}\b/g)||[]).length) s+=12;
  return s;
}
async function extraerTextoDeImagenAltaPrecisionOCR(dataUrl,onEstado,tipoDocumento){
  return encolarLecturaOCR(async()=>{
    if(onEstado) onEstado('descargando'); await cargarTesseractSiNecesario();
    if(onEstado) onEstado('preprocesando');
    const q=await ocr2CalidadImagen(dataUrl); ocr2MostrarCalidad(q);
    let base=dataUrl;
    try{ const auto=await detectarYEnderezarDocumentoOCR(dataUrl); if(auto?.detectado) base=auto.dataUrl; }catch(e){}
    const variantes=await ocr2GenerarVariantes(base,tipoDocumento);
    const lecturas=[]; let mejor=null;
    for(let i=0;i<variantes.length;i++){
      if(onEstado) onEstado(`leyendo ${i+1}/${variantes.length}`);
      try{
        const r=await ocr2ReconocerUna(variantes[i].dataUrl,tipoDocumento);
        const score=ocr2PuntuarLectura(r.text,tipoDocumento);
        lecturas.push({...r,...variantes[i],score});
        if(!mejor || score>mejor.score) mejor=lecturas.at(-1);
      }catch(e){ console.warn('OCR2 variante omitida',variantes[i].etiqueta,e); }
    }
    // Orientación: solo si ninguna variante obtuvo una lectura sólida.
    if((mejor?.score||0)<55){
      for(const ang of [90,270]){ try{
        const rot=await rotarDataUrlOCR(base,ang), r=await ocr2ReconocerUna(rot,tipoDocumento), score=ocr2PuntuarLectura(r.text,tipoDocumento);
        if(!mejor || score>mejor.score) mejor={...r,dataUrl:rot,etiqueta:`rot${ang}`,score};
      }catch(e){} }
    }
    window.miranchUltimoOCR2={calidad:q,lecturas,mejor};
    return mejor?.text||'';
  });
}
// Compatibilidad: todas las llamadas antiguas pasan por el motor 2.0.
try{ window.extraerTextoDeImagen=extraerTextoDeImagenAltaPrecisionOCR; }catch(e){}

// ---------------- Calidad de captura por archivo ----------------
async function ocr2EvaluarArchivo(archivo){
  const data=await comprimirParaOCR(archivo,2200);
  return {dataUrl:data,calidad:await ocr2CalidadImagen(data)};
}
async function ocr2ProcesarLoteArchivos(archivos,tipoDocumento,estadoProgreso){
  const lista=[...(archivos||[])].slice(0,MIRANCH_OCR2.maxImagenesLote);
  const resultados=[];
  for(let i=0;i<lista.length;i++){
    if(estadoProgreso) estadoProgreso(i+1,lista.length);
    try{
      const {dataUrl,calidad}=await ocr2EvaluarArchivo(lista[i]);
      const texto=await extraerTextoDeImagenAltaPrecisionOCR(dataUrl,null,tipoDocumento);
      resultados.push({indice:i+1,nombre:lista[i].name,dataUrl,calidad,texto});
    }catch(e){ resultados.push({indice:i+1,nombre:lista[i].name,error:String(e.message||e),texto:''}); }
  }
  return resultados;
}
function ocr2DedupeFilasAnimales(filas){
  const mapa=new Map();
  for(const f of filas||[]){
    const arete=ocr2NormalizarArete(f.arete); if(!arete) continue;
    const k=arete; const completa=(f.raza?1:0)+(f.sexo?1:0)+(f.edadMeses!=null?1:0)+(f.fechaNacimiento?1:0)+(f.estatus?1:0);
    const anterior=mapa.get(k);
    if(!anterior || completa>(anterior.__completa||0)){ mapa.set(k,{...anterior,...f,arete,__completa:completa}); }
    else mapa.set(k,{...anterior,...Object.fromEntries(Object.entries(f).filter(([_,v])=>v!==''&&v!=null)),__completa:Math.max(anterior.__completa||0,completa)});
  }
  return [...mapa.values()].map(({__completa,...f})=>f);
}
function ocr2FusionarInventarioActual(nuevas){
  const base=Array.isArray(inventarioEscaneadoTemp)?inventarioEscaneadoTemp:[];
  inventarioEscaneadoTemp=ocr2DedupeFilasAnimales([...base,...nuevas]);
}
function ocr2ResumenLote(resultados){
  const hojas=resultados.length, buenas=resultados.filter(r=>(r.calidad?.score||0)>=65).length, bajas=resultados.filter(r=>(r.calidad?.score||0)<50).length;
  return `Procesadas ${hojas} hoja(s) · ${buenas} con buena calidad · ${bajas} para revisar`;
}
// ---------------- Importación multihofja del inventario del productor ----------------
async function procesarFotoInventarioCompletoProductorOCR2(inputEl){
  const archivos=[...(inputEl.files||[])]; if(!archivos.length) return;
  if(archivos.length>1) mostrarToast(`Preparando ${archivos.length} hojas del inventario...`); else mostrarToast('Leyendo tu Concentrado SINIIGA...');
  try{
    const resultados=await ocr2ProcesarLoteArchivos(archivos,'tabla',(i,n)=>mostrarToast(`Leyendo hoja ${i} de ${n}...`));
    const filas=[];
    for(const r of resultados){
      if(!r.texto) continue;
      const p=parsearConcentradoSINIIGA(r.texto);
      filas.push(...(p.inventarioCompleto||[]));
    }
    if(!filas.length){ mostrarToast('No se logró leer ningún arete en las hojas. Toma las hojas completas, rectas y con buena luz.'); return; }
    ocr2FusionarInventarioActual(filas.map(f=>({...f,incluir:true})));
    renderVistaPreviaInventarioProductor();
    document.getElementById('modal-confirmar-inventario-productor')?.classList.remove('hidden');
    mostrarToast(`${inventarioEscaneadoTemp.length} animal(es) detectados en ${archivos.length} hoja(s). Revisa antes de guardar.`);
  }catch(e){ console.warn('OCR2 inventario',e); mostrarToast('No se pudo procesar el lote de inventario: '+e.message); }
  finally{ try{inputEl.value='';}catch(e){} }
}
window.procesarFotoInventarioCompletoProductor=procesarFotoInventarioCompletoProductorOCR2;
// ---------------- Importación multihofja de listas para veterinario/campo ----------------
async function procesarFotoListaAnimalesOCR2(inputEl){
  const archivos=[...(inputEl.files||[])]; if(!archivos.length) return;
  try{
    const resultados=await ocr2ProcesarLoteArchivos(archivos,'tabla',(i,n)=>mostrarToast(`Leyendo hoja ${i} de ${n}...`));
    let filas=[];
    for(const r of resultados){
      if(!r.texto) continue;
      const oficial=/\breemo\b/i.test(r.texto)||( /\bvigente\b/i.test(r.texto)&&/\bventa\b/i.test(r.texto));
      if(oficial){ const p=parsearConcentradoSINIIGA(r.texto); filas.push(...p.inventarioCompleto.map(f=>({arete:f.arete,fechaNacimiento:null,edadMeses:f.edadMeses,raza:f.raza,sexo:f.sexo,dudoso:f.dudoso,incluir:f.vigenteYSinFolio,estatus:f.estatus,folioRemo:f.folioRemo}))); }
      else filas.push(...parsearListaAnimalesDesdeTexto(r.texto));
    }
    filas=ocr2DedupeFilasAnimales(filas); if(!filas.length){ mostrarToast('No se reconocieron renglones con arete.'); return; }
    listaAnimalesEscaneadaTemp=ocr2DedupeFilasAnimales([...(listaAnimalesEscaneadaTemp||[]),...filas]);
    renderVistaPreviaListaAnimales(); document.getElementById('modal-confirmar-lista-animales')?.classList.remove('hidden');
    mostrarToast(`${listaAnimalesEscaneadaTemp.length} animal(es) reunidos de ${archivos.length} hoja(s).`);
  }catch(e){ console.warn('OCR2 lista',e); mostrarToast('No se pudo procesar el lote: '+e.message); }
  finally{ try{inputEl.value='';}catch(e){} }
}
window.procesarFotoListaAnimales=procesarFotoListaAnimalesOCR2;
// ---------------- SINIIGA: varias hojas en una sola selección ----------------
async function extraerTablaSINIIGAOCR2(){
  const input=document.getElementById('esc-siniiga-input'); const archivos=[...(input?.files||[])];
  if(!archivos.length){ mostrarToast('Primero selecciona una o varias hojas del Concentrado SINIIGA'); return; }
  const boton=document.getElementById('esc-siniiga-btn-extraer'); if(boton) boton.disabled=true;
  try{
    const resultados=await ocr2ProcesarLoteArchivos(archivos,'tabla',(i,n)=>{ if(boton) boton.textContent=`Leyendo hoja ${i}/${n}...`; });
    let todas=[];
    for(const r of resultados){ if(!r.texto) continue; const p=parsearConcentradoSINIIGA(r.texto); todas.push(...(p?parsearFilasSINIIGA(r.texto):[])); }
    // Si el parser especializado no conservó todas las filas, usar el parser de respaldo.
    if(!todas.length){ for(const r of resultados){ if(r.texto) todas.push(...parsearFilasSINIIGA(r.texto)); } }
    const mapaIds=new Map(); for(const f of todas){ const id=String(f.identificador||'').trim(); if(!id) continue; const prev=mapaIds.get(id); mapaIds.set(id, prev ? {...prev,...Object.fromEntries(Object.entries(f).filter(([_,v])=>v!==''&&v!=null))} : {...f}); } filasSINIIGATemp=[...mapaIds.values()].map(f=>({identificador:f.identificador,estatus:f.estatus||'VIGENTE',sexo:f.sexo||'H',raza:f.raza||'SIN RAZA REGISTRADA',fechaNacimiento:f.fechaNacimiento||'',fechaAretado:f.fechaAretado||'',tipoMovimiento:f.tipoMovimiento||'',folioRemo:f.folioRemo||null}));
    document.getElementById('esc-siniiga-texto-crudo').textContent=resultados.map(r=>`--- ${r.nombre} ---\n${r.texto||'(sin lectura)'}`).join('\n');
    document.getElementById('esc-siniiga-resultado')?.classList.remove('hidden'); renderFilasSINIIGA();
    mostrarToast(`${filasSINIIGATemp.length} animal(es) detectados en ${archivos.length} hoja(s).`);
  }catch(e){ console.warn('OCR2 SINIIGA',e); mostrarToast('No se pudo leer el lote: '+e.message); }
  finally{ if(boton){ boton.disabled=false; boton.innerHTML='<i class="fa-solid fa-wand-magic-sparkles"></i> Extraer tabla de animales'; } try{input.value='';}catch(e){} }
}
window.extraerTablaSINIIGA=extraerTablaSINIIGAOCR2;
// ---------------- Recorte/vectorización inteligente del fierro ----------------
async function ocr2ProcesarFiguraFierro(dataUrl){
  const img=await cargarImagenOCR(dataUrl); const c=canvasDesdeImagenOCR(img,1400); const ctx=c.getContext('2d',{willReadFrequently:true});
  const d=ctx.getImageData(0,0,c.width,c.height), a=d.data; let gray=new Uint8Array(c.width*c.height);
  for(let y=0;y<c.height;y++) for(let x=0;x<c.width;x++){ const i=(y*c.width+x)*4; gray[y*c.width+x]=Math.round(.299*a[i]+.587*a[i+1]+.114*a[i+2]); }
  // Umbral adaptativo aproximado y limpieza de fondo. Se conserva el original fuera de esta representación.
  let min=255,max=0; for(const v of gray){if(v<min)min=v;if(v>max)max=v;} const thr=min+(max-min)*.55;
  for(let i=0;i<gray.length;i++){ const v=gray[i]<thr?0:255; a[i*4]=a[i*4+1]=a[i*4+2]=v; a[i*4+3]=255; }
  ctx.putImageData(d,0,0);
  // Normalización geométrica: recorta el contorno detectado, agrega margen y
  // lo centra en un lienzo cuadrado. Esto produce una marca visual limpia sin
  // alterar la evidencia original.
  let minX=c.width,minY=c.height,maxX=-1,maxY=-1;
  for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++)if(gray[y*c.width+x]<150){if(x<minX)minX=x;if(x>maxX)maxX=x;if(y<minY)minY=y;if(y>maxY)maxY=y;}
  if(maxX>=minX&&maxY>=minY){
    const bw=maxX-minX+1,bh=maxY-minY+1, margen=Math.max(12,Math.round(Math.max(bw,bh)*.14)), lado=Math.max(bw,bh)+margen*2;
    const nc=document.createElement('canvas');nc.width=lado;nc.height=lado;const nctx=nc.getContext('2d',{willReadFrequently:true});nctx.fillStyle='#fff';nctx.fillRect(0,0,lado,lado);
    const offX=Math.round((lado-bw)/2),offY=Math.round((lado-bh)/2);nctx.drawImage(c,minX,minY,bw,bh,offX,offY,bw,bh);
    const nd=nctx.getImageData(0,0,lado,lado).data, ng=new Uint8Array(lado*lado);for(let i=0;i<ng.length;i++)ng[i]=nd[i*4];
    return {png:nc.toDataURL('image/png'),svg:ocr2RasterASVG(ng,lado,lado)};
  }
  return {png:c.toDataURL('image/png'),svg:ocr2RasterASVG(gray,c.width,c.height)};
}
function ocr2RasterASVG(gray,w,h){
  // Vectorización por contornos: reduce la máscara del fierro a componentes
  // conectados y genera rutas SVG cerradas. Es una representación geométrica
  // editable; la fotografía original y el PNG procesado se conservan aparte.
  const paso=Math.max(1,Math.ceil(Math.max(w,h)/900)), sw=Math.ceil(w/paso), sh=Math.ceil(h/paso);
  const mask=new Uint8Array(sw*sh), vis=new Uint8Array(sw*sh), comps=[];
  for(let y=0;y<sh;y++)for(let x=0;x<sw;x++)mask[y*sw+x]=(gray[Math.min(h-1,y*paso)*w+Math.min(w-1,x*paso)]<150)?1:0;
  const nb=[[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
  for(let y=0;y<sh;y++)for(let x=0;x<sw;x++){const k=y*sw+x;if(!mask[k]||vis[k])continue;const q=[k],pts=[];vis[k]=1;while(q.length){const cur=q.pop(),cy=Math.floor(cur/sw),cx=cur-cy*sw;pts.push([cx,cy]);for(const [dx,dy] of nb){const nx=cx+dx,ny=cy+dy;if(nx<0||ny<0||nx>=sw||ny>=sh)continue;const nk=ny*sw+nx;if(mask[nk]&&!vis[nk]){vis[nk]=1;q.push(nk);}}}if(pts.length>=5)comps.push(pts);}
  const rdp=(pts,eps)=>{if(pts.length<=2)return pts;let md=0,mi=0;const a=pts[0],b=pts[pts.length-1],dx=b[0]-a[0],dy=b[1]-a[1],den=Math.hypot(dx,dy)||1;for(let i=1;i<pts.length-1;i++){const d=Math.abs(dy*(pts[i][0]-a[0])-dx*(pts[i][1]-a[1]))/den;if(d>md){md=d;mi=i;}}if(md>eps){const l=rdp(pts.slice(0,mi+1),eps),r=rdp(pts.slice(mi),eps);return l.slice(0,-1).concat(r);}return [a,b];};
  const paths=[];
  for(const pts of comps){const set=new Set(pts.map(p=>p[0]+','+p[1])),b=[];for(const [x,y] of pts)if([[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy])=>!set.has((x+dx)+','+(y+dy))))b.push([x*paso,y*paso]);if(b.length<3)continue;const cx=b.reduce((a,p)=>a+p[0],0)/b.length,cy=b.reduce((a,p)=>a+p[1],0)/b.length;b.sort((a,z)=>Math.atan2(a[1]-cy,a[0]-cx)-Math.atan2(z[1]-cy,z[0]-cx));const q=rdp(b.concat([b[0]]),Math.max(1,paso*.65));if(q.length<3)continue;const d=q.map((p,i)=>(i?'L':'M')+' '+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' ')+' Z';paths.push('<path d="'+d+'"/>');}
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '+w+' '+h+'" fill="currentColor" stroke="currentColor" stroke-width="'+Math.max(.6,paso*.3)+'" stroke-linejoin="round">'+paths.join('')+'</svg>';
}
window.miranchOCR2={calidad:ocr2CalidadImagen,procesarLote:ocr2ProcesarLoteArchivos,procesarFierro:ocr2ProcesarFiguraFierro,normalizarCURP:ocr2NormalizarCURP,normalizarUPP:ocr2NormalizarUPP,normalizarArete:ocr2NormalizarArete};

