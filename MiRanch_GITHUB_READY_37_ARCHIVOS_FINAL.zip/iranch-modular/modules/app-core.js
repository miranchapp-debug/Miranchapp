

const LOGO_B64 = "./iranch-modular/assets/logo-miranch-horizontal.png";
let idiomaActual = localStorage.getItem('miRanchAppIdioma') || 'es';
const I18N = {
es: {
salir:'Salir', volver:'Volver', guardar:'Guardar', cancelar:'Cancelar', editar:'Editar',
buscar:'Buscar', exportar:'Exportar', exportar_csv:'CSV', exportar_excel:'Excel', exportar_pdf:'PDF',
chat_flotante__enviar_por_chat:'Enviar por chat (sin descargar)',
chat_flotante__abre_una_conversacion_primero:'Abre una conversación primero',
chat_flotante__inicia_sesion_con_una_cuenta:'Inicia sesión con una cuenta para poder enviar mensajes',
chat_flotante__mas_filas:'más filas',
chat_flotante__enviado_al_chat:'Enviado al chat',
elegir_formato:'Elige el formato de exportación', idioma:'Idioma', cambiar_idioma:'Cambiar idioma',
nav_inicio:'Inicio', nav_hato:'Hato', nav_graficas:'Gráficas', nav_boletines:'Boletines',
tile_datos:'Mis<br>datos', tile_reporte:'Reporte y<br>notificaciones', tile_graficas:'Gráficas', tile_boletines:'Boletines<br>informativos',
glosario_titulo:'Glosario técnico ganadero', glosario_sub:'Términos clave usados en la app, en los tres idiomas.',
mod_A_nombre:'Registro e Identificación Animal', mod_A_corto:'Identificación<br>animal',
mod_B_nombre:'Salud, Sanidad y Manejo', mod_B_corto:'Salud y<br>sanidad',
mod_C_nombre:'Reproducción y Maternidad', mod_C_corto:'Reproducción<br>y maternidad',
mod_D_nombre:'Pesajes y Productividad', mod_D_corto:'Pesajes y<br>productividad',
mod_E_nombre:'Mapeo Geográfico', mod_E_corto:'Mapeo<br>geográfico',
mod_F_nombre:'Administración, Costos y Reportes', mod_F_corto:'Costos y<br>reportes',
mod_G_nombre:'Producción de Leche', mod_G_corto:'Producción<br>de leche',
mod_H_nombre:'Tanque y Entrega de Leche', mod_H_corto:'Tanque y<br>entrega',
mod_I_nombre:'Alimentación Lechera', mod_I_corto:'Alimentación<br>lechera',
mod_J_nombre:'Becerros de Reemplazo', mod_J_corto:'Becerros de<br>reemplazo',
mod_K_nombre:'Bodega e Insumos', mod_K_corto:'Bodega e<br>insumos',
gl_control_lechero:'Control lechero', gl_arete_siniiga:'Arete / SINIIGA', gl_registro_partos:'Registro de partos',
gl_inseminacion:'Inseminación', gl_estatus_sanitario:'Estatus sanitario', gl_potrero:'Potrero', gl_hato:'Hato',
gl_empadre:'Empadre', gl_gestacion:'Gestación', gl_destete:'Destete', gl_calostro:'Calostro',
gl_vacunacion:'Vacunación', gl_desparasitacion:'Desparasitación', gl_gdp:'GDP (Ganancia Diaria de Peso)', gl_lote:'Lote',
exp_generado:'Generado', exp_marca:'Documento generado por MiRanch',
login_seleccion_rol__mi_ranchapp:'MiRanch',
login_seleccion_rol__gestion_de_tu_rancho_facil:'Gestión de tu rancho, fácil y clara',
login_seleccion_rol__entra_directo_por_lo_pronto:'Entra directo — por lo pronto sin contraseña',
login_seleccion_rol__ingresa_tus_datos:'Ingresa tu usuario y contraseña',
login_seleccion_rol__usuario:'Usuario',
login_seleccion_rol__contrasena:'Contraseña',
login_seleccion_rol__iniciar_sesion:'Iniciar sesión',
login_seleccion_rol__ingresa_usuario_y_contrasena:'Ingresa tu usuario y contraseña',
login_seleccion_rol__usuario_o_contrasena_incorrectos:'Usuario o contraseña incorrectos',
login_seleccion_rol__inicia_sesion:'Inicia Sesión',
login_seleccion_rol__ej_usuario:'Ej: JuanPerez',
login_seleccion_rol__olvide_mi_contrasena:'¿Olvidé mi contraseña?',
login_seleccion_rol__iniciar_sesion_mayus:'INICIAR SESIÓN',
login_seleccion_rol__no_tienes_cuenta:'¿No tienes cuenta?',
login_seleccion_rol__registrate_aqui:'Regístrate aquí.',
login_seleccion_rol__te_enviaremos_un_codigo:'Te enviaremos un código por WhatsApp al teléfono registrado en tu cuenta.',
login_seleccion_rol__enviar_codigo_por_whatsapp:'Enviar código por WhatsApp',
login_seleccion_rol__ligar_nueva_cuenta:'Ligar nueva cuenta',
login_seleccion_rol__solicita_tu_acceso:'Solicita tu acceso. El administrador confirmará tu cuenta.',
login_seleccion_rol__punto_receptor_de_leche:'Punto receptor de leche',
login_seleccion_rol__mvz:'MVZ',
vet_pacientes__personas_atendidas:'Personas atendidas',
vet_notas__mis_notas:'Mis notas',
vet_notas__guardar_nota:'Guardar nota',
vet_perfil__mi_perfil:'Mi perfil',
vet_perfil__cambiar_foto:'Cambiar foto',
vet_perfil__especialidad_medica:'Especialidad médica',
vet_perfil__descripcion:'Descripción',
vet_perfil__zona_de_atencion:'Zona de atención',
vet_perfil__guardar_perfil:'Guardar perfil',
contactos__buscar_en_mis_contactos:'Buscar en mis contactos',
contactos__buscar_amigos:'Buscar amigos',
contactos__ya_usa_la_app:'Ya usa la app',
contactos__abrir_chat:'Abrir chat',
contactos__invitar_por_whatsapp:'Invitar por WhatsApp',
contactos__no_disponible_en_este_dispositivo:'Este dispositivo no permite acceder a tus contactos. Puedes escribir un número manualmente.',
contactos__sin_coincidencias:'Ninguno de tus contactos seleccionados usa la app todavía.',
contactos__buscando:'Buscando...',
contactos__numero_manual:'Escribe un número de teléfono',
contactos__buscar_numero:'Buscar número',
login_seleccion_rol__cedula_profesional:'Cédula profesional *',
login_seleccion_rol__lugar_de_residencia:'Lugar de residencia *',
login_seleccion_rol__continuar:'Continuar',
login_seleccion_rol__moonitor_faltan_datos:'¡Espera! Todavía faltan datos por completar o revisar en este paso. Revísalos y vuelve a intentar.',
login_seleccion_rol__moonitor_datos_validados:'¡Tus datos ya fueron validados! Ahora pon el usuario y la contraseña que quieras usar para entrar.',
login_seleccion_rol__moonitor_bienvenida:'¡Bienvenido/a a MiRanch, %VAR%! Tu cuenta ya está lista. Tu usuario es: %VAR2%',
login_seleccion_rol__moonitor_ya_existe:'Parece que esos datos ya están registrados. Revisa tu teléfono, UPP o cédula.',
login_seleccion_rol__verificando_tu_cuenta:'Verificando tu cuenta...',
login_seleccion_rol__no_se_pudo_verificar_conexion:'No se pudo verificar tu cuenta. Revisa tu conexión a internet e intenta de nuevo.',
login_seleccion_rol__gps_requiere_https:'La ubicación solo funciona en el sitio publicado (https), no en esta vista previa.',
login_seleccion_rol__gps_permiso_denegado:'Diste permiso denegado a la ubicación. Actívalo en los ajustes de tu navegador.',
login_seleccion_rol__gps_no_disponible:'No se pudo detectar tu ubicación (GPS apagado o señal débil).',
login_seleccion_rol__gps_tiempo_agotado:'Se tardó demasiado en obtener tu ubicación. Intenta de nuevo.',
login_seleccion_rol__nombre_del_veterinario:'Nombre del veterinario',
login_seleccion_rol__nombre_del_local:'Nombre del local',
login_seleccion_rol__nombre_de_la_persona_encargada:'Nombre de la persona encargada',
login_seleccion_rol__ubicacion_basica:'Ubicación básica',
login_seleccion_rol__enviar_ubicacion_actual:'Enviar ubicación actual',
login_seleccion_rol__enviar_solicitud:'Enviar solicitud',
login_seleccion_rol__procesando:'Procesando…',
login_seleccion_rol__ya_existe_una_solicitud:'Ya existe una cuenta o solicitud con esos datos',
login_seleccion_rol__enviar_solicitud_por_whatsapp:'Enviar solicitud por WhatsApp',
login_seleccion_rol__bienvenido:'Bienvenido',
login_seleccion_rol__completa_nombre_y_telefono:'Completa tu nombre y un teléfono válido',
login_seleccion_rol__codigo_enviado:'Código enviado por WhatsApp',
login_seleccion_rol__completa_todos_los_campos:'Completa todos los campos con un teléfono válido',
login_seleccion_rol__solicitud_enviada:'Solicitud enviada, espera la confirmación del administrador',
login_seleccion_rol__crea_tu_acceso:'Crea tu acceso. Tu cuenta queda lista para usarse de inmediato.',
login_seleccion_rol__crea_tu_usuario:'Crea tu usuario',
login_seleccion_rol__minimo_6_caracteres:'Mínimo 6 caracteres',
login_seleccion_rol__crea_tu_contrasena:'Crea tu contraseña',
login_seleccion_rol__6_o_mas_letras_numeros:'6 o más caracteres, letras, números o combinados.',
login_seleccion_rol__usuario_y_contrasena_6_caracteres:'El usuario y la contraseña deben tener al menos 6 caracteres',
login_seleccion_rol__ese_usuario_ya_existe:'Ese nombre de usuario ya existe, elige otro',
login_seleccion_rol__cuenta_creada_inicia_sesion:'Cuenta creada, ya puedes iniciar sesión',
trabajadores__acceso_no_disponible:'Esta sección no está disponible para trabajadores',
trabajadores__enviar_a:'Enviar a...',
trabajadores__tarea_enviada_a:'Tarea enviada a',
login_seleccion_rol__soy_productor:'Soy productor',
login_seleccion_rol__soy_administrador:'Soy administrador',
login_seleccion_rol__soy_trabajador:'Soy trabajador',
login_seleccion_rol__recepcion_de_leche_queseria:'Recepción de Leche (Quesería)',
queseria_login__selecciona_tu_perfil:'Selecciona tu perfil',
queseria_login__elige_como_quieres_entrar:'Elige cómo quieres entrar al sistema',
queseria__administrador:'Administrador',
queseria_menu__recibir_leche:'Recibir Leche',
queseria_menu__panel_de_reportes:'Panel de Reportes',
queseria_menu__gestion_de_productores:'Gestión de Productores',
queseria_menu__bienvenido:'Bienvenido',
queseria_menu__cerrar_sesion:'Cerrar sesión',
queseria_recepcion__recepcion_de_leche:'Recepción de Leche',
queseria_recepcion__lechero_recolector:'Lechero recolector',
queseria_recepcion__productores_del_lechero:'Productores de este lechero',
queseria_recepcion__recibidos_hoy:'Recibidos hoy',
queseria_recepcion__litros_recibidos:'Litros recibidos',
queseria_recepcion__confirmar_recepcion:'Confirmar Recepción',
queseria_recepcion__selecciona_un_lechero:'Selecciona un lechero para ver sus productores',
queseria_recepcion__aun_no_hay_productores_para_este_lechero:'Este lechero aún no tiene productores asociados',
queseria_recepcion__aun_no_has_recibido_leche_hoy:'Aún no has registrado recepciones hoy',
queseria_recepcion__notificacion_enviada:'Notificación enviada a',
queseria_productores__gestion_de_productores:'Gestión de Productores',
queseria_productores__nombre_de_la_queseria:'Nombre de la quesería',
queseria_productores__alta_de_lechero:'Alta de lechero (ruta de recolección)',
queseria_productores__nombre_del_lechero:'Nombre del lechero',
queseria_productores__alta_de_productor:'Alta de productor',
queseria_productores__nombre_del_productor:'Nombre del productor',
queseria_productores__codigo_identificador:'Código identificador',
queseria_productores__telefono_de_contacto:'Teléfono de contacto',
queseria_productores__registrar_productor:'Registrar productor',
queseria_productores__productores_registrados:'Productores registrados',
queseria_productores__aun_no_hay_productores_registrados:'Aún no hay productores registrados',
queseria_productores__solicitud_de_vinculacion_enviada:'Solicitud de vinculación enviada al productor',
queseria_productores__completa_nombre_y_codigo:'Completa al menos el nombre y el código del productor',
queseria_productores__nombre_guardado:'Nombre de la quesería guardado',
queseria_productores__escribe_un_nombre:'Escribe el nombre del lechero',
queseria_reportes__panel_de_reportes:'Panel de Reportes',
queseria_reportes__hoy:'Hoy',
queseria_reportes__esta_semana:'Esta semana',
queseria_reportes__este_mes:'Este mes',
queseria_reportes__detalle_por_productor:'Detalle por productor',
queseria_reportes__litros_totales:'Litros totales',
queseria_reportes__productores_activos:'Productores activos',
queseria_reportes__recepciones:'Recepciones',
queseria_reportes__todos_los_lecheros:'Todos los lecheros',
queseria_reportes__aun_no_hay_datos_para_este_periodo:'Aún no hay datos para este periodo',
queseria__ingresa_los_litros:'Ingresa los litros',
queseria__dictado_por_voz_no_disponible:'El dictado por voz no está disponible en este navegador',
queseria__escuchando:'Escuchando…',
codigo_trabajador__codigo_de_4_digitos:'Código de 4 dígitos',
codigo_trabajador__codigo_de_trabajador:'Código de trabajador',
codigo_trabajador__pideselo_a_tu_administrador_o:'Pídeselo a tu administrador o productor',
codigo_trabajador__entrar:'Entrar',
seleccion_tipo_ganado__que_tipo_de_ganado_manejas:'¿Qué tipo de ganado manejas?',
seleccion_tipo_ganado__elige_tu_tipo_de_produccion:'Elige tu tipo de producción para adaptar tus funciones',
seleccion_tipo_ganado__ganado_vacuno_de_carne:'Ganado Vacuno de Carne',
seleccion_tipo_ganado__ganado_vacuno_de_leche:'Ganado Vacuno de Leche',
aviso_suscripcion_vencida__suscripcion_vencida:'Suscripción vencida',
aviso_suscripcion_vencida__tu_acceso_a_mi_ranchapp:'Tu acceso a MiRanch venció el',
aviso_suscripcion_vencida__contacta_a_tu_administrador_para:'Contacta a tu administrador para renovar tu suscripción y recuperar el acceso a tus datos.',
aviso_suscripcion_vencida__cerrar_sesion:'Cerrar sesión',
inicio_productor__buscar_animal_potrero_o_boletin:'Buscar animal, potrero o boletín...',
inicio_productor__buen_dia:'Buen día',
inicio_productor__buenas_tardes:'Buenas tardes',
inicio_productor__buenas_noches:'Buenas noches',
inicio_productor__ver_mis_datos:'Ver mis datos',
inicio_productor__actividades_recientes:'Actividades recientes',
inicio_productor__ver_todas:'Ver todas',
inicio_productor__aun_no_tienes_actividades:'Aún no tienes actividades registradas.',
inicio_productor__clima_cargando:'Cargando clima...',
inicio_productor__clima_no_disponible:'Clima no disponible por ahora',
inicio_productor__reintentar:'Reintentar',
inicio_productor__pronostico_por_horas:'Pronóstico por horas',
inicio_productor__humedad:'Humedad',
inicio_productor__viento:'Viento',
inicio_productor__probabilidad_de_lluvia:'Prob. de lluvia',
inicio_productor__sensacion:'Sensación',
inicio_productor__ubicacion_aproximada:'Ubicación aproximada — actívala en tu navegador para mayor precisión',
inicio_productor__resumen_rapido:'Resumen rápido',
inicio_productor__mas_funciones:'Más funciones',
inicio_productor__acceso_rapido:'Acceso rápido',
menu_mas_productor__mensajes_con_tu_veterinario:'Mensajes con tu veterinario',
menu_mas_productor__calendario_de_eventos:'Calendario de eventos',
menu_mas_productor__bitacora_de_visitas_veterinarias:'Bitácora de visitas veterinarias',
menu_mas_productor__manejo_de_engorda_y_corral:'Manejo de Engorda y Corral',
menu_mas_productor__mis_tareas:'Mis Tareas',
menu_mas_productor__agregar_trabajador:'Agregar Trabajador',
admin_configuracion__funciones_que_vera_el_trabajador:'Funciones que verá el trabajador',
admin_configuracion__elige_que_modulos_puede_usar:'Elige qué módulos puede usar un trabajador cuando entra con su código. Los trabajadores nunca ven gráficas, costos ni reportes, sin importar esto.',
menu_mas_productor__transferencias_de_aretes:'Transferencias de aretes',
transferencias_aretes__cuando_registras_un_arete_que:'Cuando registras un arete que ya está activo en otro predio, puedes solicitar su transferencia. El dueño actual decide si autoriza el traspaso.',
transferencias_aretes__pendientes_de_tu_autorizacion:'Pendientes de tu autorización',
transferencias_aretes__tus_solicitudes_enviadas:'Tus solicitudes enviadas',
visitas_veterinarias__nombre_del_veterinario:'Nombre del veterinario',
visitas_veterinarias__motivo_de_la_visita:'Motivo de la visita',
visitas_veterinarias__que_se_reviso_observaciones:'Qué se revisó / observaciones...',
visitas_veterinarias__registro_de_visitas_al_rancho:'Registro de visitas al rancho, separado del historial de tratamientos por animal — útil como respaldo documental.',
visitas_veterinarias__registrar_visita:'Registrar visita',
calendario_visual__salud_dosis:'Salud/dosis',
calendario_visual__partos:'Partos',
calendario_visual__tramites:'Trámites',
mensajes_veterinario_productor__escribe_un_mensaje:'Escribe un mensaje...',
ventana_personalizada__escribe_una_nota:'Escribe una nota...',
datos_productor__datos_del_productor:'Datos del productor',
editar_datos_productor__editar_datos_del_productor:'Editar datos del productor',
editar_datos_productor__nombre:'Nombre',
editar_datos_productor__nombre_del_predio:'Nombre del predio',
editar_datos_productor__ultima_actualizacion_upp:'Última actualización UPP',
editar_datos_productor__folio_fierro_de_herrar:'Folio fierro de herrar',
editar_datos_productor__vencimiento_credencial_fierro:'Vencimiento credencial fierro',
editar_datos_productor__estado:'Estado',
editar_datos_productor__municipio:'Municipio',
editar_datos_productor__ejido_parcela:'Ejido / parcela',
editar_datos_productor__actividad_pecuaria:'Actividad pecuaria',
editar_datos_productor__el_numero_de_animales_activos:'El número de animales activos se cuenta solo, según lo que registres en el módulo A.',
editar_datos_productor__guardar_cambios:'Guardar cambios',
hato_inventario_animales__buscar_animal:'Buscar animal...',
hato_inventario_animales__estatus_del_hato:'Estatus del hato',
hato_inventario_animales__todos_los_estatus:'Todos los estatus',
hato_inventario_animales__activo:'Activo',
hato_inventario_animales__engorda:'Engorda',
hato_inventario_animales__gestante:'Gestante',
hato_inventario_animales__lactando:'Lactando',
hato_inventario_animales__vaquilla:'Vaquilla',
hato_inventario_animales__semental:'Semental',
hato_inventario_animales__vendido:'Vendido',
hato_inventario_animales__finado:'Finado',
hato_inventario_animales__ambos_sexos:'Ambos sexos',
hato_inventario_animales__hembra:'Hembra',
hato_inventario_animales__macho:'Macho',
graficas__vista_previa_el_diseno_final:'Vista previa — el diseño final de las gráficas lo definimos juntos más adelante.',
graficas__composicion_del_hato_por_sexo:'Composición del hato por sexo',
graficas__aun_no_hay_animales_registrados:'Aún no hay animales registrados.',
graficas__tasa_de_prenez_por_temporada:'Tasa de preñez por temporada',
graficas__aun_no_hay_diagnosticos_de:'Aún no hay diagnósticos de gestación registrados.',
graficas__evolucion_de_pesajes:'Evolución de pesajes',
graficas__aun_no_hay_pesajes_registrados:'Aún no hay pesajes registrados.',
graficas__costos_por_categoria:'Costos por categoría',
graficas__aun_no_hay_costos_registrados:'Aún no hay costos registrados.',
graficas__proximas_fechas_importantes:'Próximas fechas importantes',
graficas__ocupacion_vs_capacidad_de_potreros:'Ocupación vs. capacidad de potreros',
graficas__aun_no_hay_potreros_registrados:'Aún no hay potreros registrados.',
graficas__gastos_vs_ingresos_por_mes:'Gastos vs. ingresos por mes',
graficas__aun_no_hay_movimientos_registrados:'Aún no hay movimientos registrados.',
graficas__edades_del_hato_por_sexo:'Edades del hato por sexo',
graficas__aun_no_hay_animales_con:'Aún no hay animales con fecha de nacimiento registrada.',
graficas__bajas_por_causa:'Bajas por causa',
graficas__aun_no_hay_bajas_registradas:'Aún no hay bajas registradas.',
boletines_informativos__boletines_informativos:'Boletines informativos',
modal_escaner_camara__escanear_arete:'Escanear arete',
modal_escaner_camara__apunta_la_camara_al_codigo:'Apunta la cámara al código de barras del arete...',
modal_boletin__cerrar:'Cerrar',
notificaciones__reporte_y_notificaciones:'Reporte y notificaciones',
notificaciones__reportar_caso_urgente_muerte_subit:'Reportar caso urgente (muerte súbita / sospecha de enfermedad exótica)',
notificaciones__exportar_tabla_de_proximos_vencimi:'Exportar tabla de próximos vencimientos',
notificaciones__reportes_de_chequeos_diarios:'Reportes de chequeos diarios',
notificaciones__notificaciones:'Notificaciones',
modal_historial_bitacora__concepto_ej_inseminacion_venta:'Concepto (ej. inseminación, venta)',
modal_historial_bitacora__monto:'Monto $',
modal_historial_bitacora__imprimir_descargar_ficha_resumen:'Imprimir / descargar ficha resumen',
modal_historial_bitacora__gastos_y_rendimiento:'Gastos y rendimiento',
modal_historial_bitacora__gasto:'Gasto',
modal_historial_bitacora__ingreso:'Ingreso',
modal_historial_bitacora__registrar:'Registrar',
modal_historial_bitacora__bitacora_del_animal:'Bitácora del animal',
inicio_administrador__modo_veterinario_solo_salud:'Modo veterinario (solo salud)',
menu_mas_administrador__resumen_general:'Resumen general',
menu_mas_administrador__informacion_general_del_sistema:'Información general del sistema',
menu_mas_administrador__cuentas_de_productores_y_vigencias:'Cuentas de productores y vigencias',
menu_mas_administrador__reportes_a_cefpp_casos_urgentes:'Reportes a CEFPP (casos urgentes)',
menu_mas_administrador__reportes_y_analisis_de_produccion:'Reportes y Análisis de Producción',
reportes_admin__cruza_datos_de_todas_las:'Cruza datos de todas las cuentas de productores por región, tipo de producción y estado de salud.',
reportes_admin__tipo_de_produccion:'Tipo de producción',
reportes_admin__estado_de_salud:'Estado de salud',
reportes_admin__todos:'Todos',
reportes_admin__alerta_cefpp:'Alerta CEFPP',
reportes_admin__actualizar_datos_de_todas_las:'Actualizar datos de todas las cuentas',
reportes_admin__folios_de_fierro_de_herrar:'Folios de fierro de herrar',
reportes_admin__desglose_por_productor:'Desglose por productor',
reportes_admin__cargando:'Cargando',
reportes_admin__datos_actualizados_de:'Datos actualizados de',
reportes_admin__nacimientos:'Nacimientos',
reportes_admin__compras:'Compras',
reportes_admin__bajas:'Bajas',
reportes_admin__siniiga_activos:'SINIIGA activos',
reportes_admin__siniiga_pendientes:'SINIIGA pendientes',
reportes_admin__alertas_sanitarias:'Alertas sanitarias',
reportes_admin__sin_folios_registrados:'Sin folios registrados',
reportes_admin__pulsa_actualizar_datos_para_ver:'Pulsa "Actualizar datos" para ver el desglose',
metricas_admin__metricas_de_interaccion:'Métricas de Interacción',
metricas_admin__uso_real_de_la_app_por:'Uso real de la app por los productores: cuándo entran, cómo llegaron y qué tanto comparten.',
metricas_admin__horarios_de_mayor_actividad:'Horarios de mayor actividad',
metricas_admin__dias_de_mayor_actividad:'Días de mayor actividad',
metricas_admin__origen_de_acceso:'Origen de acceso (código QR vs. directo)',
metricas_admin__mensajes_compartidos_por_whatsapp:'Mensajes compartidos por WhatsApp',
metricas_admin__datos_recolectados_desde_este:'Datos recolectados desde este dispositivo/instalación en adelante.',
metricas_admin__inicios_de_sesion:'Inicios de sesión',
metricas_admin__accesos_por_qr:'Accesos por QR',
metricas_admin__mensajes_por_whatsapp:'Mensajes por WhatsApp',
metricas_admin__madrugada:'Madrugada',
metricas_admin__manana:'Mañana',
metricas_admin__tarde:'Tarde',
metricas_admin__noche:'Noche',
metricas_admin__domingo:'Domingo',
metricas_admin__lunes:'Lunes',
metricas_admin__martes:'Martes',
metricas_admin__miercoles:'Miércoles',
metricas_admin__jueves:'Jueves',
metricas_admin__viernes:'Viernes',
metricas_admin__sabado:'Sábado',
metricas_admin__via_codigo_qr:'Vía código QR',
metricas_admin__acceso_directo:'Acceso directo',
metricas_admin__compartir_la_app:'Compartir la app',
metricas_admin__cuenta_nueva_creada:'Cuenta nueva creada',
metricas_admin__recuperar_contrasena:'Recuperar contraseña',
metricas_admin__recordatorio_de_vigencia:'Recordatorio de vigencia',
metricas_admin__otro:'Otro',
metricas_admin__sin_datos_aun:'Sin datos aún',
menu_mas_administrador__mensajes_con_el_productor:'Mensajes con el productor',
mensajes_admin__conversaciones:'Conversaciones',
mensajes_admin__mensaje_segmentado:'Mensaje segmentado',
mensajes_admin__filtros_de_destino:'Filtros de destino',
mensajes_admin__todos_los_tipos:'Todos los tipos',
mensajes_admin__productores_que_recibiran_este:'productores que recibirán este mensaje',
mensajes_admin__contenido_del_mensaje:'Contenido del mensaje',
mensajes_admin__usar_plantilla:'Usar plantilla...',
mensajes_admin__escribe_el_mensaje_para_los:'Escribe el mensaje para los productores seleccionados...',
mensajes_admin__adjuntar_archivo:'Adjuntar archivo',
mensajes_admin__enlace_url_opcional:'Enlace URL (opcional)',
mensajes_admin__guardar_como_plantilla:'Guardar como plantilla',
mensajes_admin__programar_envio:'Programar envío (opcional)',
mensajes_admin__enviar_ahora:'Enviar ahora',
mensajes_admin__programar:'Programar',
mensajes_admin__envios_programados:'Envíos programados',
mensajes_admin__archivo_demasiado_pesado:'Ese archivo pesa demasiado, intenta con uno más ligero',
mensajes_admin__escribe_un_mensaje_para_guardarlo:'Escribe un mensaje primero',
mensajes_admin__plantilla_guardada:'Plantilla guardada',
mensajes_admin__nadie_cumple_estos_filtros:'Ningún productor cumple estos filtros',
mensajes_admin__elige_fecha_para_programar:'Elige una fecha para programar el envío',
mensajes_admin__mensaje_programado:'Mensaje programado',
mensajes_admin__mensaje_enviado_a:'Mensaje enviado a',
mensajes_admin__no_hay_envios_programados:'No hay envíos programados',
mensajes_admin__enviado:'enviado',
menu_mas_administrador__ver_como_productor:'Ver como productor',
admin_usuarios_contrasenas__nombre_completo:'Nombre completo',
admin_usuarios_contrasenas__usuario:'Usuario',
admin_usuarios_contrasenas__contrasena:'Contraseña',
admin_usuarios_contrasenas__usuarios_y_contrasenas:'Usuarios y contraseñas',
admin_usuarios_contrasenas__agregar_nuevo_usuario:'Agregar nuevo usuario',
admin_usuarios_contrasenas__productor:'Productor',
admin_usuarios_contrasenas__administrador:'Administrador',
admin_usuarios_contrasenas__veterinario_solo_salud:'Veterinario (solo salud)',
admin_usuarios_contrasenas__crear_usuario:'Crear usuario',
admin_cuentas_productores__nombre_del_rancho_predio:'Nombre del rancho / predio',
admin_cuentas_productores__10_digitos:'10 dígitos',
admin_cuentas_productores__numero_ip:'Número IP',
admin_cuentas_productores__ej_192_168:'Ej. 192.168.0.1',
admin_cuentas_productores__completa_telefono_e_ip:'Completa el nombre, predio, UPP, teléfono e IP',
admin_cuentas_productores__cuenta_creada_compartir:'Cuenta creada. Comparte el acceso con el productor:',
admin_cuentas_productores__compartir_por_whatsapp:'Compartir por WhatsApp',
admin_cuentas_productores__mensaje_bienvenida_cuenta:'¡Bienvenido a MiRanch! Ya tienes tu cuenta lista.\nUsuario: %VAR%\nContraseña: %VAR%\nDescarga la app aquí: https://mi-ranchapp.netlify.app',
admin_cuentas_productores__cuentas_de_productores:'Cuentas de productores',
admin_cuentas_productores__alta_de_cuentas_control_de:'Alta de cuentas, control de vigencia y seguimiento comercial.',
admin_cuentas_productores__reloj_de_pruebas:'Reloj de pruebas',
admin_cuentas_productores__entorno_de_pruebas_reloj_simulado:'Entorno de pruebas — reloj simulado',
admin_cuentas_productores__hoy_real:'Hoy (real):',
admin_cuentas_productores__hoy_usado_por_la_app:'· Hoy (usado por la app):',
admin_cuentas_productores__usar_esta_fecha:'Usar esta fecha',
admin_cuentas_productores__volver_a_la_fecha_real:'Volver a la fecha real del dispositivo',
admin_cuentas_productores__metricas_de_nuevas_cuentas:'Métricas de nuevas cuentas',
admin_cuentas_productores__nuevas_cuentas_generadas:'Nuevas cuentas generadas',
admin_cuentas_productores__proximos_a_vencer:'Próximos a vencer',
admin_cuentas_productores__suscripciones_que_vencen_en_los:'Suscripciones que vencen en los próximos 15 días.',
admin_cuentas_productores__alta_de_nueva_cuenta:'Alta de nueva cuenta',
admin_cuentas_productores__registrar_nueva_cuenta:'Registrar nueva cuenta',
admin_cuentas_productores__nombre_del_productor:'Nombre del productor *',
admin_cuentas_productores__nombre_del_predio:'Nombre del predio *',
admin_cuentas_productores__numero_de_upp:'Número de UPP *',
admin_cuentas_productores__tipo_de_modulo:'Tipo de módulo *',
admin_cuentas_productores__lechera:'Lechera',
admin_cuentas_productores__carne:'Carne',
admin_cuentas_productores__telefono_whatsapp:'Teléfono (WhatsApp)',
admin_cuentas_productores__dias_de_vigencia:'Días de vigencia',
admin_cuentas_productores__crear_cuenta:'Crear cuenta',
admin_cuentas_productores__listado_completo:'Listado completo',
admin_cuentas_productores__todas_las_cuentas:'Todas las cuentas',
admin_info_general__esto_es_lo_que_vera:'Esto es lo que verá el productor en su resumen.',
admin_configuracion__nombre_del_trabajador:'Nombre del trabajador',
admin_configuracion__ej_revisar_bebederos_del_potrero:'Ej. Revisar bebederos del potrero 3',
admin_configuracion__nombre_de_la_campana:'Nombre de la campaña',
admin_configuracion__notas_opcional:'Notas (opcional)',
admin_configuracion__nombre_de_la_ventana:'Nombre de la ventana...',
admin_configuracion__escribe_el_mensaje:'Escribe el mensaje...',
admin_configuracion__configuracion_de_ventanas:'Configuración de ventanas',
admin_configuracion__ventanas_visibles_para_el_producto:'Ventanas visibles para el productor',
admin_configuracion__apariencia_de_inicio:'Apariencia — pantalla de inicio',
admin_configuracion__cambia_la_foto_de_fondo:'Cambia la foto de fondo que ven los productores en su pantalla de inicio. Se comprime automáticamente para no afectar el tiempo de carga.',
admin_configuracion__cambiar_foto_de_fondo:'Cambiar foto de fondo',
admin_configuracion__cambia_la_foto_del_encabezado:'Cambia la foto de fondo del encabezado que aparece arriba en todas las pantallas (junto al logo, el nombre y el botón de idioma).',
admin_configuracion__cambia_el_logo_de_la_app:'Cambia el logo de la app. Aparecerá en todas las pantallas donde hoy se muestra (login, encabezado, quesería).',
admin_configuracion__cambiar_logo:'Cambiar logo',
moonitor_config__titulo:'Moo-nitor (asistente)',
moonitor_config__descripcion:'Sube una imagen distinta para cambiar el estilo de Moo-nitor según la temporada (navideño, primavera, etc.) o para cada tipo de ganado. La imagen por defecto se usa si no subes ninguna.',
moonitor_config__general:'General',
moonitor_config__restaurar_imagenes:'Restaurar imágenes por defecto',
moonitor_config__recordatorio_semanal:'Recordatorio semanal de compartir',
moonitor_config__sonido_de_vaca:'Sonido de vaca al mostrar mensajes',
moonitor_config__probar_sonido:'Probar sonido',
moonitor_config__recordatorio_descripcion:'Moo-nitor le recordará una vez por semana a todos los productores que compartan la app con 2 contactos.',
moonitor__favor_de_compartir:'Favor de compartir la aplicación con dos contactos tuyos',
moonitor__compartir_por_whatsapp:'Compartir por WhatsApp',
moonitor__mensaje_compartir_app:'¡Te comparto MiRanch! Es la aplicación que uso para llevar el control de mi rancho. Descárgala aquí:',
moonitor__falta_telefono:'Te falta registrar tu número de teléfono',
moonitor__entendido:'Entendido',
moonitor__ahora_no:'Ahora no',
moonitor__tienes_avisos_pendientes:'Tienes avisos pendientes',
moonitor__ver_notificaciones:'Ver notificaciones',
moonitor__nuevo_boletin:'Nuevo boletín',
moonitor__ver_boletines:'Ver boletines',
queseria__operador:'Operador',
queseria__hora:'Hora',
queseria_reportes__exportar_pdf:'Exportar datos (PDF)',
admin_configuracion__cambiar_foto_de_encabezado:'Cambiar foto de encabezado',
admin_configuracion__orden_de_botones_en_mas:'Orden de botones en "Más funciones"',
admin_qr__titulo:'Código QR de acceso',
admin_qr__descripcion:'Genera un código QR que lleve directo a la pantalla principal de la app. Sirve para ponerlo en carteles, promociones o publicidad impresa.',
admin_qr__enlace:'Enlace',
admin_qr__descargar:'Descargar QR (PNG)',
admin_qr__escribe_un_enlace_valido:'Escribe un enlace válido (debe empezar con http:// o https://)',
admin_configuracion__usa_las_flechas_para_cambiar:'Usa las flechas para cambiar el orden en que el productor ve el hato y los módulos.',
admin_configuracion__graficas_cuales_se_ven_y:'Gráficas: cuáles se ven y en qué orden',
admin_configuracion__apaga_la_que_no_quieras:'Apaga la que no quieras mostrar, y usa las flechas para decidir cuál aparece primero.',
admin_configuracion__trabajadores_maximo_3:'Trabajadores (máximo 2)',
admin_configuracion__cada_trabajador_entra_con_un:'Cada trabajador entra con un código propio y solo puede registrar datos y ver/marcar sus tareas — no ve costos, configuración ni reportes.',
admin_configuracion__asignar_tareas:'Asignar tareas',
admin_configuracion__general:'General',
admin_configuracion__asignar_tarea:'Asignar tarea',
admin_configuracion__plan_sanitario_anual:'Plan sanitario anual',
admin_configuracion__programa_las_campanas_del_ano:'Programa las campañas del año (vacunación, desparasitación, revisiones). Avisará al productor cuando llegue el mes de cada una.',
admin_configuracion__enero:'Enero',
admin_configuracion__febrero:'Febrero',
admin_configuracion__marzo:'Marzo',
admin_configuracion__abril:'Abril',
admin_configuracion__mayo:'Mayo',
admin_configuracion__junio:'Junio',
admin_configuracion__julio:'Julio',
admin_configuracion__agosto:'Agosto',
admin_configuracion__septiembre:'Septiembre',
admin_configuracion__octubre:'Octubre',
admin_configuracion__noviembre:'Noviembre',
admin_configuracion__diciembre:'Diciembre',
admin_configuracion__agregar_al_plan:'Agregar al plan',
admin_configuracion__descargar_reporte_sanitario_anual:'Descargar reporte sanitario anual',
admin_configuracion__agregar_ventana_nueva:'Agregar ventana nueva',
admin_configuracion__crea_una_ventana_adicional_para:'Crea una ventana adicional para el productor (con espacio de notas propio).',
admin_configuracion__banner_de_mensajes:'Banner de mensajes',
admin_configuracion__se_muestra_al_abrir_la:'Se muestra al abrir la app del productor. Puedes programar varios y activar/desactivar cada uno.',
admin_configuracion__texto_del_mensaje:'Texto del mensaje',
admin_configuracion__imagen_opcional:'Imagen (opcional)',
admin_configuracion__tamano_del_texto:'Tamaño del texto',
admin_configuracion__chico:'Chico',
admin_configuracion__mediano:'Mediano',
admin_configuracion__grande:'Grande',
admin_configuracion__color_de_fondo:'Color de fondo',
admin_configuracion__color_de_texto:'Color de texto',
admin_configuracion__desde_opcional:'Desde (opcional)',
admin_configuracion__hasta_opcional:'Hasta (opcional)',
admin_configuracion__programar_banner:'Programar banner',
admin_configuracion__predios_ranchos:'Predios / ranchos',
admin_configuracion__si_el_productor_maneja_mas:'Si el productor maneja más de un predio, agrégalos aquí. Podrá elegir cuál está viendo desde la pantalla de inicio.',
admin_configuracion__agregar_predio:'Agregar predio',
admin_configuracion__notificaciones_del_navegador:'Notificaciones del navegador',
admin_configuracion__manda_un_aviso_emergente_aunque:'Manda un aviso emergente aunque la app esté cerrada en segundo plano (requiere permiso del navegador/celular).',
admin_configuracion__activar_notificaciones_push:'Activar notificaciones push',
admin_configuracion__campos_del_resumen_del_productor:'Campos del resumen del productor',
admin_publicar_boletines__titulo_del_boletin:'Título del boletín',
admin_publicar_boletines__contenido_del_boletin:'Contenido del boletín...',
admin_publicar_boletines__imagen_cartel_opcional:'Imagen / cartel (opcional)',
admin_publicar_boletines__si_subes_imagen_aparecera_circulan:'Si subes imagen, aparecerá circulando en el carrusel de arriba del boletín para el productor.',
admin_publicar_boletines__publicar_boletin:'Publicar boletín',
admin_informacion_sistema__vista_de_solo_lectura_util:'Vista de solo lectura, útil para revisar cómo va el uso de la app antes de conectarla a Firebase.',
admin_informacion_sistema__auditoria_de_transferencias_de_are:'Auditoría de transferencias de aretes',
admin_informacion_sistema__registro_de_traspasos_autorizados:'Registro de traspasos autorizados entre UPP — listo para escribirse en Firebase (colección, fecha, hora y UPPs involucradas).',
admin_reportes_cefpp__reportes_a_cefpp:'Reportes a CEFPP',
admin_reportes_cefpp__descargar_informe_completo_para_ce:'Descargar informe completo para CEFPP',
modal_conflicto_arete__arete_ya_registrado:'Arete ya registrado',
modal_conflicto_arete__solicitar_transferencia_de_registr:'Solicitar Transferencia de Registro',
exportacion_pie_pagina__pag:'Pág.',
exportacion_pie_pagina__pdf_exportado:'PDF exportado',
exportacion_pie_pagina__excel_exportado:'Excel exportado',
exportacion_pie_pagina__csv_exportado:'CSV exportado',
exportacion_pie_pagina__no_hay_registros_para_exportar:'No hay registros para exportar',
transferencia_autonoma_aretes__sin_upp:'(sin UPP)',
transferencia_autonoma_aretes__el_animal_ya_no_esta:'El animal ya no está en el hato de origen (¿ya fue transferido?)',
transferencia_autonoma_aretes__solicitud_rechazada:'Solicitud rechazada',
transferencia_autonoma_aretes__aprobada_transferido:'Aprobada — transferido',
transferencia_autonoma_aretes__no_tienes_solicitudes_de_transfere:'No tienes solicitudes de transferencia pendientes.',
transferencia_autonoma_aretes__arete:'Arete %VAR%',
transferencia_autonoma_aretes__el_productor_del_predio_upp:'El productor del predio "%VAR%" (UPP %VAR%) está solicitando este arete que tienes activo en tu hato. Si este animal fue vendido o transferido, ¿autorizas traspasar su ficha técnica e historial (edad, raza, sexo, pesajes, etc.) a su cuenta?',
transferencia_autonoma_aretes__si:'Sí',
transferencia_autonoma_aretes__no:'No',
transferencia_autonoma_aretes__no_has_enviado_solicitudes_de:'No has enviado solicitudes de transferencia.',
transferencia_autonoma_aretes__solicitado_a_upp:'Solicitado a %VAR% (UPP %VAR%) · %VAR% %VAR%',
modo_offline_first__no_se_pudo_cargar_el:'No se pudo cargar el estado guardado localmente',
modo_offline_first__no_se_pudo_guardar_el:'No se pudo guardar el estado localmente',
navegacion_general__rueda_administrador:'Rueda (administrador)',
navegacion_general__luis_administrador:'Luis (administrador)',
navegacion_general__pedro_productor_de_carne:'Pedro (productor de carne)',
navegacion_general__marcos_productor_de_leche:'Marcos (productor de leche)',
navegacion_general__predio_de_pedro_editar:'Predio de Pedro (editar)',
navegacion_general__upp_pedro:'UPP-PEDRO',
navegacion_general__predio_de_marcos_editar:'Predio de Marcos (editar)',
navegacion_general__upp_marcos:'UPP-MARCOS',
navegacion_general__codigo_incorrecto:'Código incorrecto',
render_home_productor__animales_activos:'Animales activos',
render_estatus_hato__sin_datos:'Sin datos',
render_estatus_hato__atencion_urgente:'Atención urgente',
render_estatus_hato__en_tratamiento:'En tratamiento',
render_estatus_hato__dosis_vencida:'Dosis vencida',
render_estatus_hato__activo_sano:'Activo / sano',
render_estatus_hato__proxima_revision:'Próxima revisión',
render_estatus_hato__ultimo_parto:'Último parto',
render_estatus_hato__parto_estimado:'Parto estimado',
render_estatus_hato__aun_no_has_registrado_animales:'Aún no has registrado animales.',
render_estatus_hato__registrar_el_primer_animal:'Registrar el primer animal',
render_estatus_hato__no_hay_animales_que_coincidan:'No hay animales que coincidan con la búsqueda.',
historial_bitacora_animal__nacimiento_alta_del_animal:'Nacimiento / alta del animal',
historial_bitacora_animal__aun_no_hay_eventos_registrados:'Aún no hay eventos registrados para este animal.',
gastos_rendimiento_animal__escribe_el_concepto_y_un:'Escribe el concepto y un monto válido',
gastos_rendimiento_animal__movimiento_registrado:'Movimiento registrado',
gastos_rendimiento_animal__peso_kg:'Peso (kg)',
gastos_rendimiento_animal__gastos:'Gastos',
gastos_rendimiento_animal__texto:'$%VAR%',
gastos_rendimiento_animal__ingresos:'Ingresos',
gastos_rendimiento_animal__neto:'Neto',
gastos_rendimiento_animal__sin_movimientos_registrados:'Sin movimientos registrados.',
gastos_rendimiento_animal__texto_2:'%VAR%$%VAR%',
gastos_rendimiento_animal__gdp_promedio_kg_dia:'GDP promedio: %VAR% kg/día',
gastos_rendimiento_animal__ultimo_tramo_kg_dia_ganancia:'· último tramo: %VAR% kg/día · ganancia total: %VAR% kg en %VAR% días',
gastos_rendimiento_animal__ficha:'Ficha %VAR%',
gastos_rendimiento_animal__ficha_del_animal:'Ficha del animal — %VAR%',
gastos_rendimiento_animal__predio_upp_municipio:'Predio: %VAR% · UPP: %VAR% · Municipio: %VAR%',
gastos_rendimiento_animal__datos_de_identificacion:'Datos de identificación',
gastos_rendimiento_animal__arete_siniiga:'Arete SINIIGA',
gastos_rendimiento_animal__arete_chip_campana:'Arete/chip campaña',
gastos_rendimiento_animal__raza:'Raza',
gastos_rendimiento_animal__sexo:'Sexo',
gastos_rendimiento_animal__fecha_de_nacimiento:'Fecha de nacimiento',
gastos_rendimiento_animal__estatus:'Estatus',
gastos_rendimiento_animal__madre:'Madre',
gastos_rendimiento_animal__padre:'Padre',
gastos_rendimiento_animal__historial_de_salud:'Historial de salud',
gastos_rendimiento_animal__fecha:'Fecha',
gastos_rendimiento_animal__tipo:'Tipo',
gastos_rendimiento_animal__producto_diagnostico:'Producto/diagnóstico',
gastos_rendimiento_animal__proxima:'Próxima',
gastos_rendimiento_animal__historial_de_pesajes:'Historial de pesajes',
gastos_rendimiento_animal__ficha_generada_el:'Ficha generada el %VAR%',
render_modulos_f__ver_estatus_del_hato:'Ver estatus del hato',
render_modulos_f__ver_registros:'Ver registros',
render_modulos_f__escanea_o_escribe:'Escanea o escribe...',
render_modulos_f__camara_del_celular_o_lector:'Cámara del celular o lector físico: solo se guardan los últimos 10 dígitos (se descartan el "MX" y los 2 dígitos iniciales del país).',
render_modulos_f__ej_120:'Ej. 120',
render_modulos_f__ej_venta_enfermedad_robo:'Ej. venta, enfermedad, robo...',
render_modulos_f__proposito_del_animal:'Propósito del animal',
render_modulos_f__reemplazo:'Reemplazo',
render_modulos_f__engorda_venta:'Engorda / venta',
render_modulos_f__dias_objetivo_de_engorda:'Días objetivo de engorda',
render_modulos_f__peso_meta_kg_opcional:'Peso meta (kg, opcional)',
render_modulos_f__los_dias_correran_de_forma:'Los días correrán de forma continua desde hoy hasta que marques este animal como "engorda finalizada" en Manejo de Engorda.',
render_modulos_f__sin_asignar:'Sin asignar',
render_modulos_f__motivo_de_baja_solo_si:'Motivo de baja (solo si aplica)',
render_modulos_f__foto_del_animal:'Foto del animal',
render_modulos_f__puedes_tomar_la_foto_directo:'Puedes tomar la foto directo con la cámara del celular.',
render_modulos_f__cantidad_usada:'Cantidad usada',
render_modulos_f__aplicar_a_todo_un_lote:'Aplicar a todo un lote / potrero (vacunación, desparasitación, etc.)',
render_modulos_f__potrero_lote:'Potrero / lote',
render_modulos_f__selecciona_un_potrero:'Selecciona un potrero...',
render_modulos_f__se_creara_un_registro_para:'Se creará un registro para cada animal activo de ese potrero.',
render_modulos_f__insumo_de_bodega_usado_opcional:'Insumo de bodega usado (opcional)',
render_modulos_f__sin_descontar_de_bodega:'Sin descontar de bodega',
render_modulos_f__si_seleccionas_un_insumo_se:'Si seleccionas un insumo, se descuenta automáticamente de Bodega e Insumos.',
render_modulos_f__fecha_de_servicio_monta:'Fecha de servicio / monta',
render_modulos_f__fecha_probable_de_parto:'Fecha probable de parto',
render_modulos_f__la_fecha_de_parto_se:'La fecha de parto se calcula sola (283 días desde el servicio). Puedes cambiarla a mano si tu veterinario te da otra fecha — la app usará la que tú dejes.',
render_modulos_f__color_de_etiqueta:'Color de etiqueta',
render_modulos_f__archivo_kmz_kml:'Archivo KMZ / KML',
render_modulos_f__trazar_potrero_en_el_mapa:'Traza el potrero en el mapa',
render_modulos_f__usa_el_icono_de_poligono:'Usa el ícono de polígono para dibujar los límites del potrero sobre el mapa.',
render_modulos_f__ubicacion_central:'Ubicación central',
render_modulos_f__ponle_nombre_al_potrero:'Ponle un nombre al potrero',
render_modulos_f__traza_el_poligono_en_el_mapa:'Traza el polígono del potrero en el mapa',
render_modulos_f__este_potrero_no_tiene_mapa:'Este potrero no tiene un polígono guardado',
render_modulos_f__volver_a_la_lista:'Volver a la lista',
render_modulos_f__descargar_mapa:'Descargar mapa',
render_modulos_f__no_se_pudo_generar_la_imagen:'No se pudo generar la imagen del mapa',
render_modulos_f__ver_mapa:'Ver mapa',
render_modulos_f__buscar_poblacion_camino_lugar:'Buscar población, camino o lugar',
render_modulos_f__usar_mi_ubicacion_actual:'Usar mi ubicación actual',
render_modulos_f__usar_google_maps_mas_detalle:'¿No encuentras el lugar? Usar Google Maps (más detalle)',
render_modulos_f__no_se_encontro_el_lugar:'No se encontró ese lugar, intenta con otro nombre',
render_modulos_f__buscando:'Buscando…',
render_modulos_f__ubicando:'Buscando tu ubicación…',
render_modulos_f__no_se_pudo_obtener_ubicacion:'No se pudo obtener tu ubicación. Revisa los permisos de GPS.',
render_modulos_f__geolocalizacion_no_disponible:'Tu dispositivo no permite obtener la ubicación.',
render_modulos_f__falta_api_key_google:'Falta configurar la clave de Google Maps en el código (GOOGLE_MAPS_API_KEY).',
render_modulos_f__cargando_google_maps:'Cargando Google Maps…',
render_modulos_f__guardar_registro:'Guardar registro',
render_modulos_f__siniiga:'SINIIGA %VAR% · %VAR% · %VAR%%VAR%',
render_modulos_f__kg:'%VAR% — %VAR% kg',
render_modulos_f__ha_capacidad_animales:'%VAR% ha · capacidad %VAR% animales',
render_modulos_f__texto:'%VAR%$%VAR% — %VAR%',
render_modulos_f__l:'%VAR% — %VAR% L',
render_modulos_f__am_l_pm_l:'AM %VAR% L · PM %VAR% L · %VAR%%VAR%',
render_modulos_f__l_acopiados:'%VAR% L acopiados%VAR%',
render_modulos_f__kg_dia:'%VAR% · %VAR% kg/día · %VAR%',
render_modulos_f__kg_al_nacer:'%VAR% — %VAR% kg al nacer',
render_modulos_f__calostro_l:'%VAR% · Calostro: %VAR% L%VAR%%VAR% · %VAR%%VAR%',
render_modulos_f__costo_total_actualizado:'%VAR% · costo total $%VAR% · actualizado %VAR%',
render_modulos_f__aun_no_hay_registros_en:'Aún no hay registros en este módulo.',
guardar_registros__escribe_al_menos_el_arete:'Escribe al menos el arete o el nombre del animal para poder guardarlo',
guardar_registros__ya_tienes_un_animal_registrado:'Ya tienes un animal registrado con ese arete en tu hato',
guardar_registros__animal_registrado:'Animal registrado',
escaneo_camara_barcodedetector__tu_navegador_no_soporta_escaneo:'Tu navegador no soporta escaneo por cámara. Usa el botón del lector físico o escribe el código a mano.',
escaneo_camara_barcodedetector__no_se_pudo_acceder_a:'No se pudo acceder a la cámara. Revisa los permisos, o usa el lector físico / escribe el código a mano.',
escaneo_camara_barcodedetector__codigo_escaneado:'Código escaneado',
escaneo_codigo_barras__listo_escanea_el_arete_ahora:'Listo, escanea el arete ahora...',
escaneo_codigo_barras__selecciona_un_potrero_para_aplicar:'Selecciona un potrero para aplicar por lote',
escaneo_codigo_barras__no_hay_animales_activos_en:'No hay animales activos en ese potrero',
escaneo_codigo_barras__caso_urgente_registrado_se_agrego:'Caso urgente registrado — se agregó a Reportes CEFPP',
escaneo_codigo_barras__registro_de_salud_guardado:'Registro de salud guardado',
escaneo_codigo_barras__registro_reproductivo_guardado_se:'Registro reproductivo guardado — se reprogramaron las fechas de seguimiento',
escaneo_codigo_barras__se_seguira_vigilando_5_dias:'Se seguirá vigilando 5 días más',
escaneo_codigo_barras__pesaje_guardado:'Pesaje guardado',
escaneo_codigo_barras__potrero_guardado:'Potrero guardado',
escaneo_codigo_barras__movimiento_guardado:'Movimiento guardado',
escaneo_codigo_barras__ordena_registrada:'Ordeña registrada',
escaneo_codigo_barras__registro_de_tanque_guardado:'Registro de tanque guardado',
escaneo_codigo_barras__registro_de_alimentacion_guardado:'Registro de alimentación guardado',
inventario_alimento__escribe_el_producto_y_los:'Escribe el producto y los kg disponibles',
inventario_alimento__inventario_actualizado:'Inventario actualizado',
inventario_alimento__guardado_atencion_el_calostro_se:'Guardado — atención: el calostro se dio después de las 6 horas recomendadas',
inventario_alimento__becerro_registrado:'Becerro registrado',
inventario_alimento__aun_no_registras_existencias:'Aún no registras existencias.',
inventario_alimento__kg_actualizado:'%VAR% kg · actualizado %VAR%',
bodega_e_insumos__escribe_el_nombre_del_insumo:'Escribe el nombre del insumo y una cantidad válida',
bodega_e_insumos__existencias_de_bodega_actualizadas:'Existencias de bodega actualizadas',
bodega_e_insumos__existencias_por_agotarse:'Existencias por agotarse',
bodega_e_insumos__leer_mas:'Leer más',
bodega_e_insumos__aun_no_hay_boletines_publicados:'Aún no hay boletines publicados.',
graficas__mortalidad_del_hato:'Mortalidad del hato',
graficas__gestaciones_confirmadas:'Gestaciones confirmadas',
graficas__peso_promedio_registrado:'Peso promedio registrado',
graficas__animales_asignados:'Animales asignados',
graficas__0_1_ano:'0-1 año',
graficas__1_2_anos:'1-2 años',
graficas__2_4_anos:'2-4 años',
graficas__4_8_anos:'4-8 años',
graficas__8_anos:'8+ años',
graficas__no_hay_fechas_proximas_registradas:'No hay fechas próximas registradas.',
bitacora_visitas_veterinarias__escribe_al_menos_la_fecha:'Escribe al menos la fecha y el veterinario',
bitacora_visitas_veterinarias__visita_registrada:'Visita registrada',
bitacora_visitas_veterinarias__visita_eliminada:'Visita eliminada',
bitacora_visitas_veterinarias__visita_restaurada:'Visita restaurada',
bitacora_visitas_veterinarias__tasa_de_prenez:'Tasa de preñez (%)',
bitacora_visitas_veterinarias__aun_no_hay_visitas_registradas:'Aún no hay visitas registradas.',
bitacora_visitas_veterinarias__sin_datos_suficientes:'Sin datos suficientes',
bitacora_visitas_veterinarias__costo_por_litro:'Costo por litro',
bitacora_visitas_veterinarias__eficiencia_alimenticia:'Eficiencia alimenticia',
bitacora_visitas_veterinarias__comparativo_contra_referencia_hols:'Comparativo contra referencia Holstein',
bitacora_visitas_veterinarias__grasa_promedio:'% Grasa promedio',
bitacora_visitas_veterinarias__proteina_promedio:'% Proteína promedio',
bitacora_visitas_veterinarias__servicios_por_concepcion:'Servicios por concepción',
bitacora_visitas_veterinarias__intervalo_entre_partos_iep:'Intervalo entre partos (IEP)',
bitacora_visitas_veterinarias__dias_abiertos_promedio:'Días abiertos promedio',
bitacora_visitas_veterinarias__referencia_raza_holstein_se_necesi:'Referencia raza Holstein. Se necesitan varios registros (partos reales, servicios, calidad de leche) para que estos comparativos sean confiables.',
bitacora_visitas_veterinarias__ranking_de_mejores_productoras_lit:'Ranking de mejores productoras (litros acumulados)',
bitacora_visitas_veterinarias__dias_en_leche_del_y:'Días en leche (DEL) y días abiertos',
bitacora_visitas_veterinarias__crecimiento_y_desarrollo:'Crecimiento y desarrollo',
bitacora_visitas_veterinarias__estado_de_resultados_por_mes:'Estado de resultados por mes',
bitacora_visitas_veterinarias__punto_de_equilibrio:'Punto de equilibrio',
bitacora_visitas_veterinarias__proyeccion_proximo_mes:'Proyección próximo mes',
bitacora_visitas_veterinarias__rentabilidad_por_animal_lote_imput:'Rentabilidad por animal / lote imputado',
modo_veterinario__modo_veterinario_activado_solo_ver:'Modo veterinario activado: solo verás salud',
modo_veterinario__modo_veterinario_desactivado:'Modo veterinario desactivado',
modo_veterinario__cuentas_de:'Cuentas de',
modo_veterinario__productores:'productores',
modo_veterinario__usuarios_y:'Usuarios y',
modo_veterinario__contrasenas:'contraseñas',
modo_veterinario__datos_del:'Datos del',
modo_veterinario__productor:'productor',
modo_veterinario__informativos:'informativos',
modo_veterinario__configuracion:'Configuración',
modo_veterinario__de_ventanas:'de ventanas',
predios_multiples__escribe_el_nombre_del_predio:'Escribe el nombre del predio',
predios_multiples__predio_agregado:'Predio agregado',
predios_multiples__predio_eliminado:'Predio eliminado',
predios_multiples__predio_restaurado:'Predio restaurado',
predios_multiples__aun_no_agregas_predios_adicionales:'Aún no agregas predios adicionales.',
notificaciones_push_reales__este_navegador_no_soporta_notifica:'Este navegador no soporta notificaciones',
notificaciones_push_reales__notificaciones_activadas:'Notificaciones activadas ✓',
notificaciones_push_reales__permiso_no_concedido:'Permiso no concedido',
notificaciones_push_reales__notificaciones_push_activadas:'Notificaciones push activadas',
notificaciones_push_reales__no_se_concedio_permiso_de:'No se concedió permiso de notificaciones',
notificaciones_push_reales__mi_ranchapp:'MiRanch —',
reportes_cefpp__muerte_subita:'Muerte súbita',
reportes_cefpp__sospecha_de_enfermedad_exotica:'Sospecha de enfermedad exótica',
reportes_cefpp__caso_marcado_como_enviado_a:'Caso marcado como enviado a CEFPP',
reportes_cefpp__caso_marcado_como_pendiente:'Caso marcado como pendiente',
reportes_cefpp__no_hay_casos_para_exportar:'No hay casos para exportar',
reportes_cefpp__tipo_de_caso:'Tipo de caso',
reportes_cefpp__estatus_de_envio_a_cefpp:'Estatus de envío a CEFPP',
reportes_cefpp__informe_descargado:'Informe descargado',
reportes_cefpp__no_hay_casos_urgentes_reportados:'No hay casos urgentes reportados por ahora.',
mensajes_veterinario_productor__usuario_creado:'Usuario creado',
mensajes_veterinario_productor__usuario_eliminado:'Usuario eliminado',
mensajes_veterinario_productor__usuario_restaurado:'Usuario restaurado',
mensajes_veterinario_productor__contrasena_actualizada:'Contraseña actualizada',
mensajes_veterinario_productor__aun_no_hay_mensajes:'Aún no hay mensajes.',
mensajes_veterinario_productor__productor_configurado:'Productor configurado',
mensajes_veterinario_productor__animales_registrados:'Animales registrados',
mensajes_veterinario_productor__usuarios_del_sistema:'Usuarios del sistema',
mensajes_veterinario_productor__boletines_publicados:'Boletines publicados',
mensajes_veterinario_productor__nueva_contrasena:'Nueva contraseña',
mensajes_veterinario_productor__usuario_rol:'usuario: %VAR% · rol: %VAR%',
cuentas_productores_alta__elige_una_fecha_primero:'Elige una fecha primero',
cuentas_productores_alta__reloj_de_pruebas_fijado_en:'Reloj de pruebas fijado en',
cuentas_productores_alta__usando_la_fecha_real_del:'Usando la fecha real del dispositivo',
cuentas_productores_alta__nombre_predio_y_upp_son:'Nombre, predio y UPP son obligatorios',
cuentas_productores_alta__ya_existe_una_cuenta_registrada:'Ya existe una cuenta registrada con esa UPP',
cuentas_productores_alta__productor:'(productor)',
cuentas_productores_alta__cuenta_eliminada:'Cuenta eliminada',
cuentas_productores_alta__cuenta_restaurada:'Cuenta restaurada',
cuentas_productores_alta__vigencia_actualizada:'Vigencia actualizada',
cuentas_productores_alta__cuenta_renovada_por:'Cuenta renovada por',
cuentas_productores_alta__dias_desde_hoy:'días desde hoy',
cuentas_productores_alta__cuenta_marcada_como_vencida_para:'Cuenta marcada como vencida (para pruebas)',
cuentas_productores_alta__esta_semana:'Esta semana',
cuentas_productores_alta__este_mes:'Este mes',
cuentas_productores_alta__este_ano:'Este año',
cuentas_productores_alta__cuenta_s:'cuenta(s)',
cuentas_productores_alta__por_vencer:'Por vencer',
cuentas_productores_alta__simulada:'(simulada)',
cuentas_productores_alta__real:'(real)',
cuentas_productores_alta__registros_de_salud:'Registros de salud',
cuentas_productores_alta__registros_reproductivos:'Registros reproductivos',
cuentas_productores_alta__pesajes_registrados:'Pesajes registrados',
cuentas_productores_alta__potreros_registrados:'Potreros registrados',
cuentas_productores_alta__costos_registrados:'Costos registrados',
cuentas_productores_alta__no_hay_cuentas_por_vencer:'No hay cuentas por vencer en los próximos 15 días.',
cuentas_productores_alta__upp:'%VAR% · UPP %VAR%',
cuentas_productores_alta__aun_no_hay_cuentas_de:'Aún no hay cuentas de productores registradas.',
cuentas_productores_alta__upp_2:'%VAR% · UPP %VAR% · %VAR%',
cuentas_productores_alta__usuario_contrasena:'usuario: %VAR% · contraseña: %VAR%',
cuentas_productores_alta__alta_vence:'Alta: %VAR% · Vence: %VAR% (%VAR%)',
cuentas_productores_alta__probar_acceso:'Probar acceso',
cuentas_productores_alta__renovar:'Renovar',
cuentas_productores_alta__30_dias:'+30 días',
cuentas_productores_alta__30_dias_2:'-30 días',
cuentas_productores_alta__vencer_ahora:'Vencer ahora',
cuentas_productores_alta__aun_no_se_han_autorizado:'Aún no se han autorizado transferencias de aretes.',
cuentas_productores_alta__upp_upp:'%VAR% (UPP %VAR%) → %VAR% (UPP %VAR%)',
edicion_datos_productor__datos_del_productor_actualizados:'Datos del productor actualizados',
edicion_datos_productor__a_registro_e_identificacion_animal:'A. Registro e Identificación Animal',
edicion_datos_productor__b_salud_sanidad_y_manejo:'B. Salud, Sanidad y Manejo',
edicion_datos_productor__c_reproduccion_y_maternidad:'C. Reproducción y Maternidad',
edicion_datos_productor__d_pesajes_y_productividad:'D. Pesajes y Productividad',
edicion_datos_productor__e_mapeo_geografico:'E. Mapeo Geográfico',
edicion_datos_productor__f_administracion_costos_y_reportes:'F. Administración, Costos y Reportes',
edicion_datos_productor__g_produccion_de_leche_solo:'G. Producción de Leche (solo ganado de leche)',
edicion_datos_productor__h_tanque_y_entrega_de:'H. Tanque y Entrega de Leche (solo ganado de leche)',
edicion_datos_productor__i_alimentacion_lechera_solo_ganado:'I. Alimentación Lechera (solo ganado de leche)',
edicion_datos_productor__j_becerros_de_reemplazo_solo:'J. Becerros de Reemplazo (solo ganado de leche)',
edicion_datos_productor__folio_de_fierro_de_herrar:'Folio de fierro de herrar',
edicion_datos_productor__numero_de_animales_activos:'Número de animales activos',
edicion_datos_productor__g_produccion_de_leche:'G. Producción de Leche',
edicion_datos_productor__h_tanque_y_entrega_de_2:'H. Tanque y Entrega de Leche',
edicion_datos_productor__i_alimentacion_lechera:'I. Alimentación Lechera',
edicion_datos_productor__j_becerros_de_reemplazo:'J. Becerros de Reemplazo',
edicion_datos_productor__indicadores_lecheros_comparativo_h:'Indicadores lecheros (comparativo Holstein)',
edicion_datos_productor__estatus_financiero:'Estatus financiero',
edicion_datos_productor__tasa_de_prenez:'Tasa de preñez',
edicion_datos_productor__ocupacion_de_potreros:'Ocupación de potreros',
edicion_datos_productor__edades_del_hato:'Edades del hato',
plan_sanitario_anual__escribe_el_nombre_de_la:'Escribe el nombre de la campaña',
plan_sanitario_anual__campana_agregada_al_plan:'Campaña agregada al plan',
plan_sanitario_anual__campana_eliminada:'Campaña eliminada',
plan_sanitario_anual__campana_restaurada:'Campaña restaurada',
plan_sanitario_anual__reporte_sanitario_anual_descargado:'Reporte sanitario anual descargado',
plan_sanitario_anual__aun_no_programas_campanas:'Aún no programas campañas.',
trabajadores__ya_tienes_el_maximo_de:'Ya tienes el máximo de 3 trabajadores por cuenta',
trabajadores__escribe_el_nombre_del_trabajador:'Escribe el nombre del trabajador',
trabajadores__trabajador_agregado:'Trabajador agregado',
trabajadores__trabajador_eliminado:'Trabajador eliminado',
trabajadores__trabajador_restaurado:'Trabajador restaurado',
trabajadores__aun_no_agregas_trabajadores:'Aún no agregas trabajadores.',
trabajadores__codigo_de_acceso:'Código de acceso:',
tareas__escribe_la_tarea:'Escribe la tarea',
tareas__tarea_asignada:'Tarea asignada',
tareas__aun_no_asignas_tareas:'Aún no asignas tareas.',
tareas__para:'Para: %VAR% · %VAR% %VAR%',
ventanas_personalizadas__escribe_un_nombre_para_la:'Escribe un nombre para la ventana',
ventanas_personalizadas__ventana_agregada:'Ventana agregada',
ventanas_personalizadas__ventana_eliminada:'Ventana eliminada',
ventanas_personalizadas__ventana_restaurada:'Ventana restaurada',
ventanas_personalizadas__aun_no_agregas_ventanas_propias:'Aún no agregas ventanas propias.',
ventanas_personalizadas__sin_notas_todavia:'Sin notas todavía.',
banner_mensajes__escribe_un_texto_para_el:'Escribe un texto para el banner',
banner_mensajes__banner_programado:'Banner programado',
banner_mensajes__banner_eliminado:'Banner eliminado',
banner_mensajes__banner_restaurado:'Banner restaurado',
banner_mensajes__boletin_publicado:'Boletín publicado',
banner_mensajes__boletin_eliminado:'Boletín eliminado',
banner_mensajes__boletin_restaurado:'Boletín restaurado',
banner_mensajes__aun_no_programas_banners:'Aún no programas banners.',
banner_mensajes__tienes_notificaciones_pendientes_t:'Tienes notificaciones pendientes — toca para verlas',
confirmacion_visual_al__deshacer:'Deshacer',
buscador_global__sin_resultados:'Sin resultados',
calendario_visual__vencimiento_credencial_de_fierro:'Vencimiento credencial de fierro',
calendario_visual__no_hay_vencimientos_proximos_para:'No hay vencimientos próximos para exportar',
calendario_visual__proximo:'Próximo',
calendario_visual__tramite:'Trámite',
calendario_visual__categoria:'Categoría',
calendario_visual__titulo:'Título',
calendario_visual__dias_restantes:'Días restantes',
calendario_visual__tabla_exportada:'Tabla exportada',
calendario_visual__sin_eventos_este_dia:'Sin eventos este día.',
motor_alertas_automaticas__obligatoria:'OBLIGATORIA —',
motor_alertas_automaticas__tratamiento_de_hoy:'Tratamiento de hoy',
motor_alertas_automaticas__proxima_dosis_programada:'Próxima dosis programada',
motor_alertas_automaticas__leche_apta_desde_hoy:'Leche apta desde hoy',
motor_alertas_automaticas__leche_no_apta_para_el:'Leche NO apta para el tanque',
motor_alertas_automaticas__parto_atrasado:'Parto atrasado',
motor_alertas_automaticas__parto_esperado_hoy:'Parto esperado hoy',
motor_alertas_automaticas__parto_proximo:'Parto próximo',
motor_alertas_automaticas__secado_atrasado:'Secado atrasado',
motor_alertas_automaticas__secar_hoy:'Secar hoy',
motor_alertas_automaticas__secado_proximo:'Secado próximo',
motor_alertas_automaticas__periodo_seco_vencido_atenta_al:'Periodo seco vencido — atenta al parto',
motor_alertas_automaticas__termina_el_periodo_seco_hoy:'Termina el periodo seco hoy',
motor_alertas_automaticas__periodo_seco_por_terminar:'Periodo seco por terminar',
motor_alertas_automaticas__vigilar_celo_hoy:'Vigilar celo hoy',
motor_alertas_automaticas__vigilar_posible_celo_proximo:'Vigilar posible celo próximo',
motor_alertas_automaticas__no_volvio_a_estar_en:'¿No volvió a estar en celo?',
motor_alertas_automaticas__calostro_pendiente_de_registrar:'Calostro pendiente de registrar',
motor_alertas_automaticas__inventario_de_alimento_bajo:'Inventario de alimento bajo',
motor_alertas_automaticas__campana_sanitaria_de_este_mes:'Campaña sanitaria de este mes',
motor_alertas_automaticas__tramite_vencido:'Trámite vencido',
motor_alertas_automaticas__tramite_proximo:'Trámite próximo',
motor_alertas_automaticas__sin_revision_reciente:'Sin revisión reciente',
motor_alertas_automaticas__urgente_muerte_subita:'URGENTE · Muerte súbita',
motor_alertas_automaticas__urgente_sospecha_exotica:'URGENTE · Sospecha exótica',
motor_alertas_automaticas__proximos:'Próximos',
motor_alertas_automaticas__proximos_tramites:'Próximos trámites',
motor_alertas_automaticas__no_hay_animales_enfermos_reportado:'No hay animales enfermos reportados.',
motor_alertas_automaticas__recuperado:'Recuperado',
motor_alertas_automaticas__no_tienes_notificaciones_por_ahora:'No tienes notificaciones por ahora.',
exportar_csv__toro_pajuela:'Toro/pajuela',
exportar_csv__diagnostico:'Diagnóstico',
exportar_csv__condicion_corporal:'Condición corporal',
exportar_csv__hectareas:'Hectáreas',
exportar_csv__capacidad_animal:'Capacidad animal',
exportar_csv__imputar_a:'Imputar a',
exportar_csv__descripcion:'Descripción',
exportar_csv__ordeno:'Ordeñó',
exportar_csv__litros_am:'Litros AM',
exportar_csv__litros_pm:'Litros PM',
exportar_csv__total_litros:'Total litros',
exportar_csv__grasa:'% Grasa',
exportar_csv__proteina:'% Proteína',
exportar_csv__celulas_somaticas:'Células somáticas',
exportar_csv__litros_acopiados:'Litros acopiados',
exportar_csv__precio_litro:'Precio/litro',
exportar_csv__racion:'Ración',
exportar_csv__kg_concentrado_dia:'Kg concentrado/día',
exportar_csv__fecha_nacimiento:'Fecha nacimiento',
exportar_csv__peso_al_nacer:'Peso al nacer',
exportar_csv__litros_calostro:'Litros calostro',
exportar_csv__horas_calostro:'Horas calostro',
exportar_csv__alimentacion:'Alimentación',
exportar_csv__fecha_destete:'Fecha destete',
exportar_csv__peso_destete:'Peso destete',
exportar_csv__registros_exportados:'Registros exportados',
exportar_csv__no_hay_animales_para_exportar:'No hay animales para exportar',
exportar_csv__arete_campana:'Arete campaña',
exportar_csv__inventario_exportado:'Inventario exportado',
registro_exportaciones_csv__inventario_de_hato:'Inventario de hato',
registro_exportaciones_csv__proximos_vencimientos:'Próximos vencimientos',
registro_exportaciones_csv__informe_cefpp:'Informe CEFPP',
sistema_idiomas_es__en:'EN: %VAR%',
sistema_idiomas_es__de:'DE: %VAR%',
manejo_engorda_corral__no_tienes_tareas_pendientes_por:'No tienes tareas pendientes por ahora.',
manejo_engorda_corral__en_engorda_ahora:'En engorda ahora',
manejo_engorda_corral__engordas_finalizadas:'Engordas finalizadas',
manejo_engorda_corral__aun_no_tienes_animales_marcados:'Aún no tienes animales marcados con propósito de engorda.',
manejo_engorda_corral__dias_corriendo:'%VAR% días corriendo%VAR%%VAR%',
manejo_engorda_corral__marcar_engorda_finalizada:'Marcar engorda finalizada',
manejo_engorda_corral__finalizada_en_dias:'Finalizada en %VAR% días',
manejo_engorda_corral__en_curso:'En curso',
manejo_engorda_corral__finalizadas:'Finalizadas',
csv_extra__animal:'Animal',
csv_extra__detalle:'Detalle',
csv_extra__notas:'Notas',
csv_extra__potrero:'Potrero',
csv_extra__predio:'Predio',
csv_extra2__comprador:'Comprador',
csv_extra2__lote:'Lote',
csv_extra2__producto:'Producto',
csv_extra2__recolectado:'Recolectado',
csv_extra2__alojamiento:'Alojamiento',
csv_extra2__monto:'Monto',
csv_extra2__etapa:'Etapa',
csv_extra2__vaca:'Vaca',
csv_extra2__descuentos:'Descuentos',
csv_extra2__bonos:'Bonos',
csv_extra2__temperatura:'Temperatura',
csv_extra2__becerro:'Becerro',
csv_extra3__servicio:'Servicio',
csv_extra4__vencidos:'Vencidos',
csv_extra4__hoy:'Hoy',
csv_extra4__enfermo:'Enfermo',
csv_extra5__sin_registros:'Sin registros',
csv_extra6__pendiente:'Pendiente',
csv_extra6__rechazada:'Rechazada',
csv_extra6__si_boton:'Sí',
csv_extra6__no_boton:'No',
csv_extra7__total:'Total',
csv_extra7__vencidas:'Vencidas',
csv_extra7__vence_hoy:'Vence hoy',
csv_extra7__activa:'Activa',
csv_extra7__vencida:'Vencida',
csv_extra8__vencido:'Vencido',
modal_conflicto__texto:'El arete %VAR% ya está activo bajo el predio "%VAR%" (UPP %VAR%), de %VAR%. Si este animal fue vendido o transferido a tu rancho, puedes solicitar el traspaso de su ficha e historial.',
campo_f__arete_siniiga:'Arete SINIIGA',
campo_f__arete_campana_chip:'Arete campaña / chip',
campo_f__nombre_o_alias:'Nombre o alias',
campo_f__raza:'Raza',
campo_f__sexo:'Sexo',
campo_f__fecha_de_nacimiento:'Fecha de nacimiento',
campo_f__estatus:'Estatus',
campo_f__madre_arete_nombre:'Madre (arete/nombre)',
campo_f__padre_pajuela:'Padre / pajuela',
campo_f__animal_arete_o_nombre:'Animal (arete o nombre)',
campo_f__tipo:'Tipo',
campo_f__producto_diagnostico:'Producto / diagnóstico',
campo_f__fecha_de_aplicacion:'Fecha de aplicación',
campo_f__proxima_dosis:'Próxima dosis',
campo_f__cuarto_afectado_mastitis:'Cuarto afectado (si es mastitis)',
campo_f__resultado_cmt:'Resultado CMT (si aplica)',
campo_f__notas:'Notas',
campo_f__vaca_arete_o_nombre:'Vaca (arete o nombre)',
campo_f__tipo_de_servicio:'Tipo de servicio',
campo_f__toro_pajuela_utilizada:'Toro / pajuela utilizada',
campo_f__diagnostico_de_gestacion:'Diagnóstico de gestación',
campo_f__fecha_real_de_parto:'Fecha real de parto (si ya ocurrió)',
campo_f__fecha_de_pesaje:'Fecha de pesaje',
campo_f__peso_kg:'Peso (kg)',
campo_f__lote_potrero:'Lote / potrero',
campo_f__condicion_corporal_opcional:'Condición corporal (1 a 5, opcional)',
campo_f__nombre_del_potrero:'Nombre del potrero',
campo_f__hectareas:'Hectáreas',
campo_f__capacidad_animal:'Capacidad animal',
campo_f__tipo_de_movimiento:'Tipo de movimiento',
campo_f__monto:'Monto ($)',
campo_f__categoria:'Categoría',
campo_f__fecha:'Fecha',
campo_f__imputar_a:'Imputar a (lote/animal)',
campo_f__descripcion:'Descripción',
campo_f__fecha_de_ordena:'Fecha de ordeña',
campo_f__quien_ordeno:'Quién ordeñó',
campo_f__litros_ordena_am:'Litros ordeña AM',
campo_f__litros_ordena_pm:'Litros ordeña PM',
campo_f__grasa_opcional:'% Grasa (opcional)',
campo_f__celulas_somaticas_opcional:'Células somáticas (opcional)',
campo_f__proteina_opcional:'% Proteína (opcional)',
campo_f__litros_acopiados_tanque:'Litros acopiados en tanque',
campo_f__temperatura_tanque:'Temperatura del tanque (°C)',
campo_f__ya_paso_recolector:'¿Ya pasó el recolector/pipa?',
campo_f__comprador_pasteurizadora:'Comprador / pasteurizadora',
campo_f__precio_pagado_litro:'Precio pagado por litro ($)',
campo_f__bonos_calidad:'Bonos por calidad ($)',
campo_f__descuentos_calidad:'Descuentos por calidad ($)',
campo_f__vaca_arete_o_nombre_lote:'Vaca (arete o nombre, opcional si es por lote)',
campo_f__etapa_de_lactancia:'Etapa de lactancia',
campo_f__tipo_de_racion:'Tipo de ración',
campo_f__kg_concentrado_dia:'Kg de concentrado / día',
campo_f__becerro_arete_o_nombre:'Becerro/a (arete o nombre)',
campo_f__peso_al_nacer_kg:'Peso al nacer (kg)',
campo_f__litros_calostro_dados:'Litros de calostro dados',
campo_f__horas_despues_del_parto:'Horas después del parto',
campo_f__tipo_de_alojamiento:'Tipo de alojamiento',
campo_f__alimentacion_actual:'Alimentación actual',
campo_f__fecha_de_destete:'Fecha de destete (si ya ocurrió)',
campo_f__peso_al_destete_kg:'Peso al destete (kg)',
campo_f__nombre_del_insumo:'Nombre del insumo (ej. Sal mineral, Vacuna IBR)',
campo_f__unidad:'Unidad',
campo_f__cantidad_comprada:'Cantidad comprada',
campo_f__costo_total:'Costo total ($)',
campo_f__alerta_menos_de:'Alerta cuando queden menos de...',
campo_f__potrero:'Potrero',
campo_f__dias_retiro_leche:'Días de retiro de leche (si aplicó antibiótico)',
campo_f__app_calculara_aviso_tanque:'La app calculará y avisará hasta qué fecha esta vaca no debe entrar al tanque.',
campo_f__fecha_programada_secado:'Fecha programada de secado',
campo_f__secado_se_calcula_solo:'El secado se calcula solo (60 días antes del parto probable). También puedes ajustarlo a mano.',
campo_f__fecha_cierre_lactancia:'Fecha de cierre de lactancia',
campo_f__fin_periodo_seco:'Fin del periodo seco',
campo_f__cuando_dejes_ordenarla:'Cuando dejes de ordeñarla, pon aquí la fecha — se avisa 5 días antes de que termine el periodo seco.',
campo_f__inventario_de_alimento:'Inventario de alimento',
campo_f__producto_ej_concentrado:'Producto (ej. concentrado)',
campo_f__kg_disponibles:'Kg disponibles',
campo_f__actualizar_existencia:'Actualizar existencia',
},
en: {
salir:'Sign out', volver:'Back', guardar:'Save', cancelar:'Cancel', editar:'Edit',
buscar:'Search', exportar:'Export', exportar_csv:'CSV', exportar_excel:'Excel', exportar_pdf:'PDF',
chat_flotante__enviar_por_chat:'Send via chat (no download)',
chat_flotante__abre_una_conversacion_primero:'Open a conversation first',
chat_flotante__inicia_sesion_con_una_cuenta:'Log in with an account to send messages',
chat_flotante__mas_filas:'more rows',
chat_flotante__enviado_al_chat:'Sent to chat',
elegir_formato:'Choose the export format', idioma:'Language', cambiar_idioma:'Change language',
nav_inicio:'Home', nav_hato:'Herd', nav_graficas:'Charts', nav_boletines:'Bulletins',
tile_datos:'My<br>data', tile_reporte:'Report &<br>notifications', tile_graficas:'Charts', tile_boletines:'Info<br>bulletins',
glosario_titulo:'Livestock technical glossary', glosario_sub:'Key terms used in the app, in all three languages.',
mod_A_nombre:'Animal Registration & Identification', mod_A_corto:'Animal<br>identification',
mod_B_nombre:'Health, Sanitation & Management', mod_B_corto:'Health &<br>sanitation',
mod_C_nombre:'Reproduction & Maternity', mod_C_corto:'Reproduction<br>& maternity',
mod_D_nombre:'Weighing & Productivity', mod_D_corto:'Weighing &<br>productivity',
mod_E_nombre:'Geographic Mapping', mod_E_corto:'Geographic<br>mapping',
mod_F_nombre:'Administration, Costs & Reports', mod_F_corto:'Costs &<br>reports',
mod_G_nombre:'Milk Production', mod_G_corto:'Milk<br>production',
mod_H_nombre:'Milk Tank & Delivery', mod_H_corto:'Tank &<br>delivery',
mod_I_nombre:'Dairy Feeding', mod_I_corto:'Dairy<br>feeding',
mod_J_nombre:'Replacement Calves', mod_J_corto:'Replacement<br>calves',
mod_K_nombre:'Warehouse & Supplies', mod_K_corto:'Warehouse &<br>supplies',
gl_control_lechero:'Milk recording', gl_arete_siniiga:'Ear tag / SINIIGA ID', gl_registro_partos:'Calving record',
gl_inseminacion:'Artificial insemination (AI)', gl_estatus_sanitario:'Health status', gl_potrero:'Paddock', gl_hato:'Herd',
gl_empadre:'Breeding / mating', gl_gestacion:'Gestation', gl_destete:'Weaning', gl_calostro:'Colostrum',
gl_vacunacion:'Vaccination', gl_desparasitacion:'Deworming', gl_gdp:'ADG (Average Daily Gain)', gl_lote:'Batch / lot',
exp_generado:'Generated', exp_marca:'Document generated by MiRanch',
login_seleccion_rol__mi_ranchapp:'My RanchApp',
login_seleccion_rol__gestion_de_tu_rancho_facil:'Manage your ranch, simple and clear',
login_seleccion_rol__entra_directo_por_lo_pronto:'Go straight in — no password for now',
login_seleccion_rol__ingresa_tus_datos:'Enter your username and password',
login_seleccion_rol__usuario:'Username',
login_seleccion_rol__contrasena:'Password',
login_seleccion_rol__iniciar_sesion:'Log in',
login_seleccion_rol__ingresa_usuario_y_contrasena:'Enter your username and password',
login_seleccion_rol__usuario_o_contrasena_incorrectos:'Incorrect username or password',
login_seleccion_rol__inicia_sesion:'Log In',
login_seleccion_rol__ej_usuario:'E.g: JohnDoe',
login_seleccion_rol__olvide_mi_contrasena:'Forgot my password?',
login_seleccion_rol__iniciar_sesion_mayus:'LOG IN',
login_seleccion_rol__no_tienes_cuenta:'Don\'t have an account?',
login_seleccion_rol__registrate_aqui:'Sign up here.',
login_seleccion_rol__te_enviaremos_un_codigo:'We will send you a code on WhatsApp to the phone registered on your account.',
login_seleccion_rol__enviar_codigo_por_whatsapp:'Send code on WhatsApp',
login_seleccion_rol__ligar_nueva_cuenta:'Link new account',
login_seleccion_rol__solicita_tu_acceso:'Request your access. The administrator will confirm your account.',
login_seleccion_rol__punto_receptor_de_leche:'Milk receiving point',
login_seleccion_rol__mvz:'Vet (DVM)',
vet_pacientes__personas_atendidas:'People attended',
vet_notas__mis_notas:'My notes',
vet_notas__guardar_nota:'Save note',
vet_perfil__mi_perfil:'My profile',
vet_perfil__cambiar_foto:'Change photo',
vet_perfil__especialidad_medica:'Medical specialty',
vet_perfil__descripcion:'Description',
vet_perfil__zona_de_atencion:'Service area',
vet_perfil__guardar_perfil:'Save profile',
contactos__buscar_en_mis_contactos:'Search my contacts',
contactos__buscar_amigos:'Find friends',
contactos__ya_usa_la_app:'Already using the app',
contactos__abrir_chat:'Open chat',
contactos__invitar_por_whatsapp:'Invite via WhatsApp',
contactos__no_disponible_en_este_dispositivo:'This device does not allow access to your contacts. You can type a number manually.',
contactos__sin_coincidencias:'None of your selected contacts use the app yet.',
contactos__buscando:'Searching...',
contactos__numero_manual:'Type a phone number',
contactos__buscar_numero:'Search number',
login_seleccion_rol__cedula_profesional:'Professional license number *',
login_seleccion_rol__lugar_de_residencia:'Place of residence *',
login_seleccion_rol__continuar:'Continue',
login_seleccion_rol__moonitor_faltan_datos:'Wait! Some fields are still missing or need review in this step. Check them and try again.',
login_seleccion_rol__moonitor_datos_validados:'Your data has been validated! Now choose the username and password you want to use to log in.',
login_seleccion_rol__moonitor_bienvenida:'Welcome to MiRanch, %VAR%! Your account is ready. Your username is: %VAR2%',
login_seleccion_rol__moonitor_ya_existe:'That data seems to already be registered. Check your phone, UPP, or license number.',
login_seleccion_rol__verificando_tu_cuenta:'Checking your account...',
login_seleccion_rol__no_se_pudo_verificar_conexion:'Could not verify your account. Check your internet connection and try again.',
login_seleccion_rol__gps_requiere_https:'Location only works on the published site (https), not in this preview.',
login_seleccion_rol__gps_permiso_denegado:'Location permission was denied. Enable it in your browser settings.',
login_seleccion_rol__gps_no_disponible:'Could not detect your location (GPS off or weak signal).',
login_seleccion_rol__gps_tiempo_agotado:'Getting your location took too long. Try again.',
login_seleccion_rol__nombre_del_veterinario:'Veterinarian name',
login_seleccion_rol__nombre_del_local:'Business name',
login_seleccion_rol__nombre_de_la_persona_encargada:'Name of the person in charge',
login_seleccion_rol__ubicacion_basica:'Basic location',
login_seleccion_rol__enviar_ubicacion_actual:'Send current location',
login_seleccion_rol__enviar_solicitud:'Send request',
login_seleccion_rol__procesando:'Processing…',
login_seleccion_rol__ya_existe_una_solicitud:'An account or request already exists with that information',
login_seleccion_rol__enviar_solicitud_por_whatsapp:'Send request on WhatsApp',
login_seleccion_rol__bienvenido:'Welcome',
login_seleccion_rol__completa_nombre_y_telefono:'Fill in your name and a valid phone number',
login_seleccion_rol__codigo_enviado:'Code sent on WhatsApp',
login_seleccion_rol__completa_todos_los_campos:'Fill in all fields with a valid phone number',
login_seleccion_rol__solicitud_enviada:'Request sent, wait for the administrator to confirm',
login_seleccion_rol__crea_tu_acceso:'Create your access. Your account is ready to use right away.',
login_seleccion_rol__crea_tu_usuario:'Create your username',
login_seleccion_rol__minimo_6_caracteres:'6 characters minimum',
login_seleccion_rol__crea_tu_contrasena:'Create your password',
login_seleccion_rol__6_o_mas_letras_numeros:'6+ characters, letters, numbers, or a mix.',
login_seleccion_rol__usuario_y_contrasena_6_caracteres:'Username and password must be at least 6 characters',
login_seleccion_rol__ese_usuario_ya_existe:'That username already exists, choose another one',
login_seleccion_rol__cuenta_creada_inicia_sesion:'Account created, you can log in now',
trabajadores__acceso_no_disponible:'This section is not available for workers',
trabajadores__enviar_a:'Send to...',
trabajadores__tarea_enviada_a:'Task sent to',
login_seleccion_rol__soy_productor:'I\'m a producer',
login_seleccion_rol__soy_administrador:'I\'m an administrator',
login_seleccion_rol__soy_trabajador:'I\'m a worker',
login_seleccion_rol__recepcion_de_leche_queseria:'Milk Reception (Creamery)',
queseria_login__selecciona_tu_perfil:'Select your profile',
queseria_login__elige_como_quieres_entrar:'Choose how you want to sign in',
queseria__administrador:'Administrator',
queseria_menu__recibir_leche:'Receive Milk',
queseria_menu__panel_de_reportes:'Reports Panel',
queseria_menu__gestion_de_productores:'Producer Management',
queseria_menu__bienvenido:'Welcome',
queseria_menu__cerrar_sesion:'Log out',
queseria_recepcion__recepcion_de_leche:'Milk Reception',
queseria_recepcion__lechero_recolector:'Collection route',
queseria_recepcion__productores_del_lechero:'Producers on this route',
queseria_recepcion__recibidos_hoy:'Received today',
queseria_recepcion__litros_recibidos:'Liters received',
queseria_recepcion__confirmar_recepcion:'Confirm Reception',
queseria_recepcion__selecciona_un_lechero:'Select a route to see its producers',
queseria_recepcion__aun_no_hay_productores_para_este_lechero:'This route has no producers yet',
queseria_recepcion__aun_no_has_recibido_leche_hoy:'No receptions logged yet today',
queseria_recepcion__notificacion_enviada:'Notification sent to',
queseria_productores__gestion_de_productores:'Producer Management',
queseria_productores__nombre_de_la_queseria:'Creamery name',
queseria_productores__alta_de_lechero:'Add collection route',
queseria_productores__nombre_del_lechero:'Route name',
queseria_productores__alta_de_productor:'Add producer',
queseria_productores__nombre_del_productor:'Producer name',
queseria_productores__codigo_identificador:'ID code',
queseria_productores__telefono_de_contacto:'Contact phone',
queseria_productores__registrar_productor:'Register producer',
queseria_productores__productores_registrados:'Registered producers',
queseria_productores__aun_no_hay_productores_registrados:'No producers registered yet',
queseria_productores__solicitud_de_vinculacion_enviada:'Linking request sent to the producer',
queseria_productores__completa_nombre_y_codigo:'Fill in at least the producer\'s name and code',
queseria_productores__nombre_guardado:'Creamery name saved',
queseria_productores__escribe_un_nombre:'Enter the route name',
queseria_reportes__panel_de_reportes:'Reports Panel',
queseria_reportes__hoy:'Today',
queseria_reportes__esta_semana:'This week',
queseria_reportes__este_mes:'This month',
queseria_reportes__detalle_por_productor:'Breakdown by producer',
queseria_reportes__litros_totales:'Total liters',
queseria_reportes__productores_activos:'Active producers',
queseria_reportes__recepciones:'Receptions',
queseria_reportes__todos_los_lecheros:'All routes',
queseria_reportes__aun_no_hay_datos_para_este_periodo:'No data for this period yet',
queseria__ingresa_los_litros:'Enter the liters',
queseria__dictado_por_voz_no_disponible:'Voice dictation is not available in this browser',
queseria__escuchando:'Listening…',
codigo_trabajador__codigo_de_4_digitos:'4-digit code',
codigo_trabajador__codigo_de_trabajador:'Worker code',
codigo_trabajador__pideselo_a_tu_administrador_o:'Ask your administrator or producer for it',
codigo_trabajador__entrar:'Enter',
seleccion_tipo_ganado__que_tipo_de_ganado_manejas:'What type of cattle do you raise?',
seleccion_tipo_ganado__elige_tu_tipo_de_produccion:'Choose your production type to tailor your features',
seleccion_tipo_ganado__ganado_vacuno_de_carne:'Beef Cattle',
seleccion_tipo_ganado__ganado_vacuno_de_leche:'Dairy Cattle',
aviso_suscripcion_vencida__suscripcion_vencida:'Subscription expired',
aviso_suscripcion_vencida__tu_acceso_a_mi_ranchapp:'Your access to MiRanch expired on',
aviso_suscripcion_vencida__contacta_a_tu_administrador_para:'Contact your administrator to renew your subscription and regain access to your data.',
aviso_suscripcion_vencida__cerrar_sesion:'Sign out',
inicio_productor__buscar_animal_potrero_o_boletin:'Search animal, paddock or bulletin...',
inicio_productor__buen_dia:'Good morning',
inicio_productor__buenas_tardes:'Good afternoon',
inicio_productor__buenas_noches:'Good evening',
inicio_productor__ver_mis_datos:'View my data',
inicio_productor__actividades_recientes:'Recent activities',
inicio_productor__ver_todas:'View all',
inicio_productor__aun_no_tienes_actividades:'You have no activities logged yet.',
inicio_productor__clima_cargando:'Loading weather...',
inicio_productor__clima_no_disponible:'Weather not available right now',
inicio_productor__reintentar:'Try again',
inicio_productor__pronostico_por_horas:'Hourly forecast',
inicio_productor__humedad:'Humidity',
inicio_productor__viento:'Wind',
inicio_productor__probabilidad_de_lluvia:'Rain chance',
inicio_productor__sensacion:'Feels like',
inicio_productor__ubicacion_aproximada:'Approximate location — turn it on in your browser for better accuracy',
inicio_productor__resumen_rapido:'Quick summary',
inicio_productor__mas_funciones:'More features',
inicio_productor__acceso_rapido:'Quick access',
menu_mas_productor__mensajes_con_tu_veterinario:'Messages with your vet',
menu_mas_productor__calendario_de_eventos:'Events calendar',
menu_mas_productor__bitacora_de_visitas_veterinarias:'Vet visits log',
menu_mas_productor__manejo_de_engorda_y_corral:'Feedlot & Pen Management',
menu_mas_productor__mis_tareas:'My Tasks',
menu_mas_productor__agregar_trabajador:'Add Worker',
admin_configuracion__funciones_que_vera_el_trabajador:'Features workers will see',
admin_configuracion__elige_que_modulos_puede_usar:'Choose which modules a worker can use when they log in with their code. Workers never see charts, costs, or reports, regardless of this.',
menu_mas_productor__transferencias_de_aretes:'Ear tag transfers',
transferencias_aretes__cuando_registras_un_arete_que:'When you register an ear tag that\'s already active on another property, you can request its transfer. The current owner decides whether to authorize it.',
transferencias_aretes__pendientes_de_tu_autorizacion:'Pending your authorization',
transferencias_aretes__tus_solicitudes_enviadas:'Your sent requests',
visitas_veterinarias__nombre_del_veterinario:'Vet\'s name',
visitas_veterinarias__motivo_de_la_visita:'Reason for visit',
visitas_veterinarias__que_se_reviso_observaciones:'What was checked / notes...',
visitas_veterinarias__registro_de_visitas_al_rancho:'Log of visits to the ranch, separate from each animal\'s treatment history — useful as documentation.',
visitas_veterinarias__registrar_visita:'Log visit',
calendario_visual__salud_dosis:'Health/dose',
calendario_visual__partos:'Calvings',
calendario_visual__tramites:'Paperwork',
mensajes_veterinario_productor__escribe_un_mensaje:'Write a message...',
ventana_personalizada__escribe_una_nota:'Write a note...',
datos_productor__datos_del_productor:'Producer data',
editar_datos_productor__editar_datos_del_productor:'Edit producer data',
editar_datos_productor__nombre:'Name',
editar_datos_productor__nombre_del_predio:'Property name',
editar_datos_productor__ultima_actualizacion_upp:'Last UPP update',
editar_datos_productor__folio_fierro_de_herrar:'Branding iron file number',
editar_datos_productor__vencimiento_credencial_fierro:'Branding credential expiry',
editar_datos_productor__estado:'State',
editar_datos_productor__municipio:'Municipality',
editar_datos_productor__ejido_parcela:'Ejido / plot',
editar_datos_productor__actividad_pecuaria:'Livestock activity',
editar_datos_productor__el_numero_de_animales_activos:'The number of active animals is counted automatically, based on what you register in module A.',
editar_datos_productor__guardar_cambios:'Save changes',
hato_inventario_animales__buscar_animal:'Search animal...',
hato_inventario_animales__estatus_del_hato:'Herd status',
hato_inventario_animales__todos_los_estatus:'All statuses',
hato_inventario_animales__activo:'Active',
hato_inventario_animales__engorda:'Feedlot',
hato_inventario_animales__gestante:'Pregnant',
hato_inventario_animales__lactando:'Lactating',
hato_inventario_animales__vaquilla:'Heifer',
hato_inventario_animales__semental:'Bull/Stud',
hato_inventario_animales__vendido:'Sold',
hato_inventario_animales__finado:'Deceased',
hato_inventario_animales__ambos_sexos:'Both sexes',
hato_inventario_animales__hembra:'Female',
hato_inventario_animales__macho:'Male',
graficas__vista_previa_el_diseno_final:'Preview — we\'ll define the final chart design together later.',
graficas__composicion_del_hato_por_sexo:'Herd composition by sex',
graficas__aun_no_hay_animales_registrados:'No animals registered yet.',
graficas__tasa_de_prenez_por_temporada:'Pregnancy rate by season',
graficas__aun_no_hay_diagnosticos_de:'No pregnancy diagnoses registered yet.',
graficas__evolucion_de_pesajes:'Weighing trend',
graficas__aun_no_hay_pesajes_registrados:'No weighings registered yet.',
graficas__costos_por_categoria:'Costs by category',
graficas__aun_no_hay_costos_registrados:'No costs registered yet.',
graficas__proximas_fechas_importantes:'Upcoming important dates',
graficas__ocupacion_vs_capacidad_de_potreros:'Occupancy vs. paddock capacity',
graficas__aun_no_hay_potreros_registrados:'No paddocks registered yet.',
graficas__gastos_vs_ingresos_por_mes:'Expenses vs. income by month',
graficas__aun_no_hay_movimientos_registrados:'No transactions registered yet.',
graficas__edades_del_hato_por_sexo:'Herd ages by sex',
graficas__aun_no_hay_animales_con:'No animals with a registered birth date yet.',
graficas__bajas_por_causa:'Losses by cause',
graficas__aun_no_hay_bajas_registradas:'No losses registered yet.',
boletines_informativos__boletines_informativos:'Info bulletins',
modal_escaner_camara__escanear_arete:'Scan ear tag',
modal_escaner_camara__apunta_la_camara_al_codigo:'Point the camera at the ear tag\'s barcode...',
modal_boletin__cerrar:'Close',
notificaciones__reporte_y_notificaciones:'Report & notifications',
notificaciones__reportar_caso_urgente_muerte_subit:'Report urgent case (sudden death / suspected exotic disease)',
notificaciones__exportar_tabla_de_proximos_vencimi:'Export upcoming due-dates table',
notificaciones__reportes_de_chequeos_diarios:'Daily check-up reports',
notificaciones__notificaciones:'Notifications',
modal_historial_bitacora__concepto_ej_inseminacion_venta:'Item (e.g. insemination, sale)',
modal_historial_bitacora__monto:'Amount $',
modal_historial_bitacora__imprimir_descargar_ficha_resumen:'Print / download summary sheet',
modal_historial_bitacora__gastos_y_rendimiento:'Expenses & performance',
modal_historial_bitacora__gasto:'Expense',
modal_historial_bitacora__ingreso:'Income',
modal_historial_bitacora__registrar:'Register',
modal_historial_bitacora__bitacora_del_animal:'Animal log',
inicio_administrador__modo_veterinario_solo_salud:'Vet mode (health only)',
menu_mas_administrador__resumen_general:'General summary',
menu_mas_administrador__informacion_general_del_sistema:'General system information',
menu_mas_administrador__cuentas_de_productores_y_vigencias:'Producer accounts & validity',
menu_mas_administrador__reportes_a_cefpp_casos_urgentes:'CEFPP reports (urgent cases)',
menu_mas_administrador__reportes_y_analisis_de_produccion:'Production Reports and Analysis',
reportes_admin__cruza_datos_de_todas_las:'Cross-reference data from all producer accounts by region, production type, and health status.',
reportes_admin__tipo_de_produccion:'Production type',
reportes_admin__estado_de_salud:'Health status',
reportes_admin__todos:'All',
reportes_admin__alerta_cefpp:'CEFPP alert',
reportes_admin__actualizar_datos_de_todas_las:'Update data from all accounts',
reportes_admin__folios_de_fierro_de_herrar:'Branding iron file numbers',
reportes_admin__desglose_por_productor:'Breakdown by producer',
reportes_admin__cargando:'Loading',
reportes_admin__datos_actualizados_de:'Data updated from',
reportes_admin__nacimientos:'Births',
reportes_admin__compras:'Purchases',
reportes_admin__bajas:'Culls',
reportes_admin__siniiga_activos:'Active SINIIGA',
reportes_admin__siniiga_pendientes:'Pending SINIIGA',
reportes_admin__alertas_sanitarias:'Health alerts',
reportes_admin__sin_folios_registrados:'No file numbers registered',
reportes_admin__pulsa_actualizar_datos_para_ver:'Tap "Update data" to see the breakdown',
metricas_admin__metricas_de_interaccion:'Interaction Metrics',
metricas_admin__uso_real_de_la_app_por:'Actual app usage by producers: when they log in, how they arrived, and how much they share.',
metricas_admin__horarios_de_mayor_actividad:'Peak activity hours',
metricas_admin__dias_de_mayor_actividad:'Peak activity days',
metricas_admin__origen_de_acceso:'Access source (QR code vs. direct)',
metricas_admin__mensajes_compartidos_por_whatsapp:'Messages shared via WhatsApp',
metricas_admin__datos_recolectados_desde_este:'Data collected from this device/installation onward.',
metricas_admin__inicios_de_sesion:'Logins',
metricas_admin__accesos_por_qr:'QR accesses',
metricas_admin__mensajes_por_whatsapp:'WhatsApp messages',
metricas_admin__madrugada:'Early morning',
metricas_admin__manana:'Morning',
metricas_admin__tarde:'Afternoon',
metricas_admin__noche:'Evening',
metricas_admin__domingo:'Sunday',
metricas_admin__lunes:'Monday',
metricas_admin__martes:'Tuesday',
metricas_admin__miercoles:'Wednesday',
metricas_admin__jueves:'Thursday',
metricas_admin__viernes:'Friday',
metricas_admin__sabado:'Saturday',
metricas_admin__via_codigo_qr:'Via QR code',
metricas_admin__acceso_directo:'Direct access',
metricas_admin__compartir_la_app:'Share the app',
metricas_admin__cuenta_nueva_creada:'New account created',
metricas_admin__recuperar_contrasena:'Password recovery',
metricas_admin__recordatorio_de_vigencia:'Renewal reminder',
metricas_admin__otro:'Other',
metricas_admin__sin_datos_aun:'No data yet',
menu_mas_administrador__mensajes_con_el_productor:'Messages with the producer',
mensajes_admin__conversaciones:'Conversations',
mensajes_admin__mensaje_segmentado:'Segmented message',
mensajes_admin__filtros_de_destino:'Recipient filters',
mensajes_admin__todos_los_tipos:'All types',
mensajes_admin__productores_que_recibiran_este:'producers who will receive this message',
mensajes_admin__contenido_del_mensaje:'Message content',
mensajes_admin__usar_plantilla:'Use template...',
mensajes_admin__escribe_el_mensaje_para_los:'Write the message for the selected producers...',
mensajes_admin__adjuntar_archivo:'Attach file',
mensajes_admin__enlace_url_opcional:'URL link (optional)',
mensajes_admin__guardar_como_plantilla:'Save as template',
mensajes_admin__programar_envio:'Schedule send (optional)',
mensajes_admin__enviar_ahora:'Send now',
mensajes_admin__programar:'Schedule',
mensajes_admin__envios_programados:'Scheduled sends',
mensajes_admin__archivo_demasiado_pesado:'That file is too large, try a lighter one',
mensajes_admin__escribe_un_mensaje_para_guardarlo:'Write a message first',
mensajes_admin__plantilla_guardada:'Template saved',
mensajes_admin__nadie_cumple_estos_filtros:'No producer matches these filters',
mensajes_admin__elige_fecha_para_programar:'Choose a date to schedule the send',
mensajes_admin__mensaje_programado:'Message scheduled',
mensajes_admin__mensaje_enviado_a:'Message sent to',
mensajes_admin__no_hay_envios_programados:'No scheduled sends',
mensajes_admin__enviado:'sent',
menu_mas_administrador__ver_como_productor:'View as producer',
admin_usuarios_contrasenas__nombre_completo:'Full name',
admin_usuarios_contrasenas__usuario:'Username',
admin_usuarios_contrasenas__contrasena:'Password',
admin_usuarios_contrasenas__usuarios_y_contrasenas:'Users & passwords',
admin_usuarios_contrasenas__agregar_nuevo_usuario:'Add new user',
admin_usuarios_contrasenas__productor:'Producer',
admin_usuarios_contrasenas__administrador:'Administrator',
admin_usuarios_contrasenas__veterinario_solo_salud:'Vet (health only)',
admin_usuarios_contrasenas__crear_usuario:'Create user',
admin_cuentas_productores__nombre_del_rancho_predio:'Ranch / property name',
admin_cuentas_productores__10_digitos:'10 digits',
admin_cuentas_productores__numero_ip:'IP address',
admin_cuentas_productores__ej_192_168:'E.g. 192.168.0.1',
admin_cuentas_productores__completa_telefono_e_ip:'Fill in the name, farm, UPP, phone and IP',
admin_cuentas_productores__cuenta_creada_compartir:'Account created. Share access with the producer:',
admin_cuentas_productores__compartir_por_whatsapp:'Share on WhatsApp',
admin_cuentas_productores__mensaje_bienvenida_cuenta:'Welcome to MiRanch! Your account is ready.\nUsername: %VAR%\nPassword: %VAR%\nDownload the app here: https://mi-ranchapp.netlify.app',
admin_cuentas_productores__cuentas_de_productores:'Producer accounts',
admin_cuentas_productores__alta_de_cuentas_control_de:'Account creation, validity control and commercial tracking.',
admin_cuentas_productores__reloj_de_pruebas:'Test clock',
admin_cuentas_productores__entorno_de_pruebas_reloj_simulado:'Test environment — simulated clock',
admin_cuentas_productores__hoy_real:'Today (real):',
admin_cuentas_productores__hoy_usado_por_la_app:'· Today (used by the app):',
admin_cuentas_productores__usar_esta_fecha:'Use this date',
admin_cuentas_productores__volver_a_la_fecha_real:'Revert to the device\'s real date',
admin_cuentas_productores__metricas_de_nuevas_cuentas:'New accounts metrics',
admin_cuentas_productores__nuevas_cuentas_generadas:'New accounts created',
admin_cuentas_productores__proximos_a_vencer:'Upcoming expirations',
admin_cuentas_productores__suscripciones_que_vencen_en_los:'Subscriptions expiring in the next 15 days.',
admin_cuentas_productores__alta_de_nueva_cuenta:'New account setup',
admin_cuentas_productores__registrar_nueva_cuenta:'Register new account',
admin_cuentas_productores__nombre_del_productor:'Producer\'s name *',
admin_cuentas_productores__nombre_del_predio:'Property name *',
admin_cuentas_productores__numero_de_upp:'UPP number *',
admin_cuentas_productores__tipo_de_modulo:'Module type *',
admin_cuentas_productores__lechera:'Dairy',
admin_cuentas_productores__carne:'Beef',
admin_cuentas_productores__telefono_whatsapp:'Phone (WhatsApp)',
admin_cuentas_productores__dias_de_vigencia:'Days of validity',
admin_cuentas_productores__crear_cuenta:'Create account',
admin_cuentas_productores__listado_completo:'Full list',
admin_cuentas_productores__todas_las_cuentas:'All accounts',
admin_info_general__esto_es_lo_que_vera:'This is what the producer will see in their summary.',
admin_configuracion__nombre_del_trabajador:'Worker\'s name',
admin_configuracion__ej_revisar_bebederos_del_potrero:'E.g. Check waterers in paddock 3',
admin_configuracion__nombre_de_la_campana:'Campaign name',
admin_configuracion__notas_opcional:'Notes (optional)',
admin_configuracion__nombre_de_la_ventana:'Window name...',
admin_configuracion__escribe_el_mensaje:'Write the message...',
admin_configuracion__configuracion_de_ventanas:'Windows settings',
admin_configuracion__ventanas_visibles_para_el_producto:'Windows visible to the producer',
admin_configuracion__apariencia_de_inicio:'Appearance — home screen',
admin_configuracion__cambia_la_foto_de_fondo:'Change the background photo producers see on their home screen. It is compressed automatically so it does not slow down loading.',
admin_configuracion__cambiar_foto_de_fondo:'Change background photo',
admin_configuracion__cambia_la_foto_del_encabezado:'Change the header background photo shown at the top of every screen (next to the logo, the app name, and the language button).',
admin_configuracion__cambia_el_logo_de_la_app:'Change the app logo. It will appear everywhere it currently shows (login, header, creamery).',
admin_configuracion__cambiar_logo:'Change logo',
moonitor_config__titulo:'Moo-nitor (assistant)',
moonitor_config__descripcion:'Upload a different image to change Moo-nitor\'s look for the season (Christmas, spring, etc.) or for each type of livestock. The default image is used if you do not upload one.',
moonitor_config__general:'General',
moonitor_config__restaurar_imagenes:'Restore default images',
moonitor_config__recordatorio_semanal:'Weekly sharing reminder',
moonitor_config__sonido_de_vaca:'Cow sound when showing messages',
moonitor_config__probar_sonido:'Test sound',
moonitor_config__recordatorio_descripcion:'Moo-nitor will remind all producers once a week to share the app with 2 contacts.',
moonitor__favor_de_compartir:'Please share the app with two of your contacts',
moonitor__compartir_por_whatsapp:'Share on WhatsApp',
moonitor__mensaje_compartir_app:'Check out MiRanch! It is the app I use to manage my ranch. Download it here:',
moonitor__falta_telefono:'You still need to register your phone number',
moonitor__entendido:'Got it',
moonitor__ahora_no:'Not now',
moonitor__tienes_avisos_pendientes:'You have pending alerts',
moonitor__ver_notificaciones:'View notifications',
moonitor__nuevo_boletin:'New bulletin',
moonitor__ver_boletines:'View bulletins',
queseria__operador:'Operator',
queseria__hora:'Time',
queseria_reportes__exportar_pdf:'Export data (PDF)',
admin_configuracion__cambiar_foto_de_encabezado:'Change header photo',
admin_configuracion__orden_de_botones_en_mas:'Button order in "More features"',
admin_qr__titulo:'Access QR code',
admin_qr__descripcion:'Generate a QR code that goes straight to the app\'s main screen. Great for posters, promotions, or printed ads.',
admin_qr__enlace:'Link',
admin_qr__descargar:'Download QR (PNG)',
admin_qr__escribe_un_enlace_valido:'Enter a valid link (it must start with http:// or https://)',
admin_configuracion__usa_las_flechas_para_cambiar:'Use the arrows to change the order in which the producer sees the herd and the modules.',
admin_configuracion__graficas_cuales_se_ven_y:'Charts: which are shown and in what order',
admin_configuracion__apaga_la_que_no_quieras:'Turn off the ones you don\'t want to show, and use the arrows to decide which appears first.',
admin_configuracion__trabajadores_maximo_3:'Workers (max. 2)',
admin_configuracion__cada_trabajador_entra_con_un:'Each worker signs in with their own code and can only register data and view/check their tasks — they can\'t see costs, settings or reports.',
admin_configuracion__asignar_tareas:'Assign tasks',
admin_configuracion__general:'General',
admin_configuracion__asignar_tarea:'Assign task',
admin_configuracion__plan_sanitario_anual:'Annual health plan',
admin_configuracion__programa_las_campanas_del_ano:'Schedule this year\'s campaigns (vaccination, deworming, check-ups). The producer will be alerted when each month arrives.',
admin_configuracion__enero:'January',
admin_configuracion__febrero:'February',
admin_configuracion__marzo:'March',
admin_configuracion__abril:'April',
admin_configuracion__mayo:'May',
admin_configuracion__junio:'June',
admin_configuracion__julio:'July',
admin_configuracion__agosto:'August',
admin_configuracion__septiembre:'September',
admin_configuracion__octubre:'October',
admin_configuracion__noviembre:'November',
admin_configuracion__diciembre:'December',
admin_configuracion__agregar_al_plan:'Add to plan',
admin_configuracion__descargar_reporte_sanitario_anual:'Download annual health report',
admin_configuracion__agregar_ventana_nueva:'Add new window',
admin_configuracion__crea_una_ventana_adicional_para:'Create an additional window for the producer (with its own notes area).',
admin_configuracion__banner_de_mensajes:'Message banner',
admin_configuracion__se_muestra_al_abrir_la:'Shown when the producer opens the app. You can schedule several and turn each on or off.',
admin_configuracion__texto_del_mensaje:'Message text',
admin_configuracion__imagen_opcional:'Image (optional)',
admin_configuracion__tamano_del_texto:'Text size',
admin_configuracion__chico:'Small',
admin_configuracion__mediano:'Medium',
admin_configuracion__grande:'Large',
admin_configuracion__color_de_fondo:'Background color',
admin_configuracion__color_de_texto:'Text color',
admin_configuracion__desde_opcional:'From (optional)',
admin_configuracion__hasta_opcional:'Until (optional)',
admin_configuracion__programar_banner:'Schedule banner',
admin_configuracion__predios_ranchos:'Properties / ranches',
admin_configuracion__si_el_productor_maneja_mas:'If the producer manages more than one property, add them here. They\'ll be able to choose which one they\'re viewing from the home screen.',
admin_configuracion__agregar_predio:'Add property',
admin_configuracion__notificaciones_del_navegador:'Browser notifications',
admin_configuracion__manda_un_aviso_emergente_aunque:'Sends a pop-up alert even when the app is closed in the background (requires browser/phone permission).',
admin_configuracion__activar_notificaciones_push:'Turn on push notifications',
admin_configuracion__campos_del_resumen_del_productor:'Producer summary fields',
admin_publicar_boletines__titulo_del_boletin:'Bulletin title',
admin_publicar_boletines__contenido_del_boletin:'Bulletin content...',
admin_publicar_boletines__imagen_cartel_opcional:'Image / poster (optional)',
admin_publicar_boletines__si_subes_imagen_aparecera_circulan:'If you upload an image, it will appear cycling in the carousel above the bulletin for the producer.',
admin_publicar_boletines__publicar_boletin:'Publish bulletin',
admin_informacion_sistema__vista_de_solo_lectura_util:'Read-only view, useful to check how app usage is going before connecting it to Firebase.',
admin_informacion_sistema__auditoria_de_transferencias_de_are:'Ear tag transfers audit',
admin_informacion_sistema__registro_de_traspasos_autorizados:'Log of authorized transfers between UPPs — ready to be written to Firebase (collection, date, time and UPPs involved).',
admin_reportes_cefpp__reportes_a_cefpp:'CEFPP reports',
admin_reportes_cefpp__descargar_informe_completo_para_ce:'Download full report for CEFPP',
modal_conflicto_arete__arete_ya_registrado:'Ear tag already registered',
modal_conflicto_arete__solicitar_transferencia_de_registr:'Request Registration Transfer',
exportacion_pie_pagina__pag:'Page',
exportacion_pie_pagina__pdf_exportado:'PDF exported',
exportacion_pie_pagina__excel_exportado:'Excel exported',
exportacion_pie_pagina__csv_exportado:'CSV exported',
exportacion_pie_pagina__no_hay_registros_para_exportar:'No records to export',
transferencia_autonoma_aretes__sin_upp:'(no UPP)',
transferencia_autonoma_aretes__el_animal_ya_no_esta:'The animal is no longer in the origin herd (was it already transferred?)',
transferencia_autonoma_aretes__solicitud_rechazada:'Request rejected',
transferencia_autonoma_aretes__aprobada_transferido:'Approved — transferred',
transferencia_autonoma_aretes__no_tienes_solicitudes_de_transfere:'You have no pending transfer requests.',
transferencia_autonoma_aretes__arete:'Ear tag %VAR%',
transferencia_autonoma_aretes__el_productor_del_predio_upp:'The producer of property "%VAR%" (UPP %VAR%) is requesting this ear tag, which is active in your herd. If this animal was sold or transferred, do you authorize moving its record and history (age, breed, sex, weighings, etc.) to their account?',
transferencia_autonoma_aretes__si:'Yes',
transferencia_autonoma_aretes__no:'No',
transferencia_autonoma_aretes__no_has_enviado_solicitudes_de:'You haven\'t sent any transfer requests.',
transferencia_autonoma_aretes__solicitado_a_upp:'Requested from %VAR% (UPP %VAR%) · %VAR% %VAR%',
modo_offline_first__no_se_pudo_cargar_el:'Could not load the locally saved state',
modo_offline_first__no_se_pudo_guardar_el:'Could not save the state locally',
navegacion_general__rueda_administrador:'Gear (administrator)',
navegacion_general__luis_administrador:'Luis (administrator)',
navegacion_general__pedro_productor_de_carne:'Pedro (beef producer)',
navegacion_general__marcos_productor_de_leche:'Marcos (dairy producer)',
navegacion_general__predio_de_pedro_editar:'Pedro\'s property (edit)',
navegacion_general__upp_pedro:'UPP-PEDRO',
navegacion_general__predio_de_marcos_editar:'Marcos\'s property (edit)',
navegacion_general__upp_marcos:'UPP-MARCOS',
navegacion_general__codigo_incorrecto:'Incorrect code',
render_home_productor__animales_activos:'Active animals',
render_estatus_hato__sin_datos:'No data',
render_estatus_hato__atencion_urgente:'Urgent attention',
render_estatus_hato__en_tratamiento:'Under treatment',
render_estatus_hato__dosis_vencida:'Overdue dose',
render_estatus_hato__activo_sano:'Active / healthy',
render_estatus_hato__proxima_revision:'Next check-up',
render_estatus_hato__ultimo_parto:'Last calving',
render_estatus_hato__parto_estimado:'Estimated calving',
render_estatus_hato__aun_no_has_registrado_animales:'You haven\'t registered any animals yet.',
render_estatus_hato__registrar_el_primer_animal:'Register the first animal',
render_estatus_hato__no_hay_animales_que_coincidan:'No animals match the search.',
historial_bitacora_animal__nacimiento_alta_del_animal:'Birth / animal registration',
historial_bitacora_animal__aun_no_hay_eventos_registrados:'No events registered for this animal yet.',
gastos_rendimiento_animal__escribe_el_concepto_y_un:'Enter the item and a valid amount',
gastos_rendimiento_animal__movimiento_registrado:'Transaction registered',
gastos_rendimiento_animal__peso_kg:'Weight (kg)',
gastos_rendimiento_animal__gastos:'Expenses',
gastos_rendimiento_animal__texto:'$%VAR%',
gastos_rendimiento_animal__ingresos:'Income',
gastos_rendimiento_animal__neto:'Net',
gastos_rendimiento_animal__sin_movimientos_registrados:'No transactions registered.',
gastos_rendimiento_animal__texto_2:'%VAR%$%VAR%',
gastos_rendimiento_animal__gdp_promedio_kg_dia:'Average ADG: %VAR% kg/day',
gastos_rendimiento_animal__ultimo_tramo_kg_dia_ganancia:'· last stretch: %VAR% kg/day · total gain: %VAR% kg in %VAR% days',
gastos_rendimiento_animal__ficha:'Record %VAR%',
gastos_rendimiento_animal__ficha_del_animal:'Animal record — %VAR%',
gastos_rendimiento_animal__predio_upp_municipio:'Property: %VAR% · UPP: %VAR% · Municipality: %VAR%',
gastos_rendimiento_animal__datos_de_identificacion:'Identification data',
gastos_rendimiento_animal__arete_siniiga:'SINIIGA ear tag',
gastos_rendimiento_animal__arete_chip_campana:'Field ear tag/chip',
gastos_rendimiento_animal__raza:'Breed',
gastos_rendimiento_animal__sexo:'Sex',
gastos_rendimiento_animal__fecha_de_nacimiento:'Date of birth',
gastos_rendimiento_animal__estatus:'Status',
gastos_rendimiento_animal__madre:'Mother',
gastos_rendimiento_animal__padre:'Father',
gastos_rendimiento_animal__historial_de_salud:'Health history',
gastos_rendimiento_animal__fecha:'Date',
gastos_rendimiento_animal__tipo:'Type',
gastos_rendimiento_animal__producto_diagnostico:'Product/diagnosis',
gastos_rendimiento_animal__proxima:'Next',
gastos_rendimiento_animal__historial_de_pesajes:'Weighing history',
gastos_rendimiento_animal__ficha_generada_el:'Record generated on %VAR%',
render_modulos_f__ver_estatus_del_hato:'View herd status',
render_modulos_f__ver_registros:'View records',
render_modulos_f__escanea_o_escribe:'Scan or type...',
render_modulos_f__camara_del_celular_o_lector:'Phone camera or physical scanner: only the last 10 digits are saved (the "MX" and the 2 country digits are dropped).',
render_modulos_f__ej_120:'E.g. 120',
render_modulos_f__ej_venta_enfermedad_robo:'E.g. sale, illness, theft...',
render_modulos_f__proposito_del_animal:'Animal\'s purpose',
render_modulos_f__reemplazo:'Replacement',
render_modulos_f__engorda_venta:'Feedlot / sale',
render_modulos_f__dias_objetivo_de_engorda:'Target feedlot days',
render_modulos_f__peso_meta_kg_opcional:'Target weight (kg, optional)',
render_modulos_f__los_dias_correran_de_forma:'The days will run continuously from today until you mark this animal as "feedlot finished" in Feedlot Management.',
render_modulos_f__sin_asignar:'Unassigned',
render_modulos_f__motivo_de_baja_solo_si:'Reason for loss (if applicable)',
render_modulos_f__foto_del_animal:'Animal photo',
render_modulos_f__puedes_tomar_la_foto_directo:'You can take the photo directly with your phone\'s camera.',
render_modulos_f__cantidad_usada:'Amount used',
render_modulos_f__aplicar_a_todo_un_lote:'Apply to a whole batch / paddock (vaccination, deworming, etc.)',
render_modulos_f__potrero_lote:'Paddock / batch',
render_modulos_f__selecciona_un_potrero:'Select a paddock...',
render_modulos_f__se_creara_un_registro_para:'A record will be created for every active animal in that paddock.',
render_modulos_f__insumo_de_bodega_usado_opcional:'Warehouse supply used (optional)',
render_modulos_f__sin_descontar_de_bodega:'Don\'t deduct from warehouse',
render_modulos_f__si_seleccionas_un_insumo_se:'If you select a supply, it\'s automatically deducted from Warehouse & Supplies.',
render_modulos_f__fecha_de_servicio_monta:'Service / breeding date',
render_modulos_f__fecha_probable_de_parto:'Expected calving date',
render_modulos_f__la_fecha_de_parto_se:'The calving date is calculated automatically (283 days from service). You can change it manually if your vet gives you a different date — the app will use whichever you leave.',
render_modulos_f__color_de_etiqueta:'Tag color',
render_modulos_f__archivo_kmz_kml:'KMZ / KML file',
render_modulos_f__trazar_potrero_en_el_mapa:'Draw the paddock on the map',
render_modulos_f__usa_el_icono_de_poligono:'Use the polygon icon to draw the paddock boundaries on the map.',
render_modulos_f__ubicacion_central:'Central location',
render_modulos_f__ponle_nombre_al_potrero:'Give the paddock a name',
render_modulos_f__traza_el_poligono_en_el_mapa:'Draw the paddock polygon on the map',
render_modulos_f__este_potrero_no_tiene_mapa:'This paddock has no saved polygon',
render_modulos_f__volver_a_la_lista:'Back to the list',
render_modulos_f__descargar_mapa:'Download map',
render_modulos_f__no_se_pudo_generar_la_imagen:'Could not generate the map image',
render_modulos_f__ver_mapa:'View map',
render_modulos_f__buscar_poblacion_camino_lugar:'Search town, road, or place',
render_modulos_f__usar_mi_ubicacion_actual:'Use my current location',
render_modulos_f__usar_google_maps_mas_detalle:'Cannot find the place? Use Google Maps (more detail)',
render_modulos_f__no_se_encontro_el_lugar:'That place was not found, try another name',
render_modulos_f__buscando:'Searching…',
render_modulos_f__ubicando:'Finding your location…',
render_modulos_f__no_se_pudo_obtener_ubicacion:'Could not get your location. Check your GPS permissions.',
render_modulos_f__geolocalizacion_no_disponible:'Your device does not allow getting your location.',
render_modulos_f__falta_api_key_google:'The Google Maps key (GOOGLE_MAPS_API_KEY) is not configured in the code yet.',
render_modulos_f__cargando_google_maps:'Loading Google Maps…',
render_modulos_f__guardar_registro:'Save record',
render_modulos_f__siniiga:'SINIIGA %VAR% · %VAR% · %VAR%%VAR%',
render_modulos_f__kg:'%VAR% — %VAR% kg',
render_modulos_f__ha_capacidad_animales:'%VAR% ha · capacity %VAR% animals',
render_modulos_f__texto:'%VAR%$%VAR% — %VAR%',
render_modulos_f__l:'%VAR% — %VAR% L',
render_modulos_f__am_l_pm_l:'AM %VAR% L · PM %VAR% L · %VAR%%VAR%',
render_modulos_f__l_acopiados:'%VAR% L collected%VAR%',
render_modulos_f__kg_dia:'%VAR% · %VAR% kg/day · %VAR%',
render_modulos_f__kg_al_nacer:'%VAR% — %VAR% kg at birth',
render_modulos_f__calostro_l:'%VAR% · Colostrum: %VAR% L%VAR%%VAR% · %VAR%%VAR%',
render_modulos_f__costo_total_actualizado:'%VAR% · total cost $%VAR% · updated %VAR%',
render_modulos_f__aun_no_hay_registros_en:'No records in this module yet.',
guardar_registros__escribe_al_menos_el_arete:'Enter at least the ear tag or the animal\'s name to save it',
guardar_registros__ya_tienes_un_animal_registrado:'You already have an animal registered with that ear tag in your herd',
guardar_registros__animal_registrado:'Animal registered',
escaneo_camara_barcodedetector__tu_navegador_no_soporta_escaneo:'Your browser doesn\'t support camera scanning. Use the physical scanner button or type the code by hand.',
escaneo_camara_barcodedetector__no_se_pudo_acceder_a:'Couldn\'t access the camera. Check permissions, or use the physical scanner / type the code by hand.',
escaneo_camara_barcodedetector__codigo_escaneado:'Code scanned',
escaneo_codigo_barras__listo_escanea_el_arete_ahora:'Ready, scan the ear tag now...',
escaneo_codigo_barras__selecciona_un_potrero_para_aplicar:'Select a paddock to apply by batch',
escaneo_codigo_barras__no_hay_animales_activos_en:'No active animals in that paddock',
escaneo_codigo_barras__caso_urgente_registrado_se_agrego:'Urgent case registered — added to CEFPP Reports',
escaneo_codigo_barras__registro_de_salud_guardado:'Health record saved',
escaneo_codigo_barras__registro_reproductivo_guardado_se:'Reproductive record saved — follow-up dates rescheduled',
escaneo_codigo_barras__se_seguira_vigilando_5_dias:'It will keep being monitored for 5 more days',
escaneo_codigo_barras__pesaje_guardado:'Weighing saved',
escaneo_codigo_barras__potrero_guardado:'Paddock saved',
escaneo_codigo_barras__movimiento_guardado:'Transaction saved',
escaneo_codigo_barras__ordena_registrada:'Milking registered',
escaneo_codigo_barras__registro_de_tanque_guardado:'Tank record saved',
escaneo_codigo_barras__registro_de_alimentacion_guardado:'Feeding record saved',
inventario_alimento__escribe_el_producto_y_los:'Enter the product and the available kg',
inventario_alimento__inventario_actualizado:'Inventory updated',
inventario_alimento__guardado_atencion_el_calostro_se:'Saved — note: colostrum was given after the recommended 6 hours',
inventario_alimento__becerro_registrado:'Calf registered',
inventario_alimento__aun_no_registras_existencias:'No stock registered yet.',
inventario_alimento__kg_actualizado:'%VAR% kg · updated %VAR%',
bodega_e_insumos__escribe_el_nombre_del_insumo:'Enter the supply name and a valid quantity',
bodega_e_insumos__existencias_de_bodega_actualizadas:'Warehouse stock updated',
bodega_e_insumos__existencias_por_agotarse:'Stock running low',
bodega_e_insumos__leer_mas:'Read more',
bodega_e_insumos__aun_no_hay_boletines_publicados:'No bulletins published yet.',
graficas__mortalidad_del_hato:'Herd mortality',
graficas__gestaciones_confirmadas:'Confirmed pregnancies',
graficas__peso_promedio_registrado:'Average recorded weight',
graficas__animales_asignados:'Assigned animals',
graficas__0_1_ano:'0-1 year',
graficas__1_2_anos:'1-2 years',
graficas__2_4_anos:'2-4 years',
graficas__4_8_anos:'4-8 years',
graficas__8_anos:'8+ years',
graficas__no_hay_fechas_proximas_registradas:'No upcoming dates registered.',
bitacora_visitas_veterinarias__escribe_al_menos_la_fecha:'Enter at least the date and the vet',
bitacora_visitas_veterinarias__visita_registrada:'Visit registered',
bitacora_visitas_veterinarias__visita_eliminada:'Visit deleted',
bitacora_visitas_veterinarias__visita_restaurada:'Visit restored',
bitacora_visitas_veterinarias__tasa_de_prenez:'Pregnancy rate (%)',
bitacora_visitas_veterinarias__aun_no_hay_visitas_registradas:'No visits registered yet.',
bitacora_visitas_veterinarias__sin_datos_suficientes:'Not enough data',
bitacora_visitas_veterinarias__costo_por_litro:'Cost per liter',
bitacora_visitas_veterinarias__eficiencia_alimenticia:'Feed efficiency',
bitacora_visitas_veterinarias__comparativo_contra_referencia_hols:'Comparison against Holstein reference',
bitacora_visitas_veterinarias__grasa_promedio:'Average fat %',
bitacora_visitas_veterinarias__proteina_promedio:'Average protein %',
bitacora_visitas_veterinarias__servicios_por_concepcion:'Services per conception',
bitacora_visitas_veterinarias__intervalo_entre_partos_iep:'Calving interval (CI)',
bitacora_visitas_veterinarias__dias_abiertos_promedio:'Average open days',
bitacora_visitas_veterinarias__referencia_raza_holstein_se_necesi:'Holstein breed reference. Several records (actual calvings, services, milk quality) are needed for these comparisons to be reliable.',
bitacora_visitas_veterinarias__ranking_de_mejores_productoras_lit:'Top producers ranking (accumulated liters)',
bitacora_visitas_veterinarias__dias_en_leche_del_y:'Days in milk (DIM) and open days',
bitacora_visitas_veterinarias__crecimiento_y_desarrollo:'Growth & development',
bitacora_visitas_veterinarias__estado_de_resultados_por_mes:'Monthly income statement',
bitacora_visitas_veterinarias__punto_de_equilibrio:'Break-even point',
bitacora_visitas_veterinarias__proyeccion_proximo_mes:'Next month projection',
bitacora_visitas_veterinarias__rentabilidad_por_animal_lote_imput:'Profitability by animal / allocated batch',
modo_veterinario__modo_veterinario_activado_solo_ver:'Vet mode enabled: you\'ll only see health',
modo_veterinario__modo_veterinario_desactivado:'Vet mode disabled',
modo_veterinario__cuentas_de:'Accounts',
modo_veterinario__productores:'producers',
modo_veterinario__usuarios_y:'Users &',
modo_veterinario__contrasenas:'passwords',
modo_veterinario__datos_del:'Data of the',
modo_veterinario__productor:'producer',
modo_veterinario__informativos:'info',
modo_veterinario__configuracion:'Settings',
modo_veterinario__de_ventanas:'of windows',
predios_multiples__escribe_el_nombre_del_predio:'Enter the property name',
predios_multiples__predio_agregado:'Property added',
predios_multiples__predio_eliminado:'Property deleted',
predios_multiples__predio_restaurado:'Property restored',
predios_multiples__aun_no_agregas_predios_adicionales:'No additional properties added yet.',
notificaciones_push_reales__este_navegador_no_soporta_notifica:'This browser doesn\'t support notifications',
notificaciones_push_reales__notificaciones_activadas:'Notifications enabled ✓',
notificaciones_push_reales__permiso_no_concedido:'Permission not granted',
notificaciones_push_reales__notificaciones_push_activadas:'Push notifications enabled',
notificaciones_push_reales__no_se_concedio_permiso_de:'Notification permission was not granted',
notificaciones_push_reales__mi_ranchapp:'My RanchApp —',
reportes_cefpp__muerte_subita:'Sudden death',
reportes_cefpp__sospecha_de_enfermedad_exotica:'Suspected exotic disease',
reportes_cefpp__caso_marcado_como_enviado_a:'Case marked as sent to CEFPP',
reportes_cefpp__caso_marcado_como_pendiente:'Case marked as pending',
reportes_cefpp__no_hay_casos_para_exportar:'No cases to export',
reportes_cefpp__tipo_de_caso:'Case type',
reportes_cefpp__estatus_de_envio_a_cefpp:'CEFPP submission status',
reportes_cefpp__informe_descargado:'Report downloaded',
reportes_cefpp__no_hay_casos_urgentes_reportados:'No urgent cases reported for now.',
mensajes_veterinario_productor__usuario_creado:'User created',
mensajes_veterinario_productor__usuario_eliminado:'User deleted',
mensajes_veterinario_productor__usuario_restaurado:'User restored',
mensajes_veterinario_productor__contrasena_actualizada:'Password updated',
mensajes_veterinario_productor__aun_no_hay_mensajes:'No messages yet.',
mensajes_veterinario_productor__productor_configurado:'Producer set up',
mensajes_veterinario_productor__animales_registrados:'Animals registered',
mensajes_veterinario_productor__usuarios_del_sistema:'System users',
mensajes_veterinario_productor__boletines_publicados:'Bulletins published',
mensajes_veterinario_productor__nueva_contrasena:'New password',
mensajes_veterinario_productor__usuario_rol:'user: %VAR% · role: %VAR%',
cuentas_productores_alta__elige_una_fecha_primero:'Choose a date first',
cuentas_productores_alta__reloj_de_pruebas_fijado_en:'Test clock set to',
cuentas_productores_alta__usando_la_fecha_real_del:'Using the device\'s real date',
cuentas_productores_alta__nombre_predio_y_upp_son:'Name, property and UPP are required',
cuentas_productores_alta__ya_existe_una_cuenta_registrada:'An account with that UPP is already registered',
cuentas_productores_alta__productor:'(producer)',
cuentas_productores_alta__cuenta_eliminada:'Account deleted',
cuentas_productores_alta__cuenta_restaurada:'Account restored',
cuentas_productores_alta__vigencia_actualizada:'Validity updated',
cuentas_productores_alta__cuenta_renovada_por:'Account renewed for',
cuentas_productores_alta__dias_desde_hoy:'days from today',
cuentas_productores_alta__cuenta_marcada_como_vencida_para:'Account marked as expired (for testing)',
cuentas_productores_alta__esta_semana:'This week',
cuentas_productores_alta__este_mes:'This month',
cuentas_productores_alta__este_ano:'This year',
cuentas_productores_alta__cuenta_s:'account(s)',
cuentas_productores_alta__por_vencer:'Expiring soon',
cuentas_productores_alta__simulada:'(simulated)',
cuentas_productores_alta__real:'(real)',
cuentas_productores_alta__registros_de_salud:'Health records',
cuentas_productores_alta__registros_reproductivos:'Reproductive records',
cuentas_productores_alta__pesajes_registrados:'Weighings registered',
cuentas_productores_alta__potreros_registrados:'Paddocks registered',
cuentas_productores_alta__costos_registrados:'Costs registered',
cuentas_productores_alta__no_hay_cuentas_por_vencer:'No accounts expiring in the next 15 days.',
cuentas_productores_alta__upp:'%VAR% · UPP %VAR%',
cuentas_productores_alta__aun_no_hay_cuentas_de:'No producer accounts registered yet.',
cuentas_productores_alta__upp_2:'%VAR% · UPP %VAR% · %VAR%',
cuentas_productores_alta__usuario_contrasena:'user: %VAR% · password: %VAR%',
cuentas_productores_alta__alta_vence:'Created: %VAR% · Expires: %VAR% (%VAR%)',
cuentas_productores_alta__probar_acceso:'Test access',
cuentas_productores_alta__renovar:'Renew',
cuentas_productores_alta__30_dias:'+30 days',
cuentas_productores_alta__30_dias_2:'-30 days',
cuentas_productores_alta__vencer_ahora:'Expire now',
cuentas_productores_alta__aun_no_se_han_autorizado:'No ear tag transfers authorized yet.',
cuentas_productores_alta__upp_upp:'%VAR% (UPP %VAR%) → %VAR% (UPP %VAR%)',
edicion_datos_productor__datos_del_productor_actualizados:'Producer data updated',
edicion_datos_productor__a_registro_e_identificacion_animal:'A. Animal Registration & Identification',
edicion_datos_productor__b_salud_sanidad_y_manejo:'B. Health, Sanitation & Management',
edicion_datos_productor__c_reproduccion_y_maternidad:'C. Reproduction & Maternity',
edicion_datos_productor__d_pesajes_y_productividad:'D. Weighing & Productivity',
edicion_datos_productor__e_mapeo_geografico:'E. Geographic Mapping',
edicion_datos_productor__f_administracion_costos_y_reportes:'F. Administration, Costs & Reports',
edicion_datos_productor__g_produccion_de_leche_solo:'G. Milk Production (dairy cattle only)',
edicion_datos_productor__h_tanque_y_entrega_de:'H. Milk Tank & Delivery (dairy cattle only)',
edicion_datos_productor__i_alimentacion_lechera_solo_ganado:'I. Dairy Feeding (dairy cattle only)',
edicion_datos_productor__j_becerros_de_reemplazo_solo:'J. Replacement Calves (dairy cattle only)',
edicion_datos_productor__folio_de_fierro_de_herrar:'Branding iron file number',
edicion_datos_productor__numero_de_animales_activos:'Number of active animals',
edicion_datos_productor__g_produccion_de_leche:'G. Milk Production',
edicion_datos_productor__h_tanque_y_entrega_de_2:'H. Milk Tank & Delivery',
edicion_datos_productor__i_alimentacion_lechera:'I. Dairy Feeding',
edicion_datos_productor__j_becerros_de_reemplazo:'J. Replacement Calves',
edicion_datos_productor__indicadores_lecheros_comparativo_h:'Dairy indicators (Holstein comparison)',
edicion_datos_productor__estatus_financiero:'Financial status',
edicion_datos_productor__tasa_de_prenez:'Pregnancy rate',
edicion_datos_productor__ocupacion_de_potreros:'Paddock occupancy',
edicion_datos_productor__edades_del_hato:'Herd ages',
plan_sanitario_anual__escribe_el_nombre_de_la:'Enter the campaign name',
plan_sanitario_anual__campana_agregada_al_plan:'Campaign added to plan',
plan_sanitario_anual__campana_eliminada:'Campaign deleted',
plan_sanitario_anual__campana_restaurada:'Campaign restored',
plan_sanitario_anual__reporte_sanitario_anual_descargado:'Annual health report downloaded',
plan_sanitario_anual__aun_no_programas_campanas:'No campaigns scheduled yet.',
trabajadores__ya_tienes_el_maximo_de:'You already have the maximum of 3 workers per account',
trabajadores__escribe_el_nombre_del_trabajador:'Enter the worker\'s name',
trabajadores__trabajador_agregado:'Worker added',
trabajadores__trabajador_eliminado:'Worker deleted',
trabajadores__trabajador_restaurado:'Worker restored',
trabajadores__aun_no_agregas_trabajadores:'No workers added yet.',
trabajadores__codigo_de_acceso:'Access code:',
tareas__escribe_la_tarea:'Enter the task',
tareas__tarea_asignada:'Task assigned',
tareas__aun_no_asignas_tareas:'No tasks assigned yet.',
tareas__para:'For: %VAR% · %VAR% %VAR%',
ventanas_personalizadas__escribe_un_nombre_para_la:'Enter a name for the window',
ventanas_personalizadas__ventana_agregada:'Window added',
ventanas_personalizadas__ventana_eliminada:'Window deleted',
ventanas_personalizadas__ventana_restaurada:'Window restored',
ventanas_personalizadas__aun_no_agregas_ventanas_propias:'No custom windows added yet.',
ventanas_personalizadas__sin_notas_todavia:'No notes yet.',
banner_mensajes__escribe_un_texto_para_el:'Enter text for the banner',
banner_mensajes__banner_programado:'Banner scheduled',
banner_mensajes__banner_eliminado:'Banner deleted',
banner_mensajes__banner_restaurado:'Banner restored',
banner_mensajes__boletin_publicado:'Bulletin published',
banner_mensajes__boletin_eliminado:'Bulletin deleted',
banner_mensajes__boletin_restaurado:'Bulletin restored',
banner_mensajes__aun_no_programas_banners:'No banners scheduled yet.',
banner_mensajes__tienes_notificaciones_pendientes_t:'You have pending notifications — tap to view them',
confirmacion_visual_al__deshacer:'Undo',
buscador_global__sin_resultados:'No results',
calendario_visual__vencimiento_credencial_de_fierro:'Branding credential expiry',
calendario_visual__no_hay_vencimientos_proximos_para:'No upcoming due dates to export',
calendario_visual__proximo:'Upcoming',
calendario_visual__tramite:'Paperwork',
calendario_visual__categoria:'Category',
calendario_visual__titulo:'Title',
calendario_visual__dias_restantes:'Days remaining',
calendario_visual__tabla_exportada:'Table exported',
calendario_visual__sin_eventos_este_dia:'No events on this day.',
motor_alertas_automaticas__obligatoria:'MANDATORY —',
motor_alertas_automaticas__tratamiento_de_hoy:'Today\'s treatment',
motor_alertas_automaticas__proxima_dosis_programada:'Next scheduled dose',
motor_alertas_automaticas__leche_apta_desde_hoy:'Milk fit for use starting today',
motor_alertas_automaticas__leche_no_apta_para_el:'Milk NOT fit for the tank',
motor_alertas_automaticas__parto_atrasado:'Overdue calving',
motor_alertas_automaticas__parto_esperado_hoy:'Calving expected today',
motor_alertas_automaticas__parto_proximo:'Calving coming up',
motor_alertas_automaticas__secado_atrasado:'Overdue drying-off',
motor_alertas_automaticas__secar_hoy:'Dry off today',
motor_alertas_automaticas__secado_proximo:'Drying-off coming up',
motor_alertas_automaticas__periodo_seco_vencido_atenta_al:'Dry period overdue — watch for calving',
motor_alertas_automaticas__termina_el_periodo_seco_hoy:'Dry period ends today',
motor_alertas_automaticas__periodo_seco_por_terminar:'Dry period ending soon',
motor_alertas_automaticas__vigilar_celo_hoy:'Watch for heat today',
motor_alertas_automaticas__vigilar_posible_celo_proximo:'Watch for possible upcoming heat',
motor_alertas_automaticas__no_volvio_a_estar_en:'Didn\'t come back into heat?',
motor_alertas_automaticas__calostro_pendiente_de_registrar:'Colostrum pending registration',
motor_alertas_automaticas__inventario_de_alimento_bajo:'Low feed inventory',
motor_alertas_automaticas__campana_sanitaria_de_este_mes:'This month\'s health campaign',
motor_alertas_automaticas__tramite_vencido:'Overdue paperwork',
motor_alertas_automaticas__tramite_proximo:'Upcoming paperwork',
motor_alertas_automaticas__sin_revision_reciente:'No recent check-up',
motor_alertas_automaticas__urgente_muerte_subita:'URGENT · Sudden death',
motor_alertas_automaticas__urgente_sospecha_exotica:'URGENT · Suspected exotic disease',
motor_alertas_automaticas__proximos:'Upcoming',
motor_alertas_automaticas__proximos_tramites:'Upcoming paperwork',
motor_alertas_automaticas__no_hay_animales_enfermos_reportado:'No sick animals reported.',
motor_alertas_automaticas__recuperado:'Recovered',
motor_alertas_automaticas__no_tienes_notificaciones_por_ahora:'You have no notifications right now.',
exportar_csv__toro_pajuela:'Bull/straw',
exportar_csv__diagnostico:'Diagnosis',
exportar_csv__condicion_corporal:'Body condition',
exportar_csv__hectareas:'Hectares',
exportar_csv__capacidad_animal:'Animal capacity',
exportar_csv__imputar_a:'Allocate to',
exportar_csv__descripcion:'Description',
exportar_csv__ordeno:'Milked by',
exportar_csv__litros_am:'Morning liters',
exportar_csv__litros_pm:'Evening liters',
exportar_csv__total_litros:'Total liters',
exportar_csv__grasa:'% Fat',
exportar_csv__proteina:'% Protein',
exportar_csv__celulas_somaticas:'Somatic cell count',
exportar_csv__litros_acopiados:'Liters collected',
exportar_csv__precio_litro:'Price/liter',
exportar_csv__racion:'Ration',
exportar_csv__kg_concentrado_dia:'Kg concentrate/day',
exportar_csv__fecha_nacimiento:'Birth date',
exportar_csv__peso_al_nacer:'Birth weight',
exportar_csv__litros_calostro:'Colostrum liters',
exportar_csv__horas_calostro:'Colostrum hours',
exportar_csv__alimentacion:'Feeding',
exportar_csv__fecha_destete:'Weaning date',
exportar_csv__peso_destete:'Weaning weight',
exportar_csv__registros_exportados:'Records exported',
exportar_csv__no_hay_animales_para_exportar:'No animals to export',
exportar_csv__arete_campana:'Field ear tag',
exportar_csv__inventario_exportado:'Inventory exported',
registro_exportaciones_csv__inventario_de_hato:'Herd inventory',
registro_exportaciones_csv__proximos_vencimientos:'Upcoming due dates',
registro_exportaciones_csv__informe_cefpp:'CEFPP report',
sistema_idiomas_es__en:'EN: %VAR%',
sistema_idiomas_es__de:'DE: %VAR%',
manejo_engorda_corral__no_tienes_tareas_pendientes_por:'You have no pending tasks right now.',
manejo_engorda_corral__en_engorda_ahora:'Currently in feedlot',
manejo_engorda_corral__engordas_finalizadas:'Finished feedlot batches',
manejo_engorda_corral__aun_no_tienes_animales_marcados:'No animals marked for feedlot purpose yet.',
manejo_engorda_corral__dias_corriendo:'%VAR% days running%VAR%%VAR%',
manejo_engorda_corral__marcar_engorda_finalizada:'Mark feedlot as finished',
manejo_engorda_corral__finalizada_en_dias:'Finished in %VAR% days',
manejo_engorda_corral__en_curso:'In progress',
manejo_engorda_corral__finalizadas:'Finished',
csv_extra__animal:'Animal',
csv_extra__detalle:'Detail',
csv_extra__notas:'Notes',
csv_extra__potrero:'Paddock',
csv_extra__predio:'Property',
csv_extra2__comprador:'Buyer',
csv_extra2__lote:'Batch',
csv_extra2__producto:'Product',
csv_extra2__recolectado:'Collected by',
csv_extra2__alojamiento:'Housing',
csv_extra2__monto:'Amount',
csv_extra2__etapa:'Stage',
csv_extra2__vaca:'Cow',
csv_extra2__descuentos:'Deductions',
csv_extra2__bonos:'Bonuses',
csv_extra2__temperatura:'Temperature',
csv_extra2__becerro:'Calf',
csv_extra3__servicio:'Service',
csv_extra4__vencidos:'Overdue',
csv_extra4__hoy:'Today',
csv_extra4__enfermo:'Sick',
csv_extra5__sin_registros:'No records',
csv_extra6__pendiente:'Pending',
csv_extra6__rechazada:'Rejected',
csv_extra6__si_boton:'Yes',
csv_extra6__no_boton:'No',
csv_extra7__total:'Total',
csv_extra7__vencidas:'Expired',
csv_extra7__vence_hoy:'Expires today',
csv_extra7__activa:'Active',
csv_extra7__vencida:'Expired',
csv_extra8__vencido:'Overdue',
modal_conflicto__texto:'Ear tag %VAR% is already active on property "%VAR%" (UPP %VAR%), owned by %VAR%. If this animal was sold or transferred to your ranch, you can request the transfer of its record and history.',
campo_f__arete_siniiga:'SINIIGA ear tag',
campo_f__arete_campana_chip:'Field ear tag / chip',
campo_f__nombre_o_alias:'Name or nickname',
campo_f__raza:'Breed',
campo_f__sexo:'Sex',
campo_f__fecha_de_nacimiento:'Date of birth',
campo_f__estatus:'Status',
campo_f__madre_arete_nombre:'Mother (ear tag/name)',
campo_f__padre_pajuela:'Father / straw',
campo_f__animal_arete_o_nombre:'Animal (ear tag or name)',
campo_f__tipo:'Type',
campo_f__producto_diagnostico:'Product / diagnosis',
campo_f__fecha_de_aplicacion:'Application date',
campo_f__proxima_dosis:'Next dose',
campo_f__cuarto_afectado_mastitis:'Affected quarter (if mastitis)',
campo_f__resultado_cmt:'CMT result (if applicable)',
campo_f__notas:'Notes',
campo_f__vaca_arete_o_nombre:'Cow (ear tag or name)',
campo_f__tipo_de_servicio:'Service type',
campo_f__toro_pajuela_utilizada:'Bull / straw used',
campo_f__diagnostico_de_gestacion:'Pregnancy diagnosis',
campo_f__fecha_real_de_parto:'Actual calving date (if it happened)',
campo_f__fecha_de_pesaje:'Weighing date',
campo_f__peso_kg:'Weight (kg)',
campo_f__lote_potrero:'Batch / paddock',
campo_f__condicion_corporal_opcional:'Body condition (1 to 5, optional)',
campo_f__nombre_del_potrero:'Paddock name',
campo_f__hectareas:'Hectares',
campo_f__capacidad_animal:'Animal capacity',
campo_f__tipo_de_movimiento:'Transaction type',
campo_f__monto:'Amount ($)',
campo_f__categoria:'Category',
campo_f__fecha:'Date',
campo_f__imputar_a:'Allocate to (batch/animal)',
campo_f__descripcion:'Description',
campo_f__fecha_de_ordena:'Milking date',
campo_f__quien_ordeno:'Who milked',
campo_f__litros_ordena_am:'Morning milking liters',
campo_f__litros_ordena_pm:'Evening milking liters',
campo_f__grasa_opcional:'% Fat (optional)',
campo_f__celulas_somaticas_opcional:'Somatic cell count (optional)',
campo_f__proteina_opcional:'% Protein (optional)',
campo_f__litros_acopiados_tanque:'Liters collected in tank',
campo_f__temperatura_tanque:'Tank temperature (°C)',
campo_f__ya_paso_recolector:'Has the collector/tanker already come?',
campo_f__comprador_pasteurizadora:'Buyer / dairy plant',
campo_f__precio_pagado_litro:'Price paid per liter ($)',
campo_f__bonos_calidad:'Quality bonuses ($)',
campo_f__descuentos_calidad:'Quality deductions ($)',
campo_f__vaca_arete_o_nombre_lote:'Cow (ear tag or name, optional if by batch)',
campo_f__etapa_de_lactancia:'Lactation stage',
campo_f__tipo_de_racion:'Ration type',
campo_f__kg_concentrado_dia:'Kg of concentrate / day',
campo_f__becerro_arete_o_nombre:'Calf (ear tag or name)',
campo_f__peso_al_nacer_kg:'Birth weight (kg)',
campo_f__litros_calostro_dados:'Liters of colostrum given',
campo_f__horas_despues_del_parto:'Hours after calving',
campo_f__tipo_de_alojamiento:'Housing type',
campo_f__alimentacion_actual:'Current feeding',
campo_f__fecha_de_destete:'Weaning date (if it happened)',
campo_f__peso_al_destete_kg:'Weaning weight (kg)',
campo_f__nombre_del_insumo:'Supply name (e.g. Mineral salt, IBR vaccine)',
campo_f__unidad:'Unit',
campo_f__cantidad_comprada:'Quantity purchased',
campo_f__costo_total:'Total cost ($)',
campo_f__alerta_menos_de:'Alert when less than... remain',
campo_f__potrero:'Paddock',
campo_f__dias_retiro_leche:'Milk withdrawal days (if antibiotic was applied)',
campo_f__app_calculara_aviso_tanque:'The app will calculate and warn until what date this cow shouldn\'t enter the tank.',
campo_f__fecha_programada_secado:'Scheduled drying-off date',
campo_f__secado_se_calcula_solo:'Drying-off is calculated automatically (60 days before the expected calving). You can also adjust it manually.',
campo_f__fecha_cierre_lactancia:'Lactation closing date',
campo_f__fin_periodo_seco:'End of dry period',
campo_f__cuando_dejes_ordenarla:'When you stop milking her, put the date here — you\'ll be warned 5 days before the dry period ends.',
campo_f__inventario_de_alimento:'Feed inventory',
campo_f__producto_ej_concentrado:'Product (e.g. concentrate)',
campo_f__kg_disponibles:'Kg available',
campo_f__actualizar_existencia:'Update stock',
},
de: {
salir:'Abmelden', volver:'Zurück', guardar:'Speichern', cancelar:'Abbrechen', editar:'Bearbeiten',
buscar:'Suchen', exportar:'Exportieren', exportar_csv:'CSV', exportar_excel:'Excel', exportar_pdf:'PDF',
chat_flotante__enviar_por_chat:'Über Chat senden (ohne Download)',
chat_flotante__abre_una_conversacion_primero:'Öffne zuerst eine Unterhaltung',
chat_flotante__inicia_sesion_con_una_cuenta:'Melde dich mit einem Konto an, um Nachrichten zu senden',
chat_flotante__mas_filas:'weitere Zeilen',
chat_flotante__enviado_al_chat:'An den Chat gesendet',
elegir_formato:'Exportformat wählen', idioma:'Sprache', cambiar_idioma:'Sprache ändern',
nav_inicio:'Start', nav_hato:'Herde', nav_graficas:'Grafiken', nav_boletines:'Mitteilungen',
tile_datos:'Meine<br>Daten', tile_reporte:'Bericht &<br>Benachrichtigungen', tile_graficas:'Grafiken', tile_boletines:'Info-<br>Mitteilungen',
glosario_titulo:'Fachglossar Tierhaltung', glosario_sub:'Wichtige Begriffe der App in allen drei Sprachen.',
mod_A_nombre:'Tierregistrierung und -kennzeichnung', mod_A_corto:'Tier-<br>kennzeichnung',
mod_B_nombre:'Gesundheit, Hygiene und Management', mod_B_corto:'Gesundheit &<br>Hygiene',
mod_C_nombre:'Reproduktion und Aufzucht', mod_C_corto:'Reproduktion<br>& Aufzucht',
mod_D_nombre:'Wiegungen und Produktivität', mod_D_corto:'Wiegungen &<br>Produktivität',
mod_E_nombre:'Geografische Kartierung', mod_E_corto:'Geografische<br>Kartierung',
mod_F_nombre:'Verwaltung, Kosten und Berichte', mod_F_corto:'Kosten &<br>Berichte',
mod_G_nombre:'Milchproduktion', mod_G_corto:'Milch-<br>produktion',
mod_H_nombre:'Milchtank und Lieferung', mod_H_corto:'Tank &<br>Lieferung',
mod_I_nombre:'Milchviehfütterung', mod_I_corto:'Milchvieh-<br>fütterung',
mod_J_nombre:'Aufzuchtkälber', mod_J_corto:'Aufzucht-<br>kälber',
mod_K_nombre:'Lager & Betriebsmittel', mod_K_corto:'Lager &<br>Betriebsmittel',
gl_control_lechero:'Milchleistungsprüfung (MLP)', gl_arete_siniiga:'Ohrmarke / SINIIGA-Kennzeichnung', gl_registro_partos:'Abkalbeprotokoll',
gl_inseminacion:'Künstliche Besamung (KB)', gl_estatus_sanitario:'Gesundheitsstatus', gl_potrero:'Weide/Koppel', gl_hato:'Herde/Viehbestand',
gl_empadre:'Bedeckung/Deckung', gl_gestacion:'Trächtigkeit', gl_destete:'Absetzen', gl_calostro:'Kolostrum (Biestmilch)',
gl_vacunacion:'Impfung', gl_desparasitacion:'Entwurmung', gl_gdp:'Tägliche Gewichtszunahme (TGZ)', gl_lote:'Gruppe/Charge',
exp_generado:'Erstellt am', exp_marca:'Dokument erstellt mit MiRanch',
login_seleccion_rol__mi_ranchapp:'MiRanch',
login_seleccion_rol__gestion_de_tu_rancho_facil:'Verwalte deinen Betrieb — einfach und klar',
login_seleccion_rol__entra_directo_por_lo_pronto:'Direkt einsteigen — vorerst ohne Passwort',
login_seleccion_rol__ingresa_tus_datos:'Gib deinen Benutzernamen und dein Passwort ein',
login_seleccion_rol__usuario:'Benutzername',
login_seleccion_rol__contrasena:'Passwort',
login_seleccion_rol__iniciar_sesion:'Anmelden',
login_seleccion_rol__ingresa_usuario_y_contrasena:'Gib deinen Benutzernamen und dein Passwort ein',
login_seleccion_rol__usuario_o_contrasena_incorrectos:'Benutzername oder Passwort falsch',
login_seleccion_rol__inicia_sesion:'Anmelden',
login_seleccion_rol__ej_usuario:'Z. B.: MaxMustermann',
login_seleccion_rol__olvide_mi_contrasena:'Passwort vergessen?',
login_seleccion_rol__iniciar_sesion_mayus:'ANMELDEN',
login_seleccion_rol__no_tienes_cuenta:'Kein Konto?',
login_seleccion_rol__registrate_aqui:'Hier registrieren.',
login_seleccion_rol__te_enviaremos_un_codigo:'Wir senden dir einen Code per WhatsApp an die in deinem Konto hinterlegte Telefonnummer.',
login_seleccion_rol__enviar_codigo_por_whatsapp:'Code per WhatsApp senden',
login_seleccion_rol__ligar_nueva_cuenta:'Neues Konto verknüpfen',
login_seleccion_rol__solicita_tu_acceso:'Fordere deinen Zugang an. Der Administrator bestätigt dein Konto.',
login_seleccion_rol__punto_receptor_de_leche:'Milchannahmestelle',
login_seleccion_rol__mvz:'Tierarzt',
vet_pacientes__personas_atendidas:'Betreute Personen',
vet_notas__mis_notas:'Meine Notizen',
vet_notas__guardar_nota:'Notiz speichern',
vet_perfil__mi_perfil:'Mein Profil',
vet_perfil__cambiar_foto:'Foto ändern',
vet_perfil__especialidad_medica:'Fachgebiet',
vet_perfil__descripcion:'Beschreibung',
vet_perfil__zona_de_atencion:'Einsatzgebiet',
vet_perfil__guardar_perfil:'Profil speichern',
contactos__buscar_en_mis_contactos:'Kontakte durchsuchen',
contactos__buscar_amigos:'Freunde finden',
contactos__ya_usa_la_app:'Nutzt die App bereits',
contactos__abrir_chat:'Chat öffnen',
contactos__invitar_por_whatsapp:'Über WhatsApp einladen',
contactos__no_disponible_en_este_dispositivo:'Dieses Gerät erlaubt keinen Zugriff auf deine Kontakte. Du kannst eine Nummer manuell eingeben.',
contactos__sin_coincidencias:'Keiner deiner ausgewählten Kontakte nutzt die App bisher.',
contactos__buscando:'Suche...',
contactos__numero_manual:'Telefonnummer eingeben',
contactos__buscar_numero:'Nummer suchen',
login_seleccion_rol__cedula_profesional:'Berufszulassungsnummer *',
login_seleccion_rol__lugar_de_residencia:'Wohnort *',
login_seleccion_rol__continuar:'Weiter',
login_seleccion_rol__moonitor_faltan_datos:'Warte! In diesem Schritt fehlen noch Angaben oder sie müssen überprüft werden. Bitte kontrolliere sie und versuche es erneut.',
login_seleccion_rol__moonitor_datos_validados:'Deine Daten wurden überprüft! Wähle jetzt Benutzernamen und Passwort für den Zugang.',
login_seleccion_rol__moonitor_bienvenida:'Willkommen bei MiRanch, %VAR%! Dein Konto ist bereit. Dein Benutzername ist: %VAR2%',
login_seleccion_rol__moonitor_ya_existe:'Diese Angaben scheinen bereits registriert zu sein. Überprüfe Telefon, UPP oder Zulassungsnummer.',
login_seleccion_rol__verificando_tu_cuenta:'Konto wird überprüft...',
login_seleccion_rol__no_se_pudo_verificar_conexion:'Dein Konto konnte nicht überprüft werden. Prüfe deine Internetverbindung und versuche es erneut.',
login_seleccion_rol__gps_requiere_https:'Der Standort funktioniert nur auf der veröffentlichten Seite (https), nicht in dieser Vorschau.',
login_seleccion_rol__gps_permiso_denegado:'Standortzugriff wurde verweigert. Aktiviere ihn in den Browsereinstellungen.',
login_seleccion_rol__gps_no_disponible:'Standort konnte nicht ermittelt werden (GPS aus oder schwaches Signal).',
login_seleccion_rol__gps_tiempo_agotado:'Die Standortermittlung hat zu lange gedauert. Versuche es erneut.',
login_seleccion_rol__nombre_del_veterinario:'Name des Tierarztes',
login_seleccion_rol__nombre_del_local:'Name des Betriebs',
login_seleccion_rol__nombre_de_la_persona_encargada:'Name der verantwortlichen Person',
login_seleccion_rol__ubicacion_basica:'Ungefährer Standort',
login_seleccion_rol__enviar_ubicacion_actual:'Aktuellen Standort senden',
login_seleccion_rol__enviar_solicitud:'Anfrage senden',
login_seleccion_rol__procesando:'Wird verarbeitet…',
login_seleccion_rol__ya_existe_una_solicitud:'Es gibt bereits ein Konto oder eine Anfrage mit diesen Angaben',
login_seleccion_rol__enviar_solicitud_por_whatsapp:'Anfrage per WhatsApp senden',
login_seleccion_rol__bienvenido:'Willkommen',
login_seleccion_rol__completa_nombre_y_telefono:'Trage deinen Namen und eine gültige Telefonnummer ein',
login_seleccion_rol__codigo_enviado:'Code per WhatsApp gesendet',
login_seleccion_rol__completa_todos_los_campos:'Fülle alle Felder mit einer gültigen Telefonnummer aus',
login_seleccion_rol__solicitud_enviada:'Anfrage gesendet, warte auf die Bestätigung des Administrators',
login_seleccion_rol__crea_tu_acceso:'Erstelle deinen Zugang. Dein Konto ist sofort einsatzbereit.',
login_seleccion_rol__crea_tu_usuario:'Erstelle deinen Benutzernamen',
login_seleccion_rol__minimo_6_caracteres:'Mindestens 6 Zeichen',
login_seleccion_rol__crea_tu_contrasena:'Erstelle dein Passwort',
login_seleccion_rol__6_o_mas_letras_numeros:'6 oder mehr Zeichen, Buchstaben, Zahlen oder gemischt.',
login_seleccion_rol__usuario_y_contrasena_6_caracteres:'Benutzername und Passwort müssen mindestens 6 Zeichen haben',
login_seleccion_rol__ese_usuario_ya_existe:'Dieser Benutzername existiert bereits, wähle einen anderen',
login_seleccion_rol__cuenta_creada_inicia_sesion:'Konto erstellt, du kannst dich jetzt anmelden',
trabajadores__acceso_no_disponible:'Dieser Bereich ist für Mitarbeiter nicht verfügbar',
trabajadores__enviar_a:'Senden an...',
trabajadores__tarea_enviada_a:'Aufgabe gesendet an',
login_seleccion_rol__soy_productor:'Ich bin Produzent',
login_seleccion_rol__soy_administrador:'Ich bin Administrator',
login_seleccion_rol__soy_trabajador:'Ich bin Mitarbeiter',
login_seleccion_rol__recepcion_de_leche_queseria:'Milchannahme (Käserei)',
queseria_login__selecciona_tu_perfil:'Wähle dein Profil',
queseria_login__elige_como_quieres_entrar:'Wähle, wie du dich anmelden möchtest',
queseria__administrador:'Administrator',
queseria_menu__recibir_leche:'Milch annehmen',
queseria_menu__panel_de_reportes:'Berichtspanel',
queseria_menu__gestion_de_productores:'Erzeugerverwaltung',
queseria_menu__bienvenido:'Willkommen',
queseria_menu__cerrar_sesion:'Abmelden',
queseria_recepcion__recepcion_de_leche:'Milchannahme',
queseria_recepcion__lechero_recolector:'Sammelroute',
queseria_recepcion__productores_del_lechero:'Erzeuger dieser Route',
queseria_recepcion__recibidos_hoy:'Heute angenommen',
queseria_recepcion__litros_recibidos:'Angenommene Liter',
queseria_recepcion__confirmar_recepcion:'Annahme bestätigen',
queseria_recepcion__selecciona_un_lechero:'Wähle eine Route, um ihre Erzeuger zu sehen',
queseria_recepcion__aun_no_hay_productores_para_este_lechero:'Diese Route hat noch keine Erzeuger',
queseria_recepcion__aun_no_has_recibido_leche_hoy:'Heute wurde noch keine Milch angenommen',
queseria_recepcion__notificacion_enviada:'Benachrichtigung gesendet an',
queseria_productores__gestion_de_productores:'Erzeugerverwaltung',
queseria_productores__nombre_de_la_queseria:'Name der Käserei',
queseria_productores__alta_de_lechero:'Sammelroute anlegen',
queseria_productores__nombre_del_lechero:'Name der Route',
queseria_productores__alta_de_productor:'Erzeuger anlegen',
queseria_productores__nombre_del_productor:'Name des Erzeugers',
queseria_productores__codigo_identificador:'Kenncode',
queseria_productores__telefono_de_contacto:'Kontakttelefon',
queseria_productores__registrar_productor:'Erzeuger registrieren',
queseria_productores__productores_registrados:'Registrierte Erzeuger',
queseria_productores__aun_no_hay_productores_registrados:'Noch keine Erzeuger registriert',
queseria_productores__solicitud_de_vinculacion_enviada:'Verknüpfungsanfrage an den Erzeuger gesendet',
queseria_productores__completa_nombre_y_codigo:'Trage mindestens Name und Code des Erzeugers ein',
queseria_productores__nombre_guardado:'Name der Käserei gespeichert',
queseria_productores__escribe_un_nombre:'Gib den Namen der Route ein',
queseria_reportes__panel_de_reportes:'Berichtspanel',
queseria_reportes__hoy:'Heute',
queseria_reportes__esta_semana:'Diese Woche',
queseria_reportes__este_mes:'Diesen Monat',
queseria_reportes__detalle_por_productor:'Aufschlüsselung nach Erzeuger',
queseria_reportes__litros_totales:'Liter insgesamt',
queseria_reportes__productores_activos:'Aktive Erzeuger',
queseria_reportes__recepciones:'Annahmen',
queseria_reportes__todos_los_lecheros:'Alle Routen',
queseria_reportes__aun_no_hay_datos_para_este_periodo:'Noch keine Daten für diesen Zeitraum',
queseria__ingresa_los_litros:'Liter eingeben',
queseria__dictado_por_voz_no_disponible:'Spracheingabe ist in diesem Browser nicht verfügbar',
queseria__escuchando:'Hört zu…',
codigo_trabajador__codigo_de_4_digitos:'4-stelliger Code',
codigo_trabajador__codigo_de_trabajador:'Mitarbeiter-Code',
codigo_trabajador__pideselo_a_tu_administrador_o:'Frag deinen Administrator oder Produzenten danach',
codigo_trabajador__entrar:'Anmelden',
seleccion_tipo_ganado__que_tipo_de_ganado_manejas:'Welche Art von Vieh hältst du?',
seleccion_tipo_ganado__elige_tu_tipo_de_produccion:'Wähle deine Produktionsart, um deine Funktionen anzupassen',
seleccion_tipo_ganado__ganado_vacuno_de_carne:'Rindfleischvieh',
seleccion_tipo_ganado__ganado_vacuno_de_leche:'Milchvieh',
aviso_suscripcion_vencida__suscripcion_vencida:'Abonnement abgelaufen',
aviso_suscripcion_vencida__tu_acceso_a_mi_ranchapp:'Dein Zugang zu MiRanch ist abgelaufen am',
aviso_suscripcion_vencida__contacta_a_tu_administrador_para:'Kontaktiere deinen Administrator, um dein Abonnement zu verlängern und wieder Zugang zu deinen Daten zu erhalten.',
aviso_suscripcion_vencida__cerrar_sesion:'Abmelden',
inicio_productor__buscar_animal_potrero_o_boletin:'Tier, Weide oder Mitteilung suchen...',
inicio_productor__buen_dia:'Guten Morgen',
inicio_productor__buenas_tardes:'Guten Tag',
inicio_productor__buenas_noches:'Guten Abend',
inicio_productor__ver_mis_datos:'Meine Daten ansehen',
inicio_productor__actividades_recientes:'Letzte Aktivitäten',
inicio_productor__ver_todas:'Alle ansehen',
inicio_productor__aun_no_tienes_actividades:'Du hast noch keine Aktivitäten erfasst.',
inicio_productor__clima_cargando:'Wetter wird geladen...',
inicio_productor__clima_no_disponible:'Wetter momentan nicht verfügbar',
inicio_productor__reintentar:'Erneut versuchen',
inicio_productor__pronostico_por_horas:'Stündliche Vorhersage',
inicio_productor__humedad:'Luftfeuchtigkeit',
inicio_productor__viento:'Wind',
inicio_productor__probabilidad_de_lluvia:'Regenwahrscheinlichkeit',
inicio_productor__sensacion:'Gefühlt',
inicio_productor__ubicacion_aproximada:'Ungefährer Standort — aktiviere ihn im Browser für mehr Genauigkeit',
inicio_productor__resumen_rapido:'Kurzübersicht',
inicio_productor__mas_funciones:'Weitere Funktionen',
inicio_productor__acceso_rapido:'Schnellzugriff',
menu_mas_productor__mensajes_con_tu_veterinario:'Nachrichten mit deinem Tierarzt',
menu_mas_productor__calendario_de_eventos:'Terminkalender',
menu_mas_productor__bitacora_de_visitas_veterinarias:'Tierarztbesuche-Protokoll',
menu_mas_productor__manejo_de_engorda_y_corral:'Mast- und Pferchverwaltung',
menu_mas_productor__mis_tareas:'Meine Aufgaben',
menu_mas_productor__agregar_trabajador:'Mitarbeiter hinzufügen',
admin_configuracion__funciones_que_vera_el_trabajador:'Funktionen, die der Mitarbeiter sieht',
admin_configuracion__elige_que_modulos_puede_usar:'Wähle, welche Module ein Mitarbeiter nutzen kann, wenn er sich mit seinem Code anmeldet. Mitarbeiter sehen unabhängig davon nie Grafiken, Kosten oder Berichte.',
menu_mas_productor__transferencias_de_aretes:'Ohrmarken-Übertragungen',
transferencias_aretes__cuando_registras_un_arete_que:'Wenn du eine Ohrmarke registrierst, die auf einem anderen Betrieb bereits aktiv ist, kannst du die Übertragung beantragen. Der aktuelle Besitzer entscheidet, ob er sie genehmigt.',
transferencias_aretes__pendientes_de_tu_autorizacion:'Ausstehend — deine Genehmigung',
transferencias_aretes__tus_solicitudes_enviadas:'Deine gesendeten Anfragen',
visitas_veterinarias__nombre_del_veterinario:'Name des Tierarztes',
visitas_veterinarias__motivo_de_la_visita:'Grund des Besuchs',
visitas_veterinarias__que_se_reviso_observaciones:'Was überprüft wurde / Anmerkungen...',
visitas_veterinarias__registro_de_visitas_al_rancho:'Protokoll der Besuche auf dem Betrieb, getrennt vom Behandlungsverlauf je Tier — nützlich als Dokumentation.',
visitas_veterinarias__registrar_visita:'Besuch protokollieren',
calendario_visual__salud_dosis:'Gesundheit/Dosis',
calendario_visual__partos:'Abkalbungen',
calendario_visual__tramites:'Formalitäten',
mensajes_veterinario_productor__escribe_un_mensaje:'Nachricht schreiben...',
ventana_personalizada__escribe_una_nota:'Notiz schreiben...',
datos_productor__datos_del_productor:'Produzentendaten',
editar_datos_productor__editar_datos_del_productor:'Produzentendaten bearbeiten',
editar_datos_productor__nombre:'Name',
editar_datos_productor__nombre_del_predio:'Name des Betriebs',
editar_datos_productor__ultima_actualizacion_upp:'Letzte UPP-Aktualisierung',
editar_datos_productor__folio_fierro_de_herrar:'Aktenzeichen Brandeisen',
editar_datos_productor__vencimiento_credencial_fierro:'Ablaufdatum Brandausweis',
editar_datos_productor__estado:'Bundesland/Staat',
editar_datos_productor__municipio:'Gemeinde',
editar_datos_productor__ejido_parcela:'Ejido / Parzelle',
editar_datos_productor__actividad_pecuaria:'Viehwirtschaftliche Tätigkeit',
editar_datos_productor__el_numero_de_animales_activos:'Die Anzahl aktiver Tiere wird automatisch anhand deiner Einträge in Modul A gezählt.',
editar_datos_productor__guardar_cambios:'Änderungen speichern',
hato_inventario_animales__buscar_animal:'Tier suchen...',
hato_inventario_animales__estatus_del_hato:'Herdenstatus',
hato_inventario_animales__todos_los_estatus:'Alle Status',
hato_inventario_animales__activo:'Aktiv',
hato_inventario_animales__engorda:'Mast',
hato_inventario_animales__gestante:'Trächtig',
hato_inventario_animales__lactando:'Laktierend',
hato_inventario_animales__vaquilla:'Färse',
hato_inventario_animales__semental:'Zuchtbulle',
hato_inventario_animales__vendido:'Verkauft',
hato_inventario_animales__finado:'Verstorben',
hato_inventario_animales__ambos_sexos:'Beide Geschlechter',
hato_inventario_animales__hembra:'Weiblich',
hato_inventario_animales__macho:'Männlich',
graficas__vista_previa_el_diseno_final:'Vorschau — das endgültige Design der Grafiken legen wir später gemeinsam fest.',
graficas__composicion_del_hato_por_sexo:'Herdenzusammensetzung nach Geschlecht',
graficas__aun_no_hay_animales_registrados:'Noch keine Tiere registriert.',
graficas__tasa_de_prenez_por_temporada:'Trächtigkeitsrate nach Saison',
graficas__aun_no_hay_diagnosticos_de:'Noch keine Trächtigkeitsdiagnosen erfasst.',
graficas__evolucion_de_pesajes:'Gewichtsentwicklung',
graficas__aun_no_hay_pesajes_registrados:'Noch keine Wiegungen erfasst.',
graficas__costos_por_categoria:'Kosten nach Kategorie',
graficas__aun_no_hay_costos_registrados:'Noch keine Kosten erfasst.',
graficas__proximas_fechas_importantes:'Anstehende wichtige Termine',
graficas__ocupacion_vs_capacidad_de_potreros:'Belegung vs. Weidekapazität',
graficas__aun_no_hay_potreros_registrados:'Noch keine Weiden erfasst.',
graficas__gastos_vs_ingresos_por_mes:'Ausgaben vs. Einnahmen pro Monat',
graficas__aun_no_hay_movimientos_registrados:'Noch keine Bewegungen erfasst.',
graficas__edades_del_hato_por_sexo:'Herdenalter nach Geschlecht',
graficas__aun_no_hay_animales_con:'Noch keine Tiere mit erfasstem Geburtsdatum.',
graficas__bajas_por_causa:'Abgänge nach Ursache',
graficas__aun_no_hay_bajas_registradas:'Noch keine Abgänge erfasst.',
boletines_informativos__boletines_informativos:'Informationsmitteilungen',
modal_escaner_camara__escanear_arete:'Ohrmarke scannen',
modal_escaner_camara__apunta_la_camara_al_codigo:'Kamera auf den Strichcode der Ohrmarke richten...',
modal_boletin__cerrar:'Schließen',
notificaciones__reporte_y_notificaciones:'Bericht & Benachrichtigungen',
notificaciones__reportar_caso_urgente_muerte_subit:'Dringenden Fall melden (plötzlicher Tod / Verdacht auf exotische Krankheit)',
notificaciones__exportar_tabla_de_proximos_vencimi:'Tabelle der bevorstehenden Fälligkeiten exportieren',
notificaciones__reportes_de_chequeos_diarios:'Berichte der täglichen Kontrollen',
notificaciones__notificaciones:'Benachrichtigungen',
modal_historial_bitacora__concepto_ej_inseminacion_venta:'Posten (z. B. Besamung, Verkauf)',
modal_historial_bitacora__monto:'Betrag $',
modal_historial_bitacora__imprimir_descargar_ficha_resumen:'Zusammenfassung drucken / herunterladen',
modal_historial_bitacora__gastos_y_rendimiento:'Kosten & Leistung',
modal_historial_bitacora__gasto:'Ausgabe',
modal_historial_bitacora__ingreso:'Einnahme',
modal_historial_bitacora__registrar:'Erfassen',
modal_historial_bitacora__bitacora_del_animal:'Tierprotokoll',
inicio_administrador__modo_veterinario_solo_salud:'Tierarzt-Modus (nur Gesundheit)',
menu_mas_administrador__resumen_general:'Allgemeine Übersicht',
menu_mas_administrador__informacion_general_del_sistema:'Allgemeine Systeminformation',
menu_mas_administrador__cuentas_de_productores_y_vigencias:'Produzentenkonten & Gültigkeit',
menu_mas_administrador__reportes_a_cefpp_casos_urgentes:'CEFPP-Berichte (dringende Fälle)',
menu_mas_administrador__reportes_y_analisis_de_produccion:'Produktionsberichte und -analyse',
reportes_admin__cruza_datos_de_todas_las:'Vergleicht Daten aller Erzeugerkonten nach Region, Produktionsart und Gesundheitsstatus.',
reportes_admin__tipo_de_produccion:'Produktionsart',
reportes_admin__estado_de_salud:'Gesundheitsstatus',
reportes_admin__todos:'Alle',
reportes_admin__alerta_cefpp:'CEFPP-Alarm',
reportes_admin__actualizar_datos_de_todas_las:'Daten aller Konten aktualisieren',
reportes_admin__folios_de_fierro_de_herrar:'Brandzeichen-Aktenzeichen',
reportes_admin__desglose_por_productor:'Aufschlüsselung nach Erzeuger',
reportes_admin__cargando:'Lädt',
reportes_admin__datos_actualizados_de:'Daten aktualisiert von',
reportes_admin__nacimientos:'Geburten',
reportes_admin__compras:'Käufe',
reportes_admin__bajas:'Abgänge',
reportes_admin__siniiga_activos:'SINIIGA aktiv',
reportes_admin__siniiga_pendientes:'SINIIGA ausstehend',
reportes_admin__alertas_sanitarias:'Gesundheitswarnungen',
reportes_admin__sin_folios_registrados:'Keine Aktenzeichen registriert',
reportes_admin__pulsa_actualizar_datos_para_ver:'Tippe auf "Daten aktualisieren", um die Aufschlüsselung zu sehen',
metricas_admin__metricas_de_interaccion:'Interaktionsmetriken',
metricas_admin__uso_real_de_la_app_por:'Tatsächliche App-Nutzung durch die Erzeuger: wann sie sich anmelden, wie sie kamen und wie viel sie teilen.',
metricas_admin__horarios_de_mayor_actividad:'Stunden mit der meisten Aktivität',
metricas_admin__dias_de_mayor_actividad:'Tage mit der meisten Aktivität',
metricas_admin__origen_de_acceso:'Zugangsquelle (QR-Code vs. direkt)',
metricas_admin__mensajes_compartidos_por_whatsapp:'Über WhatsApp geteilte Nachrichten',
metricas_admin__datos_recolectados_desde_este:'Daten, die ab diesem Gerät/dieser Installation gesammelt wurden.',
metricas_admin__inicios_de_sesion:'Anmeldungen',
metricas_admin__accesos_por_qr:'QR-Zugriffe',
metricas_admin__mensajes_por_whatsapp:'WhatsApp-Nachrichten',
metricas_admin__madrugada:'Frühe Morgenstunden',
metricas_admin__manana:'Morgen',
metricas_admin__tarde:'Nachmittag',
metricas_admin__noche:'Abend',
metricas_admin__domingo:'Sonntag',
metricas_admin__lunes:'Montag',
metricas_admin__martes:'Dienstag',
metricas_admin__miercoles:'Mittwoch',
metricas_admin__jueves:'Donnerstag',
metricas_admin__viernes:'Freitag',
metricas_admin__sabado:'Samstag',
metricas_admin__via_codigo_qr:'Über QR-Code',
metricas_admin__acceso_directo:'Direkter Zugriff',
metricas_admin__compartir_la_app:'App teilen',
metricas_admin__cuenta_nueva_creada:'Neues Konto erstellt',
metricas_admin__recuperar_contrasena:'Passwort wiederherstellen',
metricas_admin__recordatorio_de_vigencia:'Erneuerungserinnerung',
metricas_admin__otro:'Andere',
metricas_admin__sin_datos_aun:'Noch keine Daten',
menu_mas_administrador__mensajes_con_el_productor:'Nachrichten mit dem Produzenten',
mensajes_admin__conversaciones:'Unterhaltungen',
mensajes_admin__mensaje_segmentado:'Segmentierte Nachricht',
mensajes_admin__filtros_de_destino:'Empfängerfilter',
mensajes_admin__todos_los_tipos:'Alle Typen',
mensajes_admin__productores_que_recibiran_este:'Erzeuger, die diese Nachricht erhalten',
mensajes_admin__contenido_del_mensaje:'Nachrichteninhalt',
mensajes_admin__usar_plantilla:'Vorlage verwenden...',
mensajes_admin__escribe_el_mensaje_para_los:'Schreibe die Nachricht für die ausgewählten Erzeuger...',
mensajes_admin__adjuntar_archivo:'Datei anhängen',
mensajes_admin__enlace_url_opcional:'URL-Link (optional)',
mensajes_admin__guardar_como_plantilla:'Als Vorlage speichern',
mensajes_admin__programar_envio:'Versand planen (optional)',
mensajes_admin__enviar_ahora:'Jetzt senden',
mensajes_admin__programar:'Planen',
mensajes_admin__envios_programados:'Geplante Sendungen',
mensajes_admin__archivo_demasiado_pesado:'Diese Datei ist zu groß, versuche eine kleinere',
mensajes_admin__escribe_un_mensaje_para_guardarlo:'Schreibe zuerst eine Nachricht',
mensajes_admin__plantilla_guardada:'Vorlage gespeichert',
mensajes_admin__nadie_cumple_estos_filtros:'Kein Erzeuger entspricht diesen Filtern',
mensajes_admin__elige_fecha_para_programar:'Wähle ein Datum für den geplanten Versand',
mensajes_admin__mensaje_programado:'Nachricht geplant',
mensajes_admin__mensaje_enviado_a:'Nachricht gesendet an',
mensajes_admin__no_hay_envios_programados:'Keine geplanten Sendungen',
mensajes_admin__enviado:'gesendet',
menu_mas_administrador__ver_como_productor:'Als Produzent anzeigen',
admin_usuarios_contrasenas__nombre_completo:'Vollständiger Name',
admin_usuarios_contrasenas__usuario:'Benutzername',
admin_usuarios_contrasenas__contrasena:'Passwort',
admin_usuarios_contrasenas__usuarios_y_contrasenas:'Benutzer & Passwörter',
admin_usuarios_contrasenas__agregar_nuevo_usuario:'Neuen Benutzer hinzufügen',
admin_usuarios_contrasenas__productor:'Produzent',
admin_usuarios_contrasenas__administrador:'Administrator',
admin_usuarios_contrasenas__veterinario_solo_salud:'Tierarzt (nur Gesundheit)',
admin_usuarios_contrasenas__crear_usuario:'Benutzer erstellen',
admin_cuentas_productores__nombre_del_rancho_predio:'Name des Betriebs',
admin_cuentas_productores__10_digitos:'10 Ziffern',
admin_cuentas_productores__numero_ip:'IP-Adresse',
admin_cuentas_productores__ej_192_168:'Z. B. 192.168.0.1',
admin_cuentas_productores__completa_telefono_e_ip:'Trage Name, Hof, UPP, Telefon und IP ein',
admin_cuentas_productores__cuenta_creada_compartir:'Konto erstellt. Teile den Zugang mit dem Erzeuger:',
admin_cuentas_productores__compartir_por_whatsapp:'Über WhatsApp teilen',
admin_cuentas_productores__mensaje_bienvenida_cuenta:'Willkommen bei MiRanch! Dein Konto ist bereit.\nBenutzer: %VAR%\nPasswort: %VAR%\nApp hier herunterladen: https://mi-ranchapp.netlify.app',
admin_cuentas_productores__cuentas_de_productores:'Produzentenkonten',
admin_cuentas_productores__alta_de_cuentas_control_de:'Kontoerstellung, Gültigkeitskontrolle und kaufmännische Nachverfolgung.',
admin_cuentas_productores__reloj_de_pruebas:'Testuhr',
admin_cuentas_productores__entorno_de_pruebas_reloj_simulado:'Testumgebung — simulierte Uhr',
admin_cuentas_productores__hoy_real:'Heute (real):',
admin_cuentas_productores__hoy_usado_por_la_app:'· Heute (von der App verwendet):',
admin_cuentas_productores__usar_esta_fecha:'Dieses Datum verwenden',
admin_cuentas_productores__volver_a_la_fecha_real:'Zum echten Gerätedatum zurückkehren',
admin_cuentas_productores__metricas_de_nuevas_cuentas:'Kennzahlen neuer Konten',
admin_cuentas_productores__nuevas_cuentas_generadas:'Neu erstellte Konten',
admin_cuentas_productores__proximos_a_vencer:'Bald ablaufend',
admin_cuentas_productores__suscripciones_que_vencen_en_los:'Abonnements, die in den nächsten 15 Tagen ablaufen.',
admin_cuentas_productores__alta_de_nueva_cuenta:'Neues Konto anlegen',
admin_cuentas_productores__registrar_nueva_cuenta:'Neues Konto registrieren',
admin_cuentas_productores__nombre_del_productor:'Name des Produzenten *',
admin_cuentas_productores__nombre_del_predio:'Name des Betriebs *',
admin_cuentas_productores__numero_de_upp:'UPP-Nummer *',
admin_cuentas_productores__tipo_de_modulo:'Modultyp *',
admin_cuentas_productores__lechera:'Milchvieh',
admin_cuentas_productores__carne:'Fleisch',
admin_cuentas_productores__telefono_whatsapp:'Telefon (WhatsApp)',
admin_cuentas_productores__dias_de_vigencia:'Gültigkeitstage',
admin_cuentas_productores__crear_cuenta:'Konto erstellen',
admin_cuentas_productores__listado_completo:'Vollständige Liste',
admin_cuentas_productores__todas_las_cuentas:'Alle Konten',
admin_info_general__esto_es_lo_que_vera:'Das sieht der Produzent in seiner Übersicht.',
admin_configuracion__nombre_del_trabajador:'Name des Mitarbeiters',
admin_configuracion__ej_revisar_bebederos_del_potrero:'Z. B. Tränken in Weide 3 prüfen',
admin_configuracion__nombre_de_la_campana:'Name der Kampagne',
admin_configuracion__notas_opcional:'Notizen (optional)',
admin_configuracion__nombre_de_la_ventana:'Fenstername...',
admin_configuracion__escribe_el_mensaje:'Nachricht schreiben...',
admin_configuracion__configuracion_de_ventanas:'Fenstereinstellungen',
admin_configuracion__ventanas_visibles_para_el_producto:'Für den Produzenten sichtbare Fenster',
admin_configuracion__apariencia_de_inicio:'Erscheinungsbild — Startbildschirm',
admin_configuracion__cambia_la_foto_de_fondo:'Ändere das Hintergrundfoto, das die Erzeuger auf ihrem Startbildschirm sehen. Es wird automatisch komprimiert, damit die Ladezeit nicht leidet.',
admin_configuracion__cambiar_foto_de_fondo:'Hintergrundfoto ändern',
admin_configuracion__cambia_la_foto_del_encabezado:'Ändere das Hintergrundfoto der Kopfzeile, das oben auf jedem Bildschirm erscheint (neben Logo, Appname und Sprachauswahl).',
admin_configuracion__cambia_el_logo_de_la_app:'Ändere das App-Logo. Es erscheint überall dort, wo es derzeit angezeigt wird (Login, Kopfzeile, Käserei).',
admin_configuracion__cambiar_logo:'Logo ändern',
moonitor_config__titulo:'Moo-nitor (Assistent)',
moonitor_config__descripcion:'Lade ein anderes Bild hoch, um das Aussehen von Moo-nitor je nach Jahreszeit (Weihnachten, Frühling usw.) oder für jede Viehart zu ändern. Ohne Upload wird das Standardbild verwendet.',
moonitor_config__general:'Allgemein',
moonitor_config__restaurar_imagenes:'Standardbilder wiederherstellen',
moonitor_config__recordatorio_semanal:'Wöchentliche Teilen-Erinnerung',
moonitor_config__sonido_de_vaca:'Kuhgeräusch beim Anzeigen von Nachrichten',
moonitor_config__probar_sonido:'Ton testen',
moonitor_config__recordatorio_descripcion:'Moo-nitor erinnert alle Erzeuger einmal pro Woche daran, die App mit 2 Kontakten zu teilen.',
moonitor__favor_de_compartir:'Bitte teile die App mit zwei deiner Kontakte',
moonitor__compartir_por_whatsapp:'Über WhatsApp teilen',
moonitor__mensaje_compartir_app:'Schau dir MiRanch an! Das ist die App, mit der ich meine Ranch verwalte. Hier herunterladen:',
moonitor__falta_telefono:'Du musst noch deine Telefonnummer registrieren',
moonitor__entendido:'Verstanden',
moonitor__ahora_no:'Jetzt nicht',
moonitor__tienes_avisos_pendientes:'Du hast ausstehende Hinweise',
moonitor__ver_notificaciones:'Benachrichtigungen ansehen',
moonitor__nuevo_boletin:'Neue Mitteilung',
moonitor__ver_boletines:'Mitteilungen ansehen',
queseria__operador:'Bediener',
queseria__hora:'Uhrzeit',
queseria_reportes__exportar_pdf:'Daten exportieren (PDF)',
admin_configuracion__cambiar_foto_de_encabezado:'Kopfzeilenfoto ändern',
admin_configuracion__orden_de_botones_en_mas:'Reihenfolge der Schaltflächen unter „Weitere Funktionen“',
admin_qr__titulo:'Zugangs-QR-Code',
admin_qr__descripcion:'Erstelle einen QR-Code, der direkt zum Startbildschirm der App führt. Ideal für Plakate, Werbeaktionen oder gedruckte Anzeigen.',
admin_qr__enlace:'Link',
admin_qr__descargar:'QR herunterladen (PNG)',
admin_qr__escribe_un_enlace_valido:'Gib einen gültigen Link ein (er muss mit http:// oder https:// beginnen)',
admin_configuracion__usa_las_flechas_para_cambiar:'Nutze die Pfeile, um die Reihenfolge zu ändern, in der der Produzent Herde und Module sieht.',
admin_configuracion__graficas_cuales_se_ven_y:'Grafiken: welche angezeigt werden und in welcher Reihenfolge',
admin_configuracion__apaga_la_que_no_quieras:'Schalte aus, was du nicht anzeigen möchtest, und nutze die Pfeile, um die Reihenfolge festzulegen.',
admin_configuracion__trabajadores_maximo_3:'Mitarbeiter (max. 2)',
admin_configuracion__cada_trabajador_entra_con_un:'Jeder Mitarbeiter meldet sich mit einem eigenen Code an und kann nur Daten erfassen sowie seine Aufgaben ansehen/abhaken — er sieht keine Kosten, Einstellungen oder Berichte.',
admin_configuracion__asignar_tareas:'Aufgaben zuweisen',
admin_configuracion__general:'Allgemein',
admin_configuracion__asignar_tarea:'Aufgabe zuweisen',
admin_configuracion__plan_sanitario_anual:'Jährlicher Gesundheitsplan',
admin_configuracion__programa_las_campanas_del_ano:'Plane die Kampagnen des Jahres (Impfung, Entwurmung, Kontrollen). Der Produzent wird benachrichtigt, wenn der jeweilige Monat beginnt.',
admin_configuracion__enero:'Januar',
admin_configuracion__febrero:'Februar',
admin_configuracion__marzo:'März',
admin_configuracion__abril:'April',
admin_configuracion__mayo:'Mai',
admin_configuracion__junio:'Juni',
admin_configuracion__julio:'Juli',
admin_configuracion__agosto:'August',
admin_configuracion__septiembre:'September',
admin_configuracion__octubre:'Oktober',
admin_configuracion__noviembre:'November',
admin_configuracion__diciembre:'Dezember',
admin_configuracion__agregar_al_plan:'Zum Plan hinzufügen',
admin_configuracion__descargar_reporte_sanitario_anual:'Jährlichen Gesundheitsbericht herunterladen',
admin_configuracion__agregar_ventana_nueva:'Neues Fenster hinzufügen',
admin_configuracion__crea_una_ventana_adicional_para:'Erstelle ein zusätzliches Fenster für den Produzenten (mit eigenem Notizbereich).',
admin_configuracion__banner_de_mensajes:'Nachrichtenbanner',
admin_configuracion__se_muestra_al_abrir_la:'Wird beim Öffnen der Produzenten-App angezeigt. Du kannst mehrere planen und einzeln aktivieren/deaktivieren.',
admin_configuracion__texto_del_mensaje:'Nachrichtentext',
admin_configuracion__imagen_opcional:'Bild (optional)',
admin_configuracion__tamano_del_texto:'Textgröße',
admin_configuracion__chico:'Klein',
admin_configuracion__mediano:'Mittel',
admin_configuracion__grande:'Groß',
admin_configuracion__color_de_fondo:'Hintergrundfarbe',
admin_configuracion__color_de_texto:'Textfarbe',
admin_configuracion__desde_opcional:'Von (optional)',
admin_configuracion__hasta_opcional:'Bis (optional)',
admin_configuracion__programar_banner:'Banner planen',
admin_configuracion__predios_ranchos:'Betriebe / Höfe',
admin_configuracion__si_el_productor_maneja_mas:'Wenn der Produzent mehr als einen Betrieb führt, füge sie hier hinzu. Er kann auf dem Startbildschirm wählen, welchen er gerade ansieht.',
admin_configuracion__agregar_predio:'Betrieb hinzufügen',
admin_configuracion__notificaciones_del_navegador:'Browser-Benachrichtigungen',
admin_configuracion__manda_un_aviso_emergente_aunque:'Sendet eine Push-Benachrichtigung, auch wenn die App im Hintergrund geschlossen ist (Berechtigung von Browser/Handy erforderlich).',
admin_configuracion__activar_notificaciones_push:'Push-Benachrichtigungen aktivieren',
admin_configuracion__campos_del_resumen_del_productor:'Felder der Produzentenübersicht',
admin_publicar_boletines__titulo_del_boletin:'Titel der Mitteilung',
admin_publicar_boletines__contenido_del_boletin:'Inhalt der Mitteilung...',
admin_publicar_boletines__imagen_cartel_opcional:'Bild / Plakat (optional)',
admin_publicar_boletines__si_subes_imagen_aparecera_circulan:'Wenn du ein Bild hochlädst, erscheint es im Karussell oberhalb der Mitteilung für den Produzenten.',
admin_publicar_boletines__publicar_boletin:'Mitteilung veröffentlichen',
admin_informacion_sistema__vista_de_solo_lectura_util:'Nur-Lese-Ansicht, nützlich um die App-Nutzung vor der Firebase-Anbindung zu prüfen.',
admin_informacion_sistema__auditoria_de_transferencias_de_are:'Prüfprotokoll der Ohrmarken-Übertragungen',
admin_informacion_sistema__registro_de_traspasos_autorizados:'Protokoll der genehmigten Übertragungen zwischen UPPs — bereit für Firebase (Sammlung, Datum, Uhrzeit und beteiligte UPPs).',
admin_reportes_cefpp__reportes_a_cefpp:'CEFPP-Berichte',
admin_reportes_cefpp__descargar_informe_completo_para_ce:'Vollständigen Bericht für CEFPP herunterladen',
modal_conflicto_arete__arete_ya_registrado:'Ohrmarke bereits registriert',
modal_conflicto_arete__solicitar_transferencia_de_registr:'Registrierungsübertragung beantragen',
exportacion_pie_pagina__pag:'Seite',
exportacion_pie_pagina__pdf_exportado:'PDF exportiert',
exportacion_pie_pagina__excel_exportado:'Excel exportiert',
exportacion_pie_pagina__csv_exportado:'CSV exportiert',
exportacion_pie_pagina__no_hay_registros_para_exportar:'Keine Datensätze zum Exportieren',
transferencia_autonoma_aretes__sin_upp:'(ohne UPP)',
transferencia_autonoma_aretes__el_animal_ya_no_esta:'Das Tier befindet sich nicht mehr in der Ursprungsherde (wurde es bereits übertragen?)',
transferencia_autonoma_aretes__solicitud_rechazada:'Anfrage abgelehnt',
transferencia_autonoma_aretes__aprobada_transferido:'Genehmigt — übertragen',
transferencia_autonoma_aretes__no_tienes_solicitudes_de_transfere:'Du hast keine ausstehenden Übertragungsanfragen.',
transferencia_autonoma_aretes__arete:'Ohrmarke %VAR%',
transferencia_autonoma_aretes__el_productor_del_predio_upp:'Der Produzent des Betriebs „%VAR%“ (UPP %VAR%) fordert diese Ohrmarke an, die in deiner Herde aktiv ist. Wenn dieses Tier verkauft oder übertragen wurde, genehmigst du die Übertragung seiner Akte und Historie (Alter, Rasse, Geschlecht, Wiegungen usw.) auf sein Konto?',
transferencia_autonoma_aretes__si:'Ja',
transferencia_autonoma_aretes__no:'Nein',
transferencia_autonoma_aretes__no_has_enviado_solicitudes_de:'Du hast keine Übertragungsanfragen gesendet.',
transferencia_autonoma_aretes__solicitado_a_upp:'Angefragt bei %VAR% (UPP %VAR%) · %VAR% %VAR%',
modo_offline_first__no_se_pudo_cargar_el:'Der lokal gespeicherte Zustand konnte nicht geladen werden',
modo_offline_first__no_se_pudo_guardar_el:'Der Zustand konnte nicht lokal gespeichert werden',
navegacion_general__rueda_administrador:'Zahnrad (Administrator)',
navegacion_general__luis_administrador:'Luis (Administrator)',
navegacion_general__pedro_productor_de_carne:'Pedro (Fleischproduzent)',
navegacion_general__marcos_productor_de_leche:'Marcos (Milchproduzent)',
navegacion_general__predio_de_pedro_editar:'Pedros Betrieb (bearbeiten)',
navegacion_general__upp_pedro:'UPP-PEDRO',
navegacion_general__predio_de_marcos_editar:'Marcos\' Betrieb (bearbeiten)',
navegacion_general__upp_marcos:'UPP-MARCOS',
navegacion_general__codigo_incorrecto:'Falscher Code',
render_home_productor__animales_activos:'Aktive Tiere',
render_estatus_hato__sin_datos:'Keine Daten',
render_estatus_hato__atencion_urgente:'Dringende Aufmerksamkeit',
render_estatus_hato__en_tratamiento:'In Behandlung',
render_estatus_hato__dosis_vencida:'Fällige Dosis überfällig',
render_estatus_hato__activo_sano:'Aktiv / gesund',
render_estatus_hato__proxima_revision:'Nächste Kontrolle',
render_estatus_hato__ultimo_parto:'Letzte Abkalbung',
render_estatus_hato__parto_estimado:'Voraussichtliche Abkalbung',
render_estatus_hato__aun_no_has_registrado_animales:'Du hast noch keine Tiere registriert.',
render_estatus_hato__registrar_el_primer_animal:'Erstes Tier registrieren',
render_estatus_hato__no_hay_animales_que_coincidan:'Keine Tiere entsprechen der Suche.',
historial_bitacora_animal__nacimiento_alta_del_animal:'Geburt / Tierregistrierung',
historial_bitacora_animal__aun_no_hay_eventos_registrados:'Noch keine Ereignisse für dieses Tier erfasst.',
gastos_rendimiento_animal__escribe_el_concepto_y_un:'Gib den Posten und einen gültigen Betrag ein',
gastos_rendimiento_animal__movimiento_registrado:'Bewegung erfasst',
gastos_rendimiento_animal__peso_kg:'Gewicht (kg)',
gastos_rendimiento_animal__gastos:'Ausgaben',
gastos_rendimiento_animal__texto:'$%VAR%',
gastos_rendimiento_animal__ingresos:'Einnahmen',
gastos_rendimiento_animal__neto:'Netto',
gastos_rendimiento_animal__sin_movimientos_registrados:'Keine Bewegungen erfasst.',
gastos_rendimiento_animal__texto_2:'%VAR%$%VAR%',
gastos_rendimiento_animal__gdp_promedio_kg_dia:'Durchschnittliche TGZ: %VAR% kg/Tag',
gastos_rendimiento_animal__ultimo_tramo_kg_dia_ganancia:'· letzter Abschnitt: %VAR% kg/Tag · Gesamtzunahme: %VAR% kg in %VAR% Tagen',
gastos_rendimiento_animal__ficha:'Akte %VAR%',
gastos_rendimiento_animal__ficha_del_animal:'Tierakte — %VAR%',
gastos_rendimiento_animal__predio_upp_municipio:'Betrieb: %VAR% · UPP: %VAR% · Gemeinde: %VAR%',
gastos_rendimiento_animal__datos_de_identificacion:'Identifikationsdaten',
gastos_rendimiento_animal__arete_siniiga:'SINIIGA-Ohrmarke',
gastos_rendimiento_animal__arete_chip_campana:'Feld-Ohrmarke/Chip',
gastos_rendimiento_animal__raza:'Rasse',
gastos_rendimiento_animal__sexo:'Geschlecht',
gastos_rendimiento_animal__fecha_de_nacimiento:'Geburtsdatum',
gastos_rendimiento_animal__estatus:'Status',
gastos_rendimiento_animal__madre:'Mutter',
gastos_rendimiento_animal__padre:'Vater',
gastos_rendimiento_animal__historial_de_salud:'Gesundheitsverlauf',
gastos_rendimiento_animal__fecha:'Datum',
gastos_rendimiento_animal__tipo:'Art',
gastos_rendimiento_animal__producto_diagnostico:'Produkt/Diagnose',
gastos_rendimiento_animal__proxima:'Nächste',
gastos_rendimiento_animal__historial_de_pesajes:'Wiegeverlauf',
gastos_rendimiento_animal__ficha_generada_el:'Akte erstellt am %VAR%',
render_modulos_f__ver_estatus_del_hato:'Herdenstatus ansehen',
render_modulos_f__ver_registros:'Datensätze ansehen',
render_modulos_f__escanea_o_escribe:'Scannen oder eingeben...',
render_modulos_f__camara_del_celular_o_lector:'Handykamera oder physischer Scanner: Es werden nur die letzten 10 Ziffern gespeichert („MX“ und die 2 Länderziffern werden verworfen).',
render_modulos_f__ej_120:'Z. B. 120',
render_modulos_f__ej_venta_enfermedad_robo:'Z. B. Verkauf, Krankheit, Diebstahl...',
render_modulos_f__proposito_del_animal:'Zweck des Tieres',
render_modulos_f__reemplazo:'Ersatz',
render_modulos_f__engorda_venta:'Mast / Verkauf',
render_modulos_f__dias_objetivo_de_engorda:'Ziel-Masttage',
render_modulos_f__peso_meta_kg_opcional:'Zielgewicht (kg, optional)',
render_modulos_f__los_dias_correran_de_forma:'Die Tage laufen ab heute durchgehend, bis du dieses Tier in der Mastverwaltung als „Mast beendet“ markierst.',
render_modulos_f__sin_asignar:'Nicht zugewiesen',
render_modulos_f__motivo_de_baja_solo_si:'Abgangsgrund (falls zutreffend)',
render_modulos_f__foto_del_animal:'Tierfoto',
render_modulos_f__puedes_tomar_la_foto_directo:'Du kannst das Foto direkt mit der Handykamera aufnehmen.',
render_modulos_f__cantidad_usada:'Verwendete Menge',
render_modulos_f__aplicar_a_todo_un_lote:'Auf eine ganze Gruppe / Weide anwenden (Impfung, Entwurmung usw.)',
render_modulos_f__potrero_lote:'Weide / Gruppe',
render_modulos_f__selecciona_un_potrero:'Weide auswählen...',
render_modulos_f__se_creara_un_registro_para:'Für jedes aktive Tier dieser Weide wird ein Datensatz erstellt.',
render_modulos_f__insumo_de_bodega_usado_opcional:'Verwendetes Lagergut (optional)',
render_modulos_f__sin_descontar_de_bodega:'Nicht vom Lager abziehen',
render_modulos_f__si_seleccionas_un_insumo_se:'Wenn du ein Lagergut auswählst, wird es automatisch von Lager & Betriebsmittel abgezogen.',
render_modulos_f__fecha_de_servicio_monta:'Deck-/Besamungsdatum',
render_modulos_f__fecha_probable_de_parto:'Voraussichtliches Abkalbedatum',
render_modulos_f__la_fecha_de_parto_se:'Das Abkalbedatum wird automatisch berechnet (283 Tage nach der Besamung). Du kannst es manuell ändern, wenn dein Tierarzt ein anderes Datum angibt — die App verwendet das von dir eingegebene.',
render_modulos_f__color_de_etiqueta:'Etikettenfarbe',
render_modulos_f__archivo_kmz_kml:'KMZ-/KML-Datei',
render_modulos_f__trazar_potrero_en_el_mapa:'Weide auf der Karte einzeichnen',
render_modulos_f__usa_el_icono_de_poligono:'Nutze das Polygon-Symbol, um die Grenzen der Weide auf der Karte einzuzeichnen.',
render_modulos_f__ubicacion_central:'Mittelpunkt',
render_modulos_f__ponle_nombre_al_potrero:'Gib der Weide einen Namen',
render_modulos_f__traza_el_poligono_en_el_mapa:'Zeichne das Polygon der Weide auf der Karte ein',
render_modulos_f__este_potrero_no_tiene_mapa:'Diese Weide hat kein gespeichertes Polygon',
render_modulos_f__volver_a_la_lista:'Zurück zur Liste',
render_modulos_f__descargar_mapa:'Karte herunterladen',
render_modulos_f__no_se_pudo_generar_la_imagen:'Das Kartenbild konnte nicht erstellt werden',
render_modulos_f__ver_mapa:'Karte ansehen',
render_modulos_f__buscar_poblacion_camino_lugar:'Ort, Weg oder Stelle suchen',
render_modulos_f__usar_mi_ubicacion_actual:'Meinen aktuellen Standort verwenden',
render_modulos_f__usar_google_maps_mas_detalle:'Findest du den Ort nicht? Google Maps verwenden (mehr Details)',
render_modulos_f__no_se_encontro_el_lugar:'Dieser Ort wurde nicht gefunden, versuche einen anderen Namen',
render_modulos_f__buscando:'Suche läuft…',
render_modulos_f__ubicando:'Standort wird ermittelt…',
render_modulos_f__no_se_pudo_obtener_ubicacion:'Dein Standort konnte nicht ermittelt werden. Überprüfe die GPS-Berechtigungen.',
render_modulos_f__geolocalizacion_no_disponible:'Dein Gerät erlaubt keine Standortermittlung.',
render_modulos_f__falta_api_key_google:'Der Google-Maps-Schlüssel (GOOGLE_MAPS_API_KEY) ist im Code noch nicht eingerichtet.',
render_modulos_f__cargando_google_maps:'Google Maps wird geladen…',
render_modulos_f__guardar_registro:'Datensatz speichern',
render_modulos_f__siniiga:'SINIIGA %VAR% · %VAR% · %VAR%%VAR%',
render_modulos_f__kg:'%VAR% — %VAR% kg',
render_modulos_f__ha_capacidad_animales:'%VAR% ha · Kapazität %VAR% Tiere',
render_modulos_f__texto:'%VAR%$%VAR% — %VAR%',
render_modulos_f__l:'%VAR% — %VAR% L',
render_modulos_f__am_l_pm_l:'Morgens %VAR% L · Abends %VAR% L · %VAR%%VAR%',
render_modulos_f__l_acopiados:'%VAR% L gesammelt%VAR%',
render_modulos_f__kg_dia:'%VAR% · %VAR% kg/Tag · %VAR%',
render_modulos_f__kg_al_nacer:'%VAR% — %VAR% kg bei Geburt',
render_modulos_f__calostro_l:'%VAR% · Kolostrum: %VAR% L%VAR%%VAR% · %VAR%%VAR%',
render_modulos_f__costo_total_actualizado:'%VAR% · Gesamtkosten $%VAR% · aktualisiert %VAR%',
render_modulos_f__aun_no_hay_registros_en:'Noch keine Datensätze in diesem Modul.',
guardar_registros__escribe_al_menos_el_arete:'Gib mindestens die Ohrmarke oder den Namen des Tieres ein, um zu speichern',
guardar_registros__ya_tienes_un_animal_registrado:'Du hast bereits ein Tier mit dieser Ohrmarke in deiner Herde registriert',
guardar_registros__animal_registrado:'Tier registriert',
escaneo_camara_barcodedetector__tu_navegador_no_soporta_escaneo:'Dein Browser unterstützt kein Kamera-Scannen. Nutze den physischen Scanner oder gib den Code manuell ein.',
escaneo_camara_barcodedetector__no_se_pudo_acceder_a:'Auf die Kamera konnte nicht zugegriffen werden. Prüfe die Berechtigungen oder nutze den physischen Scanner / gib den Code manuell ein.',
escaneo_camara_barcodedetector__codigo_escaneado:'Code gescannt',
escaneo_codigo_barras__listo_escanea_el_arete_ahora:'Fertig, jetzt die Ohrmarke scannen...',
escaneo_codigo_barras__selecciona_un_potrero_para_aplicar:'Wähle eine Weide für die Gruppenanwendung',
escaneo_codigo_barras__no_hay_animales_activos_en:'Keine aktiven Tiere in dieser Weide',
escaneo_codigo_barras__caso_urgente_registrado_se_agrego:'Dringender Fall erfasst — zu CEFPP-Berichten hinzugefügt',
escaneo_codigo_barras__registro_de_salud_guardado:'Gesundheitsdatensatz gespeichert',
escaneo_codigo_barras__registro_reproductivo_guardado_se:'Reproduktionsdatensatz gespeichert — Folgetermine neu geplant',
escaneo_codigo_barras__se_seguira_vigilando_5_dias:'Es wird noch 5 weitere Tage beobachtet',
escaneo_codigo_barras__pesaje_guardado:'Wiegung gespeichert',
escaneo_codigo_barras__potrero_guardado:'Weide gespeichert',
escaneo_codigo_barras__movimiento_guardado:'Bewegung gespeichert',
escaneo_codigo_barras__ordena_registrada:'Melkung erfasst',
escaneo_codigo_barras__registro_de_tanque_guardado:'Tankdatensatz gespeichert',
escaneo_codigo_barras__registro_de_alimentacion_guardado:'Fütterungsdatensatz gespeichert',
inventario_alimento__escribe_el_producto_y_los:'Gib das Produkt und die verfügbaren kg ein',
inventario_alimento__inventario_actualizado:'Bestand aktualisiert',
inventario_alimento__guardado_atencion_el_calostro_se:'Gespeichert — Achtung: das Kolostrum wurde nach den empfohlenen 6 Stunden gegeben',
inventario_alimento__becerro_registrado:'Kalb registriert',
inventario_alimento__aun_no_registras_existencias:'Noch kein Bestand erfasst.',
inventario_alimento__kg_actualizado:'%VAR% kg · aktualisiert %VAR%',
bodega_e_insumos__escribe_el_nombre_del_insumo:'Gib den Namen des Lagerguts und eine gültige Menge ein',
bodega_e_insumos__existencias_de_bodega_actualizadas:'Lagerbestand aktualisiert',
bodega_e_insumos__existencias_por_agotarse:'Bestand geht zur Neige',
bodega_e_insumos__leer_mas:'Mehr lesen',
bodega_e_insumos__aun_no_hay_boletines_publicados:'Noch keine Mitteilungen veröffentlicht.',
graficas__mortalidad_del_hato:'Herdensterblichkeit',
graficas__gestaciones_confirmadas:'Bestätigte Trächtigkeiten',
graficas__peso_promedio_registrado:'Durchschnittliches erfasstes Gewicht',
graficas__animales_asignados:'Zugewiesene Tiere',
graficas__0_1_ano:'0–1 Jahr',
graficas__1_2_anos:'1–2 Jahre',
graficas__2_4_anos:'2–4 Jahre',
graficas__4_8_anos:'4–8 Jahre',
graficas__8_anos:'8+ Jahre',
graficas__no_hay_fechas_proximas_registradas:'Keine bevorstehenden Termine erfasst.',
bitacora_visitas_veterinarias__escribe_al_menos_la_fecha:'Gib mindestens Datum und Tierarzt ein',
bitacora_visitas_veterinarias__visita_registrada:'Besuch erfasst',
bitacora_visitas_veterinarias__visita_eliminada:'Besuch gelöscht',
bitacora_visitas_veterinarias__visita_restaurada:'Besuch wiederhergestellt',
bitacora_visitas_veterinarias__tasa_de_prenez:'Trächtigkeitsrate (%)',
bitacora_visitas_veterinarias__aun_no_hay_visitas_registradas:'Noch keine Besuche erfasst.',
bitacora_visitas_veterinarias__sin_datos_suficientes:'Nicht genügend Daten',
bitacora_visitas_veterinarias__costo_por_litro:'Kosten pro Liter',
bitacora_visitas_veterinarias__eficiencia_alimenticia:'Futtereffizienz',
bitacora_visitas_veterinarias__comparativo_contra_referencia_hols:'Vergleich mit Holstein-Referenz',
bitacora_visitas_veterinarias__grasa_promedio:'Ø Fettgehalt %',
bitacora_visitas_veterinarias__proteina_promedio:'Ø Eiweißgehalt %',
bitacora_visitas_veterinarias__servicios_por_concepcion:'Besamungen pro Konzeption',
bitacora_visitas_veterinarias__intervalo_entre_partos_iep:'Zwischenkalbezeit (ZKZ)',
bitacora_visitas_veterinarias__dias_abiertos_promedio:'Ø offene Tage',
bitacora_visitas_veterinarias__referencia_raza_holstein_se_necesi:'Referenz Rasse Holstein. Für zuverlässige Vergleiche werden mehrere Datensätze (tatsächliche Abkalbungen, Besamungen, Milchqualität) benötigt.',
bitacora_visitas_veterinarias__ranking_de_mejores_productoras_lit:'Rangliste der besten Milchkühe (kumulierte Liter)',
bitacora_visitas_veterinarias__dias_en_leche_del_y:'Laktationstage und offene Tage',
bitacora_visitas_veterinarias__crecimiento_y_desarrollo:'Wachstum & Entwicklung',
bitacora_visitas_veterinarias__estado_de_resultados_por_mes:'Monatliche Erfolgsrechnung',
bitacora_visitas_veterinarias__punto_de_equilibrio:'Gewinnschwelle',
bitacora_visitas_veterinarias__proyeccion_proximo_mes:'Prognose für nächsten Monat',
bitacora_visitas_veterinarias__rentabilidad_por_animal_lote_imput:'Rentabilität je Tier / zugeordneter Gruppe',
modo_veterinario__modo_veterinario_activado_solo_ver:'Tierarzt-Modus aktiviert: du siehst nur Gesundheit',
modo_veterinario__modo_veterinario_desactivado:'Tierarzt-Modus deaktiviert',
modo_veterinario__cuentas_de:'Konten von',
modo_veterinario__productores:'Produzenten',
modo_veterinario__usuarios_y:'Benutzer &',
modo_veterinario__contrasenas:'Passwörter',
modo_veterinario__datos_del:'Daten des',
modo_veterinario__productor:'Produzenten',
modo_veterinario__informativos:'informativ',
modo_veterinario__configuracion:'Einstellungen',
modo_veterinario__de_ventanas:'der Fenster',
predios_multiples__escribe_el_nombre_del_predio:'Namen des Betriebs eingeben',
predios_multiples__predio_agregado:'Betrieb hinzugefügt',
predios_multiples__predio_eliminado:'Betrieb gelöscht',
predios_multiples__predio_restaurado:'Betrieb wiederhergestellt',
predios_multiples__aun_no_agregas_predios_adicionales:'Noch keine zusätzlichen Betriebe hinzugefügt.',
notificaciones_push_reales__este_navegador_no_soporta_notifica:'Dieser Browser unterstützt keine Benachrichtigungen',
notificaciones_push_reales__notificaciones_activadas:'Benachrichtigungen aktiviert ✓',
notificaciones_push_reales__permiso_no_concedido:'Berechtigung nicht erteilt',
notificaciones_push_reales__notificaciones_push_activadas:'Push-Benachrichtigungen aktiviert',
notificaciones_push_reales__no_se_concedio_permiso_de:'Benachrichtigungsberechtigung nicht erteilt',
notificaciones_push_reales__mi_ranchapp:'MiRanch —',
reportes_cefpp__muerte_subita:'Plötzlicher Tod',
reportes_cefpp__sospecha_de_enfermedad_exotica:'Verdacht auf exotische Krankheit',
reportes_cefpp__caso_marcado_como_enviado_a:'Fall als an CEFPP gesendet markiert',
reportes_cefpp__caso_marcado_como_pendiente:'Fall als ausstehend markiert',
reportes_cefpp__no_hay_casos_para_exportar:'Keine Fälle zum Exportieren',
reportes_cefpp__tipo_de_caso:'Fallart',
reportes_cefpp__estatus_de_envio_a_cefpp:'CEFPP-Meldestatus',
reportes_cefpp__informe_descargado:'Bericht heruntergeladen',
reportes_cefpp__no_hay_casos_urgentes_reportados:'Derzeit keine dringenden Fälle gemeldet.',
mensajes_veterinario_productor__usuario_creado:'Benutzer erstellt',
mensajes_veterinario_productor__usuario_eliminado:'Benutzer gelöscht',
mensajes_veterinario_productor__usuario_restaurado:'Benutzer wiederhergestellt',
mensajes_veterinario_productor__contrasena_actualizada:'Passwort aktualisiert',
mensajes_veterinario_productor__aun_no_hay_mensajes:'Noch keine Nachrichten.',
mensajes_veterinario_productor__productor_configurado:'Produzent eingerichtet',
mensajes_veterinario_productor__animales_registrados:'Registrierte Tiere',
mensajes_veterinario_productor__usuarios_del_sistema:'Systembenutzer',
mensajes_veterinario_productor__boletines_publicados:'Veröffentlichte Mitteilungen',
mensajes_veterinario_productor__nueva_contrasena:'Neues Passwort',
mensajes_veterinario_productor__usuario_rol:'Benutzer: %VAR% · Rolle: %VAR%',
cuentas_productores_alta__elige_una_fecha_primero:'Wähle zuerst ein Datum',
cuentas_productores_alta__reloj_de_pruebas_fijado_en:'Testuhr eingestellt auf',
cuentas_productores_alta__usando_la_fecha_real_del:'Verwendet das echte Gerätedatum',
cuentas_productores_alta__nombre_predio_y_upp_son:'Name, Betrieb und UPP sind erforderlich',
cuentas_productores_alta__ya_existe_una_cuenta_registrada:'Es gibt bereits ein Konto mit dieser UPP',
cuentas_productores_alta__productor:'(Produzent)',
cuentas_productores_alta__cuenta_eliminada:'Konto gelöscht',
cuentas_productores_alta__cuenta_restaurada:'Konto wiederhergestellt',
cuentas_productores_alta__vigencia_actualizada:'Gültigkeit aktualisiert',
cuentas_productores_alta__cuenta_renovada_por:'Konto verlängert um',
cuentas_productores_alta__dias_desde_hoy:'Tage ab heute',
cuentas_productores_alta__cuenta_marcada_como_vencida_para:'Konto als abgelaufen markiert (zu Testzwecken)',
cuentas_productores_alta__esta_semana:'Diese Woche',
cuentas_productores_alta__este_mes:'Diesen Monat',
cuentas_productores_alta__este_ano:'Dieses Jahr',
cuentas_productores_alta__cuenta_s:'Konto(en)',
cuentas_productores_alta__por_vencer:'Läuft bald ab',
cuentas_productores_alta__simulada:'(simuliert)',
cuentas_productores_alta__real:'(real)',
cuentas_productores_alta__registros_de_salud:'Gesundheitsdatensätze',
cuentas_productores_alta__registros_reproductivos:'Reproduktionsdatensätze',
cuentas_productores_alta__pesajes_registrados:'Erfasste Wiegungen',
cuentas_productores_alta__potreros_registrados:'Erfasste Weiden',
cuentas_productores_alta__costos_registrados:'Erfasste Kosten',
cuentas_productores_alta__no_hay_cuentas_por_vencer:'Keine Konten laufen in den nächsten 15 Tagen ab.',
cuentas_productores_alta__upp:'%VAR% · UPP %VAR%',
cuentas_productores_alta__aun_no_hay_cuentas_de:'Noch keine Produzentenkonten erfasst.',
cuentas_productores_alta__upp_2:'%VAR% · UPP %VAR% · %VAR%',
cuentas_productores_alta__usuario_contrasena:'Benutzer: %VAR% · Passwort: %VAR%',
cuentas_productores_alta__alta_vence:'Erstellt: %VAR% · Läuft ab: %VAR% (%VAR%)',
cuentas_productores_alta__probar_acceso:'Zugang testen',
cuentas_productores_alta__renovar:'Verlängern',
cuentas_productores_alta__30_dias:'+30 Tage',
cuentas_productores_alta__30_dias_2:'-30 Tage',
cuentas_productores_alta__vencer_ahora:'Jetzt ablaufen lassen',
cuentas_productores_alta__aun_no_se_han_autorizado:'Noch keine Ohrmarken-Übertragungen genehmigt.',
cuentas_productores_alta__upp_upp:'%VAR% (UPP %VAR%) → %VAR% (UPP %VAR%)',
edicion_datos_productor__datos_del_productor_actualizados:'Produzentendaten aktualisiert',
edicion_datos_productor__a_registro_e_identificacion_animal:'A. Tierregistrierung und -kennzeichnung',
edicion_datos_productor__b_salud_sanidad_y_manejo:'B. Gesundheit, Hygiene und Management',
edicion_datos_productor__c_reproduccion_y_maternidad:'C. Reproduktion und Aufzucht',
edicion_datos_productor__d_pesajes_y_productividad:'D. Wiegungen und Produktivität',
edicion_datos_productor__e_mapeo_geografico:'E. Geografische Kartierung',
edicion_datos_productor__f_administracion_costos_y_reportes:'F. Verwaltung, Kosten und Berichte',
edicion_datos_productor__g_produccion_de_leche_solo:'G. Milchproduktion (nur Milchvieh)',
edicion_datos_productor__h_tanque_y_entrega_de:'H. Milchtank und Lieferung (nur Milchvieh)',
edicion_datos_productor__i_alimentacion_lechera_solo_ganado:'I. Milchviehfütterung (nur Milchvieh)',
edicion_datos_productor__j_becerros_de_reemplazo_solo:'J. Aufzuchtkälber (nur Milchvieh)',
edicion_datos_productor__folio_de_fierro_de_herrar:'Aktenzeichen Brandeisen',
edicion_datos_productor__numero_de_animales_activos:'Anzahl aktiver Tiere',
edicion_datos_productor__g_produccion_de_leche:'G. Milchproduktion',
edicion_datos_productor__h_tanque_y_entrega_de_2:'H. Milchtank und Lieferung',
edicion_datos_productor__i_alimentacion_lechera:'I. Milchviehfütterung',
edicion_datos_productor__j_becerros_de_reemplazo:'J. Aufzuchtkälber',
edicion_datos_productor__indicadores_lecheros_comparativo_h:'Milchleistungskennzahlen (Holstein-Vergleich)',
edicion_datos_productor__estatus_financiero:'Finanzstatus',
edicion_datos_productor__tasa_de_prenez:'Trächtigkeitsrate',
edicion_datos_productor__ocupacion_de_potreros:'Weidenbelegung',
edicion_datos_productor__edades_del_hato:'Herdenalter',
plan_sanitario_anual__escribe_el_nombre_de_la:'Namen der Kampagne eingeben',
plan_sanitario_anual__campana_agregada_al_plan:'Kampagne zum Plan hinzugefügt',
plan_sanitario_anual__campana_eliminada:'Kampagne gelöscht',
plan_sanitario_anual__campana_restaurada:'Kampagne wiederhergestellt',
plan_sanitario_anual__reporte_sanitario_anual_descargado:'Jährlicher Gesundheitsbericht heruntergeladen',
plan_sanitario_anual__aun_no_programas_campanas:'Noch keine Kampagnen geplant.',
trabajadores__ya_tienes_el_maximo_de:'Du hast bereits die maximale Anzahl von 3 Mitarbeitern pro Konto',
trabajadores__escribe_el_nombre_del_trabajador:'Namen des Mitarbeiters eingeben',
trabajadores__trabajador_agregado:'Mitarbeiter hinzugefügt',
trabajadores__trabajador_eliminado:'Mitarbeiter gelöscht',
trabajadores__trabajador_restaurado:'Mitarbeiter wiederhergestellt',
trabajadores__aun_no_agregas_trabajadores:'Noch keine Mitarbeiter hinzugefügt.',
trabajadores__codigo_de_acceso:'Zugangscode:',
tareas__escribe_la_tarea:'Aufgabe eingeben',
tareas__tarea_asignada:'Aufgabe zugewiesen',
tareas__aun_no_asignas_tareas:'Noch keine Aufgaben zugewiesen.',
tareas__para:'Für: %VAR% · %VAR% %VAR%',
ventanas_personalizadas__escribe_un_nombre_para_la:'Namen für das Fenster eingeben',
ventanas_personalizadas__ventana_agregada:'Fenster hinzugefügt',
ventanas_personalizadas__ventana_eliminada:'Fenster gelöscht',
ventanas_personalizadas__ventana_restaurada:'Fenster wiederhergestellt',
ventanas_personalizadas__aun_no_agregas_ventanas_propias:'Noch keine eigenen Fenster hinzugefügt.',
ventanas_personalizadas__sin_notas_todavia:'Noch keine Notizen.',
banner_mensajes__escribe_un_texto_para_el:'Text für das Banner eingeben',
banner_mensajes__banner_programado:'Banner geplant',
banner_mensajes__banner_eliminado:'Banner gelöscht',
banner_mensajes__banner_restaurado:'Banner wiederhergestellt',
banner_mensajes__boletin_publicado:'Mitteilung veröffentlicht',
banner_mensajes__boletin_eliminado:'Mitteilung gelöscht',
banner_mensajes__boletin_restaurado:'Mitteilung wiederhergestellt',
banner_mensajes__aun_no_programas_banners:'Noch keine Banner geplant.',
banner_mensajes__tienes_notificaciones_pendientes_t:'Du hast ausstehende Benachrichtigungen — tippe, um sie anzusehen',
confirmacion_visual_al__deshacer:'Rückgängig',
buscador_global__sin_resultados:'Keine Ergebnisse',
calendario_visual__vencimiento_credencial_de_fierro:'Ablaufdatum Brandausweis',
calendario_visual__no_hay_vencimientos_proximos_para:'Keine bevorstehenden Fälligkeiten zum Exportieren',
calendario_visual__proximo:'Bevorstehend',
calendario_visual__tramite:'Formalität',
calendario_visual__categoria:'Kategorie',
calendario_visual__titulo:'Titel',
calendario_visual__dias_restantes:'Verbleibende Tage',
calendario_visual__tabla_exportada:'Tabelle exportiert',
calendario_visual__sin_eventos_este_dia:'Keine Ereignisse an diesem Tag.',
motor_alertas_automaticas__obligatoria:'PFLICHT —',
motor_alertas_automaticas__tratamiento_de_hoy:'Heutige Behandlung',
motor_alertas_automaticas__proxima_dosis_programada:'Nächste geplante Dosis',
motor_alertas_automaticas__leche_apta_desde_hoy:'Milch ab heute verwendbar',
motor_alertas_automaticas__leche_no_apta_para_el:'Milch NICHT für den Tank geeignet',
motor_alertas_automaticas__parto_atrasado:'Überfällige Abkalbung',
motor_alertas_automaticas__parto_esperado_hoy:'Abkalbung heute erwartet',
motor_alertas_automaticas__parto_proximo:'Bevorstehende Abkalbung',
motor_alertas_automaticas__secado_atrasado:'Überfälliges Trockenstellen',
motor_alertas_automaticas__secar_hoy:'Heute trockenstellen',
motor_alertas_automaticas__secado_proximo:'Bevorstehendes Trockenstellen',
motor_alertas_automaticas__periodo_seco_vencido_atenta_al:'Trockenperiode überfällig — auf Abkalbung achten',
motor_alertas_automaticas__termina_el_periodo_seco_hoy:'Trockenperiode endet heute',
motor_alertas_automaticas__periodo_seco_por_terminar:'Trockenperiode endet bald',
motor_alertas_automaticas__vigilar_celo_hoy:'Brunst heute beobachten',
motor_alertas_automaticas__vigilar_posible_celo_proximo:'Mögliche bevorstehende Brunst beobachten',
motor_alertas_automaticas__no_volvio_a_estar_en:'Nicht wieder brünstig geworden?',
motor_alertas_automaticas__calostro_pendiente_de_registrar:'Kolostrum noch zu erfassen',
motor_alertas_automaticas__inventario_de_alimento_bajo:'Niedriger Futterbestand',
motor_alertas_automaticas__campana_sanitaria_de_este_mes:'Gesundheitskampagne dieses Monats',
motor_alertas_automaticas__tramite_vencido:'Überfällige Formalität',
motor_alertas_automaticas__tramite_proximo:'Bevorstehende Formalität',
motor_alertas_automaticas__sin_revision_reciente:'Keine aktuelle Kontrolle',
motor_alertas_automaticas__urgente_muerte_subita:'DRINGEND · Plötzlicher Tod',
motor_alertas_automaticas__urgente_sospecha_exotica:'DRINGEND · Verdacht auf exotische Krankheit',
motor_alertas_automaticas__proximos:'Bevorstehend',
motor_alertas_automaticas__proximos_tramites:'Bevorstehende Formalitäten',
motor_alertas_automaticas__no_hay_animales_enfermos_reportado:'Keine kranken Tiere gemeldet.',
motor_alertas_automaticas__recuperado:'Erholt',
motor_alertas_automaticas__no_tienes_notificaciones_por_ahora:'Du hast derzeit keine Benachrichtigungen.',
exportar_csv__toro_pajuela:'Bulle/Samenstab',
exportar_csv__diagnostico:'Diagnose',
exportar_csv__condicion_corporal:'Körperkondition',
exportar_csv__hectareas:'Hektar',
exportar_csv__capacidad_animal:'Tierkapazität',
exportar_csv__imputar_a:'Zuordnen zu',
exportar_csv__descripcion:'Beschreibung',
exportar_csv__ordeno:'Gemolken von',
exportar_csv__litros_am:'Liter morgens',
exportar_csv__litros_pm:'Liter abends',
exportar_csv__total_litros:'Liter insgesamt',
exportar_csv__grasa:'% Fett',
exportar_csv__proteina:'% Eiweiß',
exportar_csv__celulas_somaticas:'Zellzahl',
exportar_csv__litros_acopiados:'Gesammelte Liter',
exportar_csv__precio_litro:'Preis/Liter',
exportar_csv__racion:'Ration',
exportar_csv__kg_concentrado_dia:'Kg Kraftfutter/Tag',
exportar_csv__fecha_nacimiento:'Geburtsdatum',
exportar_csv__peso_al_nacer:'Geburtsgewicht',
exportar_csv__litros_calostro:'Liter Kolostrum',
exportar_csv__horas_calostro:'Stunden bis Kolostrum',
exportar_csv__alimentacion:'Fütterung',
exportar_csv__fecha_destete:'Absetzdatum',
exportar_csv__peso_destete:'Absetzgewicht',
exportar_csv__registros_exportados:'Datensätze exportiert',
exportar_csv__no_hay_animales_para_exportar:'Keine Tiere zum Exportieren',
exportar_csv__arete_campana:'Feld-Ohrmarke',
exportar_csv__inventario_exportado:'Bestand exportiert',
registro_exportaciones_csv__inventario_de_hato:'Herdenbestand',
registro_exportaciones_csv__proximos_vencimientos:'Bevorstehende Fälligkeiten',
registro_exportaciones_csv__informe_cefpp:'CEFPP-Bericht',
sistema_idiomas_es__en:'EN: %VAR%',
sistema_idiomas_es__de:'DE: %VAR%',
manejo_engorda_corral__no_tienes_tareas_pendientes_por:'Du hast derzeit keine ausstehenden Aufgaben.',
manejo_engorda_corral__en_engorda_ahora:'Aktuell in der Mast',
manejo_engorda_corral__engordas_finalizadas:'Abgeschlossene Mastdurchgänge',
manejo_engorda_corral__aun_no_tienes_animales_marcados:'Noch keine Tiere für die Mast markiert.',
manejo_engorda_corral__dias_corriendo:'%VAR% Tage laufend%VAR%%VAR%',
manejo_engorda_corral__marcar_engorda_finalizada:'Mast als beendet markieren',
manejo_engorda_corral__finalizada_en_dias:'Beendet in %VAR% Tagen',
manejo_engorda_corral__en_curso:'Läuft',
manejo_engorda_corral__finalizadas:'Beendet',
csv_extra__animal:'Tier',
csv_extra__detalle:'Detail',
csv_extra__notas:'Notizen',
csv_extra__potrero:'Weide',
csv_extra__predio:'Betrieb',
csv_extra2__comprador:'Käufer',
csv_extra2__lote:'Gruppe',
csv_extra2__producto:'Produkt',
csv_extra2__recolectado:'Abgeholt von',
csv_extra2__alojamiento:'Unterbringung',
csv_extra2__monto:'Betrag',
csv_extra2__etapa:'Phase',
csv_extra2__vaca:'Kuh',
csv_extra2__descuentos:'Abzüge',
csv_extra2__bonos:'Boni',
csv_extra2__temperatura:'Temperatur',
csv_extra2__becerro:'Kalb',
csv_extra3__servicio:'Besamung',
csv_extra4__vencidos:'Überfällig',
csv_extra4__hoy:'Heute',
csv_extra4__enfermo:'Krank',
csv_extra5__sin_registros:'Keine Datensätze',
csv_extra6__pendiente:'Ausstehend',
csv_extra6__rechazada:'Abgelehnt',
csv_extra6__si_boton:'Ja',
csv_extra6__no_boton:'Nein',
csv_extra7__total:'Gesamt',
csv_extra7__vencidas:'Abgelaufen',
csv_extra7__vence_hoy:'Läuft heute ab',
csv_extra7__activa:'Aktiv',
csv_extra7__vencida:'Abgelaufen',
csv_extra8__vencido:'Überfällig',
modal_conflicto__texto:'Die Ohrmarke %VAR% ist bereits auf dem Betrieb "%VAR%" (UPP %VAR%) von %VAR% aktiv. Wenn dieses Tier verkauft oder auf deinen Betrieb übertragen wurde, kannst du die Übertragung der Akte und Historie beantragen.',
campo_f__arete_siniiga:'SINIIGA-Ohrmarke',
campo_f__arete_campana_chip:'Feld-Ohrmarke / Chip',
campo_f__nombre_o_alias:'Name oder Spitzname',
campo_f__raza:'Rasse',
campo_f__sexo:'Geschlecht',
campo_f__fecha_de_nacimiento:'Geburtsdatum',
campo_f__estatus:'Status',
campo_f__madre_arete_nombre:'Mutter (Ohrmarke/Name)',
campo_f__padre_pajuela:'Vater / Samenstab',
campo_f__animal_arete_o_nombre:'Tier (Ohrmarke oder Name)',
campo_f__tipo:'Art',
campo_f__producto_diagnostico:'Produkt / Diagnose',
campo_f__fecha_de_aplicacion:'Anwendungsdatum',
campo_f__proxima_dosis:'Nächste Dosis',
campo_f__cuarto_afectado_mastitis:'Betroffenes Euterviertel (bei Mastitis)',
campo_f__resultado_cmt:'CMT-Ergebnis (falls zutreffend)',
campo_f__notas:'Notizen',
campo_f__vaca_arete_o_nombre:'Kuh (Ohrmarke oder Name)',
campo_f__tipo_de_servicio:'Art der Besamung',
campo_f__toro_pajuela_utilizada:'Verwendeter Bulle / Samenstab',
campo_f__diagnostico_de_gestacion:'Trächtigkeitsdiagnose',
campo_f__fecha_real_de_parto:'Tatsächliches Abkalbedatum (falls bereits erfolgt)',
campo_f__fecha_de_pesaje:'Wiegedatum',
campo_f__peso_kg:'Gewicht (kg)',
campo_f__lote_potrero:'Gruppe / Weide',
campo_f__condicion_corporal_opcional:'Körperkondition (1 bis 5, optional)',
campo_f__nombre_del_potrero:'Name der Weide',
campo_f__hectareas:'Hektar',
campo_f__capacidad_animal:'Tierkapazität',
campo_f__tipo_de_movimiento:'Art der Bewegung',
campo_f__monto:'Betrag ($)',
campo_f__categoria:'Kategorie',
campo_f__fecha:'Datum',
campo_f__imputar_a:'Zuordnen zu (Gruppe/Tier)',
campo_f__descripcion:'Beschreibung',
campo_f__fecha_de_ordena:'Melkdatum',
campo_f__quien_ordeno:'Wer gemolken hat',
campo_f__litros_ordena_am:'Liter Morgenmelkung',
campo_f__litros_ordena_pm:'Liter Abendmelkung',
campo_f__grasa_opcional:'% Fett (optional)',
campo_f__celulas_somaticas_opcional:'Zellzahl (optional)',
campo_f__proteina_opcional:'% Eiweiß (optional)',
campo_f__litros_acopiados_tanque:'Im Tank gesammelte Liter',
campo_f__temperatura_tanque:'Tanktemperatur (°C)',
campo_f__ya_paso_recolector:'War der Abholer/Tankwagen schon da?',
campo_f__comprador_pasteurizadora:'Käufer / Molkerei',
campo_f__precio_pagado_litro:'Bezahlter Preis pro Liter ($)',
campo_f__bonos_calidad:'Qualitätsboni ($)',
campo_f__descuentos_calidad:'Qualitätsabzüge ($)',
campo_f__vaca_arete_o_nombre_lote:'Kuh (Ohrmarke oder Name, optional bei Gruppenerfassung)',
campo_f__etapa_de_lactancia:'Laktationsphase',
campo_f__tipo_de_racion:'Rationsart',
campo_f__kg_concentrado_dia:'Kg Kraftfutter / Tag',
campo_f__becerro_arete_o_nombre:'Kalb (Ohrmarke oder Name)',
campo_f__peso_al_nacer_kg:'Geburtsgewicht (kg)',
campo_f__litros_calostro_dados:'Gegebene Liter Kolostrum',
campo_f__horas_despues_del_parto:'Stunden nach der Abkalbung',
campo_f__tipo_de_alojamiento:'Unterbringungsart',
campo_f__alimentacion_actual:'Aktuelle Fütterung',
campo_f__fecha_de_destete:'Absetzdatum (falls bereits erfolgt)',
campo_f__peso_al_destete_kg:'Absetzgewicht (kg)',
campo_f__nombre_del_insumo:'Name des Betriebsmittels (z. B. Mineralsalz, IBR-Impfstoff)',
campo_f__unidad:'Einheit',
campo_f__cantidad_comprada:'Gekaufte Menge',
campo_f__costo_total:'Gesamtkosten ($)',
campo_f__alerta_menos_de:'Warnung bei weniger als...',
campo_f__potrero:'Weide',
campo_f__dias_retiro_leche:'Wartezeit für Milch in Tagen (falls Antibiotikum verabreicht)',
campo_f__app_calculara_aviso_tanque:'Die App berechnet und warnt, bis zu welchem Datum diese Kuh nicht in den Tank darf.',
campo_f__fecha_programada_secado:'Geplantes Trockenstelldatum',
campo_f__secado_se_calcula_solo:'Das Trockenstellen wird automatisch berechnet (60 Tage vor der voraussichtlichen Abkalbung). Du kannst es auch manuell anpassen.',
campo_f__fecha_cierre_lactancia:'Datum des Laktationsabschlusses',
campo_f__fin_periodo_seco:'Ende der Trockenperiode',
campo_f__cuando_dejes_ordenarla:'Wenn du sie nicht mehr melkst, trage hier das Datum ein — du wirst 5 Tage vor Ende der Trockenperiode gewarnt.',
campo_f__inventario_de_alimento:'Futterbestand',
campo_f__producto_ej_concentrado:'Produkt (z. B. Kraftfutter)',
campo_f__kg_disponibles:'Verfügbare kg',
campo_f__actualizar_existencia:'Bestand aktualisieren',
},
pd: {
salir:'Aufmelde', volver:'Tridj', guardar:'Biwoare', cancelar:'Afbreake', editar:'Oawbeede',
buscar:'Soke', exportar:'Ekspoteere', exportar_csv:'CSV', exportar_excel:'Excel', exportar_pdf:'PDF',
chat_flotante__enviar_por_chat:'Bie Chat schekje (ohne rauhoole)',
chat_flotante__abre_una_conversacion_primero:'Moak iescht en Jesproak op',
chat_flotante__inicia_sesion_con_una_cuenta:'Aunmelde met en Konto om Norechte to schekje',
chat_flotante__mas_filas:'mea Reihe',
chat_flotante__enviado_al_chat:'Aun dän Chat jeschekjt',
elegir_formato:'Utwähl daut Ekspoat-Format', idioma:'Sproak', cambiar_idioma:'Sproak endre',
nav_inicio:'Aunfank', nav_hato:'Hoof', nav_graficas:'Grafike', nav_boletines:'Berichte',
tile_datos:'Miene<br>Doote', tile_reporte:'Berich un<br>Norechte', tile_graficas:'Grafike', tile_boletines:'Info-<br>Berichte',
glosario_titulo:'Vee-Fachwöada', glosario_sub:'Wichtje Wöada dee enn dee App jebruukt woare, enn aule vea Sproake.',
mod_A_nombre:'Vee-Registrieruns un -Tejchninj', mod_A_corto:'Vee-<br>Tejchninj',
mod_B_nombre:'Jesundheit un Behandlung', mod_B_corto:'Jesundheit',
mod_C_nombre:'Fochtboarkjeit un Kalwe', mod_C_corto:'Fochtboarkjeit<br>un Kalwe',
mod_D_nombre:'Wiegunge un Produktiwiteet', mod_D_corto:'Wiegunge un<br>Produktiwiteet',
mod_E_nombre:'Kart fonn dee Farm', mod_E_corto:'Kart fonn<br>dee Farm',
mod_F_nombre:'Verwoaltung, Kaste un Berichte', mod_F_corto:'Kaste un<br>Berichte',
mod_G_nombre:'Melk-Produktion', mod_G_corto:'Melk-<br>Produktion',
mod_H_nombre:'Melktank un Lewarunk', mod_H_corto:'Tank un<br>Lewarunk',
mod_I_nombre:'Melkvee-Fooda', mod_I_corto:'Melkvee-<br>Fooda',
mod_J_nombre:'Easatz-Kjalwa', mod_J_corto:'Easatz-<br>Kjalwa',
mod_K_nombre:'Lager un Betriebsmittel', mod_K_corto:'Lager un<br>Betriebsmittel',
gl_control_lechero:'Melk-Kontrol', gl_arete_siniiga:'Ohrenmark / SINIIGA', gl_registro_partos:'Kalw-Opschriew',
gl_inseminacion:'Besoamunk', gl_estatus_sanitario:'Jesundheit-Stoand', gl_potrero:'Weid', gl_hato:'Hoof',
gl_empadre:'Dekj', gl_gestacion:'Droajenshjeit', gl_destete:'Aufsette', gl_calostro:'Kolostrum',
gl_vacunacion:'Impfung', gl_desparasitacion:'Entwurmung', gl_gdp:'GDP (Deajlijche Wicht-Toonoahm)', gl_lote:'Lot',
exp_generado:'Jemoakt', exp_marca:'Dokument jemoakt met MiRanch',
login_seleccion_rol__mi_ranchapp:'MiRanch',
login_seleccion_rol__gestion_de_tu_rancho_facil:'Diene Farm verwoalte — eefach un kloa',
login_seleccion_rol__entra_directo_por_lo_pronto:'Gonn glieks nenn — no ohne Passwuat',
login_seleccion_rol__ingresa_tus_datos:'Jeff dien Brucka un Paßwuat en',
login_seleccion_rol__usuario:'Brucka',
login_seleccion_rol__contrasena:'Paßwuat',
login_seleccion_rol__iniciar_sesion:'Aunmelde',
login_seleccion_rol__ingresa_usuario_y_contrasena:'Jeff dien Brucka un Paßwuat en',
login_seleccion_rol__usuario_o_contrasena_incorrectos:'Brucka ooda Paßwuat es verkjeat',
login_seleccion_rol__inicia_sesion:'Aunmelde',
login_seleccion_rol__ej_usuario:'Toom Bispel: JohaunPerez',
login_seleccion_rol__olvide_mi_contrasena:'Paßwuat vejäte?',
login_seleccion_rol__iniciar_sesion_mayus:'AUNMELDE',
login_seleccion_rol__no_tienes_cuenta:'Haust du kjeen Konto?',
login_seleccion_rol__registrate_aqui:'Enschriew die hia.',
login_seleccion_rol__te_enviaremos_un_codigo:'Wie woare die en Kod bie WhatsApp schekje aun dee Telefoon-Nommer, dee enn dien Konto steit.',
login_seleccion_rol__enviar_codigo_por_whatsapp:'Kod bie WhatsApp schekje',
login_seleccion_rol__ligar_nueva_cuenta:'Nieet Konto vebinje',
login_seleccion_rol__solicita_tu_acceso:'Froag dien Toogang aun. Dee Administrator woat dien Konto bestätje.',
login_seleccion_rol__punto_receptor_de_leche:'Melk-Aunnehm-Städ',
login_seleccion_rol__mvz:'Tierarzt',
vet_pacientes__personas_atendidas:'Betreute Personen',
vet_notas__mis_notas:'Miene Notize',
vet_notas__guardar_nota:'Notiz spiechre',
vet_perfil__mi_perfil:'Mien Profil',
vet_perfil__cambiar_foto:'Foto endre',
vet_perfil__especialidad_medica:'Fachjebeed',
vet_perfil__descripcion:'Beschriewunk',
vet_perfil__zona_de_atencion:'Aunwennunksjebeed',
vet_perfil__guardar_perfil:'Profil spiechre',
contactos__buscar_en_mis_contactos:'Kontakte dorchseakje',
contactos__buscar_amigos:'Frind seakje',
contactos__ya_usa_la_app:'Bruckt dee App aul',
contactos__abrir_chat:'Chat opne',
contactos__invitar_por_whatsapp:'Doa WhatsApp enlode',
contactos__no_disponible_en_este_dispositivo:'Dit Jerät lot nich toop Kontakte too. Du kaust en Nommer selfst enjäwe.',
contactos__sin_coincidencias:'Kjeiner von diene Kontakte bruckt dee App aul.',
contactos__buscando:'Am seakje...',
contactos__numero_manual:'Nommer enjäwe',
contactos__buscar_numero:'Nommer seakje',
login_seleccion_rol__cedula_profesional:'Berufsnummer *',
login_seleccion_rol__lugar_de_residencia:'Wonort *',
login_seleccion_rol__continuar:'Wieda',
login_seleccion_rol__moonitor_faltan_datos:'Wacht! Enn dise Schret fehle noch Doote oda musse jeprieft woare. Kjik dee no un pruew daut nomol.',
login_seleccion_rol__moonitor_datos_validados:'Diene Doote sent jeprieft! Nu jeff dien Bruka un Passwoat en, daut du woascht bruck om erenntokome.',
login_seleccion_rol__moonitor_bienvenida:'Willkomm bie MiRanch, %VAR%! Dien Konto es nu kloa. Dien Bruka es: %VAR2%',
login_seleccion_rol__moonitor_ya_existe:'Dise Doote sent aul enjeschräwe. Kjik dien Telefon, UPP oda Nommer no.',
login_seleccion_rol__verificando_tu_cuenta:'Konto woat jeprieft...',
login_seleccion_rol__no_se_pudo_verificar_conexion:'Kunn dien Konto nich priewe. Kjik dien Internetverbindunk un pruew daut nomol.',
login_seleccion_rol__gps_requiere_https:'Dee Städ jeit bloos oppe veröffentlichte Websteed (https), nich enn dise Väaransecht.',
login_seleccion_rol__gps_permiso_denegado:'Dee Städ-Toolota wea aufjeleent. Moak daut aun enn dien Browser-Enstellunge.',
login_seleccion_rol__gps_no_disponible:'Kunn dien Städ nich finje (GPS aus oda swacket Signal).',
login_seleccion_rol__gps_tiempo_agotado:'Daut deed to lang, dien Städ to finje. Pruew daut nomol.',
login_seleccion_rol__nombre_del_veterinario:'Nome von dem Tierarzt',
login_seleccion_rol__nombre_del_local:'Nome von daut Lokal',
login_seleccion_rol__nombre_de_la_persona_encargada:'Nome von dee Peason, dee doaraun denkjt',
login_seleccion_rol__ubicacion_basica:'Opp-jefähre Städ',
login_seleccion_rol__enviar_ubicacion_actual:'Aktuelle Städ schekje',
login_seleccion_rol__enviar_solicitud:'Aunfroage schekje',
login_seleccion_rol__procesando:'Woat oppjeoabeit…',
login_seleccion_rol__ya_existe_una_solicitud:'Doa es aul en Konto ooda Aunfroage met dise Aunjoawe',
login_seleccion_rol__enviar_solicitud_por_whatsapp:'Aunfroage bie WhatsApp schekje',
login_seleccion_rol__bienvenido:'Wilkomm',
login_seleccion_rol__completa_nombre_y_telefono:'Schriew dien Nome un en jieltje Telefoon-Nommer',
login_seleccion_rol__codigo_enviado:'Kod bie WhatsApp jeschekjt',
login_seleccion_rol__completa_todos_los_campos:'Schriew aule Felda met en jieltje Telefoon-Nommer',
login_seleccion_rol__solicitud_enviada:'Aunfroage jeschekjt, tow oppe dee Bestätjunk von dän Administrator',
login_seleccion_rol__crea_tu_acceso:'Moak dien Toogang. Dien Konto es soofuat kloa om to bruke.',
login_seleccion_rol__crea_tu_usuario:'Moak dien Brucka-Nome',
login_seleccion_rol__minimo_6_caracteres:'Wenigstens 6 Teakjens',
login_seleccion_rol__crea_tu_contrasena:'Moak dien Paßwuat',
login_seleccion_rol__6_o_mas_letras_numeros:'6 ooda mea Teakjens, Buakjstowe, Nomre, ooda jemischt.',
login_seleccion_rol__usuario_y_contrasena_6_caracteres:'Dee Brucka-Nome un daut Paßwuat mott wenigstens 6 Teakjens habe',
login_seleccion_rol__ese_usuario_ya_existe:'Dee Brucka-Nome jeft daut aul, wael en aundre',
login_seleccion_rol__cuenta_creada_inicia_sesion:'Konto jemoakt, du kaunst die nu aunmelde',
trabajadores__acceso_no_disponible:'Dise Aufdeelunk es nich to kjriejen fa Oabeide',
trabajadores__enviar_a:'Schekje aun...',
trabajadores__tarea_enviada_a:'Doone jeschekjt aun',
login_seleccion_rol__soy_productor:'Ekj sie en Produzent',
login_seleccion_rol__soy_administrador:'Ekj sie en Administrator',
login_seleccion_rol__soy_trabajador:'Ekj sie en Oabeida',
login_seleccion_rol__recepcion_de_leche_queseria:'Melkaunnehm (Kjeeserie)',
queseria_login__selecciona_tu_perfil:'Wael dien Profil',
queseria_login__elige_como_quieres_entrar:'Wael, woo du die aunmelde welst',
queseria__administrador:'Administrator',
queseria_menu__recibir_leche:'Melk aunnehme',
queseria_menu__panel_de_reportes:'Berich-Paneel',
queseria_menu__gestion_de_productores:'Produzente-Verwaltunk',
queseria_menu__bienvenido:'Wilkomm',
queseria_menu__cerrar_sesion:'Aufmelde',
queseria_recepcion__recepcion_de_leche:'Melkaunnehm',
queseria_recepcion__lechero_recolector:'Sammel-Rute',
queseria_recepcion__productores_del_lechero:'Produzente von dise Rute',
queseria_recepcion__recibidos_hoy:'Vondoag aunjenome',
queseria_recepcion__litros_recibidos:'Aunjenome Liter',
queseria_recepcion__confirmar_recepcion:'Aunnehm bestätje',
queseria_recepcion__selecciona_un_lechero:'Wael en Rute, om äare Produzente to seene',
queseria_recepcion__aun_no_hay_productores_para_este_lechero:'Dise Rute haft noch kjeene Produzente',
queseria_recepcion__aun_no_has_recibido_leche_hoy:'Vondoag es noch kjeene Melk aunjenome',
queseria_recepcion__notificacion_enviada:'Norecht jeschekjt aun',
queseria_productores__gestion_de_productores:'Produzente-Verwaltunk',
queseria_productores__nombre_de_la_queseria:'Nome von dee Kjeeserie',
queseria_productores__alta_de_lechero:'Sammel-Rute aunlaje',
queseria_productores__nombre_del_lechero:'Nome von dee Rute',
queseria_productores__alta_de_productor:'Produzent aunlaje',
queseria_productores__nombre_del_productor:'Nome von dän Produzent',
queseria_productores__codigo_identificador:'Kenn-Kod',
queseria_productores__telefono_de_contacto:'Kontakt-Telefoon',
queseria_productores__registrar_productor:'Produzent enschriewe',
queseria_productores__productores_registrados:'Enschreewne Produzente',
queseria_productores__aun_no_hay_productores_registrados:'Noch kjeene Produzente enschreewe',
queseria_productores__solicitud_de_vinculacion_enviada:'Vebinjungs-Aunfroage aun dän Produzent jeschekjt',
queseria_productores__completa_nombre_y_codigo:'Schriew wenigstens dän Nome un Kod von dän Produzent',
queseria_productores__nombre_guardado:'Nome von dee Kjeeserie biwoat',
queseria_productores__escribe_un_nombre:'Schriew dän Nome von dee Rute',
queseria_reportes__panel_de_reportes:'Berich-Paneel',
queseria_reportes__hoy:'Vondoag',
queseria_reportes__esta_semana:'Dise Wajch',
queseria_reportes__este_mes:'Dise Moant',
queseria_reportes__detalle_por_productor:'Opdeelunk no Produzent',
queseria_reportes__litros_totales:'Liter toop',
queseria_reportes__productores_activos:'Aktive Produzente',
queseria_reportes__recepciones:'Aunnehms',
queseria_reportes__todos_los_lecheros:'Aule Rute',
queseria_reportes__aun_no_hay_datos_para_este_periodo:'Noch kjeene Doote fa dise Tiet',
queseria__ingresa_los_litros:'Jeff dee Liter en',
queseria__dictado_por_voz_no_disponible:'Sproak-Enjoawe es nich to kjriejen enn dise Browser',
queseria__escuchando:'Lustat…',
codigo_trabajador__codigo_de_4_digitos:'4-Zeffre Kod',
codigo_trabajador__codigo_de_trabajador:'Oabeida-Kod',
codigo_trabajador__pideselo_a_tu_administrador_o:'Froag dien Administrator ooda Produzent doano',
codigo_trabajador__entrar:'Nenngonn',
seleccion_tipo_ganado__que_tipo_de_ganado_manejas:'Waut fa Vee heltst du?',
seleccion_tipo_ganado__elige_tu_tipo_de_produccion:'Utwähl dien Produktionsoat, daut wie dien Funktione paust',
seleccion_tipo_ganado__ganado_vacuno_de_carne:'Fleesch-Vee',
seleccion_tipo_ganado__ganado_vacuno_de_leche:'Melkvee',
aviso_suscripcion_vencida__suscripcion_vencida:'Aboniment aufjeloope',
aviso_suscripcion_vencida__tu_acceso_a_mi_ranchapp:'Dien Toogank no MiRanch es aufjeloope aum',
aviso_suscripcion_vencida__contacta_a_tu_administrador_para:'Kontakt dien Administrator, om dien Aboniment to erneie un wada Toogank to dien Doote to kriehe.',
aviso_suscripcion_vencida__cerrar_sesion:'Aufmelde',
inicio_productor__buscar_animal_potrero_o_boletin:'Vee, Weid ooda Berich soke...',
inicio_productor__buen_dia:'Goden Morje',
inicio_productor__buenas_tardes:'Goden Dach',
inicio_productor__buenas_noches:'Goden Owend',
inicio_productor__ver_mis_datos:'Miene Doote aunkjikje',
inicio_productor__actividades_recientes:'Latste Doone',
inicio_productor__ver_todas:'Aules aunkjikje',
inicio_productor__aun_no_tienes_actividades:'Du hast noch kjeene Doone opjeschreeve.',
inicio_productor__clima_cargando:'Weda woat jeloadt...',
inicio_productor__clima_no_disponible:'Weda jrod nich to kjriejen',
inicio_productor__reintentar:'Nomol prowe',
inicio_productor__pronostico_por_horas:'Weda-Vorhersag no Stunde',
inicio_productor__humedad:'Fochtichkjeit',
inicio_productor__viento:'Wint',
inicio_productor__probabilidad_de_lluvia:'Rejen-Wahrschienlichkjeit',
inicio_productor__sensacion:'Fielt sikj aus',
inicio_productor__ubicacion_aproximada:'Opp-jefähre Städ — moak daut aun enn dien Browser fa mea Prezision',
inicio_productor__resumen_rapido:'Kot Övasicht',
inicio_productor__mas_funciones:'Mea Funktione',
inicio_productor__acceso_rapido:'Fluchtje Toogang',
menu_mas_productor__mensajes_con_tu_veterinario:'Norechte met dien Tierarzt',
menu_mas_productor__calendario_de_eventos:'Termien-Kalenda',
menu_mas_productor__bitacora_de_visitas_veterinarias:'Tierarzt-Besieke Opschriew',
menu_mas_productor__manejo_de_engorda_y_corral:'Mast- un Kroal-Verwoaltung',
menu_mas_productor__mis_tareas:'Miene Oabeide',
menu_mas_productor__agregar_trabajador:'Oabeida tobrenje',
admin_configuracion__funciones_que_vera_el_trabajador:'Funktione, waut dee Oabeida seene woat',
admin_configuracion__elige_que_modulos_puede_usar:'Wael, wetka Module en Oabeida bruke kaun, wan dee sikj met sien Kod aunmeld. Oabeida seene nienich Grafike, Kaste ooda Beriche, aule dit.',
menu_mas_productor__transferencias_de_aretes:'Ohrenmark-Övadroage',
transferencias_aretes__cuando_registras_un_arete_que:'Wan jie en Ohrenmark registriere, dee opp en aundret Städ aul aktiv es, kaun jie dee Övadroagung froage. Dee jetzje Eigena entscheed, opp hee daut toolot.',
transferencias_aretes__pendientes_de_tu_autorizacion:'Uutstoundend — dien Toolotunk',
transferencias_aretes__tus_solicitudes_enviadas:'Dien jeschekte Aunfroage',
visitas_veterinarias__nombre_del_veterinario:'Nome von dän Tierarzt',
visitas_veterinarias__motivo_de_la_visita:'Grund fa dän Besieke',
visitas_veterinarias__que_se_reviso_observaciones:'Waut nokjacht wia / Aunmoakunge...',
visitas_veterinarias__registro_de_visitas_al_rancho:'Opschriew von dee Besieke opp dee Farm, aupoat von dee Behandlungs-Jeschijchte fa jieda Vee — goot aus Dokument.',
visitas_veterinarias__registrar_visita:'Besieke opschriewe',
calendario_visual__salud_dosis:'Jesundheit/Dosis',
calendario_visual__partos:'Kalwe',
calendario_visual__tramites:'Papiere',
mensajes_veterinario_productor__escribe_un_mensaje:'En Noorecht schriewe...',
ventana_personalizada__escribe_una_nota:'En Notiz schriewe...',
datos_productor__datos_del_productor:'Produzent siene Doote',
editar_datos_productor__editar_datos_del_productor:'Produzent siene Doote oawbeede',
editar_datos_productor__nombre:'Nome',
editar_datos_productor__nombre_del_predio:'Farm sien Nome',
editar_datos_productor__ultima_actualizacion_upp:'Latste UPP-Update',
editar_datos_productor__folio_fierro_de_herrar:'Brandteijken sien Nomma',
editar_datos_productor__vencimiento_credencial_fierro:'Brandteijken-Uswies sien Aufloopdoag',
editar_datos_productor__estado:'Staot',
editar_datos_productor__municipio:'Jemeend',
editar_datos_productor__ejido_parcela:'Ejido / Stekj Launt',
editar_datos_productor__actividad_pecuaria:'Vee-Oabeit',
editar_datos_productor__el_numero_de_animales_activos:'Dee Aunidol aktive Vee woat automoatisch tellt, no waut jie enn Modul A registriere.',
editar_datos_productor__guardar_cambios:'Endarunge biwoare',
hato_inventario_animales__buscar_animal:'Vee soke...',
hato_inventario_animales__estatus_del_hato:'Hoof sien Stoand',
hato_inventario_animales__todos_los_estatus:'Aula Stoand',
hato_inventario_animales__activo:'Aktiv',
hato_inventario_animales__engorda:'Mast',
hato_inventario_animales__gestante:'Droajend',
hato_inventario_animales__lactando:'Melkjewend',
hato_inventario_animales__vaquilla:'Kwikj',
hato_inventario_animales__semental:'Fochtboll',
hato_inventario_animales__vendido:'Vekofft',
hato_inventario_animales__finado:'Jestorwe',
hato_inventario_animales__ambos_sexos:'Beid Geschlechta',
hato_inventario_animales__hembra:'Wiefsch',
hato_inventario_animales__macho:'Mansch',
graficas__vista_previa_el_diseno_final:'Vorschau — daut latste Utseehn von dee Grafike moake wie sponda tosome faust.',
graficas__composicion_del_hato_por_sexo:'Hoof-Toosomesat no Geschlecht',
graficas__aun_no_hay_animales_registrados:'Noch kjeen Vee registrieet.',
graficas__tasa_de_prenez_por_temporada:'Droajenshjeit no Joahtiet',
graficas__aun_no_hay_diagnosticos_de:'Noch kjeene Droajenshjeit-Diagnoos registrieet.',
graficas__evolucion_de_pesajes:'Wicht-Enttwikjlung',
graficas__aun_no_hay_pesajes_registrados:'Noch kjeene Wiegunge registrieet.',
graficas__costos_por_categoria:'Kaste no Kategoorii',
graficas__aun_no_hay_costos_registrados:'Noch kjeene Kaste registrieet.',
graficas__proximas_fechas_importantes:'Tokomende wichtje Doage',
graficas__ocupacion_vs_capacidad_de_potreros:'Besat vs. Weid-Kapaziteet',
graficas__aun_no_hay_potreros_registrados:'Noch kjeene Weid registrieet.',
graficas__gastos_vs_ingresos_por_mes:'Utjoawe vs. Enkomes pa Moant',
graficas__aun_no_hay_movimientos_registrados:'Noch kjeene Bewegunge registrieet.',
graficas__edades_del_hato_por_sexo:'Hoof siene Olte no Geschlecht',
graficas__aun_no_hay_animales_con:'Noch kjeen Vee met en registrieet Jeboatsdach.',
graficas__bajas_por_causa:'Vealuste no Uasoak',
graficas__aun_no_hay_bajas_registradas:'Noch kjeene Vealuste registrieet.',
boletines_informativos__boletines_informativos:'Informatioons-Berichte',
modal_escaner_camara__escanear_arete:'Ohrenmark scanne',
modal_escaner_camara__apunta_la_camara_al_codigo:'Kamera opp dee Ohrenmark sien Strichkod richte...',
modal_boletin__cerrar:'Tomoake',
notificaciones__reporte_y_notificaciones:'Berich un Norechte',
notificaciones__reportar_caso_urgente_muerte_subit:'En dringende Faul moake (plötsjlijch Doot / Vamoode fremde Kraunkheit)',
notificaciones__exportar_tabla_de_proximos_vencimi:'Tabell met tokomende Aufloopdoage ekspoteere',
notificaciones__reportes_de_chequeos_diarios:'Berichte von dee deajlijche Nokjikje',
notificaciones__notificaciones:'Norechte',
modal_historial_bitacora__concepto_ej_inseminacion_venta:'Posten (t.B. Besoame, Vekop)',
modal_historial_bitacora__monto:'Bedroag $',
modal_historial_bitacora__imprimir_descargar_ficha_resumen:'Övasicht drucke / rauhaloole',
modal_historial_bitacora__gastos_y_rendimiento:'Kaste un Leistunk',
modal_historial_bitacora__gasto:'Utjoawe',
modal_historial_bitacora__ingreso:'Enkome',
modal_historial_bitacora__registrar:'Registriere',
modal_historial_bitacora__bitacora_del_animal:'Vee sien Opschriew',
inicio_administrador__modo_veterinario_solo_salud:'Tierarzt-Modus (bloos Jesundheit)',
menu_mas_administrador__resumen_general:'Aljemeene Övasicht',
menu_mas_administrador__informacion_general_del_sistema:'Aljemeene System-Informatioon',
menu_mas_administrador__cuentas_de_productores_y_vigencias:'Produzent-Konte un Jeltichkjeit',
menu_mas_administrador__reportes_a_cefpp_casos_urgentes:'CEFPP-Berichte (dringende Faule)',
menu_mas_administrador__reportes_y_analisis_de_produccion:'Produktion-Beriche un Analyse',
reportes_admin__cruza_datos_de_todas_las:'Vejlikjt Doote von aule Produzente-Konte no Rejion, Produktion-Aut, un Jesundheit-Städ.',
reportes_admin__tipo_de_produccion:'Produktion-Aut',
reportes_admin__estado_de_salud:'Jesundheit-Städ',
reportes_admin__todos:'Aule',
reportes_admin__alerta_cefpp:'CEFPP-Warnunk',
reportes_admin__actualizar_datos_de_todas_las:'Doote von aule Konte oppdate',
reportes_admin__folios_de_fierro_de_herrar:'Brenntekjen-Aktenommere',
reportes_admin__desglose_por_productor:'Opdeelunk no Produzent',
reportes_admin__cargando:'Loadt',
reportes_admin__datos_actualizados_de:'Doote oppedatet von',
reportes_admin__nacimientos:'Jeburte',
reportes_admin__compras:'Kjeepe',
reportes_admin__bajas:'Aufgange',
reportes_admin__siniiga_activos:'SINIIGA aktiv',
reportes_admin__siniiga_pendientes:'SINIIGA noch to doone',
reportes_admin__alertas_sanitarias:'Jesundheit-Warnunge',
reportes_admin__sin_folios_registrados:'Kjeene Aktenommere enschreewe',
reportes_admin__pulsa_actualizar_datos_para_ver:'Drekj "Doote oppdate" om dee Opdeelunk to seene',
metricas_admin__metricas_de_interaccion:'Metrike von daut Bruke',
metricas_admin__uso_real_de_la_app_por:'Waut wierlijch bruckt woat von dee Produzente: wan see sikj aunmelde, woo see aunkome, un wo väl see deele.',
metricas_admin__horarios_de_mayor_actividad:'Tiede met dee miehjste Aktivitet',
metricas_admin__dias_de_mayor_actividad:'Doag met dee miehjste Aktivitet',
metricas_admin__origen_de_acceso:'Toogangs-Kwal (QR-Kod ooda direkt)',
metricas_admin__mensajes_compartidos_por_whatsapp:'Norechte jedeelt bie WhatsApp',
metricas_admin__datos_recolectados_desde_este:'Doote, dee von dit Jerät/dise Enstellunk aun jesomelt sent.',
metricas_admin__inicios_de_sesion:'Aunmeldunge',
metricas_admin__accesos_por_qr:'QR-Toogange',
metricas_admin__mensajes_por_whatsapp:'WhatsApp-Norechte',
metricas_admin__madrugada:'Fru en Morje',
metricas_admin__manana:'Morje',
metricas_admin__tarde:'Nomirdach',
metricas_admin__noche:'Owend',
metricas_admin__domingo:'Sindach',
metricas_admin__lunes:'Moondach',
metricas_admin__martes:'Dinjsdach',
metricas_admin__miercoles:'Middwoake',
metricas_admin__jueves:'Dondadach',
metricas_admin__viernes:'Friedach',
metricas_admin__sabado:'Sunowend',
metricas_admin__via_codigo_qr:'Derch QR-Kod',
metricas_admin__acceso_directo:'Direkte Toogang',
metricas_admin__compartir_la_app:'Dee App deele',
metricas_admin__cuenta_nueva_creada:'Nieet Konto jemoakt',
metricas_admin__recuperar_contrasena:'Paßwuat trigjkjrieje',
metricas_admin__recordatorio_de_vigencia:'Erenarunk fa Vebenjinj',
metricas_admin__otro:'Aundret',
metricas_admin__sin_datos_aun:'Noch kjeene Doote',
menu_mas_administrador__mensajes_con_el_productor:'Norechte met dän Produzent',
mensajes_admin__conversaciones:'Jesproakje',
mensajes_admin__mensaje_segmentado:'Enjedeelte Norecht',
mensajes_admin__filtros_de_destino:'Empfenja-Filte',
mensajes_admin__todos_los_tipos:'Aule Aute',
mensajes_admin__productores_que_recibiran_este:'Produzente, dee dise Norecht kjrieje woare',
mensajes_admin__contenido_del_mensaje:'Norecht-Enhault',
mensajes_admin__usar_plantilla:'Vorlag bruke...',
mensajes_admin__escribe_el_mensaje_para_los:'Schriew dee Norecht fa dee utjewählte Produzente...',
mensajes_admin__adjuntar_archivo:'Doatei aunhenje',
mensajes_admin__enlace_url_opcional:'URL-Link (opsional)',
mensajes_admin__guardar_como_plantilla:'Aus Vorlag biwoare',
mensajes_admin__programar_envio:'Schekje plane (opsional)',
mensajes_admin__enviar_ahora:'Nu schekje',
mensajes_admin__programar:'Plane',
mensajes_admin__envios_programados:'Jeplande Schekjes',
mensajes_admin__archivo_demasiado_pesado:'Dise Doatei es to schwoa, prow en litjre',
mensajes_admin__escribe_un_mensaje_para_guardarlo:'Schriew iescht en Norecht',
mensajes_admin__plantilla_guardada:'Vorlag biwoat',
mensajes_admin__nadie_cumple_estos_filtros:'Kjeen Produzent pausst met dise Filte',
mensajes_admin__elige_fecha_para_programar:'Wael en Dach fa daut Schekje to plane',
mensajes_admin__mensaje_programado:'Norecht jeplaant',
mensajes_admin__mensaje_enviado_a:'Norecht jeschekjt aun',
mensajes_admin__no_hay_envios_programados:'Kjeene jeplande Schekjes',
mensajes_admin__enviado:'jeschekjt',
menu_mas_administrador__ver_como_productor:'Aus Produzent aunsehne',
admin_usuarios_contrasenas__nombre_completo:'Gaunz Nome',
admin_usuarios_contrasenas__usuario:'Bruka-Nome',
admin_usuarios_contrasenas__contrasena:'Passwuat',
admin_usuarios_contrasenas__usuarios_y_contrasenas:'Bruka un Passwöade',
admin_usuarios_contrasenas__agregar_nuevo_usuario:'Nieen Bruka bietaue',
admin_usuarios_contrasenas__productor:'Produzent',
admin_usuarios_contrasenas__administrador:'Administrator',
admin_usuarios_contrasenas__veterinario_solo_salud:'Tierarzt (bloos Jesundheit)',
admin_usuarios_contrasenas__crear_usuario:'Bruka moake',
admin_cuentas_productores__nombre_del_rancho_predio:'Farm sien Nome',
admin_cuentas_productores__10_digitos:'10 Zeffre',
admin_cuentas_productores__numero_ip:'IP-Nommer',
admin_cuentas_productores__ej_192_168:'Toom Bispel 192.168.0.1',
admin_cuentas_productores__completa_telefono_e_ip:'Schriew dän Nome, Hoff, UPP, Telefoon un IP en',
admin_cuentas_productores__cuenta_creada_compartir:'Konto jemoakt. Deel dän Toogang met dän Produzent:',
admin_cuentas_productores__compartir_por_whatsapp:'Bie WhatsApp deele',
admin_cuentas_productores__mensaje_bienvenida_cuenta:'Wilkomm bie MiRanch! Dien Konto es rade.\nBrucka: %VAR%\nPaßwuat: %VAR%\nLod dee App hia rauhola: https://mi-ranchapp.netlify.app',
admin_cuentas_productores__cuentas_de_productores:'Produzent-Konte',
admin_cuentas_productores__alta_de_cuentas_control_de:'Konto moake, Jeltichkjeit kontroleere un jeschaftlijch nofolje.',
admin_cuentas_productores__reloj_de_pruebas:'Test-Klock',
admin_cuentas_productores__entorno_de_pruebas_reloj_simulado:'Test-Ombjeewunk — nomoakte Klock',
admin_cuentas_productores__hoy_real:'Vondoag (reajel):',
admin_cuentas_productores__hoy_usado_por_la_app:'· Vondoag (fonn dee App jebruukt):',
admin_cuentas_productores__usar_esta_fecha:'Dis Dach bruke',
admin_cuentas_productores__volver_a_la_fecha_real:'Torigg no daut echte Jerät-Dach gonn',
admin_cuentas_productores__metricas_de_nuevas_cuentas:'Zoahle von nieihe Konte',
admin_cuentas_productores__nuevas_cuentas_generadas:'Nieihe jemoakte Konte',
admin_cuentas_productores__proximos_a_vencer:'Boolt aufloopent',
admin_cuentas_productores__suscripciones_que_vencen_en_los:'Aboniments dee enn dee nakjste 15 Doag aufloope.',
admin_cuentas_productores__alta_de_nueva_cuenta:'Nieet Konto aunmoake',
admin_cuentas_productores__registrar_nueva_cuenta:'Nieet Konto registriere',
admin_cuentas_productores__nombre_del_productor:'Produzent sien Nome *',
admin_cuentas_productores__nombre_del_predio:'Farm sien Nome *',
admin_cuentas_productores__numero_de_upp:'UPP-Nomma *',
admin_cuentas_productores__tipo_de_modulo:'Modul-Oat *',
admin_cuentas_productores__lechera:'Melkvee',
admin_cuentas_productores__carne:'Fleesch',
admin_cuentas_productores__telefono_whatsapp:'Telefoon (WhatsApp)',
admin_cuentas_productores__dias_de_vigencia:'Jeltichkjeit-Doag',
admin_cuentas_productores__crear_cuenta:'Konto moake',
admin_cuentas_productores__listado_completo:'Gaunze List',
admin_cuentas_productores__todas_las_cuentas:'Aula Konte',
admin_info_general__esto_es_lo_que_vera:'Daut es waut dee Produzent enn siene Övasicht sitt.',
admin_configuracion__nombre_del_trabajador:'Oabeida sien Nome',
admin_configuracion__ej_revisar_bebederos_del_potrero:'T.B. Dee Drenkbakke enn Weid 3 nokjikje',
admin_configuracion__nombre_de_la_campana:'Kampanje sien Nome',
admin_configuracion__notas_opcional:'Notize (nich mott)',
admin_configuracion__nombre_de_la_ventana:'Finsta sien Nome...',
admin_configuracion__escribe_el_mensaje:'Dee Noorecht schriewe...',
admin_configuracion__configuracion_de_ventanas:'Finsta-Enstellunge',
admin_configuracion__ventanas_visibles_para_el_producto:'Finsta dee dee Produzent seene kaun',
admin_configuracion__apariencia_de_inicio:'Utsee — Startbild',
admin_configuracion__cambia_la_foto_de_fondo:'Endre daut Hinjagrund-Bild, waut dee Produzente opp äare Startbild seene. Daut woat automoatisch kompressiert, daut daut Loade nich langsam moakt.',
admin_configuracion__cambiar_foto_de_fondo:'Hinjagrund-Bild endre',
admin_configuracion__cambia_la_foto_del_encabezado:'Endre daut Hinjagrund-Bild von dee Kopprejel, waut baueoppe opp jieda Bildschirm to seene es (nist daut Logo, dän App-Nome, un dän Sproak-Knoop).',
admin_configuracion__cambia_el_logo_de_la_app:'Endre daut App-Logo. Daut woat aules seene, wua daut jrod aun jetooget woat (Login, Kopprejel, Kjeeserie).',
admin_configuracion__cambiar_logo:'Logo endre',
moonitor_config__titulo:'Moo-nitor (Halpa)',
moonitor_config__descripcion:'Lod en aundret Bild opp, om Moo-nitor sien Utsee no dee Johrestiet (Chressdach, Fruejohr, usw.) ooda fa jieda Aut Vee to endre. Wan du kjeen opplods, woat daut Standard-Bild jebruckt.',
moonitor_config__general:'Aulgemeen',
moonitor_config__restaurar_imagenes:'Standard-Bilda trigjbrenje',
moonitor_config__recordatorio_semanal:'Wajchentlje Deele-Erenarunk',
moonitor_config__sonido_de_vaca:'Vee-Jelud wan Norechte weise woare',
moonitor_config__probar_sonido:'Jelud prowe',
moonitor_config__recordatorio_descripcion:'Moo-nitor woat aule Produzente eemol enn dee Wajch doaraun erenre, dee App met 2 Kontakte to deele.',
moonitor__favor_de_compartir:'Bitte deel dee App met twee von diene Kontakte',
moonitor__compartir_por_whatsapp:'Bie WhatsApp deele',
moonitor__mensaje_compartir_app:'Kjik die MiRanch aun! Daut es dee App, waut ekj bruck om mien Ranch to leede. Lod aea hia rauhola:',
moonitor__falta_telefono:'Du meist noch diene Telefoon-Nommer enschriewe',
moonitor__entendido:'Verstone',
moonitor__ahora_no:'Jrod nich',
moonitor__tienes_avisos_pendientes:'Du haust noch offne Norechte',
moonitor__ver_notificaciones:'Norechte aunkjikje',
moonitor__nuevo_boletin:'Nieet Berich',
moonitor__ver_boletines:'Beriche aunkjikje',
queseria__operador:'Oppasa',
queseria__hora:'Stund',
queseria_reportes__exportar_pdf:'Doote rutehola (PDF)',
admin_configuracion__cambiar_foto_de_encabezado:'Kopprejel-Bild endre',
admin_configuracion__orden_de_botones_en_mas:'Ordninj von dee Knoop enn "Mea Funktione"',
admin_qr__titulo:'Toogangs-QR-Kod',
admin_qr__descripcion:'Moak en QR-Kod, waut direkt no dän Startbild von dee App fiert. Goot fa Plakate, Reklaam ooda jedrukjte Aunkindje.',
admin_qr__enlace:'Link',
admin_qr__descargar:'QR rutehola (PNG)',
admin_qr__escribe_un_enlace_valido:'Schriew en jieltje Link en (dee met http:// ooda https:// aunfange met)',
admin_configuracion__usa_las_flechas_para_cambiar:'Bruk dee Piele om dee Ordninj to endre, enn woonem dee Produzent daut Hoof un dee Module sitt.',
admin_configuracion__graficas_cuales_se_ven_y:'Grafike: woone jeweest woare un enn waut Ordninj',
admin_configuracion__apaga_la_que_no_quieras:'Moak ut waut jie nich seene wele, un bruk dee Piele om to entscheede waut toeascht kjemmt.',
admin_configuracion__trabajadores_maximo_3:'Oabeida (biem miehjste 2)',
admin_configuracion__cada_trabajador_entra_con_un:'Jieda Oabeida meld sikj aun met sien eajne Kod un kaun bloos Doote registriere un siene Oabeide seene/aufhoake — hee sitt kjeene Kaste, Enstellunge ooda Berichte.',
admin_configuracion__asignar_tareas:'Oabeide toodeele',
admin_configuracion__general:'Aljemeen',
admin_configuracion__asignar_tarea:'En Oabeit toodeele',
admin_configuracion__plan_sanitario_anual:'Joahrlijch Jesundheit-Plaun',
admin_configuracion__programa_las_campanas_del_ano:'Plaun dee Kampanjes fonn daut Joah (Impfung, Entwurmung, Nokjikje). Dee Produzent woat jewoarnt wan jieda Moant aunkjemmt.',
admin_configuracion__enero:'Januoa',
admin_configuracion__febrero:'Februoa',
admin_configuracion__marzo:'Moaz',
admin_configuracion__abril:'April',
admin_configuracion__mayo:'Mei',
admin_configuracion__junio:'Juni',
admin_configuracion__julio:'Juli',
admin_configuracion__agosto:'August',
admin_configuracion__septiembre:'September',
admin_configuracion__octubre:'Oktoba',
admin_configuracion__noviembre:'November',
admin_configuracion__diciembre:'Dezemba',
admin_configuracion__agregar_al_plan:'Toom Plaun bietaue',
admin_configuracion__descargar_reporte_sanitario_anual:'Joahrlijchen Jesundheit-Berich rauhaloole',
admin_configuracion__agregar_ventana_nueva:'Nieet Finsta bietaue',
admin_configuracion__crea_una_ventana_adicional_para:'Moak en extra Finsta fa dän Produzent (met sien eajne Notiz-Steed).',
admin_configuracion__banner_de_mensajes:'Noorecht-Banna',
admin_configuracion__se_muestra_al_abrir_la:'Woat jeweest wan dee Produzent siene App opemoakt. Jie kane meare plaune un jieda eene aun-/utmoake.',
admin_configuracion__texto_del_mensaje:'Noorecht-Text',
admin_configuracion__imagen_opcional:'Bilt (nich mott)',
admin_configuracion__tamano_del_texto:'Text-Groote',
admin_configuracion__chico:'Kjleen',
admin_configuracion__mediano:'Meddel',
admin_configuracion__grande:'Groot',
admin_configuracion__color_de_fondo:'Achtajrundskleua',
admin_configuracion__color_de_texto:'Text-Kleua',
admin_configuracion__desde_opcional:'Von (nich mott)',
admin_configuracion__hasta_opcional:'Bat (nich mott)',
admin_configuracion__programar_banner:'Banna plaune',
admin_configuracion__predios_ranchos:'Farme',
admin_configuracion__si_el_productor_maneja_mas:'Wan dee Produzent mea aus eene Farm hat, do dee hia bie. Hee kaun opp dee Aunfangs-Sied utwähle, waut hee jrod sitt.',
admin_configuracion__agregar_predio:'Farm bietaue',
admin_configuracion__notificaciones_del_navegador:'Browser-Norechte',
admin_configuracion__manda_un_aviso_emergente_aunque:'Schekjt en Norecht uk wan dee App tomoakt es (mott Toolotunk von Browser/Telefoon habe).',
admin_configuracion__activar_notificaciones_push:'Push-Norechte aunmoake',
admin_configuracion__campos_del_resumen_del_productor:'Produzent siene Övasicht-Felda',
admin_publicar_boletines__titulo_del_boletin:'Berich sien Titel',
admin_publicar_boletines__contenido_del_boletin:'Berich sien Enhoolt...',
admin_publicar_boletines__imagen_cartel_opcional:'Bilt / Placoat (nich mott)',
admin_publicar_boletines__si_subes_imagen_aparecera_circulan:'Wan jie en Bilt topbrinje, woat daut baueaben von daut Berich fa dän Produzent rundgone.',
admin_publicar_boletines__publicar_boletin:'Berich rutgäwe',
admin_informacion_sistema__vista_de_solo_lectura_util:'Bloos-to-Lease-Aunsicht, goot om to seene woo dee App jebruukt woat eah daut aun Firebase aunjeschlote woat.',
admin_informacion_sistema__auditoria_de_transferencias_de_are:'Ohrenmark-Övadroage sien Nokjikj-Opschriew',
admin_informacion_sistema__registro_de_traspasos_autorizados:'Opschriew von dee toojeloote Övadroage twuschen UPPs — kloa om enn Firebase to schriewe (Sammlunk, Dach, Tiet un dee UPPs dee doabie sent).',
admin_reportes_cefpp__reportes_a_cefpp:'CEFPP-Berichte',
admin_reportes_cefpp__descargar_informe_completo_para_ce:'Gaunzen Berich fa CEFPP rauhaloole',
modal_conflicto_arete__arete_ya_registrado:'Ohrenmark aul registrieet',
modal_conflicto_arete__solicitar_transferencia_de_registr:'Registrieruns-Övadroagung froage',
exportacion_pie_pagina__pag:'Siede',
exportacion_pie_pagina__pdf_exportado:'PDF ekspoteet',
exportacion_pie_pagina__excel_exportado:'Excel ekspoteet',
exportacion_pie_pagina__csv_exportado:'CSV ekspoteet',
exportacion_pie_pagina__no_hay_registros_para_exportar:'Kjeene Doote fa daut Ekspoteere',
transferencia_autonoma_aretes__sin_upp:'(uahne UPP)',
transferencia_autonoma_aretes__el_animal_ya_no_esta:'Daut Vee es nich mea enn daut easchte Hoof (es daut aul övadroage worde?)',
transferencia_autonoma_aretes__solicitud_rechazada:'Aunfroag aufjewiest',
transferencia_autonoma_aretes__aprobada_transferido:'Toojeloot — övadroage',
transferencia_autonoma_aretes__no_tienes_solicitudes_de_transfere:'Jie haben kjeene uutstoundende Övadroagungs-Aunfroage.',
transferencia_autonoma_aretes__arete:'Ohrenmark %VAR%',
transferencia_autonoma_aretes__el_productor_del_predio_upp:'Dee Produzent fonn dee Farm "%VAR%" (UPP %VAR%) frogt dis Ohrenmark aun, dee enn dien Hoof aktiv es. Wan dit Vee vekofft ooda övadroage wea, doo jie toolote daut siene Akte un Jeschijchte (Olter, Rass, Geschlecjht, Wiegunge, usw.) no siene Konto övadrage woat?',
transferencia_autonoma_aretes__si:'Jo',
transferencia_autonoma_aretes__no:'Nae',
transferencia_autonoma_aretes__no_has_enviado_solicitudes_de:'Jie hoaben kjeene Övadroagungs-Aunfroage jeschekjt.',
transferencia_autonoma_aretes__solicitado_a_upp:'Aunjefroagt bie %VAR% (UPP %VAR%) · %VAR% %VAR%',
modo_offline_first__no_se_pudo_cargar_el:'Dee lokoal jespieakete Stoand kunn nich jeloadt woare',
modo_offline_first__no_se_pudo_guardar_el:'Dee Stoand kunn nich lokoal jespiekat woare',
navegacion_general__rueda_administrador:'Rad (Administrator)',
navegacion_general__luis_administrador:'Luis (Administrator)',
navegacion_general__pedro_productor_de_carne:'Pedro (Fleesch-Produzent)',
navegacion_general__marcos_productor_de_leche:'Marcos (Melkvee-Produzent)',
navegacion_general__predio_de_pedro_editar:'Pedro siene Farm (oawbeede)',
navegacion_general__upp_pedro:'UPP-PEDRO',
navegacion_general__predio_de_marcos_editar:'Marcos siene Farm (oawbeede)',
navegacion_general__upp_marcos:'UPP-MARCOS',
navegacion_general__codigo_incorrecto:'Vekjaehrt Kod',
render_home_productor__animales_activos:'Aktiv Vee',
render_estatus_hato__sin_datos:'Kjeene Doote',
render_estatus_hato__atencion_urgente:'Dringend Oppasse',
render_estatus_hato__en_tratamiento:'Enn Behandlung',
render_estatus_hato__dosis_vencida:'Dosis övatiedt',
render_estatus_hato__activo_sano:'Aktiv / jesund',
render_estatus_hato__proxima_revision:'Nakjste Nokjikj',
render_estatus_hato__ultimo_parto:'Latste Kalw',
render_estatus_hato__parto_estimado:'Vamoodende Kalw',
render_estatus_hato__aun_no_has_registrado_animales:'Jie haben noch kjeen Vee registrieet.',
render_estatus_hato__registrar_el_primer_animal:'Easchte Vee registriere',
render_estatus_hato__no_hay_animales_que_coincidan:'Kjeen Vee pausst met dee Sokerie.',
historial_bitacora_animal__nacimiento_alta_del_animal:'Jeboat / Vee-Registrieruns',
historial_bitacora_animal__aun_no_hay_eventos_registrados:'Noch kjeene Jeschajchte fa dit Vee registrieet.',
gastos_rendimiento_animal__escribe_el_concepto_y_un:'Schriew dän Posten un een goode Bedroag',
gastos_rendimiento_animal__movimiento_registrado:'Bewejunk registrieet',
gastos_rendimiento_animal__peso_kg:'Wicht (kg)',
gastos_rendimiento_animal__gastos:'Utjoawe',
gastos_rendimiento_animal__texto:'$%VAR%',
gastos_rendimiento_animal__ingresos:'Enkome',
gastos_rendimiento_animal__neto:'Netto',
gastos_rendimiento_animal__sin_movimientos_registrados:'Kjeene Bewejunge registrieet.',
gastos_rendimiento_animal__texto_2:'%VAR%$%VAR%',
gastos_rendimiento_animal__gdp_promedio_kg_dia:'Dorchschnett-GDP: %VAR% kg/Dach',
gastos_rendimiento_animal__ultimo_tramo_kg_dia_ganancia:'· latste Stekj: %VAR% kg/Dach · gaunze Toonoahm: %VAR% kg enn %VAR% Doag',
gastos_rendimiento_animal__ficha:'Akte %VAR%',
gastos_rendimiento_animal__ficha_del_animal:'Vee siene Akte — %VAR%',
gastos_rendimiento_animal__predio_upp_municipio:'Farm: %VAR% · UPP: %VAR% · Jemeend: %VAR%',
gastos_rendimiento_animal__datos_de_identificacion:'Identifikatioons-Doote',
gastos_rendimiento_animal__arete_siniiga:'SINIIGA-Ohrenmark',
gastos_rendimiento_animal__arete_chip_campana:'Feld-Ohrenmark/Chip',
gastos_rendimiento_animal__raza:'Rass',
gastos_rendimiento_animal__sexo:'Geschlecjht',
gastos_rendimiento_animal__fecha_de_nacimiento:'Jeboatsdach',
gastos_rendimiento_animal__estatus:'Stoand',
gastos_rendimiento_animal__madre:'Modda',
gastos_rendimiento_animal__padre:'Voda',
gastos_rendimiento_animal__historial_de_salud:'Jesundheit-Jeschijchte',
gastos_rendimiento_animal__fecha:'Dach',
gastos_rendimiento_animal__tipo:'Oat',
gastos_rendimiento_animal__producto_diagnostico:'Produkt/Diagnoos',
gastos_rendimiento_animal__proxima:'Nakjste',
gastos_rendimiento_animal__historial_de_pesajes:'Wiegunge-Jeschijchte',
gastos_rendimiento_animal__ficha_generada_el:'Akte jemoakt aum %VAR%',
render_modulos_f__ver_estatus_del_hato:'Hoof sien Stoand aunseehne',
render_modulos_f__ver_registros:'Doote aunseehne',
render_modulos_f__escanea_o_escribe:'Scanne ooda schriewe...',
render_modulos_f__camara_del_celular_o_lector:'Telefoon-Kamera ooda en Scanna: bloos dee latste 10 Zeffre woare biwoat ("MX" un dee easchte 2 Launt-Zeffre woare wajch jeschmete).',
render_modulos_f__ej_120:'T.B. 120',
render_modulos_f__ej_venta_enfermedad_robo:'T.B. Vekop, Kraunkheit, Deefstal...',
render_modulos_f__proposito_del_animal:'Vee sien Tswek',
render_modulos_f__reemplazo:'Easatz',
render_modulos_f__engorda_venta:'Mast / Vekop',
render_modulos_f__dias_objetivo_de_engorda:'Mast-Doag Tswek',
render_modulos_f__peso_meta_kg_opcional:'Tswek-Wicht (kg, nich mott)',
render_modulos_f__los_dias_correran_de_forma:'Dee Doag loope stendich von vondoag aun, bat jie dit Vee aus "Mast fedich" enn Mast-Verwoaltung aunmoake.',
render_modulos_f__sin_asignar:'Nich toojedeelt',
render_modulos_f__motivo_de_baja_solo_si:'Uasoak fa Vealust (wan daut pausst)',
render_modulos_f__foto_del_animal:'Vee sien Bilt',
render_modulos_f__puedes_tomar_la_foto_directo:'Jie kane daut Bilt jrod met dee Telefoon-Kamera moake.',
render_modulos_f__cantidad_usada:'Jebruukte Menj',
render_modulos_f__aplicar_a_todo_un_lote:'Aun en gaunzet Lot / Weid aunwende (Impfung, Entwurmung, usw.)',
render_modulos_f__potrero_lote:'Weid / Lot',
render_modulos_f__selecciona_un_potrero:'En Weid utwähle...',
render_modulos_f__se_creara_un_registro_para:'En Opschriew woat jemoakt fa jieda aktiv Vee enn dee Weid.',
render_modulos_f__insumo_de_bodega_usado_opcional:'Jebruukte Voarroot (nich mott)',
render_modulos_f__sin_descontar_de_bodega:'Nich fom Voarroot aufttrekje',
render_modulos_f__si_seleccionas_un_insumo_se:'Wan jie en Voarroot utwähle, woat daut automoatisch fom Lager un Betriebsmittel aufjetrokjen.',
render_modulos_f__fecha_de_servicio_monta:'Dekj-/Besoamungs-Dach',
render_modulos_f__fecha_probable_de_parto:'Vamoodende Kalw-Dach',
render_modulos_f__la_fecha_de_parto_se:'Dee Kalw-Dach woat von selfst utjerekjent (283 Doag no dee Dekj). Jie kane daut selfst endre wan jun Tierarzt en aundret Dach jeft — dee App woat daut bruken waut jie dolote.',
render_modulos_f__color_de_etiqueta:'Etikett-Kleua',
render_modulos_f__archivo_kmz_kml:'KMZ-/KML-Doatei',
render_modulos_f__trazar_potrero_en_el_mapa:'Dee Weid opp dee Koat opptrocke',
render_modulos_f__usa_el_icono_de_poligono:'Bruck daut Polygon-Teijken om dee Jrenz von dee Weid opp dee Koat opptrocke.',
render_modulos_f__ubicacion_central:'Meddelpunkt',
render_modulos_f__ponle_nombre_al_potrero:'Jeff dee Weid en Nome',
render_modulos_f__traza_el_poligono_en_el_mapa:'Trock daut Polygon von dee Weid opp dee Koat',
render_modulos_f__este_potrero_no_tiene_mapa:'Dise Weid haft kjeen jespieakat Polygon',
render_modulos_f__volver_a_la_lista:'Trigj no dee Liste',
render_modulos_f__descargar_mapa:'Koat rauhoole',
render_modulos_f__no_se_pudo_generar_la_imagen:'Daut Koat-Bild kunn nich jemoakt woare',
render_modulos_f__ver_mapa:'Koat aunkjikje',
render_modulos_f__buscar_poblacion_camino_lugar:'Darp, Wajch oda Städ soke',
render_modulos_f__usar_mi_ubicacion_actual:'Miene aktuelle Städ bruke',
render_modulos_f__usar_google_maps_mas_detalle:'Fingst dee Städ nich? Google Maps bruke (mea enn dietaul)',
render_modulos_f__no_se_encontro_el_lugar:'Dise Städ wea nich to finje, prow en aundre Nome',
render_modulos_f__buscando:'Sokt jrod…',
render_modulos_f__ubicando:'Sokt diene Städ…',
render_modulos_f__no_se_pudo_obtener_ubicacion:'Diene Städ kunn nich jefunge woare. Kjik dee GPS-Verlofnis no.',
render_modulos_f__geolocalizacion_no_disponible:'Dien Jerät lot nich to, dee Städ to finje.',
render_modulos_f__falta_api_key_google:'Dee Google-Maps-Schlöätel (GOOGLE_MAPS_API_KEY) es noch nich enn dän Kod enjerecht.',
render_modulos_f__cargando_google_maps:'Google Maps woat jeloadt…',
render_modulos_f__guardar_registro:'Opschriew biwoare',
render_modulos_f__siniiga:'SINIIGA %VAR% · %VAR% · %VAR%%VAR%',
render_modulos_f__kg:'%VAR% — %VAR% kg',
render_modulos_f__ha_capacidad_animales:'%VAR% ha · Kapaziteet %VAR% Vee',
render_modulos_f__texto:'%VAR%$%VAR% — %VAR%',
render_modulos_f__l:'%VAR% — %VAR% L',
render_modulos_f__am_l_pm_l:'Muarns %VAR% L · Owents %VAR% L · %VAR%%VAR%',
render_modulos_f__l_acopiados:'%VAR% L jesammelt%VAR%',
render_modulos_f__kg_dia:'%VAR% · %VAR% kg/Dach · %VAR%',
render_modulos_f__kg_al_nacer:'%VAR% — %VAR% kg bie Jeboat',
render_modulos_f__calostro_l:'%VAR% · Kolostrum: %VAR% L%VAR%%VAR% · %VAR%%VAR%',
render_modulos_f__costo_total_actualizado:'%VAR% · gaunze Kaste $%VAR% · aktualisieet %VAR%',
render_modulos_f__aun_no_hay_registros_en:'Noch kjeene Doote enn dit Modul.',
guardar_registros__escribe_al_menos_el_arete:'Schriew tominnst dee Ohrenmark ooda daut Vee sien Nome om daut to biwoare',
guardar_registros__ya_tienes_un_animal_registrado:'Jie hoaben aul en Vee met dee Ohrenmark enn jun Hoof registrieet',
guardar_registros__animal_registrado:'Vee registrieet',
escaneo_camara_barcodedetector__tu_navegador_no_soporta_escaneo:'Jun Browser kaun nich met Kamera scanne. Bruk dee Scanna-Knoop ooda schriew dän Kod met dee Haunt.',
escaneo_camara_barcodedetector__no_se_pudo_acceder_a:'Kunn nich aun dee Kamera kome. Nokjikj dee Toolotunge, ooda bruk dee Scanna / schriew dän Kod met dee Haunt.',
escaneo_camara_barcodedetector__codigo_escaneado:'Kod jescannt',
escaneo_codigo_barras__listo_escanea_el_arete_ahora:'Kloa, scanne nu dee Ohrenmark...',
escaneo_codigo_barras__selecciona_un_potrero_para_aplicar:'Utwähl en Weid om daut no Lot to moake',
escaneo_codigo_barras__no_hay_animales_activos_en:'Kjeen aktiv Vee enn dee Weid',
escaneo_codigo_barras__caso_urgente_registrado_se_agrego:'Dringende Faul registrieet — bietoojedone no CEFPP-Berichte',
escaneo_codigo_barras__registro_de_salud_guardado:'Jesundheit-Opschriew biwoat',
escaneo_codigo_barras__registro_reproductivo_guardado_se:'Fochtboarkjeit-Opschriew biwoat — nofolj-Doag nieh jeplaunt',
escaneo_codigo_barras__se_seguira_vigilando_5_dias:'Woat noch 5 mea Doag oppjepasst',
escaneo_codigo_barras__pesaje_guardado:'Wiegunk biwoat',
escaneo_codigo_barras__potrero_guardado:'Weid biwoat',
escaneo_codigo_barras__movimiento_guardado:'Bewejunk biwoat',
escaneo_codigo_barras__ordena_registrada:'Melkje registrieet',
escaneo_codigo_barras__registro_de_tanque_guardado:'Tank-Opschriew biwoat',
escaneo_codigo_barras__registro_de_alimentacion_guardado:'Fooda-Opschriew biwoat',
inventario_alimento__escribe_el_producto_y_los:'Schriew daut Produkt un dee kg dee doa sent',
inventario_alimento__inventario_actualizado:'Voarroot aktualisieet',
inventario_alimento__guardado_atencion_el_calostro_se:'Biwoat — Oppasse: daut Kolostrum es no dee empfohle 6 Stund jejäwe worde',
inventario_alimento__becerro_registrado:'Kalw registrieet',
inventario_alimento__aun_no_registras_existencias:'Noch kjeen Voarroot registrieet.',
inventario_alimento__kg_actualizado:'%VAR% kg · aktualisieet %VAR%',
bodega_e_insumos__escribe_el_nombre_del_insumo:'Schriew dän Voarroot sien Nome un en goode Menj',
bodega_e_insumos__existencias_de_bodega_actualizadas:'Voarroot aktualisieet',
bodega_e_insumos__existencias_por_agotarse:'Voarroot woat knapp',
bodega_e_insumos__leer_mas:'Mea lease',
bodega_e_insumos__aun_no_hay_boletines_publicados:'Noch kjeene Berichte rutjejäwe.',
graficas__mortalidad_del_hato:'Hoof siene Stoawrote',
graficas__gestaciones_confirmadas:'Bestaetjde Droajenshjeit',
graficas__peso_promedio_registrado:'Dorchschnett-Wicht registrieet',
graficas__animales_asignados:'Toojedeeld Vee',
graficas__0_1_ano:'0-1 Joah',
graficas__1_2_anos:'1-2 Joah',
graficas__2_4_anos:'2-4 Joah',
graficas__4_8_anos:'4-8 Joah',
graficas__8_anos:'8+ Joah',
graficas__no_hay_fechas_proximas_registradas:'Kjeene tokomende Doage registrieet.',
bitacora_visitas_veterinarias__escribe_al_menos_la_fecha:'Schriew tominnst dän Dach un dän Tierarzt',
bitacora_visitas_veterinarias__visita_registrada:'Besieke registrieet',
bitacora_visitas_veterinarias__visita_eliminada:'Besieke wajchjedone',
bitacora_visitas_veterinarias__visita_restaurada:'Besieke torigg jehoolt',
bitacora_visitas_veterinarias__tasa_de_prenez:'Droajenshjeit-Rote (%)',
bitacora_visitas_veterinarias__aun_no_hay_visitas_registradas:'Noch kjeene Besieke registrieet.',
bitacora_visitas_veterinarias__sin_datos_suficientes:'Nich jenoag Doote',
bitacora_visitas_veterinarias__costo_por_litro:'Kaste pa Liter',
bitacora_visitas_veterinarias__eficiencia_alimenticia:'Fooda-Effizienz',
bitacora_visitas_veterinarias__comparativo_contra_referencia_hols:'Vejlikj met Holstein-Refarenz',
bitacora_visitas_veterinarias__grasa_promedio:'% Fatt dorchschnett',
bitacora_visitas_veterinarias__proteina_promedio:'% Proteen dorchschnett',
bitacora_visitas_veterinarias__servicios_por_concepcion:'Besoamunge pa Konzeptioon',
bitacora_visitas_veterinarias__intervalo_entre_partos_iep:'Twuschentiet twuschen Kalwe',
bitacora_visitas_veterinarias__dias_abiertos_promedio:'Dorchschnett oapene Doag',
bitacora_visitas_veterinarias__referencia_raza_holstein_se_necesi:'Refarenz Rass Holstein. Doa woare mea Opschriewe jebruukt (rejchte Kalwe, Besoamunge, Melk-Kwaliteet) daut dise Vejlikje trü sent.',
bitacora_visitas_veterinarias__ranking_de_mejores_productoras_lit:'Rangliste von dee beeste Melkkjeh (toosome Liter)',
bitacora_visitas_veterinarias__dias_en_leche_del_y:'Melkje-Doag un oapene Doag',
bitacora_visitas_veterinarias__crecimiento_y_desarrollo:'Wossdom un Enttwikjlung',
bitacora_visitas_veterinarias__estado_de_resultados_por_mes:'Moant-Rekjenschopp',
bitacora_visitas_veterinarias__punto_de_equilibrio:'Utjliekspunkt',
bitacora_visitas_veterinarias__proyeccion_proximo_mes:'Vamoodunk fa dän nakjste Moant',
bitacora_visitas_veterinarias__rentabilidad_por_animal_lote_imput:'Jewenn pa Vee / toojedeeld Lot',
modo_veterinario__modo_veterinario_activado_solo_ver:'Tierarzt-Modus aunjemoakt: jie seene bloos Jesundheit',
modo_veterinario__modo_veterinario_desactivado:'Tierarzt-Modus utjemoakt',
modo_veterinario__cuentas_de:'Konte von',
modo_veterinario__productores:'Produzente',
modo_veterinario__usuarios_y:'Bruka un',
modo_veterinario__contrasenas:'Passwöade',
modo_veterinario__datos_del:'Doote von dee',
modo_veterinario__productor:'Produzent',
modo_veterinario__informativos:'informatiw',
modo_veterinario__configuracion:'Enstellunge',
modo_veterinario__de_ventanas:'von Finsta',
predios_multiples__escribe_el_nombre_del_predio:'Schriew dee Farm sien Nome',
predios_multiples__predio_agregado:'Farm bietoodone',
predios_multiples__predio_eliminado:'Farm wajchjedone',
predios_multiples__predio_restaurado:'Farm torigg jehoolt',
predios_multiples__aun_no_agregas_predios_adicionales:'Noch kjeene extra Farme bietoodone.',
notificaciones_push_reales__este_navegador_no_soporta_notifica:'Dis Browser kaun kjeene Norechte moake',
notificaciones_push_reales__notificaciones_activadas:'Norechte aunjemoakt ✓',
notificaciones_push_reales__permiso_no_concedido:'Toolotunk nich jejäwe',
notificaciones_push_reales__notificaciones_push_activadas:'Push-Norechte aunjemoakt',
notificaciones_push_reales__no_se_concedio_permiso_de:'Toolotunk fa Norechte nich jejäwe',
notificaciones_push_reales__mi_ranchapp:'MiRanch —',
reportes_cefpp__muerte_subita:'Plötsjlijch Doot',
reportes_cefpp__sospecha_de_enfermedad_exotica:'Vamoode fremde Kraunkheit',
reportes_cefpp__caso_marcado_como_enviado_a:'Faul aunjemoakt aus jeschekjt no CEFPP',
reportes_cefpp__caso_marcado_como_pendiente:'Faul aunjemoakt aus uutstoundend',
reportes_cefpp__no_hay_casos_para_exportar:'Kjeene Faule fa daut Ekspoteere',
reportes_cefpp__tipo_de_caso:'Faul sien Oat',
reportes_cefpp__estatus_de_envio_a_cefpp:'CEFPP Schekj-Stoand',
reportes_cefpp__informe_descargado:'Berich rauhajeholt',
reportes_cefpp__no_hay_casos_urgentes_reportados:'Jrod kjeene dringende Faule jemoldt.',
mensajes_veterinario_productor__usuario_creado:'Bruka jemoakt',
mensajes_veterinario_productor__usuario_eliminado:'Bruka wajchjedone',
mensajes_veterinario_productor__usuario_restaurado:'Bruka torigg jehoolt',
mensajes_veterinario_productor__contrasena_actualizada:'Passwuat aktualisieet',
mensajes_veterinario_productor__aun_no_hay_mensajes:'Noch kjeene Norechte.',
mensajes_veterinario_productor__productor_configurado:'Produzent enjerecht',
mensajes_veterinario_productor__animales_registrados:'Vee registrieet',
mensajes_veterinario_productor__usuarios_del_sistema:'System-Bruka',
mensajes_veterinario_productor__boletines_publicados:'Berichte rutjejäwe',
mensajes_veterinario_productor__nueva_contrasena:'Nieet Passwuat',
mensajes_veterinario_productor__usuario_rol:'Bruka: %VAR% · Roll: %VAR%',
cuentas_productores_alta__elige_una_fecha_primero:'Utwähl eascht en Dach',
cuentas_productores_alta__reloj_de_pruebas_fijado_en:'Test-Klock enjestalt oppp',
cuentas_productores_alta__usando_la_fecha_real_del:'Bruke daut echte Jerät-Dach',
cuentas_productores_alta__nombre_predio_y_upp_son:'Nome, Farm un UPP sent mott',
cuentas_productores_alta__ya_existe_una_cuenta_registrada:'Doa es aul en Konto met dee UPP registrieet',
cuentas_productores_alta__productor:'(Produzent)',
cuentas_productores_alta__cuenta_eliminada:'Konto wajchjedone',
cuentas_productores_alta__cuenta_restaurada:'Konto torigg jehoolt',
cuentas_productores_alta__vigencia_actualizada:'Jeltichkjeit aktualisieet',
cuentas_productores_alta__cuenta_renovada_por:'Konto erneit fa',
cuentas_productores_alta__dias_desde_hoy:'Doag von vondoag aun',
cuentas_productores_alta__cuenta_marcada_como_vencida_para:'Konto aunjemoakt aus aufjeloope (fa Testware)',
cuentas_productores_alta__esta_semana:'Dise Wetjch',
cuentas_productores_alta__este_mes:'Dissen Moant',
cuentas_productores_alta__este_ano:'Dit Joah',
cuentas_productores_alta__cuenta_s:'Konto(s)',
cuentas_productores_alta__por_vencer:'Boolt aufloopent',
cuentas_productores_alta__simulada:'(nomoakt)',
cuentas_productores_alta__real:'(reajel)',
cuentas_productores_alta__registros_de_salud:'Jesundheit-Opschriewe',
cuentas_productores_alta__registros_reproductivos:'Fochtboarkjeit-Opschriewe',
cuentas_productores_alta__pesajes_registrados:'Wiegunge registrieet',
cuentas_productores_alta__potreros_registrados:'Weide registrieet',
cuentas_productores_alta__costos_registrados:'Kaste registrieet',
cuentas_productores_alta__no_hay_cuentas_por_vencer:'Kjeene Konte loope enn dee nakjste 15 Doag aufe.',
cuentas_productores_alta__upp:'%VAR% · UPP %VAR%',
cuentas_productores_alta__aun_no_hay_cuentas_de:'Noch kjeene Produzent-Konte registrieet.',
cuentas_productores_alta__upp_2:'%VAR% · UPP %VAR% · %VAR%',
cuentas_productores_alta__usuario_contrasena:'Bruka: %VAR% · Passwuat: %VAR%',
cuentas_productores_alta__alta_vence:'Jemoakt: %VAR% · Lopt aufe: %VAR% (%VAR%)',
cuentas_productores_alta__probar_acceso:'Toogank teste',
cuentas_productores_alta__renovar:'Erneie',
cuentas_productores_alta__30_dias:'+30 Doag',
cuentas_productores_alta__30_dias_2:'-30 Doag',
cuentas_productores_alta__vencer_ahora:'Nu aufloope loote',
cuentas_productores_alta__aun_no_se_han_autorizado:'Noch kjeene Ohrenmark-Övadroage toojeloot.',
cuentas_productores_alta__upp_upp:'%VAR% (UPP %VAR%) → %VAR% (UPP %VAR%)',
edicion_datos_productor__datos_del_productor_actualizados:'Produzent siene Doote aktualisieet',
edicion_datos_productor__a_registro_e_identificacion_animal:'A. Vee-Registrieruns un -Tejchninj',
edicion_datos_productor__b_salud_sanidad_y_manejo:'B. Jesundheit un Behandlung',
edicion_datos_productor__c_reproduccion_y_maternidad:'C. Fochtboarkjeit un Kalwe',
edicion_datos_productor__d_pesajes_y_productividad:'D. Wiegunge un Produktiwiteet',
edicion_datos_productor__e_mapeo_geografico:'E. Kart fonn dee Farm',
edicion_datos_productor__f_administracion_costos_y_reportes:'F. Verwoaltung, Kaste un Berichte',
edicion_datos_productor__g_produccion_de_leche_solo:'G. Melk-Produktion (bloos Melkvee)',
edicion_datos_productor__h_tanque_y_entrega_de:'H. Melktank un Lewarunk (bloos Melkvee)',
edicion_datos_productor__i_alimentacion_lechera_solo_ganado:'I. Melkvee-Fooda (bloos Melkvee)',
edicion_datos_productor__j_becerros_de_reemplazo_solo:'J. Easatz-Kjalwa (bloos Melkvee)',
edicion_datos_productor__folio_de_fierro_de_herrar:'Brandteijken sien Nomma',
edicion_datos_productor__numero_de_animales_activos:'Aunidol aktiv Vee',
edicion_datos_productor__g_produccion_de_leche:'G. Melk-Produktion',
edicion_datos_productor__h_tanque_y_entrega_de_2:'H. Melktank un Lewarunk',
edicion_datos_productor__i_alimentacion_lechera:'I. Melkvee-Fooda',
edicion_datos_productor__j_becerros_de_reemplazo:'J. Easatz-Kjalwa',
edicion_datos_productor__indicadores_lecheros_comparativo_h:'Melk-Zoahle (Holstein-Vejlikj)',
edicion_datos_productor__estatus_financiero:'Jeltlijch Stoand',
edicion_datos_productor__tasa_de_prenez:'Droajenshjeit-Rote',
edicion_datos_productor__ocupacion_de_potreros:'Weid-Besat',
edicion_datos_productor__edades_del_hato:'Hoof siene Olte',
plan_sanitario_anual__escribe_el_nombre_de_la:'Schriew dee Kampanje sien Nome',
plan_sanitario_anual__campana_agregada_al_plan:'Kampanje toom Plaun bietoodone',
plan_sanitario_anual__campana_eliminada:'Kampanje wajchjedone',
plan_sanitario_anual__campana_restaurada:'Kampanje torigg jehoolt',
plan_sanitario_anual__reporte_sanitario_anual_descargado:'Joahrlijchen Jesundheit-Berich rauhajeholt',
plan_sanitario_anual__aun_no_programas_campanas:'Noch kjeene Kampanjes jeplaunt.',
trabajadores__ya_tienes_el_maximo_de:'Jie hoaben aul daut miehjste met 3 Oabeida pa Konto',
trabajadores__escribe_el_nombre_del_trabajador:'Schriew dän Oabeida sien Nome',
trabajadores__trabajador_agregado:'Oabeida bietoodone',
trabajadores__trabajador_eliminado:'Oabeida wajchjedone',
trabajadores__trabajador_restaurado:'Oabeida torigg jehoolt',
trabajadores__aun_no_agregas_trabajadores:'Noch kjeene Oabeida bietoodone.',
trabajadores__codigo_de_acceso:'Toogank-Kod:',
tareas__escribe_la_tarea:'Schriew dee Oabeit',
tareas__tarea_asignada:'Oabeit toojedeelt',
tareas__aun_no_asignas_tareas:'Noch kjeene Oabeide toojedeelt.',
tareas__para:'Fa: %VAR% · %VAR% %VAR%',
ventanas_personalizadas__escribe_un_nombre_para_la:'Schriew en Nome fa daut Finsta',
ventanas_personalizadas__ventana_agregada:'Finsta bietoodone',
ventanas_personalizadas__ventana_eliminada:'Finsta wajchjedone',
ventanas_personalizadas__ventana_restaurada:'Finsta torigg jehoolt',
ventanas_personalizadas__aun_no_agregas_ventanas_propias:'Noch kjeene eajne Finsta bietoodone.',
ventanas_personalizadas__sin_notas_todavia:'Noch kjeene Notize.',
banner_mensajes__escribe_un_texto_para_el:'Schriew en Text fa daut Banna',
banner_mensajes__banner_programado:'Banna jeplaunt',
banner_mensajes__banner_eliminado:'Banna wajchjedone',
banner_mensajes__banner_restaurado:'Banna torigg jehoolt',
banner_mensajes__boletin_publicado:'Berich rutjejäwe',
banner_mensajes__boletin_eliminado:'Berich wajchjedone',
banner_mensajes__boletin_restaurado:'Berich torigg jehoolt',
banner_mensajes__aun_no_programas_banners:'Noch kjeene Banna jeplaunt.',
banner_mensajes__tienes_notificaciones_pendientes_t:'Jie hoaben uutstoundende Norechte — tekj om dee to seene',
confirmacion_visual_al__deshacer:'Torigg moake',
buscador_global__sin_resultados:'Kjeene Resultote',
calendario_visual__vencimiento_credencial_de_fierro:'Brandteijken-Uswies sien Aufloopdoag',
calendario_visual__no_hay_vencimientos_proximos_para:'Kjeene tokomende Aufloopdoage fa daut Ekspoteere',
calendario_visual__proximo:'Tokomend',
calendario_visual__tramite:'Papia',
calendario_visual__categoria:'Kategoorii',
calendario_visual__titulo:'Titel',
calendario_visual__dias_restantes:'Doag dee öwajch sent',
calendario_visual__tabla_exportada:'Tabell ekspoteet',
calendario_visual__sin_eventos_este_dia:'Kjeene Jeschajchte aun dissen Dach.',
motor_alertas_automaticas__obligatoria:'MOTT —',
motor_alertas_automaticas__tratamiento_de_hoy:'Vondoag siene Behandlung',
motor_alertas_automaticas__proxima_dosis_programada:'Nakjste jeplaunte Dosis',
motor_alertas_automaticas__leche_apta_desde_hoy:'Melk von vondoag aun goot',
motor_alertas_automaticas__leche_no_apta_para_el:'Melk NICH goot fa daut Tank',
motor_alertas_automaticas__parto_atrasado:'Kalw övatiedt',
motor_alertas_automaticas__parto_esperado_hoy:'Kalw vondoag vamoodt',
motor_alertas_automaticas__parto_proximo:'Tokomende Kalw',
motor_alertas_automaticas__secado_atrasado:'Dreajstel övatiedt',
motor_alertas_automaticas__secar_hoy:'Vondoag dreajstelle',
motor_alertas_automaticas__secado_proximo:'Tokomend Dreajstel',
motor_alertas_automaticas__periodo_seco_vencido_atenta_al:'Dreaj-Tiet övatiedt — oppp Kalw oppasse',
motor_alertas_automaticas__termina_el_periodo_seco_hoy:'Dreaj-Tiet endjcht vondoag',
motor_alertas_automaticas__periodo_seco_por_terminar:'Dreaj-Tiet endjcht boolt',
motor_alertas_automaticas__vigilar_celo_hoy:'Vondoag oppp Brunst oppasse',
motor_alertas_automaticas__vigilar_posible_celo_proximo:'Oppp muajlijch tokomende Brunst oppasse',
motor_alertas_automaticas__no_volvio_a_estar_en:'Nich wada enn Brunst jekome?',
motor_alertas_automaticas__calostro_pendiente_de_registrar:'Kolostrum noch to registriere',
motor_alertas_automaticas__inventario_de_alimento_bajo:'Fooda-Voarroot es knapp',
motor_alertas_automaticas__campana_sanitaria_de_este_mes:'Dissen Moant siene Jesundheit-Kampanje',
motor_alertas_automaticas__tramite_vencido:'Papia övatiedt',
motor_alertas_automaticas__tramite_proximo:'Tokomende Papia',
motor_alertas_automaticas__sin_revision_reciente:'Kjeene niehe Nokjikj',
motor_alertas_automaticas__urgente_muerte_subita:'DRINGEND · Plötsjlijch Doot',
motor_alertas_automaticas__urgente_sospecha_exotica:'DRINGEND · Vamoode fremde Kraunkheit',
motor_alertas_automaticas__proximos:'Tokomend',
motor_alertas_automaticas__proximos_tramites:'Tokomende Papiere',
motor_alertas_automaticas__no_hay_animales_enfermos_reportado:'Kjeen kraunk Vee jemoldt.',
motor_alertas_automaticas__recuperado:'Wada jesund',
motor_alertas_automaticas__no_tienes_notificaciones_por_ahora:'Jie hoaben jrod kjeene Norechte.',
exportar_csv__toro_pajuela:'Boll/Somestrooh',
exportar_csv__diagnostico:'Diagnoos',
exportar_csv__condicion_corporal:'Liew-Toostaunt',
exportar_csv__hectareas:'Hektoa',
exportar_csv__capacidad_animal:'Vee-Kapaziteet',
exportar_csv__imputar_a:'Toodeele no',
exportar_csv__descripcion:'Beschriewunk',
exportar_csv__ordeno:'Jemelkjt fonn',
exportar_csv__litros_am:'Liter muarns',
exportar_csv__litros_pm:'Liter owents',
exportar_csv__total_litros:'Liter toosome',
exportar_csv__grasa:'% Fatt',
exportar_csv__proteina:'% Proteen',
exportar_csv__celulas_somaticas:'Zell-Tal',
exportar_csv__litros_acopiados:'Jesammelte Liter',
exportar_csv__precio_litro:'Pries/Liter',
exportar_csv__racion:'Ratioon',
exportar_csv__kg_concentrado_dia:'Kg Kroaftfooda/Dach',
exportar_csv__fecha_nacimiento:'Jeboatsdach',
exportar_csv__peso_al_nacer:'Jeboats-Wicht',
exportar_csv__litros_calostro:'Liter Kolostrum',
exportar_csv__horas_calostro:'Stund bat Kolostrum',
exportar_csv__alimentacion:'Fooda',
exportar_csv__fecha_destete:'Aufsett-Dach',
exportar_csv__peso_destete:'Aufsett-Wicht',
exportar_csv__registros_exportados:'Doote ekspoteet',
exportar_csv__no_hay_animales_para_exportar:'Kjeen Vee fa daut Ekspoteere',
exportar_csv__arete_campana:'Feld-Ohrenmark',
exportar_csv__inventario_exportado:'Voarroot ekspoteet',
registro_exportaciones_csv__inventario_de_hato:'Hoof-Voarroot',
registro_exportaciones_csv__proximos_vencimientos:'Tokomende Aufloopdoage',
registro_exportaciones_csv__informe_cefpp:'CEFPP-Berich',
sistema_idiomas_es__en:'EN: %VAR%',
sistema_idiomas_es__de:'DE: %VAR%',
manejo_engorda_corral__no_tienes_tareas_pendientes_por:'Jie hoaben jrod kjeene uutstoundende Oabeide.',
manejo_engorda_corral__en_engorda_ahora:'Jrod enn Mast',
manejo_engorda_corral__engordas_finalizadas:'Fedich Mast',
manejo_engorda_corral__aun_no_tienes_animales_marcados:'Noch kjeen Vee fa Mast aunjemoakt.',
manejo_engorda_corral__dias_corriendo:'%VAR% Doag loopent%VAR%%VAR%',
manejo_engorda_corral__marcar_engorda_finalizada:'Mast aus fedich aunmoake',
manejo_engorda_corral__finalizada_en_dias:'Fedich enn %VAR% Doag',
manejo_engorda_corral__en_curso:'Am Loop',
manejo_engorda_corral__finalizadas:'Fedich',
csv_extra__animal:'Vee',
csv_extra__detalle:'Enkelheit',
csv_extra__notas:'Notize',
csv_extra__potrero:'Weid',
csv_extra__predio:'Farm',
csv_extra2__comprador:'Kjeepa',
csv_extra2__lote:'Lot',
csv_extra2__producto:'Produkt',
csv_extra2__recolectado:'Aufjeholt fonn',
csv_extra2__alojamiento:'Onnabrinjunk',
csv_extra2__monto:'Bedroag',
csv_extra2__etapa:'Stounde',
csv_extra2__vaca:'Kjoo',
csv_extra2__descuentos:'Aftrekkinj',
csv_extra2__bonos:'Extrajelt',
csv_extra2__temperatura:'Temperatua',
csv_extra2__becerro:'Kalw',
csv_extra3__servicio:'Besoamunk',
csv_extra4__vencidos:'Övatiedt',
csv_extra4__hoy:'Vondoag',
csv_extra4__enfermo:'Kraunk',
csv_extra5__sin_registros:'Kjeene Doote',
csv_extra6__pendiente:'Uutstoundend',
csv_extra6__rechazada:'Aufjewiest',
csv_extra6__si_boton:'Jo',
csv_extra6__no_boton:'Nae',
csv_extra7__total:'Toosome',
csv_extra7__vencidas:'Aufjeloope',
csv_extra7__vence_hoy:'Lopt vondoag aufe',
csv_extra7__activa:'Aktiv',
csv_extra7__vencida:'Aufjeloope',
csv_extra8__vencido:'Övatiedt',
modal_conflicto__texto:'Dee Ohrenmark %VAR% es aul aktiv opp dee Farm "%VAR%" (UPP %VAR%), fonn %VAR%. Wan dit Vee vekofft ooda no jun Farm övadroage wea, kaun jie dee Övadroagung fonn dee Akte un Jeschijchte froage.',
campo_f__arete_siniiga:'SINIIGA-Ohrenmark',
campo_f__arete_campana_chip:'Feld-Ohrenmark / Chip',
campo_f__nombre_o_alias:'Nome ooda Bienome',
campo_f__raza:'Rass',
campo_f__sexo:'Geschlecjht',
campo_f__fecha_de_nacimiento:'Jeboatsdach',
campo_f__estatus:'Stoand',
campo_f__madre_arete_nombre:'Modda (Ohrenmark/Nome)',
campo_f__padre_pajuela:'Voda / Somestrooh',
campo_f__animal_arete_o_nombre:'Vee (Ohrenmark ooda Nome)',
campo_f__tipo:'Oat',
campo_f__producto_diagnostico:'Produkt / Diagnoos',
campo_f__fecha_de_aplicacion:'Aunwendungs-Dach',
campo_f__proxima_dosis:'Nakjste Dosis',
campo_f__cuarto_afectado_mastitis:'Aunjegrepen Vieadel (bie Mastitis)',
campo_f__resultado_cmt:'CMT-Resultoat (wan daut pausst)',
campo_f__notas:'Notize',
campo_f__vaca_arete_o_nombre:'Kjoo (Ohrenmark ooda Nome)',
campo_f__tipo_de_servicio:'Besoamunk sien Oat',
campo_f__toro_pajuela_utilizada:'Bruukte Boll / Somestrooh',
campo_f__diagnostico_de_gestacion:'Droajenshjeit-Diagnoos',
campo_f__fecha_real_de_parto:'Rejchte Kalw-Dach (wan daut aul wia)',
campo_f__fecha_de_pesaje:'Wiege-Dach',
campo_f__peso_kg:'Wicht (kg)',
campo_f__lote_potrero:'Lot / Weid',
campo_f__condicion_corporal_opcional:'Liew-Toostaunt (1 bat 5, nich mott)',
campo_f__nombre_del_potrero:'Weid sien Nome',
campo_f__hectareas:'Hektoa',
campo_f__capacidad_animal:'Vee-Kapaziteet',
campo_f__tipo_de_movimiento:'Bewejunk sien Oat',
campo_f__monto:'Bedroag ($)',
campo_f__categoria:'Kategoorii',
campo_f__fecha:'Dach',
campo_f__imputar_a:'Toodeele no (Lot/Vee)',
campo_f__descripcion:'Beschriewunk',
campo_f__fecha_de_ordena:'Melkje-Dach',
campo_f__quien_ordeno:'Wecha jemelkjt hat',
campo_f__litros_ordena_am:'Liter Muarns-Melkje',
campo_f__litros_ordena_pm:'Liter Owents-Melkje',
campo_f__grasa_opcional:'% Fatt (nich mott)',
campo_f__celulas_somaticas_opcional:'Zell-Tal (nich mott)',
campo_f__proteina_opcional:'% Proteen (nich mott)',
campo_f__litros_acopiados_tanque:'Liter enn Tank jesammelt',
campo_f__temperatura_tanque:'Tank siene Temperatua (°C)',
campo_f__ya_paso_recolector:'Es dee Aufhola/Tanka aul jekome?',
campo_f__comprador_pasteurizadora:'Kjeepa / Melkerei',
campo_f__precio_pagado_litro:'Betoolt Pries pa Liter ($)',
campo_f__bonos_calidad:'Kwaliteet-Extrajelt ($)',
campo_f__descuentos_calidad:'Kwaliteet-Aftrekkinj ($)',
campo_f__vaca_arete_o_nombre_lote:'Kjoo (Ohrenmark ooda Nome, nich mott wan daut no Lot es)',
campo_f__etapa_de_lactancia:'Melkje-Stounde',
campo_f__tipo_de_racion:'Ratioon sien Oat',
campo_f__kg_concentrado_dia:'Kg Kroaftfooda / Dach',
campo_f__becerro_arete_o_nombre:'Kalw (Ohrenmark ooda Nome)',
campo_f__peso_al_nacer_kg:'Jeboats-Wicht (kg)',
campo_f__litros_calostro_dados:'Jejäwene Liter Kolostrum',
campo_f__horas_despues_del_parto:'Stund no dee Kalw',
campo_f__tipo_de_alojamiento:'Onnabrinjunk sien Oat',
campo_f__alimentacion_actual:'Jetzje Fooda',
campo_f__fecha_de_destete:'Aufsett-Dach (wan daut aul wia)',
campo_f__peso_al_destete_kg:'Aufsett-Wicht (kg)',
campo_f__nombre_del_insumo:'Voarroot sien Nome (t.B. Mineroal-Solt, IBR-Impfung)',
campo_f__unidad:'Eenheit',
campo_f__cantidad_comprada:'Kofte Menj',
campo_f__costo_total:'Gaunze Kaste ($)',
campo_f__alerta_menos_de:'Woarne wan weinja aus... öwajch es',
campo_f__potrero:'Weid',
campo_f__dias_retiro_leche:'Wartezeit fa Melk enn Doag (wan Antibiotikum jejäwe wea)',
campo_f__app_calculara_aviso_tanque:'Dee App woat utrekjne un woarne bat woonem Dach dise Kjoo nich enn daut Tank kaun.',
campo_f__fecha_programada_secado:'Jeplaunt Dreajstel-Dach',
campo_f__secado_se_calcula_solo:'Daut Dreajstel woat automoatisch utjerekjent (60 Doag eah dee vamoodende Kalw). Jie kane daut uk selfst endre.',
campo_f__fecha_cierre_lactancia:'Melkje-Aufschluss Dach',
campo_f__fin_periodo_seco:'Enj fonn dee Dreaj-Tiet',
campo_f__cuando_dejes_ordenarla:'Wan jie ophole met Melkje, do hia dän Dach enn — jie woare 5 Doag eah daut Enj fonn dee Dreaj-Tiet jewoarnt.',
campo_f__inventario_de_alimento:'Fooda-Voarroot',
campo_f__producto_ej_concentrado:'Produkt (t.B. Kroaftfooda)',
campo_f__kg_disponibles:'kg dee doa sent',
campo_f__actualizar_existencia:'Voarroot aktualisieere',
},
};
// ================= SISTEMA DE INTERNACIONALIZACIÓN (i18n) =================
// Idioma nativo/principal: español (I18N.es) — es la fuente de verdad y el
// idioma de respaldo automático cuando falta una traducción en otro idioma.
// Idiomas soportados: es (Español), en (English), de (Deutsch), pd (Plautdietsch).
//
// Cómo agregar texto nuevo a la app (botones, pestañas, etiquetas, placeholders):
//   1) Define una clave única, ej: mi_seccion__mi_texto
//   2) Agrégala a los 4 bloques (es/en/de/pd) con su traducción correspondiente.
//   3) Úsala con tr('mi_seccion__mi_texto') en JS, o data-i18n="mi_seccion__mi_texto"
//      (texto), data-i18n-html="..." (HTML), data-i18n-placeholder="..." (placeholder
//      de un input) o data-i18n-title="..." (atributo title) directamente en el HTML.
// Si olvidas agregar la clave a algún idioma, tr() cae automáticamente a español
// en vez de romperse — pero corre verificarCoberturaI18N() en la consola del
// navegador para ver qué claves faltan por traducir en cada idioma.
function verificarCoberturaI18N(){
const idiomas = Object.keys(I18N).filter(i => i !== 'es');
const clavesEs = Object.keys(I18N.es);
const faltantes = {};
idiomas.forEach(idioma => {
faltantes[idioma] = clavesEs.filter(clave => !(clave in I18N[idioma]));
});
const totalFaltantes = Object.values(faltantes).reduce((acc, arr) => acc + arr.length, 0);
if (totalFaltantes === 0){
if (typeof console !== 'undefined' && typeof console.log === 'function') console.log('✅ i18n: todas las claves de español están traducidas en en/de/pd.');
} else {
if (typeof console !== 'undefined' && typeof console.warn === 'function') console.warn('⚠️ i18n: hay claves sin traducir (se muestran en español como respaldo):', faltantes);
}
return faltantes;
}
try { verificarCoberturaI18N(); } catch(e){ /* nunca debe interrumpir la carga de la app */ }
function tr(clave){
return (I18N[idiomaActual] && I18N[idiomaActual][clave]) || I18N.es[clave] || clave;
}
function nombreModulo(letra){ return tr('mod_' + letra + '_nombre'); }
function iconoTileHTML(clave, faIconClass){
const url = estado.iconosBotones && estado.iconosBotones[clave];
if (url){
return `<span class="tile-icono-grande" style="background-image:url('${url}'); background-size:cover; background-position:center; background-color:transparent;"></span>`;
}
return `<span class="tile-icono-grande"><i class="fa-solid ${faIconClass}"></i></span>`;
}
function iconoChicoHTML(clave, faIconClass){
const url = estado.iconosBotones && estado.iconosBotones[clave];
if (url){
return `<span class="icono" style="background-image:url('${url}'); background-size:cover; background-position:center;"></span>`;
}
return `<span class="icono"><i class="fa-solid ${faIconClass}"></i></span>`;
}
function aplicarIconosBotonesEstaticos(){
const mapa = {
calendario: { id:'ticon-calendario', icono:'fa-calendar-days' },
visitas: { id:'ticon-visitas', icono:'fa-user-doctor' },
engorda: { id:'ticon-engorda', icono:'fa-chart-line' },
tareas: { id:'ticon-tareas', icono:'fa-clipboard-check' },
transferencias: { id:'ticon-transferencias', icono:'fa-tag' },
reg_leche: { id:'ticon-reg-leche', icono:'fa-jug-detergent' },
reg_carne: { id:'ticon-reg-carne', icono:'fa-drumstick-bite' },
reg_punto: { id:'ticon-reg-punto', icono:'fa-industry' },
reg_mvz: { id:'ticon-reg-mvz', icono:'fa-user-doctor' },
reg_cefp: { id:'ticon-reg-cefp', icono:'fa-building-shield' },
};
Object.entries(mapa).forEach(([clave, cfg]) => {
const el = document.getElementById(cfg.id);
if (!el) return;
const url = estado.iconosBotones && estado.iconosBotones[clave];
if (url){
el.innerHTML = '';
el.style.backgroundImage = `url('${url}')`;
el.style.backgroundSize = 'cover';
el.style.backgroundPosition = 'center';
} else {
el.style.backgroundImage = '';
el.innerHTML = `<i class="fa-solid ${cfg.icono}"></i>`;
}
});
}
function cortoModulo(letra){ return tr('mod_' + letra + '_corto'); }
function aplicarIdioma(){
document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = tr(el.getAttribute('data-i18n')); });
document.querySelectorAll('[data-i18n-html]').forEach(el => { el.innerHTML = tr(el.getAttribute('data-i18n-html')); });
document.querySelectorAll('[data-i18n-placeholder]').forEach(el => { el.setAttribute('placeholder', tr(el.getAttribute('data-i18n-placeholder'))); });
document.querySelectorAll('[data-i18n-title]').forEach(el => { el.setAttribute('title', tr(el.getAttribute('data-i18n-title'))); });
document.querySelectorAll('.idioma-opcion').forEach(b => b.classList.toggle('idioma-activa', b.dataset.idioma === idiomaActual));
const etiquetasIdioma = { es:'ESP', en:'ENG', de:'DEU', pd:'PDS' }; document.querySelectorAll('.idioma-actual-label').forEach(el => { el.textContent = etiquetasIdioma[idiomaActual] || 'ESP'; });
function safeRender(fn){ if (typeof fn === 'function'){ try{ fn(); }catch(e){ console.warn('aplicarIdioma: fallo repintando', fn.name, e); } } }
[renderNavbar, renderTiles, renderGlosario, renderResumenProductor, renderTarjetaDatosGenerales,
renderHato, renderModulo, renderMisTareas, renderEngorda, renderInventarioAlimento, renderAlertasBodega,
renderCarruselBoletines, renderBoletines, actualizarGraficas, renderIndicadores, renderTimelineFechas,
renderVisitasVet, renderPanelIndicadoresLeche, renderPanelCrecimiento, renderPanelFinanciero,
renderGridAdminHome, renderListaPredios, renderListaCefpp, renderMensajes,
renderTodoAdmin, renderResumenAdmin, renderListaUsuarios, renderMetricasCuentas, renderProximosAVencer,
renderListadoCuentas, renderCuentas, renderInfoSistema, renderAuditoriaTransferencias, renderTogglesModulos, renderTogglesPermisosTrabajador,
renderListaOrdenMas, renderListaOrdenGraficas, renderListaPlanSanitario, renderListaTrabajadores,
renderListaTareasAdmin, renderTogglesCampos, renderTogglesVentanasExtra, renderNotasVentana,
renderListaBanners, renderBannerHome, renderBoletinesAdmin, renderCalendario, renderAlertasMotor,
renderAnimalesEnfermos, renderNotificaciones, renderSolicitudesTransferencia, renderActividadesRecientesHome, pintarClimaHome,
actualizarBadgeNotificaciones, actualizarBannerConexion
].forEach(safeRender);
}
function cambiarIdioma(idioma){
idiomaActual = idioma;
try { localStorage.setItem('miRanchAppIdioma', idioma); } catch(e){}
aplicarIdioma();
cerrarSelectorIdioma();
if (typeof mostrarToast === 'function') mostrarToast(tr('idioma') + ': ' + idioma.toUpperCase());
if (typeof hablarMoonitorSiEstaVisible === 'function') hablarMoonitorSiEstaVisible();
}
function toggleSelectorIdioma(){
document.querySelectorAll('.menu-idioma').forEach(menu => menu.classList.toggle('hidden'));
}
function cerrarSelectorIdioma(){
document.querySelectorAll('.menu-idioma').forEach(menu => menu.classList.add('hidden'));
}
function renderGlosario(){
const cont = document.getElementById('lista-glosario');
if (!cont) return;
const claves = ['gl_hato','gl_arete_siniiga','gl_control_lechero','gl_registro_partos','gl_inseminacion','gl_empadre','gl_gestacion','gl_estatus_sanitario','gl_vacunacion','gl_desparasitacion','gl_potrero','gl_lote','gl_destete','gl_calostro','gl_gdp'];
cont.innerHTML = claves.map(c => `
<div class="item-registro">
<p class="font-bold">${I18N.es[c]}</p>
<p class="text-sm" style="color:var(--sage);"><i class="fa-solid fa-flag" style="width:16px;"></i> EN: ${I18N.en[c]}</p>
<p class="text-sm" style="color:var(--sage);"><i class="fa-solid fa-flag" style="width:16px;"></i> DE: ${I18N.de[c]}</p>
</div>`).join('');
}
let appVisibleAntesGlosario = null;
function abrirGlosario(){
const productor = document.getElementById('app-productor');
const admin = document.getElementById('app-admin');
appVisibleAntesGlosario = productor && !productor.classList.contains('hidden') ? 'app-productor' : 'app-admin';
if (productor) productor.classList.add('hidden');
if (admin) admin.classList.add('hidden');
const pantalla = document.getElementById('screen-glosario');
if (pantalla) pantalla.style.display = 'block';
renderGlosario();
}
function cerrarGlosario(){
const pantalla = document.getElementById('screen-glosario');
if (pantalla) pantalla.style.display = 'none';
if (appVisibleAntesGlosario){
const app = document.getElementById(appVisibleAntesGlosario);
if (app) app.classList.remove('hidden');
}
}
function formatoFechaHora(){
const d = new Date();
const pad = n => String(n).padStart(2,'0');
return `${pad(d.getDate())}/${pad(d.getMonth()+1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}
async function generarPDFConPie(titulo, encabezados, filas){
try {
await cargarJsPDFSiNecesario();
const { jsPDF } = window.jspdf;
const doc = new jsPDF({ orientation: filas.length && encabezados.length > 6 ? 'landscape' : 'portrait' });
doc.setFontSize(14);
doc.text(titulo, 14, 16);
doc.autoTable({
head: [encabezados],
body: filas.map(f => f.map(v => (v === null || v === undefined) ? '' : String(v))),
startY: 22,
styles: { fontSize: 8 },
headStyles: { fillColor: [31,58,46] },
didDrawPage: function(data){
const alturaPagina = doc.internal.pageSize.getHeight();
const anchoPagina = doc.internal.pageSize.getWidth();
try { doc.addImage(LOGO_B64, 'JPEG', 14, alturaPagina - 16, 10, 10); } catch(e){}
doc.setFontSize(8);
doc.setTextColor(120);
doc.text(`MiRanch — ${tr('exp_generado')}: ${formatoFechaHora()}`, 27, alturaPagina - 10);
doc.text(tr('exp_marca'), 27, alturaPagina - 6);
doc.text(tr('exportacion_pie_pagina__pag') + ' ' + doc.internal.getNumberOfPages(), anchoPagina - 22, alturaPagina - 8);
},
margin: { bottom: 22 }
});
doc.save(titulo.toLowerCase().replace(/[^a-z0-9]+/g,'-') + '.pdf');
if (typeof mostrarToast === 'function') mostrarToast(tr('exportacion_pie_pagina__pdf_exportado'));
} catch(e){
console.warn('No se pudo generar el PDF', e);
if (typeof mostrarToast === 'function') mostrarToast('No se pudo generar el PDF — revisa tu conexión e inténtalo otra vez');
}
}
async function generarExcelConPie(titulo, encabezados, filas){
// ExcelJS y FileSaver son pesadas y solo hacen falta aquí — se descargan la
// primera vez que alguien exporta a Excel, no en cada apertura de la app.
try {
if (typeof mostrarToast === 'function') mostrarToast('Preparando Excel...');
await Promise.all([cargarExcelJSSiNecesario(), cargarFileSaverSiNecesario()]);
const workbook = new ExcelJS.Workbook();
const hoja = workbook.addWorksheet(titulo.substring(0,31) || 'Reporte');
hoja.addRow(encabezados).font = { bold: true };
filas.forEach(f => hoja.addRow(f));
hoja.columns.forEach(col => { col.width = 18; });
hoja.addRow([]);
const filaPie1 = hoja.addRow([`MiRanch — ${tr('exp_generado')}: ${formatoFechaHora()}`]);
filaPie1.font = { italic: true, size: 9, color: { argb: 'FF5C6B55' } };
const filaPie2 = hoja.addRow([tr('exp_marca')]);
filaPie2.font = { italic: true, size: 9, color: { argb: 'FF5C6B55' } };
try {
const imgId = workbook.addImage({ base64: LOGO_B64, extension: 'jpeg' });
hoja.addImage(imgId, { tl: { col: encabezados.length + 1, row: 0 }, ext: { width: 60, height: 60 } });
} catch(e){}
const buffer = await workbook.xlsx.writeBuffer();
const blob = new Blob([buffer], { type: 'application/octet-stream' });
saveAs(blob, titulo.toLowerCase().replace(/[^a-z0-9]+/g,'-') + '.xlsx');
if (typeof mostrarToast === 'function') mostrarToast(tr('exportacion_pie_pagina__excel_exportado'));
} catch(e){
console.warn('No se pudo generar el Excel', e);
if (typeof mostrarToast === 'function') mostrarToast('No se pudo generar el Excel — revisa tu conexión e inténtalo otra vez');
}
}
function generarCSVConPie(titulo, encabezados, filas){
const filasTexto = [encabezados, ...filas].map(f => f.map(v => `"${(v ?? '').toString().replace(/"/g,'""')}"`).join(','));
filasTexto.push('');
filasTexto.push(`"MiRanch — ${tr('exp_generado')}: ${formatoFechaHora()}"`);
filasTexto.push(`"${tr('exp_marca')}"`);
const csv = filasTexto.join('\n');
const blob = new Blob(['\ufeff' + csv], { type:'text/csv;charset=utf-8;' });
const url = URL.createObjectURL(blob);
const a = document.createElement('a');
a.href = url; a.download = titulo.toLowerCase().replace(/[^a-z0-9]+/g,'-') + '.csv';
a.click();
URL.revokeObjectURL(url);
if (typeof mostrarToast === 'function') mostrarToast(tr('exportacion_pie_pagina__csv_exportado'));
}
const EXPORT_REGISTRY = {};
let exportPendiente = null;
function abrirMenuExportar(clave){
exportPendiente = clave;
const modal = document.getElementById('modal-exportar');
if (modal) modal.classList.remove('hidden');
}
function cerrarMenuExportar(){
const modal = document.getElementById('modal-exportar');
if (modal) modal.classList.add('hidden');
exportPendiente = null;
}
function ejecutarExportar(formato){
if (!exportPendiente) return;
const fn = EXPORT_REGISTRY[exportPendiente];
if (!fn){ cerrarMenuExportar(); return; }
const cfg = fn();
if (!cfg || !cfg.filas || cfg.filas.length === 0){
if (typeof mostrarToast === 'function') mostrarToast(tr('exportacion_pie_pagina__no_hay_registros_para_exportar'));
cerrarMenuExportar();
return;
}
if (formato === 'csv') generarCSVConPie(cfg.titulo, cfg.encabezados, cfg.filas);
else if (formato === 'excel') generarExcelConPie(cfg.titulo, cfg.encabezados, cfg.filas);
else if (formato === 'pdf') generarPDFConPie(cfg.titulo, cfg.encabezados, cfg.filas);
cerrarMenuExportar();
}
const parametrosURLInicio = new URLSearchParams(window.location.search);
const quiereAbrirChatDirecto = parametrosURLInicio.get('abrir') === 'chat';
const estado = {
rolActual: 'productor', 
productor: {
nombre:'', apellidoPaterno:'', apellidoMaterno:'', nombres:'',
domicilio:'Conocido', localidad:'', correoElectronico:'',
predio:'', upp:'', folio:'', estado:'', municipio:'', ejido:'', actividad:'',
latitudUPP:null, longitudUPP:null, codigoPostal:'', fierroImagen:null,
suscripcion: { fechaAlta: null, diasVigencia: 365, fechaVencimiento: null },
camposPersonalizados: {},
},
configuracion: { fondoHome: null, fondoHeader: null, logoPersonalizado: null },
cuentasProductores: [],
cuentasProductivas: [], // alias explícito del modelo: una persona puede tener múltiples UPP independientes.
referral: { codigo: null, invitadorId: null, activadoDesde: null, recompensasDias: 0 },
// Identidad única de la persona; los perfiles y organizaciones no crean usuarios duplicados.
personaMiRanch: { id:null, uid:null, nombre:'', telefono:'', telefonoVerificado:false, correo:'' },
perfilesIdentidad: [],
organizaciones: [],
membresiasOrganizacion: [],
contextoActivo: { tipo:'perfil', id:'productor' },
// Productores que este admin/veterinario/comité ya confirmó por "Buscar
// amigos" (encontrados entre sus propios contactos del celular) — la
// bandeja de mensajes solo muestra gente de esta lista (o con quien ya
// haya conversación empezada), nunca el directorio completo de todos los
// productores del sistema. Así, una cuenta nueva no puede simplemente
// navegar y escribirle a cualquiera — primero tiene que encontrarlo entre
// sus contactos reales.
contactosVerificadosChat: [],
// Cuando está en true, la app está mostrando una vista de ejemplo (modo
// demo) — ningún guardado real se dispara mientras esto sea true.
modoDemoActivo: false,
// Última copia guardada del inventario de animales de cada productor, tomada
// la última vez que hubo señal — para que la búsqueda de arete en pruebas de
// campo (TB/Brucelosis) siga funcionando aunque el médico entre sin conexión.
// Clave: id de la cuenta del productor. No sustituye el dato en vivo — solo
// es respaldo para cuando no hay forma de traerlo de Firebase en ese momento.
inventariosOfflineProductores: {},
veterinarios: [],
vistaVeterinario: false,
veterinarioActivoId: null,
zonasAtencionDisponibles: ['Zona Norte','Zona Sur','Zona Centro','Zona Oriente','Zona Poniente'],
relojSimulado: null, 
visibilidad: {
hato:true, graficas:true, boletines:true, reporte:true,
moduloA:true, moduloB:true, moduloC:true, moduloD:true, moduloE:true, moduloF:true, moduloG:true, moduloH:true, moduloI:true, moduloJ:true, moduloK:true,
},
iconosBotones: { hato:'', A:'', B:'', C:'', D:'', E:'', F:'', G:'', H:'', I:'', J:'', K:'', calendario:'', visitas:'', engorda:'', tareas:'', transferencias:'',
adm_cuentas:'', adm_usuarios:'', adm_productor:'', adm_boletines:'', adm_config:'',
vet_boletines:'', vet_pacientes:'', vet_notas:'', vet_pruebascampo:'',
q_recepcion:'', q_reportes:'', q_productores:'' },
camposPersonalizadosDef: [],
camposProductor: { nombre:true, predio:true, upp:true, actualizacionUPP:true, folio:true, vencimientoFierro:true, estado:true, municipio:true, ejido:true, curp:true, actividad:true, animales:true },
permisosTrabajador: { moduloA:true, moduloB:true, moduloC:false, moduloD:true, moduloE:false, moduloF:false, moduloG:false, moduloH:false, moduloI:false, moduloJ:false, moduloK:false },
ventanasExtra: [],
banners: [],
predios: [],
modoVeterinario: false,
modoCapturista: false,
modoAlmita: false,
pushActivado: false,
mensajes: [],
visitasVet: [],
ordenMas: ['hato','A','B','C','D','E','F','G','H','I','J','K'],
ordenGraficas: ['indicadoresLeche','crecimiento','financiero','sexo','prenez','pesajes','costos','fechas','potreros','gastosingresos','edades','bajas'],
visibilidadGraficas: { indicadoresLeche:true, crecimiento:true, financiero:true, sexo:true, prenez:true, pesajes:true, costos:true, fechas:true, potreros:true, gastosingresos:true, edades:true, bajas:true },
tipoGanado: null,
produccionLeche: [],
// Catálogo de sementales/pajillas de inseminación — nombre, raza, dosis
// disponibles. Se descuenta sola una dosis cada vez que se registra un
// servicio de inseminación artificial con ese semental.
sementales: [],
// Catálogo de clientes y proveedores — nombre, tipo (cliente/proveedor),
// teléfono, notas. Se usa para ligar movimientos de dinero a alguien
// concreto y poder generarle un recibo/factura simple en PDF.
contactosComerciales: [],
// Métodos de pago de la SUSCRIPCIÓN de la app (tarjeta/CLABE, QR, referencia
// OXXO) — el productor siempre ve solo el que esté marcado "activo" aquí.
// Cambiar de tarjeta cuando una se satura es marcar otra como activa, nunca
// tocar el código.
metodosPago: [],
// Confirmaciones de pago que mandan los productores (foto del ticket + su
// número de folio) para que el admin las revise y extienda la suscripción a
// mano. Cada folio solo puede aparecer UNA vez en todo el sistema — así
// nadie puede mandar el mismo comprobante fingiendo que pagó dos veces, ni
// que dos productores distintos manden el mismo ticket.
solicitudesPago: [],
tanqueLeche: [],
alimentacionLeche: [],
becerros: [],
inventarioAlimento: [],
ultimaSemanaResumen: null,
trabajadores: [],
tareas: [],
planSanitario: [],
ultimoAvisoPlanSanitario: {},
modoTrabajador: false,
trabajadorActualId: null,
animales: [], salud: [], reproduccion: [], pesajes: [], potreros: [], costos: [], boletines: [],
bodega: [], 
movimientosAnimal: [], 
colaSincronizacion: [], 
ultimaSincronizacion: null,
};
estado.cuentaActivaId = null;
estado.contextoActivo = { tipo:'perfil', id:'productor' };
estado.puntoActivoId = null;
estado.solicitudesTransferencia = []; 
estado.auditoriaTransferencias = [];  
estado.queseria = { nombre: '', operadorActivo: null, rolActivoQueseria: null, usuarioAdmin: 'quesero', claveAdminHash: '707628f73a7e03b4b13ab34ab48ca87f03c3c5227eb27948cb17c3f4ffd75403', claveAdminSalt: 'queseria-admin-v1', claveIteraciones: 120000, claveAlg:'PBKDF2-SHA256' };
estado.operadoresQueseria = [
{ id:'op1', nombre:'Operador 1', usuario:'operador1', claveHash:'da5ab05a24de47bfbf7fb104dd8729046bf1e3b46932d209454a2d93c445a816', claveSalt:'op1-v1', claveIteraciones:120000, claveAlg:'PBKDF2-SHA256' },
{ id:'op2', nombre:'Operador 2', usuario:'operador2', claveHash:'ee941daba378d8b55f0534b2d37beb24eec16f838b30c897f9e6b9c6a7defe47', claveSalt:'op2-v1', claveIteraciones:120000, claveAlg:'PBKDF2-SHA256' },
{ id:'op3', nombre:'Operador 3', usuario:'operador3', claveHash:'c33d6b9915afe6611c7ff874f1409804bfec7f4a5da90222e787c9526485ec5c', claveSalt:'op3-v1', claveIteraciones:120000, claveAlg:'PBKDF2-SHA256' },
];
estado.lecheros = [];
estado.productoresLeche = [];
estado.recepcionesLeche = [];
estado.solicitudesVinculacionLeche = [];
estado.solicitudesRegistro = [];
estado.mensajesPorProductor = {};
estado.chatMetaPorProductor = {};
// Versión "resumen" y liviana de los chats — solo el último mensaje y cuántos
// sin leer tiene cada conversación, NO la conversación completa. Esto es lo
// único de mensajes que vive en la cola de administración (así el admin
// arma su bandeja de entrada sin tener que cargar los 300 chats completos);
// cada conversación completa vive en su propio documento aparte, y solo la
// abren los 2 que participan en ella.
estado.resumenMensajes = {};
estado.pruebasCampoVet = [];
estado.solicitudesAretes = [];
estado.solicitudesPrueba = [];
estado.solicitudesCEFP = [];
estado.reportesRecibidosComiteTB = [];
estado.flujosPendientesEnvio = [];
estado.enviosAlmita = [];
estado.solicitudesCEFPPVet = [];
estado.plantillasMensajes = [];
estado.mensajesProgramados = [];
estado.eventosUso = [];
// ================= MÓDULO TB — avisos de reactores + médicos de campo del comité =================
estado.avisosReactoresTB = [];
estado.medicosComiteTB = [];
estado.modoMedicoCampoTB = false;
estado.medicoComiteActivoId = null;
estado.modoCapturistaTB = false;
estado.modoComite = false;
estado.bitacoraVoz = [];
estado.moonitor = { imagenDefault: null, imagenCarne: null, imagenLeche: null, recordatorioCompartirActivo: false, diaRecordatorioCompartir: 1, ultimoRecordatorioCompartir: null, sonidoActivado: true };
const HATO_DEMO = estado.animales;
const SALUD_DEMO = estado.salud;
const PESAJES_DEMO = estado.pesajes;
const REPRODUCCION_DEMO = estado.reproduccion;
function obtenerArraysDeCuenta(cuentaId){
if (!cuentaId) return { animales: estado.animales, salud: estado.salud, pesajes: estado.pesajes, reproduccion: estado.reproduccion };
if (!Array.isArray(estado.cuentasProductores)) estado.cuentasProductores = [];
const cuenta = estado.cuentasProductores.find(c => c && c.id === cuentaId);
if (!cuenta) return { animales: [], salud: [], pesajes: [], reproduccion: [] };
if (!Array.isArray(cuenta.hato)) cuenta.hato = [];
if (!Array.isArray(cuenta.salud)) cuenta.salud = [];
if (!Array.isArray(cuenta.pesajes)) cuenta.pesajes = [];
if (!Array.isArray(cuenta.reproduccion)) cuenta.reproduccion = [];
return { animales: cuenta.hato, salud: cuenta.salud, pesajes: cuenta.pesajes, reproduccion: cuenta.reproduccion };
}
function buscarAreteEnOtraUPP(arete){
if (!arete || !Array.isArray(estado.cuentasProductores)) return null;
for (const cuenta of estado.cuentasProductores){
if (!cuenta || cuenta.id === estado.cuentaActivaId) continue; 
const animal = (Array.isArray(cuenta.hato) ? cuenta.hato : []).find(a => a && a.arete === arete);
if (animal) return { cuentaId: cuenta.id, upp: cuenta.upp, nombre: cuenta.nombre, predio: cuenta.predio, animal };
}
return null;
}
let conflictoAretePendiente = null;
function mostrarConflictoArete(arete, conflicto){
conflictoAretePendiente = {
arete,
cuentaPropietariaId: conflicto.cuentaId,
uppPropietario: conflicto.upp,
nombrePropietario: conflicto.nombre,
predioPropietario: conflicto.predio,
};
document.getElementById('texto-conflicto-arete').textContent =
tr('modal_conflicto__texto').replace('%VAR%', arete).replace('%VAR%', conflicto.predio).replace('%VAR%', conflicto.upp).replace('%VAR%', conflicto.nombre);
document.getElementById('modal-conflicto-arete').classList.remove('hidden');
}
function cerrarModalConflictoArete(){
document.getElementById('modal-conflicto-arete').classList.add('hidden');
conflictoAretePendiente = null;
}
function solicitarTransferenciaArete(){
if (!conflictoAretePendiente) return;
const solicitud = {
id: 'sol_' + Date.now(),
arete: conflictoAretePendiente.arete,
cuentaSolicitanteId: estado.cuentaActivaId,
uppSolicitante: estado.productor.upp || tr('transferencia_autonoma_aretes__sin_upp'),
nombreSolicitante: estado.productor.nombre || 'Productor',
predioSolicitante: estado.productor.predio || '',
cuentaPropietarioId: conflictoAretePendiente.cuentaPropietariaId,
uppPropietario: conflictoAretePendiente.uppPropietario,
nombrePropietario: conflictoAretePendiente.nombrePropietario,
fecha: hoyISO(),
hora: new Date().toTimeString().slice(0,5),
estatus: 'pendiente',
};
estado.solicitudesTransferencia.push(solicitud);
cerrarModalConflictoArete();
mostrarToast(`Solicitud enviada a ${solicitud.nombrePropietario} para el arete ${solicitud.arete}`);
renderSolicitudesTransferencia();
guardarEnColaAdminComoProductor('solicitudesTransferencia');
}
function estaSolicitudMeAtane(s){ 
return estado.cuentaActivaId ? s.cuentaPropietarioId === estado.cuentaActivaId : s.uppPropietario === estado.productor.upp;
}
function esMiSolicitudEnviada(s){ 
return estado.cuentaActivaId ? s.cuentaSolicitanteId === estado.cuentaActivaId : s.uppSolicitante === estado.productor.upp;
}
function autorizarTransferencia(id){
const s = estado.solicitudesTransferencia.find(x => x.id === id);
if (!s || s.estatus !== 'pendiente') return;
const origen = obtenerArraysDeCuenta(s.cuentaPropietarioId);
const destino = obtenerArraysDeCuenta(s.cuentaSolicitanteId);
const idxAnimal = origen.animales.findIndex(a => a.arete === s.arete);
if (idxAnimal === -1){
mostrarToast(tr('transferencia_autonoma_aretes__el_animal_ya_no_esta'));
s.estatus = 'rechazada';
renderSolicitudesTransferencia();
return;
}
const [animal] = origen.animales.splice(idxAnimal, 1);
destino.animales.push(animal);
const claveArete = animal.arete, claveNombre = animal.nombre;
['salud','pesajes','reproduccion'].forEach(campo => {
const quedan = [];
origen[campo].forEach(r => {
const pertenece = r.animal === claveArete || (claveNombre && r.animal === claveNombre);
if (pertenece) destino[campo].push(r); else quedan.push(r);
});
origen[campo].length = 0;
origen[campo].push(...quedan);
});
s.estatus = 'aprobada';
s.fechaResolucion = hoyISO();
s.horaResolucion = new Date().toTimeString().slice(0,5);
estado.auditoriaTransferencias.push({
id: 'aud_' + Date.now(),
arete: s.arete,
uppOrigen: s.uppPropietario, uppDestino: s.uppSolicitante,
productorOrigen: s.nombrePropietario, productorDestino: s.nombreSolicitante,
fecha: s.fechaResolucion, hora: s.horaResolucion,
});
renderSolicitudesTransferencia();
if (typeof renderHato === 'function') renderHato();
renderResumenVientresToros();
if (typeof renderResumenProductor === 'function') renderResumenProductor();
mostrarToast(`Transferencia autorizada: el arete ${s.arete} ahora pertenece a ${s.nombreSolicitante}`);
}
function rechazarTransferencia(id){
const s = estado.solicitudesTransferencia.find(x => x.id === id);
if (!s || s.estatus !== 'pendiente') return;
s.estatus = 'rechazada';
s.fechaResolucion = hoyISO();
renderSolicitudesTransferencia();
mostrarToast(tr('transferencia_autonoma_aretes__solicitud_rechazada'));
}
function actualizarBadgeTransferencias(){
const badge = document.getElementById('badge-transferencias');
if (!badge) return;
const n = estado.solicitudesTransferencia.filter(s => s.estatus === 'pendiente' && estaSolicitudMeAtane(s)).length;
badge.classList.toggle('hidden', n === 0);
badge.textContent = n;
}
function renderSolicitudesTransferencia(){
const contRecibidas = document.getElementById('lista-transferencias-recibidas');
const contEnviadas = document.getElementById('lista-transferencias-enviadas');
actualizarBadgeTransferencias();
if (!contRecibidas || !contEnviadas) return;
const recibidas = estado.solicitudesTransferencia.filter(s => s.estatus === 'pendiente' && estaSolicitudMeAtane(s));
const enviadas = estado.solicitudesTransferencia.filter(esMiSolicitudEnviada).sort((a,b) => (b.fecha + b.hora).localeCompare(a.fecha + a.hora));
contRecibidas.innerHTML = recibidas.length === 0
? `<div class="vacio"><i class="fa-solid fa-inbox"></i><p>${tr('transferencia_autonoma_aretes__no_tienes_solicitudes_de_transfere')}</p></div>`
: recibidas.map(s => `
<div class="item-registro" style="border-left:6px solid var(--orange);">
<p class="font-bold">${tr('transferencia_autonoma_aretes__arete').replace('%VAR%', s.arete)}</p>
<p class="text-sm" style="color:var(--sage);">${tr('transferencia_autonoma_aretes__el_productor_del_predio_upp').replace('%VAR%', s.predioSolicitante || s.uppSolicitante).replace('%VAR%', s.uppSolicitante)}</p>
<div class="flex gap-2 mt-3">
<button onclick="autorizarTransferencia('${s.id}')" class="flex-1 text-sm font-bold px-3 py-2 rounded-full" style="background:var(--green); color:#fff;"><i class="fa-solid fa-check"></i> ${tr('csv_extra6__si_boton')}</button>
<button onclick="rechazarTransferencia('${s.id}')" class="flex-1 text-sm font-bold px-3 py-2 rounded-full" style="background:var(--parchment); color:var(--red); border:2px solid var(--line);"><i class="fa-solid fa-xmark"></i> ${tr('csv_extra6__no_boton')}</button>
</div>
</div>`).join('');
const ETQ = { pendiente: tr('csv_extra6__pendiente'), aprobada: tr('transferencia_autonoma_aretes__aprobada_transferido'), rechazada: tr('csv_extra6__rechazada') };
const COL = { pendiente:'var(--yellow)', aprobada:'var(--green)', rechazada:'var(--red)' };
contEnviadas.innerHTML = enviadas.length === 0
? `<div class="vacio"><i class="fa-solid fa-paper-plane"></i><p>${tr('transferencia_autonoma_aretes__no_has_enviado_solicitudes_de')}</p></div>`
: enviadas.map(s => `
<div class="item-registro" style="border-left:6px solid ${COL[s.estatus]};">
<p class="font-bold">${tr('transferencia_autonoma_aretes__arete').replace('%VAR%', s.arete)} <span class="text-xs px-2 py-0.5 rounded-full ml-1" style="background:${COL[s.estatus]}; color:#fff;">${ETQ[s.estatus]}</span></p>
<p class="text-sm" style="color:var(--sage);">${tr('transferencia_autonoma_aretes__solicitado_a_upp').replace('%VAR%', s.nombrePropietario).replace('%VAR%', s.uppPropietario).replace('%VAR%', s.fecha).replace('%VAR%', s.hora)}</p>
</div>`).join('');
}
const CLAVE_ALMACENAMIENTO_LOCAL = 'mi_ranchapp_estado_v1';
function cargarEstadoLocal(){
try {
const guardado = localStorage.getItem(CLAVE_ALMACENAMIENTO_LOCAL);
if (!guardado) return;
const datos = JSON.parse(guardado);
Object.assign(estado, datos);
normalizarEstadoCargado();
if (estado.cuentaActivaId && Array.isArray(estado.cuentasProductores)){
const cuenta = estado.cuentasProductores.find(c => c && c.id === estado.cuentaActivaId);
if (cuenta){
cargarDatosDeCuenta(cuenta);
} else {
estado.cuentaActivaId = null;
}
}
} catch(e){
console.warn('No se pudo cargar el estado guardado localmente', e);
}
}
function normalizarEstadoCargado(){
// El modo demo NUNCA debe quedar guardado de un uso anterior — si por
// cualquier bug de una versión vieja se llegó a guardar como "true" alguna
// vez, se quedaría así para siempre y ninguna corrección de rutas de
// navegación lo alcanzaría a arreglar, porque el problema no es por dónde
// se navega, es lo que se carga desde el celular al abrir la app. Aquí se
// fuerza a "false" siempre, sin excepción, cada vez que se abre la app.
estado.modoDemoActivo = false;
const arreglos = ['animales','salud','reproduccion','pesajes','potreros','costos','boletines',
'bodega','movimientosAnimal','colaSincronizacion','cuentasProductores','solicitudesTransferencia',
'auditoriaTransferencias','usuarios','trabajadores','veterinarios','tareas','planSanitario','mensajes','visitasVet',
'predios','banners','ventanasExtra','produccionLeche','tanqueLeche','alimentacionLeche','becerros',
'inventarioAlimento','lecheros','productoresLeche','recepcionesLeche','solicitudesVinculacionLeche','solicitudesRegistro','solicitudesPago','contactosVerificadosChat'];
arreglos.forEach(clave => { if (!Array.isArray(estado[clave])) estado[clave] = []; });
estado.relojSimulado = null;
if (!estado.configuracion || typeof estado.configuracion !== 'object') estado.configuracion = { fondoHome: null, fondoHeader: null, logoPersonalizado: null };
if (!('logoPersonalizado' in estado.configuracion)) estado.configuracion.logoPersonalizado = null;
if (!('fondoHeader' in estado.configuracion)) estado.configuracion.fondoHeader = null;
if (!estado.queseria || typeof estado.queseria !== 'object') estado.queseria = { nombre: '', operadorActivo: null, rolActivoQueseria: null, usuarioAdmin: 'quesero', claveAdminHash: '707628f73a7e03b4b13ab34ab48ca87f03c3c5227eb27948cb17c3f4ffd75403', claveAdminSalt: 'queseria-admin-v1', claveIteraciones: 120000, claveAlg:'PBKDF2-SHA256' };
if (!Array.isArray(estado.operadoresQueseria) || estado.operadoresQueseria.length === 0) estado.operadoresQueseria = [{ id:'op1', nombre:'Operador 1', usuario:'operador1', claveHash:'da5ab05a24de47bfbf7fb104dd8729046bf1e3b46932d209454a2d93c445a816', claveSalt:'op1-v1', claveIteraciones:120000, claveAlg:'PBKDF2-SHA256' },{ id:'op2', nombre:'Operador 2', usuario:'operador2', claveHash:'ee941daba378d8b55f0534b2d37beb24eec16f838b30c897f9e6b9c6a7defe47', claveSalt:'op2-v1', claveIteraciones:120000, claveAlg:'PBKDF2-SHA256' },{ id:'op3', nombre:'Operador 3', usuario:'operador3', claveHash:'c33d6b9915afe6611c7ff874f1409804bfec7f4a5da90222e787c9526485ec5c', claveSalt:'op3-v1', claveIteraciones:120000, claveAlg:'PBKDF2-SHA256' }];
if (!estado.queseria.usuarioAdmin){ estado.queseria.usuarioAdmin = 'quesero'; estado.queseria.claveAdminHash = '707628f73a7e03b4b13ab34ab48ca87f03c3c5227eb27948cb17c3f4ffd75403'; estado.queseria.claveAdminSalt='queseria-admin-v1'; estado.queseria.claveIteraciones=120000; estado.queseria.claveAlg='PBKDF2-SHA256'; }
if (!estado.moonitor || typeof estado.moonitor !== 'object') estado.moonitor = { imagenDefault: null, imagenCarne: null, imagenLeche: null, recordatorioCompartirActivo: false, diaRecordatorioCompartir: 1, ultimoRecordatorioCompartir: null, sonidoActivado: true };
if (!estado.iconosBotones || typeof estado.iconosBotones !== 'object') estado.iconosBotones = {};
['hato','A','B','C','D','E','F','G','H','I','J','K','calendario','visitas','engorda','tareas','transferencias',
'adm_cuentas','adm_usuarios','adm_productor','adm_boletines','adm_config',
'vet_boletines','vet_pacientes','vet_notas','vet_pruebascampo',
'q_recepcion','q_reportes','q_productores',
'reg_leche','reg_carne','reg_punto','reg_mvz','reg_cefp'].forEach(k => { if (!(k in estado.iconosBotones)) estado.iconosBotones[k] = ''; });
if (!Array.isArray(estado.camposPersonalizadosDef)) estado.camposPersonalizadosDef = [];
if (!estado.productor.camposPersonalizados || typeof estado.productor.camposPersonalizados !== 'object') estado.productor.camposPersonalizados = {};
if (!estado.productor.domicilio) estado.productor.domicilio = 'Conocido';
if (!('apellidoPaterno' in estado.productor)) estado.productor.apellidoPaterno = '';
if (!('apellidoMaterno' in estado.productor)) estado.productor.apellidoMaterno = '';
if (!('nombres' in estado.productor)) estado.productor.nombres = '';
if (!('localidad' in estado.productor)) estado.productor.localidad = '';
if (!('correoElectronico' in estado.productor)) estado.productor.correoElectronico = '';
if (!('latitudUPP' in estado.productor)) estado.productor.latitudUPP = null;
if (!('longitudUPP' in estado.productor)) estado.productor.longitudUPP = null;
if (!('codigoPostal' in estado.productor)) estado.productor.codigoPostal = '';
if (!('fierroImagen' in estado.productor)) estado.productor.fierroImagen = null;
if (!Array.isArray(estado.sementales)) estado.sementales = [];
if (!Array.isArray(estado.contactosComerciales)) estado.contactosComerciales = [];
if (!Array.isArray(estado.metodosPago)) estado.metodosPago = [];
if (typeof estado.moonitor.sonidoActivado !== 'boolean') estado.moonitor.sonidoActivado = true;
if (!('puntoActivoId' in estado)) estado.puntoActivoId = null;
if (!estado.permisosTrabajador || typeof estado.permisosTrabajador !== 'object') estado.permisosTrabajador = { moduloA:true, moduloB:true, moduloC:false, moduloD:true, moduloE:false, moduloF:false, moduloG:false, moduloH:false, moduloI:false, moduloJ:false, moduloK:false };
if (!estado.mensajesPorProductor || typeof estado.mensajesPorProductor !== 'object') estado.mensajesPorProductor = {};
if (!estado.resumenMensajes || typeof estado.resumenMensajes !== 'object') estado.resumenMensajes = {};
if (!Array.isArray(estado.pruebasCampoVet)) estado.pruebasCampoVet = [];
if (!Array.isArray(estado.solicitudesAretes)) estado.solicitudesAretes = [];
if (!Array.isArray(estado.solicitudesPrueba)) estado.solicitudesPrueba = [];
if (!Array.isArray(estado.solicitudesCEFP)) estado.solicitudesCEFP = [];
if (!Array.isArray(estado.avisosReactoresTB)) estado.avisosReactoresTB = [];
if (!Array.isArray(estado.medicosComiteTB)) estado.medicosComiteTB = [];
if (typeof estado.modoMedicoCampoTB !== 'boolean') estado.modoMedicoCampoTB = false;
if (!('medicoComiteActivoId' in estado)) estado.medicoComiteActivoId = null;
if (typeof estado.modoCapturistaTB !== 'boolean') estado.modoCapturistaTB = false;
if (typeof estado.modoComite !== 'boolean') estado.modoComite = false;
if (!Array.isArray(estado.bitacoraVoz)) estado.bitacoraVoz = [];
if (!Array.isArray(estado.enviosAlmita)) estado.enviosAlmita = [];
if (!Array.isArray(estado.solicitudesCEFPPVet)) estado.solicitudesCEFPPVet = [];
if (!Array.isArray(estado.historialImpresiones)) estado.historialImpresiones = [];
if (!Array.isArray(estado.plantillasMensajes)) estado.plantillasMensajes = [];
if (!Array.isArray(estado.mensajesProgramados)) estado.mensajesProgramados = [];
if (!Array.isArray(estado.eventosUso)) estado.eventosUso = [];
if (!estado.productor || typeof estado.productor !== 'object') estado.productor = {};
if (!validarFechaISO(estado.productor.suscripcion && estado.productor.suscripcion.fechaVencimiento)){
estado.productor.suscripcion = { fechaAlta: hoyISO(), diasVigencia: 365, fechaVencimiento: sumarDiasISO(hoyISO(), 365) };
}
(estado.cuentasProductores || []).forEach(c => {
if (!c) return;
if (!Array.isArray(c.hato)) c.hato = [];
if (!Array.isArray(c.salud)) c.salud = [];
if (!Array.isArray(c.pesajes)) c.pesajes = [];
if (!Array.isArray(c.reproduccion)) c.reproduccion = [];
if (!c.suscripcion || typeof c.suscripcion !== 'object' || !validarFechaISO(c.suscripcion.fechaVencimiento)){
c.suscripcion = { diasVigencia: (c.suscripcion && c.suscripcion.diasVigencia) || 365, fechaVencimiento: sumarDiasISO(hoyISO(), 365) };
}
});
}
function validarFechaISO(fecha){
if (!fecha || typeof fecha !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(fecha)) return false;
const d = new Date(fecha + 'T00:00:00');
return !isNaN(d.getTime());
}
let guardadoLocalPendiente = null;
let sincronizandoConFirebase = false;
let sincronizacionNuevamenteSolicitada = false;
let versionCambiosLocales = 0;
let ultimoIntentoSyncFallido = 0;
let temporizadorReintentoSync = null;
// ================= CAPA DE PROTECCIÓN LOCAL =================
// Centraliza la serialización del estado para poder detectar problemas de cuota
// sin borrar información ni interrumpir la sesión. No intenta "limpiar" datos
// automáticamente: si el dispositivo no tiene espacio, la memoria en RAM sigue
// viva y Firebase conserva la posibilidad de sincronizar cuando corresponda.
function clonarRegistroSinCredencialesEnClaroIRanch(r){const c=JSON.parse(JSON.stringify(r||{}));delete c.clave;delete c.password;delete c.contrasena;return c;}
function sanitizarCredencialesRecursivoIRanch(valor){if(Array.isArray(valor))return valor.map(sanitizarCredencialesRecursivoIRanch);if(valor&&typeof valor==='object'){const o={};Object.entries(valor).forEach(([k,v])=>{if(['clave','password','contrasena'].includes(k))return;o[k]=sanitizarCredencialesRecursivoIRanch(v);});return o;}return valor;}
function clonarEstadoSinCredencialesEnClaroIRanch(){
  const copia=JSON.parse(JSON.stringify(estado));
  const limpiar=r=>{if(r&&typeof r==='object'){delete r.clave;delete r.password;delete r.contrasena;}};
  ['cuentasProductores','usuarios','trabajadores','veterinarios','operadoresQueseria','solicitudesCEFP','solicitudesRegistro'].forEach(k=>(copia[k]||[]).forEach(limpiar));
  if(copia.queseria&&typeof copia.queseria==='object'){delete copia.queseria.claveAdmin;delete copia.queseria.passwordAdmin;}
  return copia;
}
function guardarEstadoEnLocalSeguro(){
try {
  const serializado = JSON.stringify(clonarEstadoSinCredencialesEnClaroIRanch());
  localStorage.setItem(CLAVE_ALMACENAMIENTO_LOCAL, serializado);
  return true;
} catch(e){
  console.warn('No se pudo persistir el estado local:', e);
  return false;
}
}

// ================= CONTROL DE IA (PREPARADO, SIN COSTO) =================
// No realiza llamadas de IA por sí mismo. Es una barrera central para que las
// futuras funciones de IA nazcan desactivadas y con límites explícitos. Un
// límite real de facturación debe imponerse también en el proveedor/backend;
// este control es solo una segunda barrera del cliente.
const IRANCH_AI_CONFIG = Object.freeze({
  enabled: false,
  maxRequestsPerSession: 20,
  maxEstimatedCostPerSession: 0
});
let iRanchAIRequestsThisSession = 0;
let iRanchAIEstimatedCostThisSession = 0;
function puedeUsarIAIRanch(costoEstimado = 0){
  if (!IRANCH_AI_CONFIG.enabled) return false;
  if (iRanchAIRequestsThisSession >= IRANCH_AI_CONFIG.maxRequestsPerSession) return false;
  if ((iRanchAIEstimatedCostThisSession + Number(costoEstimado || 0)) > IRANCH_AI_CONFIG.maxEstimatedCostPerSession) return false;
  return true;
}
function registrarUsoIAIRanch(costoEstimado = 0){
  if (!puedeUsarIAIRanch(costoEstimado)) return false;
  iRanchAIRequestsThisSession++;
  iRanchAIEstimatedCostThisSession += Number(costoEstimado || 0);
  return true;
}

// Huellas de los últimos payloads confirmados. Evitan escribir en Firestore
// cuando una ruta de la app dispara guardarEstadoLocal() pero el documento
// correspondiente realmente no cambió. Esto reduce costo y tráfico sin
// cambiar el comportamiento visible.
let firmaGlobalSincronizada = null;
let firmaColaAdminSincronizada = null;
let firmaCuentaSincronizada = null;
let firmaCuentaSincronizadaId = null;
let intentosSyncFallidos = 0;
let aplicandoCambioRemoto = false;
// Rol autenticado en esta sesión. No se deriva de la pantalla solicitada.
// Solo se establece tras una autenticación válida y se invalida al cerrar sesión.
let sesionRolAutenticado = null;
let primeraCargaGlobalHecha = false;
let resolverPrimeraCargaGlobal;
const primeraCargaGlobalPromise = new Promise(resolve => { resolverPrimeraCargaGlobal = resolve; });
function esperarPrimeraCargaGlobal(timeoutMs){
return Promise.race([
primeraCargaGlobalPromise,
new Promise(resolve => setTimeout(resolve, timeoutMs || 6000))
]);
}
// La promesa de arriba solo se resuelve UNA vez, la primera vez que llega el
// índice global — reusarla más tarde ya no sirve para esperar una actualización
// FRESCA (ya está resuelta desde hace rato). Este contador sí sube cada vez que
// llega una actualización nueva del índice global, así se puede esperar una
// actualización reciente de verdad (ej. al fallar un login con caché vieja,
// por si la cuenta se creó/editó en otro dispositivo después de la última vez
// que este dispositivo se sincronizó).
let contadorActualizacionesGlobales = 0;
function esperarNuevaActualizacionGlobal(timeoutMs){
const inicio = contadorActualizacionesGlobales;
return new Promise(resolve => {
const limite = setTimeout(() => { clearInterval(revisar); resolve(false); }, timeoutMs || 3000);
const revisar = setInterval(() => {
if (contadorActualizacionesGlobales > inicio){
clearInterval(revisar); clearTimeout(limite); resolve(true);
}
}, 150);
});
}
// ================= CUENTAS GUARDADAS EN ESTE DISPOSITIVO =================
// Solo usuario/etiqueta. Nunca se almacena una contraseña en localStorage.
const CLAVE_CUENTAS_GUARDADAS = 'miRanchAppCuentasGuardadasV2';
try{localStorage.removeItem('miRanchAppCuentasGuardadas');}catch(e){}
function leerCuentasGuardadas(){try{return JSON.parse(localStorage.getItem(CLAVE_CUENTAS_GUARDADAS)||'[]');}catch(e){return [];}}
function guardarCuentaEnDispositivo(usuario,_clave,etiqueta){if(!usuario)return;try{let lista=leerCuentasGuardadas().filter(c=>c.usuario!==usuario);lista.unshift({usuario,etiqueta:etiqueta||usuario,ultimoAcceso:new Date().toISOString()});localStorage.setItem(CLAVE_CUENTAS_GUARDADAS,JSON.stringify(lista.slice(0,6)));}catch(e){}}
function olvidarCuentaGuardada(usuario){try{localStorage.setItem(CLAVE_CUENTAS_GUARDADAS,JSON.stringify(leerCuentasGuardadas().filter(c=>c.usuario!==usuario)));}catch(e){}renderCuentasGuardadas();}
function iniciarSesionConCuentaGuardada(usuario){establecerValor('login-usuario',usuario);establecerValor('login-clave','');document.getElementById('login-clave')?.focus();mostrarToast('Cuenta reconocida. Introduce tu contraseña para continuar.');}
function renderCuentasGuardadas(){const bloque=document.getElementById('bloque-cuentas-guardadas'),cont=document.getElementById('lista-cuentas-guardadas');if(!bloque||!cont)return;const lista=leerCuentasGuardadas();if(!lista.length){bloque.classList.add('hidden');return;}bloque.classList.remove('hidden');cont.innerHTML=lista.map(c=>`<div class="flex items-center gap-2 rounded-2xl px-3 py-2" style="background:rgba(255,255,255,0.55);border:1px solid rgba(92,58,30,0.25);"><button class="flex-1 flex items-center gap-2 text-left" onclick="iniciarSesionConCuentaGuardada('${String(c.usuario||'').replace(/'/g,"\'")}')" type="button">${avatarHtml(c.etiqueta,null,32)}<span class="font-bold text-sm" style="color:#3A2A15;">${String(c.etiqueta||c.usuario||'').replace(/[<>]/g,'')}</span></button><button onclick="olvidarCuentaGuardada('${String(c.usuario||'').replace(/'/g,"\'")}')" style="color:#8A5323;" type="button"><i class="fa-solid fa-xmark"></i></button></div>`).join('');}
// Busca un nombre amigable para mostrar en la tarjeta de "cuentas guardadas" a
// partir del usuario que acaba de iniciar sesión con éxito.
function obtenerNombreParaUsuario(usuario){
const u = usuario.toLowerCase();
const cuenta = estado.cuentasProductores.find(c => (c.usuario || '').toLowerCase() === u);
if (cuenta) return cuenta.nombre || usuario;
const usr = estado.usuarios.find(x => (x.usuario || '').toLowerCase() === u);
if (usr) return usr.nombre || usuario;
const trabajador = estado.trabajadores.find(t => (t.usuario || '').toLowerCase() === u);
if (trabajador) return trabajador.nombre || usuario;
const operador = estado.operadoresQueseria.find(o => (o.usuario || '').toLowerCase() === u);
if (operador) return operador.nombre || usuario;
return usuario;
}
// ============================================================
// ===== MODO DEMO — solo administrador, ver cualquier rol al instante =====
// ============================================================
// Resuelve perder tiempo dando de alta cuentas falsas de cada rol solo para
// revisar pantallas. Reutiliza las pantallas y funciones de SIEMPRE, con
// datos de ejemplo — nunca lee ni escribe ninguna cuenta real. Con
// honestidad: NO incluye ver cuentas reales de productores sin su
// contraseña — eso es un riesgo de seguridad real que no se construye,
// sin importar cómo se pida.
const DATOS_DEMO_POR_ROL = {
lechero: {
tipoGanado: 'leche',
productor: { nombre: 'Productor Demo (Lechera)', predio: 'Rancho Demo Lechero', upp: '00-000-0000-000', municipio: 'Municipio Demo', estado: 'Estado Demo', telefono: '5550000000', correo: 'demo@ejemplo.com', curp: '', rfc: '', actualizacionUPP: '', folio: '', vencimientoFierro: '', ejido: '', actividad: 'Ganadería lechera', latitudUPP: null, longitudUPP: null },
animales: [
{ arete:'DEMO001', nombre:'Vaca demo 1', raza:'Holstein', sexo:'Hembra', fecha:'2021-03-10', estatus:'Activo', potrero:'Potrero Demo', proposito:'', madre:'', padre:'', motivoBaja:'', foto:null, engordaFinalizado:false },
{ arete:'DEMO002', nombre:'Vaca demo 2', raza:'Jersey', sexo:'Hembra', fecha:'2022-06-15', estatus:'Activo', potrero:'Potrero Demo', proposito:'', madre:'', padre:'', motivoBaja:'', foto:null, engordaFinalizado:false },
{ arete:'DEMO003', nombre:'Becerra demo', raza:'Holstein', sexo:'Hembra', fecha:'2024-01-05', estatus:'Activo', potrero:'Potrero Demo', proposito:'reemplazo', madre:'DEMO001', padre:'', motivoBaja:'', foto:null, engordaFinalizado:false },
],
potreros: [{ nombre:'Potrero Demo', capacidad:20, color:'#5C6B55', poligono:null, hectareas:8 }],
produccionLeche: [{ animal:'DEMO001', fecha: hoyISO(), ordenador:'', litrosAM:12, litrosPM:11, total:23, grasa:'', proteina:'', celulas:'', notas:'' }],
salud: [], pesajes: [], reproduccion: [], costos: [], bodega: [], tareas: [], trabajadores: [], movimientosAnimal: [],
},
carne: {
tipoGanado: 'carne',
productor: { nombre: 'Productor Demo (Carne)', predio: 'Rancho Demo Carne', upp: '00-000-0000-001', municipio: 'Municipio Demo', estado: 'Estado Demo', telefono: '5550000001', correo: 'demo@ejemplo.com', curp: '', rfc: '', actualizacionUPP: '', folio: '', vencimientoFierro: '', ejido: '', actividad: 'Ganadería de carne', latitudUPP: null, longitudUPP: null },
animales: [
{ arete:'DEMO101', nombre:'Toro demo', raza:'Brahman', sexo:'Macho', fecha:'2020-02-01', estatus:'Semental', potrero:'Potrero Demo', proposito:'', madre:'', padre:'', motivoBaja:'', foto:null, engordaFinalizado:false },
{ arete:'DEMO102', nombre:'Novillo demo', raza:'Charolais', sexo:'Macho', fecha:'2023-08-20', estatus:'Engorda', potrero:'Potrero Demo', proposito:'engorda', engordaDiasObjetivo:180, engordaPesoMeta:450, madre:'', padre:'', motivoBaja:'', foto:null, engordaFinalizado:false },
{ arete:'DEMO103', nombre:'Vaquilla demo', raza:'Angus', sexo:'Hembra', fecha:'2022-11-11', estatus:'Vaquilla', potrero:'Potrero Demo', proposito:'', madre:'', padre:'', motivoBaja:'', foto:null, engordaFinalizado:false },
],
potreros: [{ nombre:'Potrero Demo', capacidad:30, color:'#5C6B55', poligono:null, hectareas:15 }],
pesajes: [{ animal:'DEMO102', fecha: hoyISO(), peso:380, lote:'', condicionCorporal:3 }],
salud: [], reproduccion: [], costos: [], bodega: [], tareas: [], trabajadores: [], movimientosAnimal: [], produccionLeche: [],
},
veterinario: {
modoVeterinario: true, modoComite: false,
cuentasProductores: [
{ id:'demo_prod_1', nombre:'Productor Demo Uno', predio:'Rancho Uno Demo', upp:'00-000-0000-002', tipo:'carne', animales:[], salud:[], pesajes:[], reproduccion:[] },
{ id:'demo_prod_2', nombre:'Productor Demo Dos', predio:'Rancho Dos Demo', upp:'00-000-0000-003', tipo:'leche', animales:[], salud:[], pesajes:[], reproduccion:[] },
],
solicitudesRegistro: [], solicitudesPago: [], solicitudesTransferencia: [], avisosReactoresTB: [], resumenMensajes: {},
},
comite: {
modoComite: true, modoVeterinario: false,
cuentasProductores: [
{ id:'demo_prod_1', nombre:'Productor Demo Uno', predio:'Rancho Uno Demo', upp:'00-000-0000-002', tipo:'carne', animales:[], salud:[{ animal:'X', estadoCEFPP:'enviado' }], pesajes:[], reproduccion:[] },
],
avisosReactoresTB: [{ id:'demo_1', animal:'DEMO201', estatus:'pendiente', fecha: hoyISO() }],
solicitudesRegistro: [], solicitudesPago: [], solicitudesTransferencia: [], resumenMensajes: {},
},
};
let respaldoEstadoAntesDeDemo = null;
let modoDemoRol = null;
// Restaura la cuenta real desde el respaldo, de forma limpia — la usan
// TODAS las salidas del modo demo (botón, cerrar sesión, login, quesería,
// y el vigilante automático de abajo), para no repetir la misma lógica 5
// veces y arriesgar que una copia se quede desactualizada.
function restaurarDeModoDemoSiHaceFalta(){
if (!estado.modoDemoActivo) return;
if (respaldoEstadoAntesDeDemo){
const real = JSON.parse(respaldoEstadoAntesDeDemo);
Object.keys(estado).forEach(k => delete estado[k]);
Object.assign(estado, real);
}
respaldoEstadoAntesDeDemo = null;
modoDemoRol = null;
estado.modoDemoActivo = false;
const bannerDemo = document.getElementById('banner-modo-demo');
if (bannerDemo) bannerDemo.classList.add('hidden');
}
function activarModoDemo(tipoDemo){
if (sesionRolAutenticado !== 'admin' || estado.rolActual !== 'admin' || rolRestringidoActivo()) {
  console.warn('MiRanch: intento de activar modo demo sin administrador completo');
  return false;
}
const demo = DATOS_DEMO_POR_ROL[tipoDemo];
if (!demo) return;
// Si ya se estaba viendo otro modo demo, se restaura primero de forma
// limpia antes de activar el nuevo — nunca se guarda un respaldo que en
// realidad ya era de mentira.
restaurarDeModoDemoSiHaceFalta();
respaldoEstadoAntesDeDemo = JSON.stringify(estado);
modoDemoRol = tipoDemo;
Object.assign(estado, JSON.parse(JSON.stringify(demo)));
estado.modoDemoActivo = true;
const bannerDemo = document.getElementById('banner-modo-demo');
if (bannerDemo){
bannerDemo.classList.remove('hidden');
document.getElementById('banner-modo-demo-texto').textContent = `Viendo modo ${tipoDemo.toUpperCase()} de ejemplo — nada de esto es real`;
}
if (tipoDemo === 'lechero' || tipoDemo === 'carne'){
document.getElementById('app-admin').classList.add('hidden');
document.getElementById('app-productor').classList.remove('hidden');
if (typeof renderTodoProductor === 'function') renderTodoProductor();
irA('home');
} else {
document.getElementById('app-productor').classList.add('hidden');
document.getElementById('app-admin').classList.remove('hidden');
if (typeof renderTodoAdmin === 'function') renderTodoAdmin();
if (typeof irAdmin === 'function') irAdmin('home');
}
}
function salirModoDemo(){
restaurarDeModoDemoSiHaceFalta();
document.getElementById('app-productor').classList.add('hidden');
document.getElementById('app-admin').classList.remove('hidden');
if (typeof renderTodoAdmin === 'function') renderTodoAdmin();
if (typeof irAdmin === 'function') irAdmin('home');
mostrarToast('Modo demo cerrado — de vuelta en tu cuenta real');
}
// ---- VIGILANTE AUTOMÁTICO: se corrige solo, sin depender de que se haya
// atrapado cada ruta de salida a mano. Cada segundo revisa: si la pantalla
// de login está visible pero el modo demo sigue prendido por dentro (sin
// importar por qué camino haya pasado eso), lo corrige de inmediato. Esta
// es la protección de fondo real — las de arriba son solo para que se vea
// bien al momento, esta es la que garantiza que nunca se quede pegado.
setInterval(() => {
if (!estado.modoDemoActivo) return;
const loginVisible = document.getElementById('screen-login')?.classList.contains('active');
if (loginVisible) restaurarDeModoDemoSiHaceFalta();
}, 1000);
function guardarEstadoLocal(){
// Mientras el modo demo esté activo, nada se guarda de verdad.
if (estado.modoDemoActivo) return;
versionCambiosLocales++;
if (guardadoLocalPendiente) clearTimeout(guardadoLocalPendiente);
guardadoLocalPendiente = setTimeout(() => {
// Esta bandera solo representa el debounce pendiente; al disparar se libera.
guardadoLocalPendiente = null;
try {
guardarEstadoEnLocalSeguro();
if (aplicandoCambioRemoto){ actualizarBadgeSincronizacion(); return; }
if (!navigator.onLine || !window.firebaseListo){
if (!estado.colaSincronizacion.length) estado.colaSincronizacion.push({ fecha: new Date().toISOString(), motivo: 'sin_conexion' });
actualizarBadgeSincronizacion();
return;
}
sincronizarConFirebase();
} catch(e){
console.warn('No se pudo guardar el estado localmente', e);
// Si el almacenamiento local falla, no intentamos borrar datos para "hacer espacio".
// La sesión sigue viva en memoria y Firebase podrá recibirla si está disponible.
}
// Debounce de 900ms: agrupa cambios seguidos y reduce escrituras a Firestore.
}, 900);
}
// Si hay un guardado esperando su turno (dentro de la ventana de 900ms) y la
// persona cierra la app o cambia de pestaña/app justo en ese momento, el
// setTimeout de arriba nunca llega a disparar — el cambio se perdería sin
// avisar. Esto lo detecta y fuerza el guardado a localStorage AHORA MISMO
// (de forma síncrona, sin esperar el temporizador). No dispara la
// sincronización con Firestore aquí a propósito (eso sí puede esperar a la
// próxima vez que se abra la app) — lo único que no puede esperar es que el
// dato quede seguro en el celular.
function guardarEstadoLocalDeInmediatoSiHaceFalta(){
if (!guardadoLocalPendiente) return;
clearTimeout(guardadoLocalPendiente);
guardadoLocalPendiente = null;
try { localStorage.setItem(CLAVE_ALMACENAMIENTO_LOCAL, JSON.stringify(clonarEstadoSinCredencialesEnClaroIRanch())); }
catch(e){ console.warn('No se pudo forzar el guardado local antes de cerrar', e); }
}
window.addEventListener('beforeunload', guardarEstadoLocalDeInmediatoSiHaceFalta);
// beforeunload no es confiable en celulares (Android/iOS a veces no lo
// disparan al cerrar una app o cambiar de aplicación) — visibilitychange sí
// se dispara de forma consistente en ese caso, así que es el resguardo real
// para uso en celular.
document.addEventListener('visibilitychange', () => {
if (document.hidden) guardarEstadoLocalDeInmediatoSiHaceFalta();
});
// pagehide cubre navegadores móviles que suspenden la página sin disparar
// beforeunload; solo protege la copia local y nunca intenta una escritura de red.
window.addEventListener('pagehide', guardarEstadoLocalDeInmediatoSiHaceFalta);
function actualizarBadgeSincronizacion(){
const badge = document.getElementById('badge-sync-pendiente');
if (!badge) return;
const n = estado.colaSincronizacion.length;
badge.classList.toggle('hidden', n === 0);
badge.textContent = n;
}
async function sincronizarConFirebase(){
// Si ya hay una sincronización en curso, no abrimos otra escritura paralela.
// Solo dejamos una petición pendiente para repetirla al terminar con el estado
// más reciente. Así no se pierden cambios hechos mientras una escritura esperaba.
if (sincronizandoConFirebase){
  sincronizacionNuevamenteSolicitada = true;
  return;
}
if (estado.modoDemoActivo) return;
// Segunda barrera contra eco remoto: aunque otra ruta invoque directamente
// sincronizarConFirebase mientras se aplica una actualización de Firestore,
// no se permite abrir una escritura saliente desde ese callback.
if (aplicandoCambioRemoto) return;
if (!window.firebaseListo || typeof window.firebaseGuardarGlobal !== 'function') return;
if (!navigator.onLine) return;
sincronizandoConFirebase = true;
sincronizacionNuevamenteSolicitada = false;
const versionAlInicio = versionCambiosLocales;
try {
const pendientes = estado.colaSincronizacion.length;
const payloadGlobal = construirPayloadGlobal();
const firmaGlobal = JSON.stringify(payloadGlobal);
let exitoGlobal = true;
if (firmaGlobal !== firmaGlobalSincronizada){
  exitoGlobal = await window.firebaseGuardarGlobal(payloadGlobal);
  if (exitoGlobal) firmaGlobalSincronizada = firmaGlobal;
}
let exitoColaAdmin = true;
// Solo una cuenta de administración guarda la cola administrativa desde el
// guardado automático normal. Los productores la actualizan por separado.
if (estado.rolActual === 'admin' && typeof window.firebaseGuardarColaAdmin === 'function'){
  const payloadColaAdmin = construirPayloadColaAdmin();
  const firmaColaAdmin = JSON.stringify(payloadColaAdmin);
  if (firmaColaAdmin !== firmaColaAdminSincronizada){
    exitoColaAdmin = await window.firebaseGuardarColaAdmin(payloadColaAdmin);
    if (exitoColaAdmin) firmaColaAdminSincronizada = firmaColaAdmin;
  }
}
let exitoCuenta = true;
let cuentaUsaDominios = false;
if (estado.cuentaActivaId && IRANCH_STORAGE_CONFIG.modo === 'auto'){
  const cuentaParaMigrar = estado.cuentasProductores.find(c => c.id === estado.cuentaActivaId);
  cuentaUsaDominios = await asegurarDominiosCuentaListos(cuentaParaMigrar);
}
if (estado.cuentaActivaId && cuentaUsaDominios && typeof window.firebaseGuardarDominioCuenta === 'function'){
  const cuentaActual = estado.cuentasProductores.find(c => c.id === estado.cuentaActivaId) || { id: estado.cuentaActivaId };
  ARREGLOS_POR_CUENTA.forEach(clave => { cuentaActual[clave] = estado[MAPA_CLAVE_ESTADO[clave] || clave] || []; });
  const deteccion = detectarDominiosModificadosCuenta(cuentaActual);
  for (const dominio of deteccion.modificados){
    const claveEstado = MAPA_CLAVE_ESTADO[dominio] || dominio;
    const ok = await window.firebaseGuardarDominioCuenta(estado.cuentaActivaId, dominio, estado[claveEstado] || []);
    if (!ok) { exitoCuenta = false; break; }
    marcarDominioCargado(estado.cuentaActivaId, dominio);
  }
  if (exitoCuenta){
    const firmasCompletas = Object.assign({}, firmasDominiosCuenta[estado.cuentaActivaId] || {}, deteccion.actual);
    firmasDominiosCuenta[estado.cuentaActivaId] = firmasCompletas;
    actualizarMetadatosStorageLocal(estado.cuentaActivaId, { dominios: firmasCompletas, modo:'dominios' });
  }
}
// Aunque los dominios de crecimiento estén separados, tareas, potreros, costos,
// bodega y demás datos compatibles siguen viviendo en el documento legado.
// Este guardado NO incluye los dominios ya migrados, para no volver a inflar el
// documento ni sobrescribir la copia modular con una versión antigua.
if (estado.cuentaActivaId && typeof window.firebaseGuardarCuenta === 'function'){
  await archivarRegistrosAntiguosSiNecesario();
  const payloadCuenta = cuentaUsaDominios ? construirPayloadCuentaActivaSinDominiosMigrados() : construirPayloadCuentaActiva();
  const firmaCuenta = JSON.stringify(payloadCuenta);
  if (estado.cuentaActivaId !== firmaCuentaSincronizadaId || firmaCuenta !== firmaCuentaSincronizada){
    exitoCuenta = await window.firebaseGuardarCuenta(estado.cuentaActivaId, payloadCuenta);
    if (exitoCuenta){ firmaCuentaSincronizadaId = estado.cuentaActivaId; firmaCuentaSincronizada = firmaCuenta; }
  }
  if (exitoCuenta) await archivarRegistrosAntiguosSiNecesario();
}
if (!exitoGlobal || !exitoColaAdmin || !exitoCuenta){
  ultimoIntentoSyncFallido = Date.now();
  intentosSyncFallidos = Math.min(intentosSyncFallidos + 1, 6);
  if (!estado.colaSincronizacion.length) estado.colaSincronizacion.push({ fecha: new Date().toISOString(), motivo: 'reintento_sync' });
  actualizarBadgeSincronizacion();
  programarReintentoSync();
  return;
}
// Si alguien editó la app mientras esperábamos a Firebase, esta escritura
// corresponde a una versión anterior. No vaciamos la cola ni damos por final
// la sincronización: guardamos el estado actual y hacemos un último ciclo.
if (versionCambiosLocales !== versionAlInicio || sincronizacionNuevamenteSolicitada){
  sincronizacionNuevamenteSolicitada = false;
  guardarEstadoEnLocalSeguro();
  return;
}
estado.colaSincronizacion = [];
estado.ultimaSincronizacion = new Date().toISOString();
ultimoIntentoSyncFallido = 0;
intentosSyncFallidos = 0;
if (temporizadorReintentoSync){ clearTimeout(temporizadorReintentoSync); temporizadorReintentoSync = null; }
guardarEstadoEnLocalSeguro();
actualizarBadgeSincronizacion();
if (pendientes > 0 && typeof mostrarToast === 'function') mostrarToast(`${pendientes} cambio(s) sincronizado(s) con Firebase`);
} catch(e){
// Las funciones Firebase normalmente devuelven false, pero este catch protege
// contra errores inesperados de cualquier capa intermedia.
console.warn('Error inesperado durante la sincronización:', e);
ultimoIntentoSyncFallido = Date.now();
intentosSyncFallidos = Math.min(intentosSyncFallidos + 1, 6);
if (!estado.colaSincronizacion.length) estado.colaSincronizacion.push({ fecha: new Date().toISOString(), motivo: 'excepcion_sync' });
actualizarBadgeSincronizacion();
programarReintentoSync();
} finally {
sincronizandoConFirebase = false;
if (versionCambiosLocales !== versionAlInicio || sincronizacionNuevamenteSolicitada){
  sincronizacionNuevamenteSolicitada = false;
  if (navigator.onLine && window.firebaseListo) setTimeout(() => sincronizarConFirebase(), 0);
}
}
}
function programarReintentoSync(){
if (temporizadorReintentoSync || estado.modoDemoActivo || !navigator.onLine) return;
const fallos = Math.max(1, Math.min(6, intentosSyncFallidos || 1));
// Espera corta y acotada; el evento online sigue siendo el camino principal.
const espera = Math.min(30000, 2000 * Math.pow(2, Math.min(4, fallos - 1)));
temporizadorReintentoSync = setTimeout(() => {
  temporizadorReintentoSync = null;
  if (navigator.onLine) sincronizarConFirebase();
}, espera);
}
window.addEventListener('online', sincronizarConFirebase);
// ================= ATRAPADOR GLOBAL DE ERRORES =================
// Si algo truena en cualquier parte de la app que nadie haya protegido con
// try/catch (justo el riesgo del punto A6 de la auditoría), esto evita que
// se vea como una pantalla en blanco o que la app deje de responder — en vez
// de eso, se guarda el detalle y aparece un aviso chico y claro, sin tapar
// la pantalla ni interrumpir lo que se estaba haciendo. Cubre tanto errores
// normales (window.onerror) como promesas rechazadas sin .catch()
// (unhandledrejection) — los guardados/sincronizaciones usan promesas.
const ERRORES_CAPTURADOS = [];
const LIMITE_ERRORES_GUARDADOS = 20;
function registrarErrorGlobal(mensaje, detalle){
ERRORES_CAPTURADOS.push({ mensaje, detalle, fecha: new Date().toISOString() });
if (ERRORES_CAPTURADOS.length > LIMITE_ERRORES_GUARDADOS) ERRORES_CAPTURADOS.shift();
console.error('Error atrapado por el manejador global:', mensaje, detalle);
mostrarAvisoErrorGlobal(mensaje);
}
function mostrarAvisoErrorGlobal(mensaje){
let aviso = document.getElementById('aviso-error-global');
if (!aviso && document.body){
aviso = document.createElement('div');
aviso.id = 'aviso-error-global';
aviso.style.cssText = 'position:fixed; left:12px; right:12px; bottom:12px; z-index:9999; background:#211E19; color:#fff; border-radius:16px; padding:12px 14px; display:flex; align-items:center; gap:10px; box-shadow:0 8px 20px -6px rgba(0,0,0,0.5); font-size:.8rem;';
aviso.innerHTML = `<i class="fa-solid fa-triangle-exclamation" style="color:#F97316;"></i>
<span style="flex:1;">Algo no funcionó como debía — el resto de la app sigue funcionando.</span>
<button onclick="mostrarDetalleErroresGlobal()" style="background:rgba(255,255,255,0.15); border:none; color:#fff; font-weight:700; padding:6px 10px; border-radius:999px; font-size:.72rem;">Ver detalle</button>
<button onclick="document.getElementById('aviso-error-global').remove()" style="background:none; border:none; color:#fff; opacity:.7;"><i class="fa-solid fa-xmark"></i></button>`;
document.body.appendChild(aviso);
setTimeout(() => { document.getElementById('aviso-error-global')?.remove(); }, 12000);
}
}
function mostrarDetalleErroresGlobal(){
const texto = ERRORES_CAPTURADOS.slice(-5).map(e => `${e.fecha}\n${e.mensaje}\n${e.detalle || ''}`).join('\n\n---\n\n') || 'Sin detalles guardados';
if (navigator.clipboard && navigator.clipboard.writeText){
navigator.clipboard.writeText(texto).then(() => alert('Detalle copiado — pégalo para mandarlo a soporte:\n\n' + texto)).catch(() => alert(texto));
} else {
alert(texto);
}
}
window.onerror = function(mensaje, origen, linea, columna, error){
registrarErrorGlobal(String(mensaje), `${origen || ''}:${linea || ''}:${columna || ''}\n${error && error.stack ? error.stack : ''}`);
return true; // evita que el navegador muestre su propio error y "congele" la interacción
};
window.addEventListener('unhandledrejection', function(evento){
registrarErrorGlobal('Promesa sin atrapar: ' + (evento.reason && evento.reason.message ? evento.reason.message : String(evento.reason)), evento.reason && evento.reason.stack ? evento.reason.stack : '');
evento.preventDefault();
liberarBotonLoginSiSeQuedoColgado();
});
// Red de seguridad global: si algo truena en cualquier parte de la app de forma
// no controlada, se registra el error exacto en consola (para poder diagnosticarlo)
// y, si el botón de iniciar sesión se quedó girando en ese momento, se libera solo
// en vez de dejarlo girando para siempre sin explicación.
function liberarBotonLoginSiSeQuedoColgado(){
const boton = document.getElementById('btn-iniciar-sesion');
const spinner = document.getElementById('btn-iniciar-sesion-spinner');
const texto = document.getElementById('btn-iniciar-sesion-texto');
if (boton && boton.disabled) boton.disabled = false;
if (spinner && !spinner.classList.contains('hidden')) spinner.classList.add('hidden');
if (texto && typeof tr === 'function') texto.textContent = tr('login_seleccion_rol__iniciar_sesion_mayus');
}
window.addEventListener('error', (evento) => {
console.error('Error no controlado en MiRanch:', evento.error || evento.message);
liberarBotonLoginSiSeQuedoColgado();
});
cargarEstadoLocal();
// ================= CUENTAS DE PRUEBA (una sola vez, a pedido de Luis) =================
// Crea las 8 cuentas de prueba con contraseña simple "123456" para probar
// cada rol rápido — corre UNA sola vez por dispositivo (usa una bandera en
// localStorage para no duplicar cuentas cada vez que se recarga la app).
function crearCuentasDePruebaSiHaceFalta(){ return false; }
// Antes, si el navegador recargaba la página a medio uso (algo común en celulares
// cuando la cámara nativa toma el control para tomar una foto — el sistema puede
// descargar la pestaña de memoria y al volver la recarga desde cero), la persona
// terminaba de regreso en la pantalla de login aunque sus datos siguieran a salvo
// en este dispositivo y en la nube — se sentía como si "la sacara de la cuenta".
// Esto reanuda automáticamente la sesión activa si el dispositivo ya tenía una
// abierta, para que una recarga a medio trabajo no boté a la persona al login.
// Detecta si quedó un escaneo de documentos ("Alta rápida") a medias — se usa
// tanto aquí (para regresar directo a esa pantalla al reanudar sesión) como
// dentro del propio flujo de escaneo.
function hayBorradorEscaneoDocActivo(){
let datos = null;
try { datos = JSON.parse(localStorage.getItem('miRanchAppBorradorEscaneoDocumentos') || 'null'); } catch(e){ datos = null; }
if (!datos) return false;
return !!((datos.imagenes && Object.keys(datos.imagenes).length > 0) || (datos.filasSINIIGATemp && datos.filasSINIIGATemp.length > 0) || (datos.campos && Object.values(datos.campos).some(v => v)));
}
// Se declara aquí (antes de reanudarSesionSiAplica) porque esa función llama a
// activarEscuchaCuentaActiva(), que necesita esta variable — antes estaba
// declarada más abajo, así que cada vez que la página se recargaba con una
// sesión activa (típicamente al volver de la cámara nativa tras tomar una
// foto), truena con "no se puede usar antes de inicializarse", eso se atrapaba
// en silencio, y la persona terminaba de vuelta en la pantalla de login aunque
// su sesión siguiera guardada. Confirmado con el error real del navegador.
let cancelarEscuchaCuenta = () => {};
function reanudarSesionSiAplica(){
if (estado.modoTrabajador && estado.trabajadorActualId){
activarEscuchaCuentaActiva();
mostrarApp('productor');
// Si el celular recargó la página a medio escanear un documento (lo más
// común: el sistema operativo cierra la pestaña en segundo plano mientras
// la cámara nativa toma la foto, sobre todo con poca memoria libre), antes
// esto regresaba a la persona a su pantalla de inicio normal — sentía
// exactamente como si "la sacara" de donde estaba. Ahora, si detecta que
// había un escaneo en curso, regresa derechito a esa pantalla con todo lo
// que ya se había avanzado restaurado, en vez de dejarla en el inicio.
if (typeof hayBorradorEscaneoDocActivo === 'function' && hayBorradorEscaneoDocActivo() && typeof abrirEscaneoDocumentos === 'function') abrirEscaneoDocumentos();
return true;
}
if (estado.cuentaActivaId){
activarEscuchaCuentaActiva();
mostrarApp('productor');
if (typeof hayBorradorEscaneoDocActivo === 'function' && hayBorradorEscaneoDocActivo() && typeof abrirEscaneoDocumentos === 'function') abrirEscaneoDocumentos();
return true;
}
if (estado.modoVeterinario || estado.modoCapturista || estado.modoAlmita || estado.modoMedicoCampoTB || estado.modoCapturistaTB || estado.modoComite){
mostrarApp('admin');
return true;
}
return false;
}
// Si reanudar la sesión falla por cualquier motivo inesperado (datos guardados
// corruptos/incompletos de una versión vieja de la app, etc.), NUNCA debe dejar
// la app a medio arrancar — se registra el error y se cae de vuelta a la
// pantalla de login normal, que siempre debe quedar disponible.
// Se aplaza un instante (hasta que el archivo completo termine de cargar) antes
// de arrancar — reanudarSesionSiAplica() termina usando, indirectamente, TODA
// la app (pantallas, módulos, etc.), y algunas de esas piezas se declaran más
// abajo en este mismo archivo. Arrancar de inmediato podía tronar con "no se
// puede usar antes de inicializarse" en cualquiera de ellas — eso se atrapaba
// en silencio y la persona terminaba de vuelta en el login (o a medio
// cargar) aunque su sesión siguiera guardada. Confirmado con el error real del
// navegador en dos variables distintas. setTimeout(...,0) espera a que el
// archivo completo termine de ejecutarse una vez, así ya no importa en qué
// orden esté declarado nada.
setTimeout(() => {
let huboSesionReanudada = false;
try { huboSesionReanudada = reanudarSesionSiAplica(); }
catch(e){ console.error('No se pudo reanudar la sesión guardada — se muestra el login normal:', e); }
if (!huboSesionReanudada) renderCuentasGuardadas();
detectarAccesoPorQR();
['modal-exportar', 'modal-conflicto-arete'].forEach(id => {
const el = document.getElementById(id);
if (el) el.classList.add('hidden');
});
}, 0);
let cancelarEscuchaMensajesProductor = () => {};
let cancelarEscuchaMetaChatProductor = () => {};
let cancelarEscuchaDominiosCuenta = () => {};
function detenerListenersDominiosCuenta(){
  Object.keys(cancelacionesListenersDominios).forEach(clave => { try { cancelacionesListenersDominios[clave](); } catch(e) {} delete cancelacionesListenersDominios[clave]; delete dominiosCuentaCargados[clave]; });
}
function activarEscuchaCuentaActiva(){
detenerListenersDominiosCuenta();
cancelarEscuchaCuenta();
cancelarEscuchaCuenta = () => {};
cancelarEscuchaDominiosCuenta();
cancelarEscuchaDominiosCuenta = () => {};
cancelarEscuchaMensajesProductor();
cancelarEscuchaMensajesProductor = () => {};
cancelarEscuchaMetaChatProductor();
cancelarEscuchaMetaChatProductor = () => {};
if (!estado.cuentaActivaId || typeof window.firebaseEscucharCuenta !== 'function') return;
cancelarEscuchaCuenta = window.firebaseEscucharCuenta(estado.cuentaActivaId, (datosCuenta, actualizado) => {
if (actualizado && estado.ultimaSincronizacionCuenta === actualizado) return;
if (!datosCuenta || datosCuenta.id !== estado.cuentaActivaId) return;
// Mismo resguardo que en el escucha global: si hay un guardado local pendiente
// o una sincronización en curso, este dato remoto podría ser anterior a un
// cambio que aún no termina de subirse (ej. un animal recién agregado) y lo
// borraría. Se ignora aquí y llegará de nuevo, ya actualizado, cuando termine.
if (guardadoLocalPendiente || sincronizandoConFirebase) return;
aplicandoCambioRemoto = true;
ARREGLOS_POR_CUENTA.forEach(clave => {
// Cuando el dominio ya vive de forma modular, el documento legado queda como
// respaldo y NO debe pisar una versión modular más reciente.
if (IRANCH_STORAGE_CONFIG.dominiosCrecimiento.includes(clave) && metadatosStorageCuenta[estado.cuentaActivaId]?.migracionDominios === true) return;
const claveEstado = MAPA_CLAVE_ESTADO[clave] || clave;
if (Array.isArray(datosCuenta[clave])) estado[claveEstado] = datosCuenta[clave];
});
reengancharCuentaActiva();
estado.ultimaSincronizacionCuenta = actualizado;
if (estado.rolActual === 'productor' && typeof refrescarProductorSinNavegar === 'function') refrescarProductorSinNavegar();
// Este cambio vino de Firestore: persiste solo la copia local. NO programes
// guardarEstadoLocal(), porque eso puede convertir el eco remoto en una nueva
// escritura a Firestore después de que termine el debounce.
guardarEstadoEnLocalSeguro();
actualizarBadgeSincronizacion();
aplicandoCambioRemoto = false;
});
// Los dominios modulares se escuchan individualmente al abrir una pantalla que los necesita.
prepararCuentaModularEnSegundoPlano(estado.cuentasProductores.find(c => c && c.id === estado.cuentaActivaId));
// Un productor solo escucha en vivo SU PROPIA conversación — nunca la de
// otros productores. Es la misma cuenta con la que inició sesión, así que
// va de la mano con el resto de sus datos. Se usa solo cuentaActivaId (no
// estado.rolActual) porque esta función se llama desde varios puntos del
// login y en algunos rolActual todavía no se ha terminado de poner — pero
// cuentaActivaId SIEMPRE es una cuenta de productor cuando tiene valor (el
// admin nunca lo usa para sí mismo), así que es la señal confiable.
if (typeof window.firebaseEscucharChatMeta === 'function'){
cancelarEscuchaMetaChatProductor = window.firebaseEscucharChatMeta(estado.cuentaActivaId, (metaChat) => {
estado.chatMetaPorProductor[estado.cuentaActivaId] = metaChat || null;
if (typeof actualizarBadgeChatProductor === 'function') actualizarBadgeChatProductor();
});
}
// El historial completo NO se escucha al iniciar sesión. Se abre únicamente
// cuando la pantalla de chat está visible, igual que WhatsApp: el badge usa el
// documento meta ultraligero y el hilo usa su listener solo mientras está abierto.
}
let cancelarEscuchaColaAdminIRanch = () => {};
function detenerEscuchaColaAdminIRanch(){ try { cancelarEscuchaColaAdminIRanch(); } catch(e) {} cancelarEscuchaColaAdminIRanch = () => {}; }
function activarEscuchaColaAdminSegunRol(){
  detenerEscuchaColaAdminIRanch();
  if (estado.rolActual !== 'admin' || typeof window.firebaseEscucharColaAdmin !== 'function') return;
  cancelarEscuchaColaAdminIRanch = window.firebaseEscucharColaAdmin((datosColaAdmin, actualizado) => {
    if (actualizado && estado.ultimaSincronizacionColaAdmin === actualizado) return;
    if (guardadoLocalPendiente || sincronizandoConFirebase) return;
    Object.assign(estado, datosColaAdmin || {});
    estado.ultimaSincronizacionColaAdmin = actualizado;
    if (typeof renderTodoAdmin === 'function') renderTodoAdmin();
    // La cola administrativa llegó de la nube; no la vuelvas a escribir a la
    // nube desde el callback del listener.
    guardarEstadoEnLocalSeguro();
    actualizarBadgeSincronizacion();
  });
}
function aplicarGlobalRemoto(datosRemotos, actualizado){
  if (!datosRemotos) return;
  contadorActualizacionesGlobales++;
  if (!primeraCargaGlobalHecha){ primeraCargaGlobalHecha = true; resolverPrimeraCargaGlobal(); }
  if (actualizado && estado.ultimaSincronizacion === actualizado) return;
  if (guardadoLocalPendiente || sincronizandoConFirebase) return;
  aplicandoCambioRemoto = true;
  const cuentaActivaIdAntes = estado.cuentaActivaId;
  Object.assign(estado, datosRemotos);
  normalizarEstadoCargado();
  reengancharCuentaActiva();
  estado.ultimaSincronizacion = actualizado;
  if (estado.rolActual === 'productor' && typeof refrescarProductorSinNavegar === 'function') refrescarProductorSinNavegar();
  else if (estado.rolActual === 'admin' && typeof renderTodoAdmin === 'function') renderTodoAdmin();
  if (typeof aplicarFondoHeaderProductor === 'function') aplicarFondoHeaderProductor();
  if (typeof aplicarLogoPersonalizado === 'function') aplicarLogoPersonalizado();
  if (typeof actualizarBadgeChatProductor === 'function' && estado.rolActual === 'productor') actualizarBadgeChatProductor();
  if (typeof actualizarBadgeChatAdmin === 'function' && estado.rolActual === 'admin') actualizarBadgeChatAdmin();
  if (estado.cuentaActivaId !== cuentaActivaIdAntes) activarEscuchaCuentaActiva();
  // El dato llegó de Firestore: se actualiza la copia local únicamente. No se
  // programa un guardado con debounce porque eso volvería a enviar el mismo dato.
  guardarEstadoEnLocalSeguro();
  actualizarBadgeSincronizacion();
  aplicandoCambioRemoto = false;
}
let cancelarEscuchaGlobalIRanch = () => {};
function detenerEscuchaGlobalIRanch(){ try { cancelarEscuchaGlobalIRanch(); } catch(e) {} cancelarEscuchaGlobalIRanch = () => {}; }
function activarEscuchaGlobalSegunRol(){
  detenerEscuchaGlobalIRanch();
  if (estado.rolActual !== 'admin' || typeof window.firebaseEscucharGlobal !== 'function') return;
  cancelarEscuchaGlobalIRanch = window.firebaseEscucharGlobal(aplicarGlobalRemoto);
}
async function cargarGlobalInicialUnaVez(){
  if (typeof window.firebaseLeerGlobal !== 'function') return;
  try {
    const remoto = await window.firebaseLeerGlobal();
    if (remoto?.datos) aplicarGlobalRemoto(remoto.datos, remoto.actualizado);
    else if (!primeraCargaGlobalHecha){ primeraCargaGlobalHecha = true; resolverPrimeraCargaGlobal(); }
  } catch(e){
    console.warn('No se pudo obtener el índice global inicial:', e);
    if (!primeraCargaGlobalHecha){ primeraCargaGlobalHecha=true; resolverPrimeraCargaGlobal(); }
  }
}
function iniciarFirebase(){
  cargarGlobalInicialUnaVez();
  sincronizarConFirebase();
  activarEscuchaCuentaActiva();
  activarEscuchaGlobalSegunRol();
  activarEscuchaColaAdminSegunRol();
  if (typeof sincronizarFotosPendientes === 'function') sincronizarFotosPendientes();
}
if (window.firebaseListo) iniciarFirebase();
else window.addEventListener('firebase-listo', iniciarFirebase, { once: true });
function fechaHoy(){
if (estado.relojSimulado){
const d = new Date(estado.relojSimulado + 'T00:00:00');
if (!isNaN(d)) return d;
}
const real = new Date();
return new Date(real.getFullYear(), real.getMonth(), real.getDate());
}
function formatearFechaISO(d){
const pad = n => String(n).padStart(2,'0');
return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
}
// Arreglos que pertenecen a UN rancho/cuenta específica (no deben compartirse entre productores).
// hato/salud/pesajes/reproduccion ya se aislaban; el resto vivía como un solo arreglo global
// compartido por todas las cuentas — este es el defecto que se corrige aquí.
const ARREGLOS_POR_CUENTA = ['hato','salud','pesajes','reproduccion','tareas','potreros',
'costos','bodega','movimientosAnimal','planSanitario','visitasVet','predios','produccionLeche',
'tanqueLeche','alimentacionLeche','becerros','inventarioAlimento'];
const MAPA_CLAVE_ESTADO = { hato: 'animales' }; // estado.animales <-> cuenta.hato (nombres históricos distintos)
// Arquitectura de almacenamiento por dominios (fase compatible):
// mantenemos el documento actual como fuente de compatibilidad mientras
// preparamos una migración gradual de los módulos que más crecen. La bandera
// queda apagada hasta que las reglas de Firestore contemplen las nuevas rutas.
const IRANCH_STORAGE_CONFIG = {
  version: 4,
  modo: 'auto', // 'auto' | 'compatibilidad' | 'dominios'
  activarDominiosAutomaticamente: true,
  // Solo se activan/sincronizan en vivo los dominios que tienen sentido para
  // el tipo de cuenta. Esto NO borra nada: los demás dominios siguen en el
  // respaldo legado y se cargan solo cuando una función realmente los necesita.
  perfilesDominios: {
    carne: ['hato','salud','pesajes','reproduccion','movimientosAnimal'],
    leche: ['hato','salud','pesajes','reproduccion','movimientosAnimal','produccionLeche','tanqueLeche','alimentacionLeche'],
    punto: [],
    veterinario: [],
    admin: []
  },
  dominiosCrecimiento: ['produccionLeche','salud','pesajes','movimientosAnimal'],
  maxFirmaMemoria: 900000
};
function dominiosCrecimientoParaCuenta(cuenta){
  const tipo = String(cuenta?.tipo || '').toLowerCase();
  const perfil = IRANCH_STORAGE_CONFIG.perfilesDominios?.[tipo];
  return Array.isArray(perfil) ? perfil : IRANCH_STORAGE_CONFIG.dominiosCrecimiento;
}
const IRANCH_DOMAIN_META_KEY = 'miRanchApp_storage_meta_v3';
// Registro de estado de la arquitectura: permite detectar cuentas que todavía
// usan compatibilidad, medir crecimiento sin descargar otro documento y dejar
// trazabilidad local de la última migración. No contiene credenciales.
const IRANCH_HEALTH_KEY = 'miRanchApp_storage_health_v1';
let iRanchHealth = Object.create(null);
function cargarSaludStorageLocal(){
  try {
    const raw = localStorage.getItem(IRANCH_HEALTH_KEY);
    if (raw) iRanchHealth = JSON.parse(raw) || Object.create(null);
  } catch(e){ iRanchHealth = Object.create(null); }
}
function registrarSaludStorage(cuentaId, datos){
  if (!cuentaId) return;
  iRanchHealth[cuentaId] = Object.assign({}, iRanchHealth[cuentaId] || {}, datos || {}, { actualizado: new Date().toISOString() });
  try { localStorage.setItem(IRANCH_HEALTH_KEY, JSON.stringify(iRanchHealth)); } catch(e) {}
}
cargarSaludStorageLocal();
let firmasDominiosCuenta = Object.create(null);
let metadatosStorageCuenta = Object.create(null);
function obtenerFirmaLigera(valor){
  try {
    const texto = JSON.stringify(valor ?? null);
    // FNV-1a 32 bits: suficientemente estable para detectar cambios locales,
    // evitando guardar otra copia completa del documento solo para comparar.
    let h = 2166136261;
    for (let i=0;i<texto.length;i++) { h ^= texto.charCodeAt(i); h = Math.imul(h, 16777619); }
    return (h >>> 0).toString(16) + ':' + texto.length;
  } catch(e){ return 'error'; }
}
function actualizarMetadatosStorageLocal(cuentaId, extra){
  if (!cuentaId) return;
  metadatosStorageCuenta[cuentaId] = Object.assign({}, metadatosStorageCuenta[cuentaId] || {}, extra || {}, { actualizado: new Date().toISOString() });
  try { localStorage.setItem(IRANCH_DOMAIN_META_KEY, JSON.stringify(metadatosStorageCuenta)); } catch(e){}
}
function cargarMetadatosStorageLocal(){
  try {
    const raw = localStorage.getItem(IRANCH_DOMAIN_META_KEY);
    if (raw) metadatosStorageCuenta = JSON.parse(raw) || Object.create(null);
  } catch(e){ metadatosStorageCuenta = Object.create(null); }
}
cargarMetadatosStorageLocal();
// Dominios que ya están disponibles en memoria en esta sesión. Un dominio
// modular se trae solo cuando una pantalla lo necesita; no se descargan todos
// los historiales del rancho al iniciar sesión.
const dominiosCuentaCargados = Object.create(null);
const dominiosCuentaCargando = Object.create(null);
const cancelacionesListenersDominios = Object.create(null);
function claveDominioSesion(cuentaId, dominio){ return `${cuentaId}::${dominio}`; }
function dominiosInicialesParaCuenta(cuenta){
  const base = ['hato','salud'];
  if (String(cuenta?.tipo || '').toLowerCase() === 'leche') base.push('produccionLeche');
  return base.filter(d => dominiosCrecimientoParaCuenta(cuenta).includes(d));
}
function marcarDominioCargado(cuentaId, dominio){ if (cuentaId && dominio) dominiosCuentaCargados[claveDominioSesion(cuentaId, dominio)] = true; }
function dominioEstaCargado(cuentaId, dominio){ return !!dominiosCuentaCargados[claveDominioSesion(cuentaId, dominio)]; }
function activarListenerDominioSiHaceFalta(cuentaId, dominio){
  const clave = claveDominioSesion(cuentaId, dominio);
  if (cancelacionesListenersDominios[clave] || typeof window.firebaseEscucharDominiosCuenta !== 'function') return;
  cancelacionesListenersDominios[clave] = window.firebaseEscucharDominiosCuenta(cuentaId, [dominio], (d, datos, actualizado) => {
    if (d !== dominio || guardadoLocalPendiente || sincronizandoConFirebase) return;
    const claveEstado = MAPA_CLAVE_ESTADO[d] || d;
    aplicandoCambioRemoto = true;
    estado[claveEstado] = Array.isArray(datos) ? datos : [];
    const cuenta = estado.cuentasProductores.find(c => c && c.id === cuentaId);
    if (cuenta) cuenta[d] = estado[claveEstado];
    marcarDominioCargado(cuentaId, d);
    firmasDominiosCuenta[cuentaId] = construirIndiceDominiosCuenta(cuenta || {});
    actualizarMetadatosStorageLocal(cuentaId, { dominios: firmasDominiosCuenta[cuentaId], modo:'dominios' });
    estado.ultimaSincronizacionCuenta = actualizado || estado.ultimaSincronizacionCuenta;
    if (estado.rolActual === 'productor' && typeof refrescarProductorSinNavegar === 'function') refrescarProductorSinNavegar();
    setTimeout(() => { aplicandoCambioRemoto = false; }, 500);
  });
}
async function asegurarDominioCuentaCargado(cuentaId, dominio){
  if (!cuentaId || !dominio) return false;
  if (dominioEstaCargado(cuentaId, dominio)) return true;
  const cuenta = estado.cuentasProductores.find(c => c && c.id === cuentaId);
  const perfil = dominiosCrecimientoParaCuenta(cuenta || {});
  if (!perfil.includes(dominio)) return false;
  const meta = metadatosStorageCuenta[cuentaId] || {};
  // Si todavía no existe migración modular, el listener/documento legado ya
  // contiene este dominio: no hacemos una lectura redundante.
  if (meta.migracionDominios !== true){ marcarDominioCargado(cuentaId, dominio); return true; }
  if (typeof window.firebaseLeerDominioCuenta !== 'function') return false;
  const clave = claveDominioSesion(cuentaId, dominio);
  if (dominiosCuentaCargando[clave]) return dominiosCuentaCargando[clave];
  dominiosCuentaCargando[clave] = (async () => {
    try {
      const remoto = await window.firebaseLeerDominioCuenta(cuentaId, dominio);
      const claveEstado = MAPA_CLAVE_ESTADO[dominio] || dominio;
      if (remoto && remoto.datos != null){
        estado[claveEstado] = Array.isArray(remoto.datos) ? remoto.datos : [];
        if (cuenta) cuenta[dominio] = estado[claveEstado];
      } else if (cuenta && !Array.isArray(cuenta[dominio])) {
        cuenta[dominio] = estado[claveEstado] = [];
      }
      marcarDominioCargado(cuentaId, dominio);
      activarListenerDominioSiHaceFalta(cuentaId, dominio);
      firmasDominiosCuenta[cuentaId] = construirIndiceDominiosCuenta(cuenta || {});
      actualizarMetadatosStorageLocal(cuentaId, { dominios: firmasDominiosCuenta[cuentaId], modo:'dominios' });
      return true;
    } catch(e){ console.warn(`No se pudo cargar el dominio ${dominio}; se conserva el estado local.`, e); return false; }
    finally { delete dominiosCuentaCargando[clave]; }
  })();
  return dominiosCuentaCargando[clave];
}
async function asegurarDominiosPantallaProductor(nombre){
  const cuentaId = estado.cuentaActivaId;
  if (!cuentaId) return true;
  const cuenta = estado.cuentasProductores.find(c => c && c.id === cuentaId);
  const mapa = {
    home: dominiosInicialesParaCuenta(cuenta),
    hato: ['hato','salud','reproduccion'],
    estatus: ['hato','salud','reproduccion'],
    graficas: ['hato','salud','pesajes','reproduccion'],
    notificaciones: ['salud','reproduccion'],
    engorda: ['hato','pesajes'],
    transferencias: ['hato','movimientosAnimal'],
    historial: ['movimientosAnimal'],
    mensajes: [],
  };
  const dominios = (mapa[nombre] || []).filter(d => dominiosCrecimientoParaCuenta(cuenta || {}).includes(d));
  for (const dominio of dominios) await asegurarDominioCuentaCargado(cuentaId, dominio);
  return true;
}
async function prepararCuentaModularEnSegundoPlano(cuenta){
  if (!cuenta?.id || typeof window.firebaseLeerMetaCuenta !== 'function') return;
  try {
    const remoto = await window.firebaseLeerMetaCuenta(cuenta.id);
    if (remoto?.migracionDominios === true){
      metadatosStorageCuenta[cuenta.id] = Object.assign({}, metadatosStorageCuenta[cuenta.id] || {}, remoto, { migracionDominios:true, modo:'dominios' });
      actualizarMetadatosStorageLocal(cuenta.id, { migracionDominios:true, dominios: remoto.dominios || {}, modo:'dominios' });
      for (const dominio of dominiosInicialesParaCuenta(cuenta)) await asegurarDominioCuentaCargado(cuenta.id, dominio);
    } else {
      // El documento legado sigue siendo la fuente de compatibilidad hasta que
      // la migración termine; marcamos los dominios del perfil como disponibles
      // para no duplicar lecturas.
      dominiosCrecimientoParaCuenta(cuenta).forEach(d => marcarDominioCargado(cuenta.id, d));
    }
  } catch(e){ console.warn('No se pudo comprobar el estado modular de la cuenta; se mantiene compatibilidad.', e); }
}
function construirIndiceDominiosCuenta(cuenta){
  const indice = {};
  ARREGLOS_POR_CUENTA.forEach(clave => {
    const claveEstado = MAPA_CLAVE_ESTADO[clave] || clave;
    indice[clave] = obtenerFirmaLigera(cuenta?.[clave] ?? estado?.[claveEstado] ?? []);
  });
  return indice;
}
async function asegurarDominiosCuentaListos(cuenta){
  if (!cuenta?.id || !IRANCH_STORAGE_CONFIG.activarDominiosAutomaticamente) return false;
  const meta = metadatosStorageCuenta[cuenta.id] || {};
  if (meta.migracionDominios === true) return true;
  if (typeof window.firebaseLeerDominioCuenta !== 'function' || typeof window.firebaseGuardarDominioCuenta !== 'function') return false;
  try {
    // Antes de migrar, consulta una metadata diminuta. Si otro dispositivo ya
    // terminó la migración, no repetimos lecturas/escrituras innecesarias.
    if (typeof window.firebaseLeerMetaCuenta === 'function'){
      const remotoMeta = await window.firebaseLeerMetaCuenta(cuenta.id);
      if (remotoMeta?.migracionDominios === true){
        metadatosStorageCuenta[cuenta.id] = Object.assign({}, meta, remotoMeta, { migracionDominios:true, modo:'dominios' });
        firmasDominiosCuenta[cuenta.id] = Object.assign({}, remotoMeta.dominios || {});
        actualizarMetadatosStorageLocal(cuenta.id, { migracionDominios:true, dominios:firmasDominiosCuenta[cuenta.id], modo:'dominios' });
        return true;
      }
    }
    const firmas = construirIndiceDominiosCuenta(cuenta);
    const dominios = dominiosCrecimientoParaCuenta(cuenta);
    for (const dominio of dominios){
      const remoto = await window.firebaseLeerDominioCuenta(cuenta.id, dominio);
      const claveEstado = MAPA_CLAVE_ESTADO[dominio] || dominio;
      if (remoto && remoto.datos != null){
        cuenta[dominio] = Array.isArray(remoto.datos) ? remoto.datos : [];
      } else {
        const datos = Array.isArray(cuenta[dominio]) ? cuenta[dominio] : (estado[claveEstado] || []);
        const ok = await window.firebaseGuardarDominioCuenta(cuenta.id, dominio, datos);
        if (!ok) return false;
        cuenta[dominio] = datos;
      }
      firmas[dominio] = obtenerFirmaLigera(cuenta[dominio]);
    }
    // Una vez que cada dominio tiene copia modular, se retiran esos campos del
    // documento legado. El resto de la cuenta sigue allí para compatibilidad.
    if (typeof window.firebaseEliminarDominiosLegacy === 'function'){
      const retirados = await window.firebaseEliminarDominiosLegacy(cuenta.id, dominios);
      if (!retirados) return false;
    }
    if (typeof window.firebaseGuardarMetaCuenta === 'function'){
      const metaOk = await window.firebaseGuardarMetaCuenta(cuenta.id, { migracionDominios:true, tipo:cuenta.tipo || null, dominios:firmas, version:IRANCH_STORAGE_CONFIG.version });
      if (!metaOk) return false;
    }
    meta.migracionDominios = true;
    metadatosStorageCuenta[cuenta.id] = meta;
    firmasDominiosCuenta[cuenta.id] = firmas;
    dominios.forEach(d => marcarDominioCargado(cuenta.id, d));
    actualizarMetadatosStorageLocal(cuenta.id, { migracionDominios:true, dominios:firmas, modo:'dominios' });
    registrarSaludStorage(cuenta.id, { modo:'dominios', migracion:'completa', dominios:Object.keys(firmas) });
    dominiosInicialesParaCuenta(cuenta).forEach(d => activarListenerDominioSiHaceFalta(cuenta.id, d));
    return true;
  } catch(e){
    console.warn('Migración modular no disponible; se conserva el almacenamiento legado:', e);
    return false;
  }
}

function detectarDominiosModificadosCuenta(cuenta){
  const id = cuenta?.id || estado?.cuentaActivaId;
  const anterior = firmasDominiosCuenta[id] || {};
  const actualCompleto = construirIndiceDominiosCuenta(cuenta || {});
  // Solo los dominios realmente independientes se sincronizan aquí. Los
  // demás continúan en el documento de cuenta legado para no cambiar su
  // contrato ni provocar escrituras adicionales.
  const actual = {};
  const modificados = [];
  dominiosCrecimientoParaCuenta(cuenta || {}).filter(clave => metadatosStorageCuenta[id]?.migracionDominios === true && dominioEstaCargado(id, clave)).forEach(clave => {
    actual[clave] = actualCompleto[clave];
    if (actual[clave] !== anterior[clave]) modificados.push(clave);
  });
  return { actual, actualCompleto, modificados };
}

// Diagnóstico ligero para soporte: no contiene contraseñas ni datos de animales;
// solo describe qué arquitectura está usando una cuenta y cuánto crecen sus
// dominios. Sirve para detectar cuentas que todavía necesitan migración sin
// obligar al usuario a exportar manualmente toda su información.
function obtenerDiagnosticoAlmacenamientoCuenta(cuentaId){
  const id = cuentaId || estado.cuentaActivaId;
  const cuenta = (estado.cuentasProductores || []).find(c => c && c.id === id);
  if (!cuenta) return null;
  const dominios = {};
  ARREGLOS_POR_CUENTA.forEach(dominio => {
    const claveEstado = MAPA_CLAVE_ESTADO[dominio] || dominio;
    const datos = estado[claveEstado] || cuenta[dominio] || [];
    dominios[dominio] = { registros: Array.isArray(datos) ? datos.length : 0, firma: obtenerFirmaLigera(datos) };
  });
  const modo = metadatosStorageCuenta[id]?.migracionDominios ? 'dominios' : 'compatibilidad';
  const diagnostico = { version: IRANCH_STORAGE_CONFIG.version, modo, cuentaId: id, dominios, salud: iRanchHealth[id] || null };
  registrarSaludStorage(id, { modo, registrosTotales: Object.values(dominios).reduce((s, d) => s + (d.registros || 0), 0) });
  return diagnostico;
}
// Herramienta de soporte no invasiva: devuelve un resumen pequeño y no sensible
// para revisar el estado de almacenamiento sin exponer contraseñas ni datos
// de animales. Se deja en window para poder auditar una instalación desde la
// consola del navegador cuando haga falta.
window.iRanchDiagnosticoAlmacenamiento = function(cuentaId){
  try { return obtenerDiagnosticoAlmacenamientoCuenta(cuentaId); }
  catch(e){ return { error: 'diagnostico_no_disponible' }; }
};

const CLAVES_ESTADO_POR_CUENTA = ARREGLOS_POR_CUENTA.map(c => MAPA_CLAVE_ESTADO[c] || c);
// Estos 5 van en su propio documento ("cola de administración"), aparte del
// documento público — solo cambian cuando alguien manda una solicitud o pasa
// algo que un administrador tiene que revisar, y solo a ellos les urge
// enterarse al instante. Ver notas junto a firebaseEscucharColaAdmin.
const CAMPOS_COLA_ADMIN = ['solicitudesRegistro', 'solicitudesPago', 'solicitudesTransferencia', 'auditoriaTransferencias', 'avisosReactoresTB', 'resumenMensajes'];
// mensajesPorProductor NUNCA va en el documento global ni en la cola de
// administración — cada conversación vive en su propio documento aparte
// (colección "miranchapp_mensajes"), y solo la escuchan en vivo los 2 que
// participan en ella. Se excluye aquí a mano porque construirPayloadGlobal()
// recorre TODAS las claves de estado por defecto.
const CAMPOS_EXCLUIDOS_DE_TODO_SYNC_COMPARTIDO = ['mensajesPorProductor','chatMetaPorProductor'];
function cargarDatosDeCuenta(cuenta){
ARREGLOS_POR_CUENTA.forEach(clave => {
if (!Array.isArray(cuenta[clave])) cuenta[clave] = [];
estado[MAPA_CLAVE_ESTADO[clave] || clave] = cuenta[clave];
});
}
// Para usar al iniciar sesión: primero intenta traer los datos pesados de esa cuenta
// desde su documento propio en Firestore (por si este dispositivo nunca los tenía en
// caché); si no hay conexión o falla, sigue con lo que ya haya en memoria/local.
async function cargarDatosDeCuentaConFirestore(cuenta){
if (typeof window.firebaseLeerCuenta === 'function' && navigator.onLine){
try {
const remoto = await window.firebaseLeerCuenta(cuenta.id);
if (remoto) Object.assign(cuenta, remoto);
} catch(e){ console.warn('No se pudieron traer los datos de la cuenta desde Firestore', e); }
}
cargarDatosDeCuenta(cuenta);
const id = cuenta?.id;
if (id){
  firmasDominiosCuenta[id] = construirIndiceDominiosCuenta(cuenta);
  actualizarMetadatosStorageLocal(id, { dominios: firmasDominiosCuenta[id], modo: IRANCH_STORAGE_CONFIG.modo });
  if (typeof prepararCuentaModularEnSegundoPlano === 'function') await prepararCuentaModularEnSegundoPlano(cuenta);
}
}

function limpiarDatosDeCuentaActiva(){
ARREGLOS_POR_CUENTA.forEach(clave => {
if (clave === 'hato'){ estado.animales = []; return; }
estado[clave] = [];
});
}
// Versión "ligera" de una cuenta: solo lo que el admin necesita ver en su lista
// (nombre, UPP, usuario, vigencia...), SIN los arreglos pesados del rancho — esos
// se guardan aparte, en el documento propio de esa cuenta.
function cuentaLigera(cuenta){
const ligera = {};
Object.keys(cuenta).forEach(clave => {
if (!ARREGLOS_POR_CUENTA.includes(clave) && !['clave','password','contrasena'].includes(clave)) ligera[clave] = cuenta[clave];
});
return ligera;
}
// Arma lo que se guarda en el documento GLOBAL de Firestore: todo el estado excepto
// los arreglos por-cuenta (que viven en el documento de cada cuenta), y con
// cuentasProductores "aligerado" (sin los datos pesados de cada rancho adentro).
function construirPayloadGlobal(){
const payload = {};
Object.keys(estado).forEach(clave => {
if (CLAVES_ESTADO_POR_CUENTA.includes(clave)) return; // se guardan aparte
if (CAMPOS_COLA_ADMIN.includes(clave)) return; // se guardan aparte, en la cola de administración
if (CAMPOS_EXCLUIDOS_DE_TODO_SYNC_COMPARTIDO.includes(clave)) return; // cada uno en su propio documento
payload[clave] = sanitizarCredencialesRecursivoIRanch(estado[clave]);
});
payload.cuentasProductores = (estado.cuentasProductores || []).map(cuentaLigera);
return payload;
}
// Arma lo que se guarda en el documento de la "cola de administración" —
// solo los 5 campos que de verdad necesitan avisar en vivo a quien
// administra, y a nadie más.
function construirPayloadColaAdmin(){
const payload = {};
CAMPOS_COLA_ADMIN.forEach(clave => { payload[clave] = sanitizarCredencialesRecursivoIRanch(estado[clave]); });
return payload;
}
// Para cuentas de PRODUCTOR nada más: como ya NO se quedan escuchando en vivo
// la cola de administración (para no generarles tráfico de más), su copia
// local de los otros 4 campos puede estar desactualizada o incompleta. Antes
// de guardar algo nuevo ahí (una solicitud, un ticket de pago), primero se
// trae la versión más reciente del servidor para esos otros campos y se
// combina — así nunca se sobreescribe ni se borra lo que mandaron otros
// productores mientras tanto. campoModificado es el único que se deja tal
// cual está en local (ya trae lo nuevo que se acaba de agregar).
async function guardarEnColaAdminComoProductor(campoModificado){
if (typeof window.firebaseLeerColaAdmin !== 'function' || typeof window.firebaseGuardarColaAdmin !== 'function') return false;
try {
const remoto = await window.firebaseLeerColaAdmin();
if (remoto){
CAMPOS_COLA_ADMIN.forEach(clave => {
if (clave === campoModificado) return;
if (Array.isArray(remoto[clave])) estado[clave] = remoto[clave];
});
}
return await window.firebaseGuardarColaAdmin(construirPayloadColaAdmin());
} catch(e){
console.warn('No se pudo guardar en la cola de administración de forma segura', e);
return false;
}
}
// Arma lo que se guarda en el documento de la cuenta activa: solo sus arreglos pesados.
function construirPayloadCuentaActivaSinDominiosMigrados(){
  const payload = { id: estado.cuentaActivaId };
  const cuenta = estado.cuentasProductores.find(c => c && c.id === estado.cuentaActivaId) || {};
  const migrados = new Set(metadatosStorageCuenta[estado.cuentaActivaId]?.migracionDominios ? dominiosCrecimientoParaCuenta(cuenta) : []);
  ARREGLOS_POR_CUENTA.forEach(clave => {
    if (migrados.has(clave)) return;
    payload[clave] = estado[MAPA_CLAVE_ESTADO[clave] || clave];
  });
  return payload;
}
function construirPayloadCuentaActiva(){
const payload = { id: estado.cuentaActivaId };
ARREGLOS_POR_CUENTA.forEach(clave => {
payload[clave] = estado[MAPA_CLAVE_ESTADO[clave] || clave];
});
return payload;
}
// ================= ARCHIVADO AUTOMÁTICO DE REGISTROS VIEJOS =================
// Estos 4 campos son los que más rápido crecen con el tiempo (un registro
// nuevo por animal cada vez que se ordeña/pesa/atiende), a diferencia del
// resto (hato, potreros, bodega) que crecen mucho más despacio. Si se dejan
// crecer sin control, el documento de la cuenta puede pasar el límite de
// 1 MB de Firestore — sobre todo en ranchos lecheros con registro diario.
const CAMPOS_QUE_SE_ARCHIVAN = ['produccionLeche', 'salud', 'pesajes', 'movimientosAnimal'];
const MESES_ANTES_DE_ARCHIVAR = 12;
// Calcula cuánto pesaría el documento de la cuenta activa ahorita mismo, tal
// como se guardaría en Firestore.
function tamanoDocumentoCuentaActiva(){
return new Blob([JSON.stringify(construirPayloadCuentaActiva())]).size;
}
// Revisa si el documento de la cuenta ya se acercó demasiado al límite (se
// dispara bastante antes del 1 MB real, para tener margen) y, si sí, manda
// los registros más viejos de los 4 campos de arriba a un documento de
// archivo aparte — dejando en el documento principal solo lo reciente.
// Se avisa siempre con un mensaje claro, nunca se archiva en silencio.
const LIMITE_AVISO_BYTES = 600 * 1024; // 600 KB — deja margen antes de llegar a 1 MB
function tamanoAproximadoBytes(valor){
  try {
    const texto = JSON.stringify(valor);
    return typeof TextEncoder === 'function' ? new TextEncoder().encode(texto).length : texto.length * 2;
  } catch(e){ return Number.MAX_SAFE_INTEGER; }
}
function archivoLegadoTieneEspacioSuficiente(archivo){
  return tamanoAproximadoBytes(archivo) < LIMITE_AVISO_BYTES;
}
// Datos del informe bimestral pendiente de descargar (se llenan al detectar
// que hace falta, y se usan cuando la persona confirma la descarga/archivo).
let datosInformeBimestralPendiente = null;
// Paso 1: revisa si hace falta el informe — si sí, arma qué se archivaría
// (sin tocar nada todavía) y muestra el aviso obligatorio.
async function revisarSiHaceFaltaInformeBimestral(){
if (!estado.cuentaActivaId) return false;
const tamano = tamanoDocumentoCuentaActiva();
if (tamano < LIMITE_AVISO_BYTES) return false;
const fechaCorte = sumarDiasISO(hoyISO(), -30 * MESES_ANTES_DE_ARCHIVAR);
const paraArchivar = {};
let totalRegistros = 0;
CAMPOS_QUE_SE_ARCHIVAN.forEach(campo => {
  const arreglo = estado[campo] || [];
  const viejos = arreglo.filter(r => r.fecha && r.fecha < fechaCorte);
  if (viejos.length > 0){ paraArchivar[campo] = viejos; totalRegistros += viejos.length; }
});
if (!totalRegistros){ mostrarToast('Aviso: la cuenta está creciendo y no se encontraron registros antiguos archivables.'); return false; }
if (typeof window.firebaseGuardarArchivoBloque !== 'function' || typeof window.firebaseLeerIndiceArchivo !== 'function' || typeof window.firebaseGuardarIndiceArchivo !== 'function'){
  // Compatibilidad: si el proyecto aún no expone el archivo modular, se usa
  // el archivo histórico legado automáticamente. Ya no se obliga al productor
  // a descargar un CSV para poder continuar.
  let archivoExistente = null;
  if (typeof window.firebaseLeerArchivo === 'function') archivoExistente = await window.firebaseLeerArchivo(estado.cuentaActivaId);
  const archivoFinal = archivoExistente || {};
  CAMPOS_QUE_SE_ARCHIVAN.forEach(campo => { if (paraArchivar[campo]) archivoFinal[campo] = [...(archivoFinal[campo] || []), ...paraArchivar[campo]]; });
  // El archivo legado también es un documento único. Nunca lo hacemos crecer
  // hasta el límite de Firestore: si ya no cabe con margen, dejamos los datos
  // en operación y reintentamos cuando el almacenamiento modular esté disponible.
  if (!archivoLegadoTieneEspacioSuficiente(archivoFinal)) {
    console.warn('Archivo legado demasiado grande; se conserva el historial operativo para reintento modular.');
    return false;
  }
  if (typeof window.firebaseGuardarArchivo !== 'function' || !(await window.firebaseGuardarArchivo(estado.cuentaActivaId, archivoFinal))) return false;
  CAMPOS_QUE_SE_ARCHIVAN.forEach(campo => { if (paraArchivar[campo]) estado[campo] = (estado[campo] || []).filter(r => !(r.fecha && r.fecha < fechaCorte)); });
  guardarEstadoLocal();
  mostrarToast(`Historial protegido automáticamente: ${totalRegistros} registro(s) archivados.`);
  return true;
}
const cuentaId = estado.cuentaActivaId;
const indice = (await window.firebaseLeerIndiceArchivo(cuentaId)) || {};
const periodosIndice = indice.periodos || {};
let archivados = 0;
for (const campo of CAMPOS_QUE_SE_ARCHIVAN){
  const registros = paraArchivar[campo] || [];
  if (!registros.length) continue;
  const porPeriodo = {};
  registros.forEach(r => {
    const periodo = String(r.fecha || fechaCorte).slice(0,7);
    (porPeriodo[periodo] ||= []).push(r);
  });
  for (const [periodo, lote] of Object.entries(porPeriodo)){
    // El mismo periodo se vuelve a leer/combinar para que una segunda
    // ejecución nunca borre registros archivados previamente.
    const existentes = await window.firebaseLeerArchivoBloque(cuentaId, campo, periodo) || [];
    const mapa = new Map();
    [...existentes, ...lote].forEach(r => {
      const k = String(r.id || r.idRegistro || JSON.stringify([r.animal,r.fecha,r.hora,r.tipo,r.detalle]));
      mapa.set(k, r);
    });
    const combinado = Array.from(mapa.values()).sort((a,b) => String(a.fecha||'').localeCompare(String(b.fecha||'')));
    const ok = await window.firebaseGuardarArchivoBloque(cuentaId, campo, periodo, combinado);
    if (!ok){
      // Si las reglas actuales todavía no permiten la colección modular,
      // intentamos el almacenamiento legado ya existente antes de abortar.
      let archivoExistente = null;
      if (typeof window.firebaseLeerArchivo === 'function') archivoExistente = await window.firebaseLeerArchivo(cuentaId);
      const archivoFinal = archivoExistente || {};
      CAMPOS_QUE_SE_ARCHIVAN.forEach(c => { if (paraArchivar[c]) archivoFinal[c] = [...(archivoFinal[c] || []), ...paraArchivar[c]]; });
      // No arriesgar un documento legado cercano al límite de Firestore.
      if (!archivoLegadoTieneEspacioSuficiente(archivoFinal)) {
        console.warn('Archivo legado demasiado grande; se conserva el historial operativo para reintento modular.');
        return false;
      }
      if (typeof window.firebaseGuardarArchivo !== 'function' || !(await window.firebaseGuardarArchivo(cuentaId, archivoFinal))) return false;
      CAMPOS_QUE_SE_ARCHIVAN.forEach(c => { if (paraArchivar[c]) estado[c] = (estado[c] || []).filter(r => !(r.fecha && r.fecha < fechaCorte)); });
      guardarEstadoLocal();
      mostrarToast(`Historial protegido automáticamente: ${totalRegistros} registro(s) archivados con almacenamiento compatible.`);
      return true;
    }
    periodosIndice[campo] ||= [];
    if (!periodosIndice[campo].includes(periodo)) periodosIndice[campo].push(periodo);
    archivados += lote.length;
  }
}
const okIndice = await window.firebaseGuardarIndiceArchivo(cuentaId, { periodos: periodosIndice, version: 2 });
if (!okIndice) return false;
// Solo se eliminan del documento operativo después de confirmar que los
// bloques y su índice quedaron escritos correctamente.
CAMPOS_QUE_SE_ARCHIVAN.forEach(campo => {
  if (!paraArchivar[campo]) return;
  estado[campo] = (estado[campo] || []).filter(r => !(r.fecha && r.fecha < fechaCorte));
});
datosInformeBimestralPendiente = null;
guardarEstadoLocal();
mostrarToast(`Historial protegido automáticamente: ${archivados} registro(s) pasaron a archivo por bloques.`);
return true;
}
function mostrarModalInformeBimestral(){
const d = datosInformeBimestralPendiente;
if (!d) return;
document.getElementById('informe-bimestral-resumen').innerHTML = ETIQUETAS_CAMPOS_ARCHIVO
? CAMPOS_QUE_SE_ARCHIVAN.filter(c => d.paraArchivar[c]).map(c => `<li>${ETIQUETAS_CAMPOS_ARCHIVO[c].titulo}: <strong>${d.paraArchivar[c].length}</strong> registro(s)</li>`).join('')
: '';
document.getElementById('informe-bimestral-vista-1').classList.remove('hidden');
document.getElementById('informe-bimestral-vista-2').classList.add('hidden');
document.getElementById('modal-informe-bimestral').classList.remove('hidden');
}
// Respaldo opcional: genera un CSV con los registros que fueron seleccionados
// para archivo. El archivado automático NO depende de que el productor descargue
// nada; la descarga queda disponible únicamente como copia personal adicional.
function descargarInformeBimestral(){
const d = datosInformeBimestralPendiente;
if (!d) return;
const encabezados = ['categoria','animal','fecha','detalle'];
const filas = [];
CAMPOS_QUE_SE_ARCHIVAN.forEach(campo => {
if (!d.paraArchivar[campo]) return;
const info = ETIQUETAS_CAMPOS_ARCHIVO[campo];
d.paraArchivar[campo].forEach(r => {
const detalle = info.columnas.filter(c => c !== 'animal' && c !== 'fecha').map(c => `${c}: ${r[c] ?? ''}`).join(' | ');
filas.push([info.titulo, r.animal || '', r.fecha || '', detalle]);
});
});
if (typeof generarCSVConPie === 'function') generarCSVConPie(`Informe bimestral ${hoyISO()}`, encabezados, filas);
// Se pasa a la segunda vista (sugerencia de respaldo por correo) después de
// que el navegador ya disparó la descarga.
document.getElementById('informe-bimestral-vista-1').classList.add('hidden');
document.getElementById('informe-bimestral-vista-2').classList.remove('hidden');
}
// Sugerencia de respaldo: abre el menú de compartir del propio celular (el
// mismo que usa para compartir fotos por WhatsApp) para que, si quiere,
// avise por correo que ya tiene su respaldo — la app nunca manda el correo
// ella misma, ni tiene forma de hacerlo. El archivo ya se descargó en el
// paso anterior; aquí solo se ayuda a recordar mandarlo a su correo desde
// donde el celular lo haya guardado (Descargas, Archivos, etc.).
async function compartirInformeBimestralPorCorreo(){
if (navigator.share){
try {
await navigator.share({ title: 'Informe bimestral de MiRanch', text: 'Ya descargué mi informe bimestral — lo estoy respaldando en mi correo.' });
return;
} catch(e){ /* la persona canceló — no pasa nada */ }
}
mostrarToast('Busca el archivo que se acaba de descargar en tu celular (carpeta Descargas) y compártelo a tu correo desde ahí');
}
// Compatibilidad histórica: permite completar manualmente un archivado desde
// la interfaz antigua. El flujo automático ya archiva directamente por bloques.
async function confirmarArchivadoBimestral(){
const d = datosInformeBimestralPendiente;
if (!d) return;
CAMPOS_QUE_SE_ARCHIVAN.forEach(campo => {
if (!d.paraArchivar[campo]) return;
estado[campo] = (estado[campo] || []).filter(r => !(r.fecha && r.fecha < d.fechaCorte));
});
let archivoExistente = null;
if (typeof window.firebaseLeerArchivo === 'function'){
archivoExistente = await window.firebaseLeerArchivo(estado.cuentaActivaId);
}
const archivoFinal = archivoExistente || {};
CAMPOS_QUE_SE_ARCHIVAN.forEach(campo => {
if (!d.paraArchivar[campo]) return;
archivoFinal[campo] = [...(archivoFinal[campo] || []), ...d.paraArchivar[campo]];
});
if (typeof window.firebaseGuardarArchivo === 'function'){
if (!archivoLegadoTieneEspacioSuficiente(archivoFinal)) {
  mostrarToast('El historial es demasiado grande para el archivo compatible; se conserva en la cuenta y se reintentará el archivado seguro.');
  return;
}
await window.firebaseGuardarArchivo(estado.cuentaActivaId, archivoFinal);
}
guardarEstadoLocal();
document.getElementById('modal-informe-bimestral').classList.add('hidden');
mostrarToast(`Listo — se archivaron ${d.totalRegistros} registro(s). Siguen disponibles en "Historial archivado".`);
datosInformeBimestralPendiente = null;
}
// Se deja el nombre anterior apuntando al nuevo primer paso, para no romper
// nada de lo que ya llama a esta función (ej. dentro de sincronizarConFirebase).
async function archivarRegistrosAntiguosSiNecesario(){ return await revisarSiHaceFaltaInformeBimestral(); }
// Trae temporalmente lo archivado y lo junta con lo actual, SOLO para
// mostrarlo/exportarlo en pantalla — no se vuelve a guardar mezclado en la
// cuenta principal (para no regresar al mismo problema).
async function obtenerRegistrosConArchivo(campo){
const actuales = estado[campo] || [];
if (typeof window.firebaseLeerArchivo !== 'function' || !estado.cuentaActivaId) return actuales;
const archivo = await window.firebaseLeerArchivo(estado.cuentaActivaId);
let historicos = archivo && Array.isArray(archivo[campo]) ? [...archivo[campo]] : [];
if (typeof window.firebaseLeerIndiceArchivo === 'function' && typeof window.firebaseLeerArchivoBloque === 'function'){
  const indice = await window.firebaseLeerIndiceArchivo(estado.cuentaActivaId);
  const periodos = Array.isArray(indice?.periodos?.[campo]) ? indice.periodos[campo] : [];
  for (const periodo of periodos){
    const bloque = await window.firebaseLeerArchivoBloque(estado.cuentaActivaId, campo, periodo);
    if (Array.isArray(bloque)) historicos = historicos.concat(bloque);
  }
}
if (!historicos.length) return actuales;
const mapa = new Map();
[...historicos, ...actuales].forEach(r => {
  const k = String(r.id || r.idRegistro || JSON.stringify([r.animal,r.fecha,r.hora,r.tipo,r.detalle]));
  mapa.set(k, r);
});
return Array.from(mapa.values()).sort((a,b) => (a.fecha||'').localeCompare(b.fecha||''));
}
// Pantalla "Historial archivado": consulta y muestra en una tabla sencilla lo
// que se pidió, combinando lo archivado con lo reciente — con botón para
// exportarlo a CSV si se necesita.
const ETIQUETAS_CAMPOS_ARCHIVO = {
produccionLeche: { titulo: 'Producción de leche', columnas: ['animal','fecha','ordenador','litrosAM','litrosPM','total','grasa','proteina','celulas'] },
salud: { titulo: 'Salud', columnas: ['animal','fecha','tipo','producto','proxima','notas'] },
pesajes: { titulo: 'Pesajes', columnas: ['animal','fecha','peso','lote','condicionCorporal'] },
movimientosAnimal: { titulo: 'Movimientos', columnas: ['animal','fecha','tipo','de','a','notas'] },
};
async function cargarYMostrarArchivo(){
const campo = valor('archivo-tipo-campo');
const cont = document.getElementById('archivo-historico-resultado');
if (!cont) return;
cont.innerHTML = `<p class="text-xs text-center py-4" style="color:var(--sage);"><i class="fa-solid fa-spinner fa-spin"></i> Consultando...</p>`;
const registros = await obtenerRegistrosConArchivo(campo);
const info = ETIQUETAS_CAMPOS_ARCHIVO[campo];
if (registros.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-4" style="color:var(--sage);">Sin registros de "${info.titulo}" todavía</p>`;
return;
}
cont.innerHTML = `
<div class="flex items-center justify-between mb-2">
<p class="text-sm font-bold">${registros.length} registro(s) — ${info.titulo}</p>
<button class="text-xs font-bold px-3 py-2 rounded-full" onclick='exportarArchivoComoCSV(${JSON.stringify(campo)})' style="background:var(--parchment); color:var(--pine); border:2px solid var(--line);"><i class="fa-solid fa-file-arrow-down"></i> CSV</button>
</div>
<div class="space-y-1" style="max-height:60vh; overflow-y:auto;">
${registros.map(r => `<div class="bg-white rounded-2xl p-3 text-xs" style="border:1.5px solid var(--line);">${info.columnas.map(c => `<span style="color:var(--sage);">${c}:</span> <strong>${r[c] ?? '—'}</strong>`).join(' · ')}</div>`).join('')}
</div>`;
}
function exportarArchivoComoCSV(campo){
obtenerRegistrosConArchivo(campo).then(registros => {
const info = ETIQUETAS_CAMPOS_ARCHIVO[campo];
const filas = registros.map(r => info.columnas.map(c => r[c] ?? ''));
if (typeof generarCSVConPie === 'function') generarCSVConPie(info.titulo, info.columnas, filas);
});
}
// Tras recibir el documento global remoto (que trae cuentasProductores "ligero"),
// vuelve a enganchar los arreglos pesados de la cuenta activa para que cuenta.hato
// siga apuntando al mismo arreglo que estado.animales (y así el resto del código,
// que ya asume esa relación, no se rompa).
function reengancharCuentaActiva(){
if (!estado.cuentaActivaId) return;
const cuenta = estado.cuentasProductores.find(c => c && c.id === estado.cuentaActivaId);
if (!cuenta) return;
ARREGLOS_POR_CUENTA.forEach(clave => {
cuenta[clave] = estado[MAPA_CLAVE_ESTADO[clave] || clave];
});
}
function hoyISO(){ return formatearFechaISO(fechaHoy()); }
// Calcula la edad en meses completos a partir de una fecha de nacimiento —
// las pruebas de campo piden la edad en meses, pero los documentos oficiales
// (como la lista de animales del productor) suelen traer la fecha de
// nacimiento, no la edad ya calculada. Acepta 'YYYY-MM-DD' u otro formato que
// Date() entienda; regresa null si la fecha no es válida o es futura.
// ---- Formato oficial "Concentrado de Identificadores SINIIGA" ----
// Documento más estructurado que una lista libre: trae estatus (VIGENTE/VENTA),
// folio REEMO (solo aparece si el animal ya no está vigente para movilización),
// y la fecha de nacimiento viene como mes-año (ej. "06-2016"), no día completo.
function normalizarAreteOficial(numeroCrudo){
// Misma convención ya usada en el resto de la app: se descartan el "MX" y los
// dígitos de relleno iniciales, quedándose solo con los últimos 10 dígitos.
// A propósito NO se antepone "MX" al valor que se guarda aquí — el resto de
// la app (buscarAnimalPorArete, etc.) compara aretes por texto exacto contra
// lo que ya está guardado en el inventario, que tampoco trae "MX".
const soloDigitos = (numeroCrudo || '').replace(/\D/g, '');
if (soloDigitos.length < 6) return null;
return soloDigitos.slice(-10);
}
function extraerEstatusDeTexto(linea){
if (/\bVIGENTE\b/i.test(linea)) return 'VIGENTE';
if (/\bVENTA\b/i.test(linea)) return 'VENTA';
if (/\b(BAJA|MUERTE|MUERTO|SACRIFICIO)\b/i.test(linea)) return 'BAJA';
return null;
}
function extraerFolioRemoDeTexto(linea, areteCrudo){
// "Folio Reemo 12345" con la etiqueta junto al número (algunos documentos sí
// la repiten por renglón).
const conEtiqueta = linea.match(/\breemo[:\s]*([0-9]{3,})\b/i);
if (conEtiqueta) return conEtiqueta[1];
// Respaldo por posición: en una tabla, cada renglón trae los valores en el
// mismo orden que el encabezado, sin repetir la etiqueta — el folio REEMO
// suele ser la última columna. Si el renglón termina en un guion, no hay
// folio; si termina en un número que no es el arete, se toma como folio.
const tokens = linea.trim().split(/\s+/);
const ultimo = tokens[tokens.length - 1];
if (ultimo === '-') return null;
if (/^\d{3,}$/.test(ultimo) && ultimo !== areteCrudo) return ultimo;
return null;
}
function extraerFechaMesAnioDeTexto(linea){
// Formato "MM-YYYY" o "MM/YYYY" (fecha de nacimiento en este documento no
// trae día, solo mes y año).
const m = linea.match(/\b(0?[1-9]|1[0-2])[-\/](20\d{2}|19\d{2})\b/);
return m ? { mes: parseInt(m[1], 10), anio: parseInt(m[2], 10) } : null;
}
function calcularEdadMesesDesdeMesAnio(mesAnio){
if (!mesAnio) return null;
const hoy = fechaHoy();
let meses = (hoy.getFullYear() - mesAnio.anio) * 12 + (hoy.getMonth() + 1 - mesAnio.mes);
return Math.max(0, meses);
}
function parsearConcentradoSINIIGA(textoCompleto){
const lineasCrudas = textoCompleto.split('\n').map(l => l.trim()).filter(Boolean);
// Metadatos del encabezado del documento (UPP y nombre del productor), si
// aparecen en las primeras líneas.
const primerasLineas = lineasCrudas.slice(0, 8);
const lineaUpp = primerasLineas.find(l => /\bUPP\b/i.test(l));
const uppMatch = lineaUpp ? (lineaUpp.match(/\bUPP[:\s]*([0-9]{6,15})\b/i) || lineaUpp.match(/\b([0-9]{2}[-\s]?[0-9]{3}[-\s]?[0-9]{3,7})\b/)) : null;
const lineaProductor = primerasLineas.find(l => /(?:PRODUCTOR|PROPIETARIO)[:\s]/i.test(l));
const nombreMatch = lineaProductor ? lineaProductor.match(/(?:PRODUCTOR|PROPIETARIO)[:\s]+([A-ZÁÉÍÓÚÑ ]{6,60})/i) : null;
const idxEncabezado = detectarRenglonEncabezado(lineasCrudas);
const lineas = idxEncabezado >= 0 ? lineasCrudas.slice(idxEncabezado + 1) : lineasCrudas;
const inventarioCompleto = [];
lineas.forEach(linea => {
const areteCrudo = extraerAreteDeTexto(linea);
if (!areteCrudo) return;
const arete = normalizarAreteOficial(areteCrudo);
const estatus = extraerEstatusDeTexto(linea);
const folioRemo = extraerFolioRemoDeTexto(linea, areteCrudo);
const mesAnioNac = extraerFechaMesAnioDeTexto(linea);
const edadMeses = calcularEdadMesesDesdeMesAnio(mesAnioNac);
const raza = extraerRazaDeTexto(linea);
const sexo = extraerSexoDeTexto(linea);
const vigenteYSinFolio = (estatus === 'VIGENTE' || !estatus) && !folioRemo;
const dudoso = !estatus || edadMeses == null || !raza || !sexo;
inventarioCompleto.push({ arete, estatus: estatus || 'DESCONOCIDO', folioRemo, edadMeses, raza, sexo, vigenteYSinFolio, dudoso, incluir: vigenteYSinFolio });
});
return {
metadatos: { upp: uppMatch ? uppMatch[1].replace(/[\s-]/g,'') : null, productor: nombreMatch ? nombreMatch[1].trim() : null },
inventarioCompleto,
filtradoPruebaCampo: inventarioCompleto.filter(f => f.vigenteYSinFolio),
};
}
async function extraerConcentradoSINIIGARobusto(dataUrl, textoInicial){
  const texto=String(textoInicial||'');
  const base=parsearConcentradoSINIIGA(texto);
  const idsDetectados=new Map();
  (base.inventarioCompleto||[]).forEach(f=>{ if(f.arete) idsDetectados.set(f.arete, f); });
  // El lector dirigido de la tabla rescata identificadores que el OCR de la
  // página completa puede perder por líneas, bordes o celdas. Para inventario
  // completo los conservamos aunque falten otros campos: nunca es mejor perder
  // un animal que mostrarlo como "pendiente de revisar".
  try{
    const ids=await (typeof extraerIdentificadoresSINIIGADirigidos==='function'
      ? extraerIdentificadoresSINIIGADirigidos(dataUrl) : []);
    const idsNorm=[...(new Set((ids||[]).map(normalizarAreteOficial).filter(Boolean)))];
    if(idsNorm.length >= 2){
      // Cuando el lector especializado encuentra varios identificadores válidos,
      // esos números son una fuente más confiable que los falsos positivos que
      // el OCR de página completa puede producir con fechas/folios. Reconstruimos
      // la lista desde ellos y conservamos únicamente los demás datos que sí pudo
      // leer el OCR general para ese mismo arete.
      const porArete=new Map(idsNorm.map(arete=>[arete, idsDetectados.get(arete)]));
      idsDetectados.clear();
      idsNorm.forEach(arete=>idsDetectados.set(arete, porArete.get(arete) || {
        arete, estatus:'DESCONOCIDO', folioRemo:null, edadMeses:null,
        raza:null, sexo:null, vigenteYSinFolio:false, dudoso:true, incluir:true
      }));
    } else {
      idsNorm.forEach(arete=>{
        if(!idsDetectados.has(arete)) idsDetectados.set(arete, {
          arete, estatus:'DESCONOCIDO', folioRemo:null, edadMeses:null,
          raza:null, sexo:null, vigenteYSinFolio:false, dudoso:true, incluir:true
        });
      });
    }
  }catch(e){ console.warn('No se pudo hacer rescate dirigido SINIIGA',e); }
  return {
    metadatos: base.metadatos,
    inventarioCompleto: [...idsDetectados.values()],
    filtradoPruebaCampo: [...idsDetectados.values()].filter(f=>f.vigenteYSinFolio)
  };
}

function calcularEdadMesesDesdeFechaNacimiento(fechaNacimiento){
if (!fechaNacimiento) return null;
const nac = new Date(fechaNacimiento.includes('T') ? fechaNacimiento : fechaNacimiento + 'T00:00:00');
if (isNaN(nac)) return null;
const hoy = fechaHoy();
if (nac > hoy) return null;
let meses = (hoy.getFullYear() - nac.getFullYear()) * 12 + (hoy.getMonth() - nac.getMonth());
if (hoy.getDate() < nac.getDate()) meses -= 1;
return Math.max(0, meses);
}
// ============================================================
// ===== ESCANEO DE LISTA DE ANIMALES (OCR + reglas de texto) =====
// ============================================================
// A diferencia del escaneo de la credencial (un solo documento con campos
// fijos), aquí el documento es una TABLA con un renglón por animal, y el
// diseño de esa tabla varía de un productor a otro. Sin mandar la imagen a
// una IA externa (que tendría costo por foto y necesitaría un servidor para
// guardar la clave a salvo), esto se resuelve con reglas de texto: busca los
// encabezados de columna más comunes para saber qué significa cada una, y
// dentro de cada renglón busca los patrones típicos de cada dato (número de
// arete, fecha, edad en texto, raza conocida, sexo). No "entiende" la hoja
// como lo haría una IA — funciona bien si el documento es razonablemente
// parecido a una tabla, pero por eso SIEMPRE se muestra para confirmar antes
// de agregar nada (ver modal-confirmar-lista-animales).
let inventarioEscaneadoTemp = [];
let listaAnimalesEscaneadaTemp = [];
async function procesarFotoInventarioCompletoProductor(inputEl){
const archivo = inputEl.files && inputEl.files[0];
if (!archivo) { mostrarToast('No se recibió la foto. Tómala nuevamente o elígela de la galería.'); return; }
mostrarToast('Foto recibida. Preparando el Concentrado SINIIGA…');
try {
const dataUrl = await comprimirParaOCR(archivo, 1800);
try { const nit=await evaluarNitidezImagenOCR(dataUrl); if(nit && nit.varianza < 70) mostrarToast('La foto está muy suave/desenfocada. Se intentará leerla, pero una nueva foto más nítida dará mejores resultados.'); } catch(e){}
const texto = await extraerTextoDeImagen(dataUrl, null, 'tabla');
const resultado = await extraerConcentradoSINIIGARobusto(dataUrl, texto);
if (resultado.inventarioCompleto.length === 0){
mostrarToast('No se logró leer ningún renglón con número de arete — intenta con mejor luz o más de cerca');
inputEl.value = '';
return;
}
// A diferencia de la prueba de campo, aquí se incluye TODO — vigentes, de
// baja/venta, cualquier estatus — porque esto alimenta el inventario
// completo del productor, no solo lo que un veterinario va a trabajar hoy.
inventarioEscaneadoTemp = resultado.inventarioCompleto.map(f => ({ ...f, incluir: true }));
renderVistaPreviaInventarioProductor();
document.getElementById('modal-confirmar-inventario-productor').classList.remove('hidden');
} catch(e){
console.warn('No se pudo leer el inventario del productor', e);
mostrarToast('No se pudo leer la foto — revisa tu conexión a internet e inténtalo de nuevo');
} finally {
inputEl.value = '';
}
}
function renderVistaPreviaInventarioProductor(){
const cont = document.getElementById('inventario-productor-preview');
const resumenCont = document.getElementById('resumen-inventario-escaneado');
if (!cont || !resumenCont) return;
const vigentes = inventarioEscaneadoTemp.filter(f => f.estatus === 'VIGENTE').length;
const bajas = inventarioEscaneadoTemp.filter(f => f.estatus !== 'VIGENTE').length;
const machos = inventarioEscaneadoTemp.filter(f => f.sexo === 'Macho').length;
const hembras = inventarioEscaneadoTemp.filter(f => f.sexo === 'Hembra').length;
resumenCont.innerHTML = `
<div class="rounded-xl p-2" style="background:rgba(76,153,89,0.12);"><p class="text-lg font-bold" style="color:var(--green);">${vigentes}</p><p class="text-xs" style="color:var(--sage);">Vigentes</p></div>
<div class="rounded-xl p-2" style="background:rgba(211,71,71,0.1);"><p class="text-lg font-bold" style="color:var(--red);">${bajas}</p><p class="text-xs" style="color:var(--sage);">Bajas/venta</p></div>
<div class="rounded-xl p-2" style="background:var(--parchment);"><p class="text-lg font-bold">${machos}</p><p class="text-xs" style="color:var(--sage);">Machos</p></div>
<div class="rounded-xl p-2" style="background:var(--parchment);"><p class="text-lg font-bold">${hembras}</p><p class="text-xs" style="color:var(--sage);">Hembras</p></div>`;
cont.innerHTML = inventarioEscaneadoTemp.map((f, i) => {
const yaExiste = estado.animales.some(a => a.arete === f.arete);
return `
<div class="rounded-2xl p-3 flex items-start gap-2" style="border:2px solid ${f.dudoso ? 'var(--yellow-d)' : 'var(--line)'};">
<input type="checkbox" ${f.incluir ? 'checked' : ''} onchange="inventarioEscaneadoTemp[${i}].incluir = this.checked" style="margin-top:4px;"/>
<div class="flex-1 min-w-0 text-sm">
<p class="font-bold">${f.arete} ${yaExiste ? '<span class="text-xs font-normal" style="color:var(--sage);">(ya lo tienes — no se duplica)</span>' : ''}</p>
<p class="text-xs" style="color:var(--sage);">${f.estatus}${f.folioRemo ? ' · folio ' + f.folioRemo : ''} · ${f.edadMeses != null ? f.edadMeses + ' meses' : 'edad: ?'} · ${f.raza || 'raza: ?'} · ${f.sexo || 'sexo: ?'}</p>
</div>
</div>`;
}).join('');
}
function confirmarInventarioCompletoProductor(){
const seleccionados = inventarioEscaneadoTemp.filter(f => f.incluir && !estado.animales.some(a => a.arete === f.arete));
if (seleccionados.length === 0){ mostrarToast('No hay animales nuevos para agregar (o no marcaste ninguno)'); return; }
seleccionados.forEach(f => {
estado.animales.push({
arete: f.arete, chip: '', nombre: '', raza: f.raza || '',
sexo: f.sexo === 'Macho' ? 'macho' : 'hembra',
fecha: '', estatus: f.estatus === 'VIGENTE' ? 'activo' : (f.estatus === 'VENTA' ? 'vendido' : (f.estatus === 'BAJA' ? 'finado' : 'activo')),
madre: '', padre: '', potrero: '', motivoBaja: f.folioRemo ? ('Folio REEMO ' + f.folioRemo) : '', foto: null,
proposito: '', engordaDiasObjetivo: null, engordaPesoMeta: null, engordaInicio: null,
engordaFinalizado: false, engordaDiasFinal: null,
edadMesesAlAlta: f.edadMeses,
});
});
document.getElementById('modal-confirmar-inventario-productor').classList.add('hidden');
inventarioEscaneadoTemp = [];
renderResumenProductor(); renderHato(); renderResumenVientresToros();
mostrarToast(`Se agregaron ${seleccionados.length} animal(es) a tu inventario`);
}
const ENCABEZADOS_COLUMNA_ANIMAL = {
arete: ['no.', 'no', 'num', 'número', 'numero', 'identificaci', 'arete', 'siniiga', 'sinniga', 'id'],
fecha: ['fecha de nac', 'f. nac', 'nacimiento', 'f.nac'],
raza: ['raza'],
sexo: ['sexo', 'genero', 'género'],
edad: ['edad'],
};
function detectarRenglonEncabezado(lineas){
// Busca la primera línea que mencione al menos 2 encabezados de columna
// conocidos — esa es la fila de encabezado; ayuda a no tratarla como si
// fuera un animal más.
for (let i = 0; i < Math.min(lineas.length, 6); i++){
const linea = lineas[i].toLowerCase();
let coincidencias = 0;
Object.values(ENCABEZADOS_COLUMNA_ANIMAL).forEach(palabras => { if (palabras.some(p => linea.includes(p))) coincidencias++; });
if (coincidencias >= 2) return i;
}
return -1;
}
function extraerFechaDeTexto(linea){
// YYYY-MM-DD o YYYY/MM/DD
let m = linea.match(/\b(20\d{2}|19\d{2})[-\/](0?[1-9]|1[0-2])[-\/](0?[1-9]|[12]\d|3[01])\b/);
if (m) return `${m[1]}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}`;
// DD-MM-YYYY o DD/MM/YYYY
m = linea.match(/\b(0?[1-9]|[12]\d|3[01])[-\/](0?[1-9]|1[0-2])[-\/](20\d{2}|19\d{2})\b/);
if (m) return `${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`;
return null;
}
function extraerEdadMesesDeTexto(linea){
// "18 meses", "18m", "18 m"
let m = linea.match(/\b(\d{1,3})\s*m(?:eses)?\b/i);
if (m) return parseInt(m[1], 10);
// "1.5 años", "2 años", "1,5 anos"
m = linea.match(/\b(\d{1,2}(?:[.,]\d)?)\s*a(?:ñ|n)os?\b/i);
if (m) return Math.round(parseFloat(m[1].replace(',', '.')) * 12);
return null;
}
function extraerAreteDeTexto(linea){
// Se separa por palabras (no por franjas de caracteres) para no juntar por
// error el número de arete con la fecha o con otro número que esté al lado
// separado solo por espacio — cada palabra se evalúa por separado y se toma
// la más larga que, al quitarle separadores, sea puramente numérica.
const palabras = linea.split(/\s+/);
let mejor = '';
palabras.forEach(palabra => {
const soloDigitos = palabra.replace(/[^\d]/g, '');
if (soloDigitos.length >= 6 && soloDigitos.length <= 15 && soloDigitos.length > mejor.length) mejor = soloDigitos;
});
return mejor || null;
}
function extraerRazaDeTexto(linea){
const m = linea.match(/\b(holstein|angus|charolais|charoláis|brahman|brahm[aá]n|simmental|hereford|jersey|pardo suizo|suizo|cebú|cebu|criollo|gyr|sardo negro|limousin|cruza|cruzado)\b/i);
return m ? m[1].toUpperCase() : null;
}
function extraerSexoDeTexto(linea){
if (/\b(hembra|h|f)\b/i.test(linea) && !/\b(macho|m)\b/i.test(linea)) return 'Hembra';
if (/\b(macho|m)\b/i.test(linea) && !/\b(hembra|h|f)\b/i.test(linea)) return 'Macho';
return null;
}
function parsearListaAnimalesDesdeTexto(textoCompleto){
const lineasCrudas = textoCompleto.split('\n').map(l => l.trim()).filter(Boolean);
const idxEncabezado = detectarRenglonEncabezado(lineasCrudas);
const lineas = idxEncabezado >= 0 ? lineasCrudas.slice(idxEncabezado + 1) : lineasCrudas;
const filas = [];
lineas.forEach(linea => {
const arete = extraerAreteDeTexto(linea);
if (!arete) return; // sin un número de arete legible, no se puede tratar como un renglón de animal
const fechaNacimiento = extraerFechaDeTexto(linea);
let edadMeses = fechaNacimiento ? calcularEdadMesesDesdeFechaNacimiento(fechaNacimiento) : extraerEdadMesesDeTexto(linea);
const raza = extraerRazaDeTexto(linea);
const sexo = extraerSexoDeTexto(linea);
const dudoso = !fechaNacimiento && edadMeses == null || !raza || !sexo;
filas.push({ arete, fechaNacimiento, edadMeses, raza, sexo, dudoso, incluir: true });
});
return filas;
}
async function procesarFotoListaAnimales(inputEl){
const archivo = inputEl.files && inputEl.files[0];
if (!archivo) { mostrarToast('No se recibió la foto. Tómala nuevamente o elígela de la galería.'); return; }
mostrarToast('Foto recibida. Preparando la lista…');
try {
const dataUrl = await comprimirParaOCR(archivo, 1800);
try { const nit=await evaluarNitidezImagenOCR(dataUrl); if(nit && nit.varianza < 70) mostrarToast('La foto está muy suave/desenfocada. Se intentará leerla, pero una nueva foto más nítida dará mejores resultados.'); } catch(e){}
const texto = await extraerTextoDeImagen(dataUrl, null, 'tabla');
const esConcentradoOficial = /\breemo\b/i.test(texto) || (/\bvigente\b/i.test(texto) && /\bventa\b/i.test(texto));
let filas;
if (esConcentradoOficial){
const resultado = await extraerConcentradoSINIIGARobusto(dataUrl, texto);
filas = resultado.inventarioCompleto.map(f => ({
arete: f.arete, fechaNacimiento: null, edadMeses: f.edadMeses, raza: f.raza, sexo: f.sexo,
dudoso: f.dudoso, incluir: f.vigenteYSinFolio, estatus: f.estatus, folioRemo: f.folioRemo,
}));
if (filas.length > 0) mostrarToast('Se detectó un Concentrado de Identificadores SINIIGA — solo se marcaron los vigentes sin folio de baja/venta');
} else {
filas = parsearListaAnimalesDesdeTexto(texto);
}
if (filas.length === 0){
mostrarToast('No se logró leer ningún renglón con número de arete — intenta con mejor luz o más de cerca');
inputEl.value = '';
return;
}
listaAnimalesEscaneadaTemp = filas;
renderVistaPreviaListaAnimales();
document.getElementById('modal-confirmar-lista-animales').classList.remove('hidden');
} catch(e){
console.warn('No se pudo leer la lista de animales', e);
mostrarToast('No se pudo leer la foto — revisa tu conexión a internet e inténtalo de nuevo');
} finally {
inputEl.value = '';
}
}
function renderVistaPreviaListaAnimales(){
const cont = document.getElementById('lista-animales-preview');
const estadoTxt = document.getElementById('lista-animales-estado-lectura');
if (!cont) return;
const dudosos = listaAnimalesEscaneadaTemp.filter(f => f.dudoso).length;
if (estadoTxt) estadoTxt.textContent = `${listaAnimalesEscaneadaTemp.length} renglón(es) encontrados — ${dudosos} con algo dudoso`;
cont.innerHTML = listaAnimalesEscaneadaTemp.map((f, i) => {
const etiquetaEstatus = f.estatus ? `<span class="text-xs font-bold px-2 py-0.5 rounded-full" style="background:${f.estatus === 'VIGENTE' ? 'rgba(76,153,89,0.15)' : 'rgba(211,71,71,0.12)'}; color:${f.estatus === 'VIGENTE' ? 'var(--green)' : 'var(--red)'};">${f.estatus}${f.folioRemo ? ' · folio ' + f.folioRemo : ''}</span>` : '';
return `
<div class="rounded-2xl p-3 flex items-start gap-2" style="border:2px solid ${f.dudoso ? 'var(--yellow-d)' : 'var(--line)'}; background:${f.dudoso ? 'rgba(217,164,6,0.06)' : '#fff'};">
<input type="checkbox" ${f.incluir ? 'checked' : ''} onchange="listaAnimalesEscaneadaTemp[${i}].incluir = this.checked" style="margin-top:4px;"/>
<div class="flex-1 min-w-0 text-sm">
<p class="font-bold flex items-center gap-2 flex-wrap">${f.arete} ${etiquetaEstatus}</p>
<p class="text-xs" style="color:var(--sage);">${f.edadMeses != null ? f.edadMeses + ' meses' : 'edad: ?'} · ${f.raza || 'raza: ?'} · ${f.sexo || 'sexo: ?'}${f.fechaNacimiento ? ' · nació ' + f.fechaNacimiento : ''}</p>
</div>
</div>`;
}).join('');
}
function confirmarAltaListaAnimalesEscaneada(){
const seleccionados = listaAnimalesEscaneadaTemp.filter(f => f.incluir);
if (seleccionados.length === 0){ mostrarToast('No marcaste ningún renglón para agregar'); return; }
seleccionados.forEach(f => {
const nuevoId = 'fila_' + Date.now() + Math.random().toString(36).slice(2,6);
filasAnimalesPruebaCampo.push({
id: nuevoId, arete: f.arete, especie: 'Bovino',
edad: f.edadMeses != null ? String(f.edadMeses) : '',
sexo: f.sexo === 'Macho' ? 'M' : (f.sexo === 'Hembra' ? 'H' : 'H'),
raza: f.raza || '', fierro: '', resultado: 'N',
});
});
document.getElementById('modal-confirmar-lista-animales').classList.add('hidden');
listaAnimalesEscaneadaTemp = [];
renderFilasAnimalesPruebaCampo();
mostrarToast(`Se agregaron ${seleccionados.length} animal(es) — revisa que cada uno quede completo`);
}
// ================= REGISTRO DE EVENTOS DE USO (para Métricas de Interacción) =================
function registrarEvento(tipo, subtipo){
const ahora = new Date();
estado.eventosUso.push({
tipo, subtipo: subtipo || null,
fecha: hoyISO(), hora: ahora.getHours(), diaSemana: ahora.getDay(), ts: ahora.toISOString(),
});
// Limita el historial para no inflar el documento compartido de Firestore.
if (estado.eventosUso.length > 3000) estado.eventosUso.splice(0, estado.eventosUso.length - 3000);
guardarEstadoLocal();
}
function detectarAccesoPorQR(){
try {
const parametros = new URLSearchParams(window.location.search);
if (parametros.get('src') === 'qr') registrarEvento('acceso', 'qr');
else registrarEvento('acceso', 'directo');
} catch(e){}
}
function sumarDiasISO(fechaISO, dias){
const d = new Date(fechaISO + 'T00:00:00');
d.setDate(d.getDate() + Number(dias || 0));
return formatearFechaISO(d);
}
function diasEntreISO(fechaFuturaISO, fechaBaseISO){
const a = new Date(fechaFuturaISO + 'T00:00:00');
const b = new Date(fechaBaseISO + 'T00:00:00');
return Math.round((a - b) / 86400000);
}
function estatusCuenta(cuenta){
const dias = diasEntreISO(cuenta.suscripcion.fechaVencimiento, hoyISO());
if (dias < 0) return { estatus:'vencida', dias };
if (dias <= 15) return { estatus:'por_vencer', dias };
return { estatus:'activa', dias };
}
function quitarAcentos(txt){
return txt.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}
function generarUsuarioDesdeNombre(nombre){
const base = quitarAcentos(nombre.toLowerCase().trim()).replace(/[^a-z0-9]+/g, '.').replace(/^\.+|\.+$/g, '') || 'productor';
let candidato = base;
let intento = 1;
const existentes = new Set([...estado.usuarios.map(u => u.usuario), ...estado.cuentasProductores.map(c => c.usuario)]);
while (existentes.has(candidato)){
intento++;
candidato = `${base}${intento}`;
}
return candidato;
}
function generarContrasenaProvisional(){
const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
let clave = '';
for (let i = 0; i < 8; i++) clave += chars[Math.floor(Math.random() * chars.length)];
return clave;
}
if (!estado.productor.suscripcion.fechaAlta){
estado.productor.suscripcion.fechaAlta = hoyISO();
estado.productor.suscripcion.fechaVencimiento = sumarDiasISO(estado.productor.suscripcion.fechaAlta, estado.productor.suscripcion.diasVigencia);
}
const TILES = [
{ id:'datos',      color:'bg-slate',  icono:'fa-id-badge',      labelKey:'tile_datos',    ir:"irA('datos-productor')" },
{ id:'reporte',    color:'bg-yellow', icono:'fa-bell',          labelKey:'tile_reporte',  ir:"irA('notificaciones')" },
{ id:'graficas',   color:'bg-teal',   icono:'fa-chart-column',  labelKey:'tile_graficas', ir:"irA('graficas')" },
{ id:'boletines',  color:'bg-pink',   icono:'fa-bullhorn',      labelKey:'tile_boletines',ir:"irA('boletines')" },
];
const ESTADOS_MEXICO = ["Aguascalientes","Baja California","Baja California Sur","Campeche","Coahuila de Zaragoza","Colima","Chiapas","Chihuahua","Ciudad de México","Durango","Guanajuato","Guerrero","Hidalgo","Jalisco","México","Michoacán de Ocampo","Morelos","Nayarit","Nuevo León","Oaxaca","Puebla","Querétaro","Quintana Roo","San Luis Potosí","Sinaloa","Sonora","Tabasco","Tamaulipas","Tlaxcala","Veracruz de Ignacio de la Llave","Yucatán","Zacatecas"];
const MUNICIPIOS_MEXICO = {"Aguascalientes":["Aguascalientes","Asientos","Calvillo","Cosío","El Llano","Jesús María","Pabellón de Arteaga","Rincón de Romos","San Francisco de los Romo","San José de Gracia","Tepezalá"],"Baja California":["Ensenada","Mexicali","Playas de Rosarito","San Felipe","San Quintín","Tecate","Tijuana"],"Baja California Sur":["Comondú","La Paz","Loreto","Los Cabos","Mulegé"],"Campeche":["Calakmul","Calkiní","Campeche","Candelaria","Carmen","Champotón","Dzitbalché","Escárcega","Hecelchakán","Hopelchén","Palizada","Seybaplaya","Tenabo"],"Coahuila de Zaragoza":["Abasolo","Acuña","Allende","Arteaga","Candela","Castaños","Cuatro Ciénegas","Escobedo","Francisco I. Madero","Frontera","General Cepeda","Guerrero","Hidalgo","Jiménez","Juárez","Lamadrid","Matamoros","Monclova","Morelos","Múzquiz","Nadadores","Nava","Ocampo","Parras","Piedras Negras","Progreso","Ramos Arizpe","Sabinas","Sacramento","Saltillo","San Buenaventura","San Juan de Sabinas","San Pedro","Sierra Mojada","Torreón","Viesca","Villa Unión","Zaragoza"],"Colima":["Armería","Colima","Comala","Coquimatlán","Cuauhtémoc","Ixtlahuacán","Manzanillo","Minatitlán","Tecomán","Villa de Álvarez"],"Chiapas":["Acacoyagua","Acala","Acapetahua","Aldama","Altamirano","Amatenango de la Frontera","Amatenango del Valle","Amatán","Arriaga","Bejucal de Ocampo","Bella Vista","Benemérito de las Américas","Berriozábal","Bochil","Cacahoatán","Catazajá","Chalchihuitán","Chamula","Chanal","Chapultenango","Chenalhó","Chiapa de Corzo","Chiapilla","Chicoasén","Chicomuselo","Chilón","Cintalapa de Figueroa","Coapilla","Comitán de Domínguez","Copainalá","El Bosque","El Porvenir","Emiliano Zapata","Escuintla","Francisco León","Frontera Comalapa","Frontera Hidalgo","Huehuetán","Huitiupán","Huixtla","Huixtán","Ixhuatán","Ixtacomitán","Ixtapa","Ixtapangajoya","Jiquipilas","Jitotol","Juárez","La Concordia","La Grandeza","La Independencia","La Libertad","La Trinitaria","Larráinzar","Las Margaritas","Las Rosas","Mapastepec","Maravilla Tenejapa","Marqués de Comillas","Mazapa de Madero","Mazatán","Metapa","Mezcalapa","Mitontic","Motozintla","Nicolás Ruíz","Ocosingo","Ocotepec","Ocozocoautla de Espinosa","Ostuacán","Osumacinta","Oxchuc","Palenque","Pantelhó","Pantepec","Pichucalco","Pijijiapan","Pueblo Nuevo Solistahuacán","Rayón","Reforma","Sabanilla","Salto de Agua","San Andrés Duraznal","San Cristóbal de las Casas","San Fernando","San Juan Cancuc","San Lucas","Santiago el Pinar","Siltepec","Simojovel","Sitalá","Socoltenango","Solosuchiapa","Soyaló","Suchiapa","Suchiate","Sunuapa","Tapachula","Tapalapa","Tapilula","Tecpatán","Tenejapa","Teopisca","Tila","Tonalá","Totolapa","Tumbalá","Tuxtla Chico","Tuxtla Gutiérrez","Tuzantán","Tzimol","Unión Juárez","Venustiano Carranza","Villa Comaltitlán","Villa Corzo","Villaflores","Yajalón","Zinacantán","Ángel Albino Corzo"],"Chihuahua":["Ahumada","Aldama","Allende","Aquiles Serdán","Ascensión","Bachíniva","Balleza","Batopilas de Manuel Gómez Morín","Bocoyna","Buenaventura","Camargo","Carichí","Casas Grandes","Chihuahua","Chínipas","Coronado","Coyame del Sotol","Cuauhtémoc","Cusihuiriachi","Delicias","Dr. Belisario Domínguez","El Tule","Galeana","Gran Morelos","Guachochi","Guadalupe","Guadalupe y Calvo","Guazapares","Guerrero","Gómez Farías","Hidalgo del Parral","Huejotitán","Ignacio Zaragoza","Janos","Jiménez","Julimes","Juárez","La Cruz","López","Madera","Maguarichi","Manuel Benavides","Matachí","Matamoros","Meoqui","Morelos","Moris","Namiquipa","Nonoava","Nuevo Casas Grandes","Ocampo","Ojinaga","Praxedis G. Guerrero","Riva Palacio","Rosales","San Francisco de Borja","San Francisco de Conchos","San Francisco del Oro","Santa Bárbara","Santa Isabel","Satevó","Saucillo","Temósachic","Urique","Uruachi","Valle de Zaragoza","Valle del Rosario"],"Ciudad de México":["Azcapotzalco","Benito Juárez","Coyoacán","Cuajimalpa de Morelos","Cuauhtémoc","Gustavo A. Madero","Iztacalco","Iztapalapa","La Magdalena Contreras","Miguel Hidalgo","Milpa Alta","Tlalpan","Tláhuac","Venustiano Carranza","Xochimilco","Álvaro Obregón"],"Durango":["Canatlán","Canelas","Coneto de Comonfort","Cuencamé","Durango","El Oro","General Simón Bolívar","Guadalupe Victoria","Guanaceví","Gómez Palacio","Hidalgo","Indé","Lerdo","Mapimí","Mezquital","Nazas","Nombre de Dios","Nuevo Ideal","Ocampo","Otáez","Peñón Blanco","Poanas","Pueblo Nuevo","Pánuco de Coronado","Rodeo","San Bernardo","San Dimas","San Juan de Guadalupe","San Juan del Río","San Luis del Cordero","San Pedro del Gallo","Santa Clara","Santiago Papasquiaro","Súchil","Tamazula","Tepehuanes","Tlahualilo","Topia","Vicente Guerrero"],"Guanajuato":["Abasolo","Acámbaro","Apaseo el Alto","Apaseo el Grande","Atarjea","Celaya","Comonfort","Coroneo","Cortazar","Cuerámaro","Doctor Mora","Dolores Hidalgo Cuna de la Independencia Nacional","Guanajuato","Huanímaro","Irapuato","Jaral del Progreso","Jerécuaro","León","Manuel Doblado","Moroleón","Ocampo","Pueblo Nuevo","Purísima del Rincón","Pénjamo","Romita","Salamanca","Salvatierra","San Diego de la Unión","San Felipe","San Francisco del Rincón","San José de Iturbide","San Luis de la Paz","San Miguel de Allende","Santa Catarina","Santa Cruz de Juventino Rosas","Santiago Maravatío","Silao de la Victoria","Tarandacuao","Tarimoro","Tierra Blanca","Uriangato","Valle de Santiago","Victoria","Villagrán","Xichú","Yuriria"],"Guerrero":["Acapulco de Juárez","Acatepec","Ahuacuotzingo","Ajuchitlán del Progreso","Alcozauca de Guerrero","Alpoyeca","Apaxtla de Castrejón","Arcelia","Atenango del Río","Atlamajalcingo del Monte","Atlixtac","Atoyac de Álvarez","Ayutla de los Libres","Azoyú","Benito Juárez","Buenavista de Cuéllar","Chilapa de Álvarez","Chilpancingo de los Bravo","Coahuayutla de José María Izazaga","Cochoapa el Grande","Cocula","Copala","Copalillo","Copanatoyac","Coyuca de Benítez","Coyuca de Catalán","Cuajinicuilapa","Cualác","Cuautepec","Cuetzala del Progreso","Cutzamala de Pinzón","Eduardo Neri","Florencio Villarreal","General Heliodoro Castillo","Huamuxtitlán","Huitzuco de los Figueroa","Iguala de la Independencia","Igualapa","Iliatenco","Ixcateopan de Cuauhtémoc","José Joaquín de Herrera","Juan R. Escudero","La Unión de Isidoro Montes de Oca","Leonardo Bravo","Malinaltepec","Marquelia","Metlatónoc","Mochitlán","Olinalá","Ometepec","Petatlán","Pilcaya","Pungarabato","Quechultenango","San Luis Acatlán","San Marcos","San Miguel Totolapan","Taxco de Alarcón","Tecoanapa","Teloloapan","Tepecoacuilco de Trujano","Tetipac","Tixtla de Guerrero","Tlacoachistlahuaca","Tlacoapa","Tlalchapa","Tlalixtaquilla de Maldonado","Tlapa de Comonfort","Tlapehuala","Técpan de Galeana","Xalpatláhuac","Xochihuehuetlán","Xochistlahuaca","Zapotitlán Tablas","Zihuatanejo de Azueta","Zirándaro","Zitlala"],"Hidalgo":["Acatlán","Acaxochitlán","Actopan","Agua Blanca de Iturbide","Ajacuba","Alfajayucan","Almoloya","Apan","Atitalaquia","Atlapexco","Atotonilco de Tula","Atotonilco el Grande","Calnali","Cardonal","Chapantongo","Chapulhuacán","Chilcuautla","Cuautepec de Hinojosa","El Arenal","Eloxochitlán","Emiliano Zapata","Epazoyucan","Francisco I. Madero","Huasca de Ocampo","Huautla","Huazalingo","Huehuetla","Huejutla de Reyes","Huichapan","Ixmiquilpan","Jacala de Ledezma","Jaltocán","Metepec","Metztitlán","Mineral de la Reforma","Mineral del Chico","Mineral del Monte","Mixquiahuala de Juárez","Molango de Escamilla","Nicolás Flores","Nopala de Villagrán","Omitlán de Juárez","Pachuca de Soto","Pisaflores","Progreso de Obregón","San Agustín Tlaxiaca","San Bartolo Tutotepec","San Felipe Orizatlán","Santiago Tulantepec de Lugo Guerrero","Singuilucan","Tasquillo","Tecozautla","Tenango de Doria","Tepeapulco","Tepehuacán de Guerrero","Tepeji del Río de Ocampo","Tetepango","Tezontepec de Aldama","Tianguistengo","Tizayuca","Tlahuelilpan","Tlahuiltepa","Tlanalapa","Tlanchinol","Tlaxcoapan","Tolcayuca","Tula de Allende","Tulancingo de Bravo","Xochiatipan","Xochicoatlán","Yahualica","Zacualtipán de Ángeles","Zapotlán de Juárez","Zempoala","Zimapán"],"Jalisco":["Acatic","Acatlán de Juárez","Ahualulco de Mercado","Amacueca","Amatitán","Ameca","Arandas","Atemajac de Brizuela","Atengo","Atenguillo","Atotonilco el Alto","Atoyac","Autlán de Navarro","Ayotlán","Ayutla","Bolaños","Cabo Corrientes","Casimiro Castillo","Chapala","Chimaltitán","Chiquilistlán","Cihuatlán","Cocula","Colotlán","Concepción de Buenos Aires","Cuautitlán de García Barragán","Cuautla","Cuquío","Degollado","Ejutla","El Arenal","El Grullo","El Limón","El Salto","Encarnación de Díaz","Etzatlán","Guachinango","Guadalajara","Gómez Farías","Hostotipaquillo","Huejuquilla el Alto","Ixtlahuacán de los Membrillos","Ixtlahuacán del Río","Jalostotitlán","Jamay","Jesús María","Jilotlán de los Dolores","Jocotepec","Juanacatlán","Juchitlán","La Barca","La Huerta","Lagos de Moreno","Magdalena","Mascota","Mazamitla","Mexticacán","Mezquitic","Mixtlán","Ocotlán","Ojuelos de Jalisco","Pihuamo","Poncitlán","Puerto Vallarta","San Cristóbal de la Barranca","San Gabriel","San Juan de los Lagos","San Julián","San Martín Hidalgo","San Miguel el Alto","San Pedro Tlaquepaque","Sayula","Tala","Talpa de Allende","Tamazula de Gordiano","Tapalpa","Tecalitlán","Tecolotlán","Tenamaxtlán","Teocaltiche","Teocuitatlán de Corona","Tepatitlán de Morelos","Tequila","Teuchitlán","Tizapán el Alto","Tlajomulco de Zúñiga","Tolimán","Tomatlán","Tonalá","Tonaya","Tonila","Totatiche","Tototlán","Tuxpan","Unión de San Antonio","Unión de Tula","Valle de Guadalupe","Villa Corona","Villa Guerrero","Villa Hidalgo","Villa Purificación","Yahualica de González Gallo","Zacoalco de Torres","Zapopan","Zapotiltic","Zapotitlán de Vadillo","Zapotlanejo","Zapotlán del Rey","Zapotlán el Grande"],"México":["Acambay de Ruíz Castañeda","Acolman","Aculco","Almoloya de Alquisiras","Almoloya de Juárez","Almoloya del Río","Amanalco","Amatepec","Amecameca","Apaxco","Atenco","Atizapán","Atizapán de Zaragoza","Atlacomulco","Atlautla","Axapusco","Ayapango","Calimaya","Capulhuac","Chalco","Chapa de Mota","Chapultepec","Chiautla","Chicoloapan","Chiconcuac","Chimalhuacán","Coacalco de Berriozábal","Coatepec Harinas","Cocotitlán","Coyotepec","Cuautitlán","Cuautitlán Izcalli","Donato Guerra","Ecatepec de Morelos","Ecatzingo","El Oro","Huehuetoca","Hueypoxtla","Huixquilucan","Ixtapaluca","Ixtapan de la Sal","Ixtlahuaca","Jaltenco","Jilotepec","Jiquipilco","Jocotitlán","Joquicingo","Juchitepec","La Paz","Lerma","Malinalco","Melchor Ocampo","Metepec","Naucalpan de Juárez","Nezahualcóyotl","Nicolás Romero","Ocoyoacac","Otumba","Otzolotepec","Ozumba","Rayón","San Felipe del Progreso","San Mateo Atenco","Tecámac","Tejupilco","Temascalcingo","Temoaya","Tenancingo","Tenango del Valle","Teoloyucan","Teotihuacán","Tepotzotlán","Tequixquiac","Texcoco","Tianguistenco","Tlalmanalco","Tlalnepantla de Baz","Toluca","Tultepec","Tultitlán","Valle de Bravo","Valle de Chalco Solidaridad","Villa Victoria","Xonacatlán","Zinacantepec","Zumpango"],"Michoacán de Ocampo":["Acuitzio","Aguililla","Angamacutiro","Angangueo","Apatzingán","Aporo","Aquila","Ario","Arteaga","Briseñas","Buenavista","Carácuaro","Charapan","Charo","Chavinda","Cherán","Chilchota","Chinicuila","Chucándiro","Churintzio","Churumuco","Coahuayana","Coalcomán de Vázquez Pallares","Coeneo","Contepec","Copándaro","Cotija","Cuitzeo","Ecuandureo","Erongarícuaro","Hidalgo","Huandacareo","Huaniqueo","Huetamo","Indaparapeo","Jacona","Jiménez","Jiquilpan","Jungapeo","Juárez","La Huacana","La Piedad","Lagunillas","Los Reyes","Lázaro Cárdenas","Madero","Maravatío","Morelia","Morelos","Múgica","Nahuatzen","Nuevo Parangaricutiro","Ocampo","Pajacuarán","Panindícuaro","Paracho","Parácuaro","Penjamillo","Peribán","Puruándiro","Purépero","Pátzcuaro","Queréndaro","Quiroga","Sahuayo","Salvador Escalante","Santa Ana Maya","Senguio","Susupuato","Tacámbaro","Tancítaro","Tangamandapio","Tangancícuaro","Tanhuato","Taretan","Tarímbaro","Tepalcatepec","Tingambato","Tingüindín","Tlalpujahua","Tocumbo","Tumbiscatío","Turicato","Tuxpan","Tuzantla","Tzintzuntzan","Uruapan","Venustiano Carranza","Villamar","Yurécuaro","Zacapu","Zamora","Zinapécuaro","Ziracuaretiro","Zitácuaro","Álvaro Obregón"],"Morelos":["Amacuzac","Atlatlahucan","Axochiapan","Ayala","Coatetelco","Coatlán del Río","Cuautla","Cuernavaca","Emiliano Zapata","Hueyapan","Huitzilac","Jantetelco","Jiutepec","Jojutla","Jonacatepec de Leandro Valle","Mazatepec","Miacatlán","Ocuituco","Puente de Ixtla","Temixco","Temoac","Tepalcingo","Tepoztlán","Tetecala","Tetela del Volcán","Tlalnepantla","Tlaltizapán de Zapata","Tlaquiltenango","Tlayacapan","Totolapan","Xochitepec","Xoxocotla","Yautepec","Yecapixtla","Zacatepec","Zacualpan de Amilpas"],"Nayarit":["Acaponeta","Ahuacatlán","Amatlán de Cañas","Bahía de Banderas","Compostela","Del Nayar","Huajicori","Ixtlán del Río","Jala","La Yesca","Rosamorada","Ruíz","San Blas","San Pedro Lagunillas","Santa María del Oro","Santiago Ixcuintla","Tecuala","Tepic","Tuxpan","Xalisco"],"Nuevo León":["Abasolo","Agualeguas","Los Aldamas","Allende","Anáhuac","Apodaca","Aramberri","Bustamante","Cadereyta Jiménez","El Carmen","Cerralvo","Ciénega de Flores","China","Doctor Arroyo","Doctor Coss","Doctor González","Galeana","García","San Pedro Garza García","General Bravo","General Escobedo","General Terán","General Treviño","General Zaragoza","General Zuazua","Guadalupe","Los Herreras","Higueras","Hualahuises","Iturbide","Juárez","Lampazos de Naranjo","Linares","Marín","Melchor Ocampo","Mier y Noriega","Mina","Montemorelos","Monterrey","Parás","Pesquería","Los Ramones","Rayones","Sabinas Hidalgo","Salinas Victoria","San Nicolás de los Garza","Hidalgo","Santa Catarina","Santiago","Vallecillo","Villaldama"],"Oaxaca":["Oaxaca de Juárez","Ejutla de Crespo","Huajuapan de León","Juchitán de Zaragoza","Miahuatlán de Porfirio Díaz","Pinotepa Nacional","Puerto Escondido (San Pedro Mixtepec)","Salina Cruz","San Juan Bautista Tuxtepec","Santa Cruz Xoxocotlán","Santa Lucía del Camino","Santo Domingo Tehuantepec","Tlacolula de Matamoros","Tlaxiaco","Zimatlán de Álvarez","Loma Bonita","Matías Romero Avendaño","Villa de Etla"],"Puebla":["Puebla","Amozoc","Atlixco","Cholula (San Pedro Cholula)","San Andrés Cholula","Cuautlancingo","Huauchinango","Huejotzingo","Izúcar de Matamoros","San Martín Texmelucan","Tehuacán","Teziutlán","Zacatlán"],"Querétaro":["Amealco de Bonfil","Arroyo Seco","Cadereyta de Montes","Colón","Corregidora","Ezequiel Montes","Huimilpan","Jalpan de Serra","Landa de Matamoros","El Marqués","Pedro Escobedo","Peñamiller","Pinal de Amoles","Querétaro","San Joaquín","San Juan del Río","Tequisquiapan","Tolimán"],"Quintana Roo":["Bacalar","Benito Juárez","Cozumel","Felipe Carrillo Puerto","Isla Mujeres","José María Morelos","Lázaro Cárdenas","Othón P. Blanco","Puerto Morelos","Solidaridad","Tulum"],"San Luis Potosí":["Ahualulco","Alaquines","Aquismón","Armadillo de los Infante","Cárdenas","Catorce","Cedral","Cerritos","Cerro de San Pedro","Charcas","Ciudad Fernández","Ciudad Valles","Ciudad del Maíz","Coxcatlán","Ebano","Guadalcázar","Huehuetlán","Matehuala","Mexquitic de Carmona","Moctezuma","Rayón","Rioverde","Salinas","San Antonio","San Ciro de Acosta","San Luis Potosí","San Martín Chalchicuautla","San Nicolás Tolentino","Santa Catarina","Santa María del Río","Santo Domingo","Soledad de Graciano Sánchez","Tamasopo","Tamazunchale","Tampacán","Tampamolón Corona","Tamuín","Tancanhuitz","Tanlajás","Tanquián de Escobedo","Tierra Nueva","Vanegas","Venado","Villa Juárez","Villa de Arriaga","Villa de Guadalupe","Villa de Ramos","Villa de Reyes","Villa Hidalgo","Xilitla","Zaragoza"],"Sinaloa":["Ahome","Angostura","Badiraguato","Choix","Concordia","Cosalá","Culiacán","Elota","Escuinapa","El Fuerte","Guasave","Mazatlán","Mocorito","Rosario","Salvador Alvarado","San Ignacio","Sinaloa","Navolato"],"Sonora":["Aconchi","Agua Prieta","Alamos","Altar","Arivechi","Arizpe","Atil","Bacadéhuachi","Bacanora","Bacerac","Bacoachi","Bácum","Banámichi","Baviácora","Bavispe","Benito Juárez","Benjamín Hill","Caborca","Cajeme","Cananea","Carbó","La Colorada","Cucurpe","Cumpas","Divisaderos","Empalme","Etchojoa","Fronteras","General Plutarco Elías Calles","Guaymas","Hermosillo","Huachinera","Huásabas","Huatabampo","Huépac","Imuris","Mazatán","Moctezuma","Naco","Nácori Chico","Nacozari de García","Navojoa","Nogales","Onavas","Opodepe","Oquitoa","Pitiquito","Puerto Peñasco","Quiriego","Rayón","Rosario","Sahuaripa","San Felipe de Jesús","San Ignacio Río Muerto","San Javier","San Luis Río Colorado","San Miguel de Horcasitas","San Pedro de la Cueva","Santa Ana","Santa Cruz","Sáric","Soyopa","Suaqui Grande","Tepache","Trincheras","Tubutama","Ures","Villa Hidalgo","Villa Pesqueira","Yécora"],"Tabasco":["Balancán","Cárdenas","Centla","Centro","Comalcalco","Cunduacán","Emiliano Zapata","Huimanguillo","Jalapa","Jalpa de Méndez","Jonuta","Macuspana","Nacajuca","Paraíso","Tacotalpa","Teapa","Tenosique"],"Tamaulipas":["Abasolo","Aldama","Altamira","Antiguo Morelos","Burgos","Bustamante","Camargo","Casas","Ciudad Madero","Cruillas","Gómez Farías","González","Güémez","Guerrero","Gustavo Díaz Ordaz","Hidalgo","Jaumave","Jiménez","Llera","Mainero","El Mante","Matamoros","Méndez","Mier","Miguel Alemán","Miquihuana","Nuevo Laredo","Nuevo Morelos","Ocampo","Padilla","Palmillas","Reynosa","Río Bravo","San Carlos","San Fernando","San Nicolás","Soto la Marina","Tampico","Tula","Valle Hermoso","Victoria","Villagrán","Xicoténcatl"],"Tlaxcala":["Amaxac de Guerrero","Apetatitlán de Antonio Carvajal","Atlangatepec","Atltzayanca","Apizaco","Calpulalpan","El Carmen Tequexquitla","Cuapiaxtla","Cuaxomulco","Chiautempan","Muñoz de Domingo Arenas","Españita","Huamantla","Hueyotlipan","Ixtacuixtla de Mariano Matamoros","Ixtenco","Mazatecochco de José María Morelos","Contla de Juan Cuamatzi","Tepetitla de Lardizábal","Sanctórum de Lázaro Cárdenas","Nanacamilpa de Mariano Arista","Acuamanala de Miguel Hidalgo","Natívitas","Panotla","San Pablo del Monte","Santa Cruz Tlaxcala","Tenancingo","Teolocholco","Tepeyanco","Terrenate","Tetla de la Solidaridad","Tetlatlahuca","Tlaxcala","Tlaxco","Tocatlán","Totolac","Xaloztoc","Xaltocan","Papalotla de Xicohténcatl","Xicohtzinco","Yauhquemehcan","Zacatelco","Benito Juárez","Emiliano Zapata","Lázaro Cárdenas"],"Veracruz de Ignacio de la Llave":["Acayucan","Alvarado","Boca del Río","Coatzacoalcos","Córdoba","Cosamaloapan de Carpio","Cosoleacaque","Fortín","Ixtaczoquitlán","Martínez de la Torre","Minatitlán","Orizaba","Papantla","Poza Rica de Hidalgo","San Andrés Tuxtla","Tantoyuca","Tierra Blanca","Tuxpan","Veracruz","Xalapa"],"Yucatán":["Abalá","Acanceh","Akil","Baca","Bokobá","Buctzotz","Cacalchén","Calotmul","Cansahcab","Cantamayec","Celestún","Cenotillo","Chacsinkín","Chankom","Chapab","Chemax","Chicxulub Pueblo","Chichimilá","Chikindzonot","Chocholá","Chumayel","Conkal","Cuncunul","Cuzamá","Dzán","Dzemul","Dzidzantún","Dzilam González","Dzilam de Bravo","Dzitás","Dzoncauich","Espita","Halachó","Hocabá","Hoctún","Homún","Huhí","Hunucmá","Ixil","Izamal","Kanasín","Kantunil","Kaua","Kinchil","Kopomá","Mama","Maní","Maxcanú","Mayapán","Mérida","Mocochá","Motul","Muna","Muxupip","Opichén","Oxkutzcab","Panabá","Peto","Progreso","Quintana Roo","Río Lagartos","Sacalum","Samahil","San Felipe","Sanahcat","Santa Elena","Seyé","Sinanché","Sotuta","Sucilá","Sudzal","Suma","Tahdziú","Tahmek","Teabo","Tecoh","Tekal de Venegas","Tekantó","Tekax","Tekit","Tekom","Telchac Pueblo","Telchac Puerto","Temax","Temozón","Tepakán","Tetiz","Teya","Ticul","Timucuy","Tinum","Tixcacalcupul","Tixkokob","Tixmehuac","Tixpéhual","Tizimín","Tunkás","Tzucacab","Uayma","Ucú","Umán","Valladolid","Xocchel","Yaxcabá","Yaxkukul","Yobaín"],"Zacatecas":["Apozol","Apulco","Atolinga","Benito Juárez","Calera","Cañitas de Felipe Pescador","Concepción del Oro","Cuauhtémoc","Chalchihuites","Fresnillo","Trinidad García de la Cadena","Genaro Codina","General Enrique Estrada","General Francisco R. Murguía","El Plateado de Joaquín Amaro","General Pánfilo Natera","Guadalupe","Huanusco","Jalpa","Jerez","Jiménez del Teul","Juan Aldama","Juchipila","Loreto","Luis Moya","Mazapil","Melchor Ocampo","Mezquital del Oro","Miguel Auza","Momax","Monte Escobedo","Morelos","Moyahua de Estrada","Nochistlán de Mejía","Noria de Ángeles","Ojocaliente","Pánuco","Pinos","Río Grande","Sain Alto","El Salvador","Sombrerete","Susticacán","Tabasco","Tepechitlán","Tepetongo","Teúl de González Ortega","Tlaltenango de Sánchez Román","Valparaíso","Vetagrande","Villa de Cos","Villa García","Villa González Ortega","Villa Hidalgo","Villanueva","Zacatecas"]};
const MODULOS = {
A: { nombre:'Registro e Identificación Animal', corto:'Identificación<br>animal', icono:'fa-id-card',           color:'var(--blue)',   bg:'bg-blue' },
B: { nombre:'Salud, Sanidad y Manejo',           corto:'Salud y<br>sanidad',       icono:'fa-syringe',           color:'var(--purple)', bg:'bg-purple' },
C: { nombre:'Reproducción y Maternidad',         corto:'Reproducción<br>y maternidad', icono:'fa-heart',        color:'var(--pink)',   bg:'bg-pink' },
D: { nombre:'Pesajes y Productividad',           corto:'Pesajes y<br>productividad', icono:'fa-weight-scale',  color:'var(--green)',  bg:'bg-green' },
E: { nombre:'Mapeo Geográfico',                  corto:'Mapeo<br>geográfico',      icono:'fa-map-location-dot', color:'var(--teal)',   bg:'bg-teal' },
F: { nombre:'Administración, Costos y Reportes', corto:'Costos y<br>reportes',     icono:'fa-file-invoice-dollar', color:'var(--orange)', bg:'bg-orange' },
G: { nombre:'Producción de Leche',               corto:'Producción<br>de leche',   icono:'fa-jug-detergent',     color:'var(--blue)',   bg:'bg-blue' },
H: { nombre:'Tanque y Entrega de Leche',         corto:'Tanque y<br>entrega',       icono:'fa-temperature-low',  color:'var(--teal)',   bg:'bg-teal' },
I: { nombre:'Alimentación Lechera',              corto:'Alimentación<br>lechera',   icono:'fa-wheat-awn',        color:'var(--green)',  bg:'bg-green' },
J: { nombre:'Becerros de Reemplazo',             corto:'Becerros de<br>reemplazo',  icono:'fa-cow',               color:'var(--pink)',   bg:'bg-pink' },
K: { nombre:'Bodega e Insumos',                  corto:'Bodega e<br>insumos',       icono:'fa-warehouse',         color:'var(--orange)', bg:'bg-orange' },
};
const HOLSTEIN_REF = {
produccionLactancia305: [8000, 12000],   
produccionDiaria: [25, 40],              
grasa: [3.6, 3.8],                       
proteina: [3.0, 3.2],                    
duracionLactancia: 305,                  
periodoSeco: [45, 60],                   
edadPrimerServicioMeses: [13, 15],       
pesoPrimerServicio: [360, 380],          
edadPrimerPartoMeses: [22, 26],          
intervaloPartos: [365, 420],             
diasAbiertos: [85, 120],                 
serviciosPorConcepcion: [1.5, 2.3],
cicloEstralDias: [18, 24],
duracionCeloHoras: [12, 18],
curvaCrecimiento: [[0,40],[2,90],[6,180],[12,320],[15,380],[24,550]],
};
let letraActual = 'A';
let subtabActual = 'registrar';
let charts = {};
estado.usuarios = [];
estado.cuentasProductores = [];
// Se llama HASTA AQUÍ (no antes) porque esta función revisa duplicados contra
// estado.usuarios/estado.cuentasProductores/estado.trabajadores/etc., y varias
// de esas listas (usuarios y cuentasProductores en particular) no existían
// todavía en las líneas de arriba — llamarla antes tronaba con un error de
// JavaScript ("Cannot read properties of undefined") ANTES de crear una sola
// cuenta, y ese error detenía toda la inicialización que venía después en esta
// misma parte del código. Confirmado ejecutando la app real en un navegador:
// en un dispositivo/perfil nuevo (sin nada guardado todavía), esto pasaba
// SIEMPRE, no solo a veces — por eso ningún usuario de prueba ni las cuentas
// semilla (pedro/marcos/rueda/luis) llegaban a abrir.
// Las cuentas de prueba hardcodeadas no se crean en producción. El modo demo administra datos sintéticos sin credenciales.
function mostrarPantallaTipoGanado(){
document.getElementById('screen-login').classList.remove('active');
document.getElementById('screen-tipo-ganado').classList.add('active');
}
// Borra el caché guardado del navegador y da de baja el service worker, para
// forzar que la próxima vez se descargue la versión más nueva de verdad —
// sirve cuando alguien ve la app "atorada" en una versión vieja después de
// que se subieron cambios. A propósito NO toca localStorage (ahí vive el
// hato/salud/pesajes que un productor haya guardado sin señal todavía —
// borrarlo perdería ese trabajo).
async function forzarActualizacionApp(){
if (!confirm('Esto va a limpiar la copia guardada de la app y recargarla desde cero — tus datos guardados (hato, salud, etc.) NO se tocan. ¿Continuar?')) return;
mostrarToast('Actualizando...');
try {
if ('caches' in window){
const nombres = await caches.keys();
await Promise.all(nombres.map(n => caches.delete(n)));
}
if ('serviceWorker' in navigator){
const registros = await navigator.serviceWorker.getRegistrations();
await Promise.all(registros.map(r => r.unregister()));
}
} catch(e){
console.warn('No se pudo limpiar caché/service worker por completo', e);
}
location.reload();
}
function mostrarPantallaLogin(){
restaurarDeModoDemoSiHaceFalta();
// Llegar al login por cualquier ruta de salida invalida la sesión de aplicación;
// así un rol administrativo anterior no puede reutilizarse mediante una llamada
// directa a mostrarApp('admin'). El login volverá a establecer el rol al autenticar.
sesionRolAutenticado = null;
estado.rolActual = null;
document.getElementById('screen-tipo-ganado').classList.remove('active');
document.getElementById('screen-login').classList.add('active');
renderCuentasGuardadas();
const fabVoz = document.getElementById('fab-comando-voz');
if (fabVoz) fabVoz.classList.add('hidden');
// Estos 2 son exclusivos del productor (el "+" de módulos y el chat con el
// veterinario) — nadie debe verlos flotando antes de haber iniciado sesión.
const fabMas = document.getElementById('fab-mas-productor');
if (fabMas) fabMas.classList.add('hidden');
const btnChat = document.getElementById('btn-chat-flotante-productor');
if (btnChat) btnChat.classList.add('hidden');
}
function alternarVerContrasenaLogin(){
const campo = document.getElementById('login-clave');
const icono = document.getElementById('icono-ver-contrasena-login');
const verActualmente = campo.type === 'text';
campo.type = verActualmente ? 'password' : 'text';
icono.className = verActualmente ? 'fa-solid fa-eye' : 'fa-solid fa-eye-slash';
}
function elegirTipoGanado(tipo){
estado.tipoGanado = tipo;
document.getElementById('screen-tipo-ganado').classList.remove('active');
mostrarApp('productor');
}
function mostrarPantallaCodigoTrabajador(){
document.getElementById('screen-login').classList.remove('active');
document.getElementById('screen-codigo-trabajador').classList.add('active');
}
function entrarComoTrabajador(){
const codigo = valor('input-codigo-trabajador').trim();
const trabajador = estado.trabajadores.find(t => t.codigo === codigo);
if (!trabajador){ mostrarToast(tr('navegacion_general__codigo_incorrecto')); return; }
estado.modoTrabajador = true;
estado.trabajadorActualId = trabajador.id;
establecerValor('input-codigo-trabajador', '');
document.getElementById('screen-codigo-trabajador').classList.remove('active');
mostrarApp('productor');
mostrarToast(`Bienvenido, ${trabajador.nombre}`);
}

let intervaloMensajesProgramadosActivo = null;
let cancelarEscuchaBandejaRol = null;
function detenerEscuchaBandejaRol(){ if (cancelarEscuchaBandejaRol){ try{cancelarEscuchaBandejaRol();}catch(e){} } cancelarEscuchaBandejaRol=null; }
function claveBandejaRolActual(){
  if (estado.modoMedicoCampoTB && estado.medicoComiteActivoId) return 'medico_'+estado.medicoComiteActivoId;
  if (estado.modoComite) return 'comite_dgo';
  if (estado.modoVeterinario && estado.veterinarioActivoId) return 'vet_'+estado.veterinarioActivoId;
  if (estado.rolActual === 'productor' && estado.cuentaActivaId) return 'prod_'+estado.cuentaActivaId;
  return null;
}
function integrarFlujosRecibidos(items){
  const lista=Array.isArray(items)?items:[];
  if (!estado.flujoOrigenPorId || typeof estado.flujoOrigenPorId !== 'object') estado.flujoOrigenPorId = {};
  lista.forEach(f=>{
    const p=f.payload||{};
    if (f.id) estado.flujoOrigenPorId[f.id] = f.origenBandeja || null;
    if(f.tipo==='solicitud_prueba' && estado.modoVeterinario){
      if(!Array.isArray(estado.solicitudesPrueba)) estado.solicitudesPrueba=[];
      if(!estado.solicitudesPrueba.some(x=>x.id===p.id)) estado.solicitudesPrueba.push(p);
      else { const i=estado.solicitudesPrueba.findIndex(x=>x.id===p.id); if(i>-1) estado.solicitudesPrueba[i]=Object.assign({},estado.solicitudesPrueba[i],p); }
    }
    if(f.tipo==='solicitud_aretes' && estado.modoVeterinario){
      if(!Array.isArray(estado.solicitudesAretes)) estado.solicitudesAretes=[];
      if(!estado.solicitudesAretes.some(x=>x.id===p.id)) estado.solicitudesAretes.push(p);
    }
    if(f.tipo==='aviso_reactor' && estado.modoComite){
      if(!Array.isArray(estado.avisosReactoresTB)) estado.avisosReactoresTB=[];
      if(!estado.avisosReactoresTB.some(x=>x.id===p.id)) estado.avisosReactoresTB.push(p);
      else { const i=estado.avisosReactoresTB.findIndex(x=>x.id===p.id); if(i>-1) estado.avisosReactoresTB[i]=Object.assign({},estado.avisosReactoresTB[i],p); }
    }
    if(f.tipo==='informe_prueba' && estado.modoComite){
      if(!Array.isArray(estado.reportesRecibidosComiteTB)) estado.reportesRecibidosComiteTB=[];
      if(!estado.reportesRecibidosComiteTB.some(x=>x.id===p.id)) estado.reportesRecibidosComiteTB.push(p);
      else { const i=estado.reportesRecibidosComiteTB.findIndex(x=>x.id===p.id); if(i>-1) estado.reportesRecibidosComiteTB[i]=Object.assign({},estado.reportesRecibidosComiteTB[i],p); }
    }
    if(f.tipo==='reporte_pcc' && estado.modoComite){
      if(!Array.isArray(estado.reportesRecibidosComiteTB)) estado.reportesRecibidosComiteTB=[];
      const id=p.id||f.id; if(!estado.reportesRecibidosComiteTB.some(x=>x.id===id)) estado.reportesRecibidosComiteTB.push({...p,id});
    }
    if(f.tipo==='asignacion_pcc' && estado.modoMedicoCampoTB){
      if(!Array.isArray(estado.avisosReactoresTB)) estado.avisosReactoresTB=[];
      if(!estado.avisosReactoresTB.some(x=>x.id===p.id)) estado.avisosReactoresTB.push(p);
      else { const i=estado.avisosReactoresTB.findIndex(x=>x.id===p.id); if(i>-1) estado.avisosReactoresTB[i]=Object.assign({},estado.avisosReactoresTB[i],p); }
    }
    if(f.tipo==='prueba_compartida' && estado.rolActual==='productor' && estado.cuentaActivaId){
      if(p.productorId!==estado.cuentaActivaId) return;
      if(!Array.isArray(estado.pruebasCampoVet)) estado.pruebasCampoVet=[];
      if(!estado.pruebasCampoVet.some(x=>x.id===p.id)) estado.pruebasCampoVet.push(p);
      else { const i=estado.pruebasCampoVet.findIndex(x=>x.id===p.id); if(i>-1) estado.pruebasCampoVet[i]=Object.assign({},estado.pruebasCampoVet[i],p); }
    }
  });
  try{
    guardarEstadoEnLocalSeguro();
    if(estado.modoVeterinario) { renderSolicitudesPruebaVet(); renderSolicitudesAretesVet(); }
    if(estado.modoComite) { if(typeof renderAvisosReactoresTB==='function') renderAvisosReactoresTB(); if(typeof renderMedicosComiteTB==='function') renderMedicosComiteTB(); }
    if(estado.modoMedicoCampoTB) renderCasosMedicoCampoTB();
    if(estado.rolActual==='productor' && typeof renderPruebasCampoCompartidas==='function') renderPruebasCampoCompartidas();
    refrescarProductorSinNavegar?.();
  }catch(e){ console.warn('No se pudo refrescar la interfaz tras recibir un flujo:',e); }
}
function activarEscuchaBandejaRol(){
  detenerEscuchaBandejaRol();
  const clave=claveBandejaRolActual();
  if(!clave || typeof window.firebaseEscucharBandejaFlujos!=='function') return;
  cancelarEscuchaBandejaRol=window.firebaseEscucharBandejaFlujos(clave, integrarFlujosRecibidos);
}
function enviarFlujoConReintento(destinatario, flujoId, tipo, payload, extra={}){
  if(!destinatario || !flujoId) return;
  Promise.resolve(window.firebaseEnviarFlujo?.(destinatario,flujoId,tipo,payload,extra)).then(ok=>{
    if(ok) return;
    if(!Array.isArray(estado.flujosPendientesEnvio)) estado.flujosPendientesEnvio=[];
    if(!estado.flujosPendientesEnvio.some(x=>x.flujoId===flujoId)) estado.flujosPendientesEnvio.push({destinatario,flujoId,tipo,payload,extra});
    guardarEstadoEnLocalSeguro();
  }).catch(()=>{});
}
async function reintentarFlujosPendientes(){
  const pendientes=Array.isArray(estado.flujosPendientesEnvio)?estado.flujosPendientesEnvio.slice():[];
  if(!pendientes.length || typeof window.firebaseEnviarFlujo!=='function') return;
  for(const f of pendientes){ const ok=await window.firebaseEnviarFlujo(f.destinatario,f.flujoId,f.tipo,f.payload,f.extra||{}); if(ok) estado.flujosPendientesEnvio=estado.flujosPendientesEnvio.filter(x=>x.flujoId!==f.flujoId); }
  guardarEstadoEnLocalSeguro();
}
window.addEventListener('online', () => { setTimeout(() => reintentarFlujosPendientes(), 350); });

// ================= CUENTA PRODUCTIVA / UPP / REFERIDOS =================
const IRANCH_UPP_ONBOARDING_KEY='miranchUPPOnboardingV1';
const IRANCH_REFERRAL_KEY='miranchReferralV1';
function uppValidaMiRanch(v){ return /^\d{12}$/.test(String(v||'').replace(/\D/g,'')); }
function cuentaActivaProductiva(){
  const id=estado.cuentaActivaId;
  return (estado.cuentasProductores||[]).find(c=>c&&c.id===id)||null;
}
function cuentaTieneUPP(c){ return !!(c && uppValidaMiRanch(c.upp)); }
function sincronizarAliasCuentasProductivas(){
  estado.cuentasProductivas=(estado.cuentasProductores||[]).filter(c=>c&&c.tipo!=='punto');
}
function obtenerEstadoOnboardingUPP(cuenta){
  const id=cuenta?.id; if(!id) return {aperturas:0,primera:null,ultima:null};
  try{ const all=JSON.parse(localStorage.getItem(IRANCH_UPP_ONBOARDING_KEY)||'{}'); return all[id]||{aperturas:0,primera:null,ultima:null}; }catch(e){ return {aperturas:0,primera:null,ultima:null}; }
}
function registrarAperturaOnboardingUPP(cuenta){
  if(!cuenta || cuentaTieneUPP(cuenta)) return;
  try{
    const all=JSON.parse(localStorage.getItem(IRANCH_UPP_ONBOARDING_KEY)||'{}');
    const id=cuenta.id, x=all[id]||{aperturas:0,primera:null,ultima:null};
    x.aperturas=(x.aperturas||0)+1; x.primera=x.primera||Date.now(); x.ultima=Date.now(); all[id]=x;
    localStorage.setItem(IRANCH_UPP_ONBOARDING_KEY,JSON.stringify(all));
  }catch(e){}
}
function estadoGateUPPMiRanch(cuenta){const x=obtenerEstadoOnboardingUPP(cuenta);const dias=x.primera?((Date.now()-x.primera)/86400000):0;return {estado:x,dias,obligatorio:x.aperturas>=3||dias>=5};}
function mostrarOnboardingUPP(force=false){
  const cuenta=cuentaActivaProductiva(); if(!cuenta || cuentaTieneUPP(cuenta)) return;
  const gate=estadoGateUPPMiRanch(cuenta);
  if(!force && gate.estado.aperturas<2 && !gate.obligatorio) return;
  let m=document.getElementById('modal-onboarding-upp');
  if(!m){
    m=document.createElement('div'); m.id='modal-onboarding-upp'; m.className='hidden';
    m.style='position:fixed;inset:0;background:rgba(0,0,0,.62);z-index:240;display:none;align-items:flex-end;';
    m.innerHTML=`<div class="w-full bg-white rounded-t-3xl p-6 space-y-4" style="max-height:88vh;overflow:auto"><div class="flex items-start justify-between gap-3"><div><p class="text-xs font-bold uppercase" style="color:var(--sage)">Cuenta productiva</p><h2 class="font-display text-2xl font-bold">Completa tu UPP</h2></div><button id="cerrar-onboarding-upp" class="text-xl" style="color:var(--sage)"><i class="fa-solid fa-xmark"></i></button></div><p class="text-sm" style="color:var(--sage)">Tu identidad ya está creada. Para activar el trabajo productivo necesitamos registrar una UPP. La ubicación del productor y la ubicación de la unidad pecuaria se guardan por separado.</p><div class="grid gap-3"><label class="campo-label">Nombre del predio / unidad</label><input id="onb-upp-predio" type="text" placeholder="Ej. Rancho El Sol"><label class="campo-label">UPP (12 dígitos)</label><input id="onb-upp-numero" maxlength="12" inputmode="numeric" type="text" placeholder="000000000000"><label class="campo-label">Municipio de la UPP</label><input id="onb-upp-municipio" type="text"><label class="campo-label">Estado de la UPP</label><input id="onb-upp-estado" type="text"><label class="campo-label">Localidad de la UPP</label><input id="onb-upp-localidad" type="text"></div><div class="grid grid-cols-2 gap-2"><button id="onb-upp-ocr" class="btn-primario-plano" style="background:var(--teal)"><i class="fa-solid fa-camera"></i> Escanear documentos</button><button id="onb-upp-guardar" class="btn-primario-plano" style="background:var(--green)"><i class="fa-solid fa-check"></i> Activar UPP</button></div><p id="onb-upp-mensaje-gate" class="text-xs font-semibold" style="color:var(--sage)"></p></div>`;
    document.body.appendChild(m);
    document.getElementById('cerrar-onboarding-upp').onclick=()=>{if(estadoGateUPPMiRanch(cuentaActivaProductiva()).obligatorio){mostrarToast('Completa la UPP para continuar con las funciones productivas.');return;}m.classList.add('hidden');m.style.removeProperty('display');};
    document.getElementById('onb-upp-ocr').onclick=()=>{m.classList.add('hidden');m.style.removeProperty('display');try{irA('escaneo-documentos');}catch(e){}};
    document.getElementById('onb-upp-guardar').onclick=guardarUPPDesdeOnboarding;
  }
  establecerValor('onb-upp-predio',cuenta.predio||''); establecerValor('onb-upp-numero',cuenta.upp||'');
  establecerValor('onb-upp-municipio',cuenta.municipioUPP||''); establecerValor('onb-upp-estado',cuenta.estadoUPP||''); establecerValor('onb-upp-localidad',cuenta.localidadUPP||'');
  const bc=document.getElementById('cerrar-onboarding-upp'), msg=document.getElementById('onb-upp-mensaje-gate');
  if(gate.obligatorio){if(bc)bc.style.display='none';if(msg)msg.textContent='Tu periodo de captura inicial terminó. Completa la UPP para habilitar las funciones productivas.';}else{if(bc)bc.style.display='';if(msg)msg.textContent='Puedes seguir explorando. Te volveremos a pedir la UPP al llegar al tercer acceso o al quinto día.';}
  m.classList.remove('hidden');m.style.display='flex';
}
async function guardarUPPDesdeOnboarding(){
  const c=cuentaActivaProductiva(); if(!c) return;
  const upp=String(valor('onb-upp-numero')).replace(/\D/g,'');
  const predio=valor('onb-upp-predio'), municipio=valor('onb-upp-municipio'), estadoUPP=valor('onb-upp-estado'), localidad=valor('onb-upp-localidad');
  if(!predio||!uppValidaMiRanch(upp)||!municipio||!estadoUPP){ mostrarToast('Para activar la cuenta productiva necesitas predio, UPP de 12 dígitos, municipio y estado de la UPP.'); return; }
  if((estado.cuentasProductores||[]).some(x=>x&&x.id!==c.id&&uppValidaMiRanch(x.upp)&&String(x.upp).replace(/\D/g,'')===upp)){ mostrarToast('Esa UPP ya está asociada a otra cuenta productiva.'); return; }
  c.predio=predio;c.upp=upp;c.municipioUPP=municipio;c.estadoUPP=estadoUPP;c.localidadUPP=localidad;c.estadoProductivo='activo';c.uppCompletaEn=new Date().toISOString();
  estado.productor.predio=predio;estado.productor.upp=upp;estado.productor.municipio=municipio;estado.productor.estado=estadoUPP;estado.productor.localidad=localidad;
  sincronizarAliasCuentasProductivas(); guardarEstadoEnLocalSeguro();
  try{await window.firebaseGuardarCuenta?.(c.id,clonarRegistroSinCredencialesEnClaroIRanch(c));}catch(e){}
  const m=document.getElementById('modal-onboarding-upp');if(m){m.classList.add('hidden');m.style.removeProperty('display');}
  renderResumenProductor?.(); renderSelectorEspacios?.(); mostrarToast('Cuenta productiva activada. Tu UPP quedó separada de tu domicilio personal.');
}
function prepararCuentaProductivaNueva(datos={}){
  const id='cta_'+Date.now()+'_'+Math.random().toString(36).slice(2,7);
  const c={id,tipo:datos.tipo||'leche',telefono:datos.telefono||'',correo:datos.correo||'',usuario:datos.usuario||'',clave:datos.clave||'',nombre:datos.nombre||'',predio:datos.predio||'',upp:'',estadoProductivo:'pendiente_upp',tipoCuenta:'individual',rolOrganizacional:'productor',suscripcion:{diasVigencia:60,fechaAlta:hoyISO(),fechaVencimiento:sumarDiasISO(hoyISO(),60)},hato:[],salud:[],pesajes:[],reproduccion:[]};
  estado.cuentasProductores.push(c); sincronizarAliasCuentasProductivas(); return c;
}
function registrarReferenciaEntrante(){
  try{const p=new URLSearchParams(location.search);const ref=p.get('ref');if(!ref)return;const u=JSON.parse(localStorage.getItem(IRANCH_REFERRAL_KEY)||'null')||{};if(!u.invitadorId)u.invitadorId=ref;u.capturadoEn=Date.now();localStorage.setItem(IRANCH_REFERRAL_KEY,JSON.stringify(u));estado.referral={...estado.referral,invitadorId:ref,activadoDesde:u.activadoDesde||null};}catch(e){}
}
async function activarReferidoSiCorresponde(){
  let r=null;try{r=JSON.parse(localStorage.getItem(IRANCH_REFERRAL_KEY)||'null')}catch(e){}
  if(!r?.invitadorId||r.activadoDesde||!estado.personaMiRanch?.uid)return;
  r.activadoDesde=Date.now();try{localStorage.setItem(IRANCH_REFERRAL_KEY,JSON.stringify(r));}catch(e){}
  estado.referral={...estado.referral,invitadorId:r.invitadorId,activadoDesde:r.activadoDesde};
  try{await window.firebaseRegistrarActivacionReferido?.(r.invitadorId,estado.personaMiRanch.uid,{nombre:estado.personaMiRanch.nombre||estado.productor?.nombre||''});}catch(e){}
}
function construirEnlaceReferido(){
  const uid=estado.personaMiRanch?.uid||estado.cuentaActivaId; if(!uid)return location.href;
  const u=new URL(location.href);u.search='';u.searchParams.set('ref',uid);return u.toString();
}
async function compartirMiRanch(){
  const url=construirEnlaceReferido(); const msg='Únete a MiRanch y prueba la app. Tu registro se puede completar después con tu UPP.\n'+url;
  try{if(navigator.share)await navigator.share({title:'MiRanch',text:msg,url});else{await navigator.clipboard?.writeText(url);window.open('https://wa.me/?text='+encodeURIComponent(msg),'_blank');}}catch(e){}
}
window.registrarReferenciaEntrante=registrarReferenciaEntrante;window.activarReferidoSiCorresponde=activarReferidoSiCorresponde;window.compartirMiRanch=compartirMiRanch;window.mostrarOnboardingUPP=mostrarOnboardingUPP;window.guardarUPPDesdeOnboarding=guardarUPPDesdeOnboarding;
function instalarAccionCompartirHome(){try{const home=document.getElementById('screen-home');if(!home||document.getElementById('btn-compartir-miranch-home'))return;const b=document.createElement('button');b.id='btn-compartir-miranch-home';b.className='w-full btn-primario-plano';b.style='background:var(--green);min-height:50px;';b.innerHTML='<i class="fa-solid fa-share-nodes"></i> Invitar a MiRanch';b.onclick=compartirMiRanch;home.appendChild(b);}catch(e){}}
window.instalarAccionCompartirHome=instalarAccionCompartirHome;
registrarReferenciaEntrante();

function mostrarApp(rol){
const demoPermitida = estado.modoDemoActivo && ((rol === 'productor' && (modoDemoRol === 'lechero' || modoDemoRol === 'carne')) || (rol === 'admin' && (modoDemoRol === 'veterinario' || modoDemoRol === 'comite')));
// La pantalla administrativa nunca se abre solo porque alguien conozca el
// nombre de la función: exige una sesión autenticada como admin (o un demo
// iniciado por la propia sesión). Productor conserva el flujo de configuración
// inicial previo al alta, pero sus datos reales siguen dependiendo de cuentaActivaId.
if (!['productor','admin'].includes(rol) || (rol === 'admin' && !demoPermitida && sesionRolAutenticado !== 'admin')) {
  console.warn('MiRanch: intento de abrir una aplicación administrativa sin sesión autorizada', rol);
  return false;
}
const destinoId = rol === 'productor' ? 'app-productor' : 'app-admin';
const destino = document.getElementById(destinoId);
const continuar = () => {
document.getElementById('screen-login').classList.remove('active');
document.getElementById('app-productor').classList.toggle('hidden', rol !== 'productor');
document.getElementById('app-admin').classList.toggle('hidden', rol !== 'admin');
estado.rolActual = rol;
activarEscuchaBandejaRol();
reintentarFlujosPendientes();
activarEscuchaGlobalSegunRol();
activarEscuchaColaAdminSegunRol();
const fabVoz = document.getElementById('fab-comando-voz');
if (fabVoz) fabVoz.classList.remove('hidden');
// Solo el productor ve el "+" de módulos y el chat flotante — el admin
// tiene sus propias pantallas para esto, no le hacen falta flotando encima.
const fabMas = document.getElementById('fab-mas-productor');
if (fabMas) fabMas.classList.toggle('hidden', rol !== 'productor');
const btnChat = document.getElementById('btn-chat-flotante-productor');
if (btnChat) btnChat.classList.toggle('hidden', rol !== 'productor');
if (typeof actualizarBotonVozSegunConexion === 'function') actualizarBotonVozSegunConexion();
const etiquetaVoz = document.getElementById('fab-voz-etiqueta');
if (etiquetaVoz){
etiquetaVoz.textContent = 'Toca y habla';
etiquetaVoz.style.opacity = '1'; etiquetaVoz.style.transform = 'translateX(0)';
setTimeout(() => { etiquetaVoz.style.opacity = '0'; etiquetaVoz.style.transform = 'translateX(-6px)'; }, 3200);
}
if (rol === 'productor') { sincronizarAliasCuentasProductivas(); const ca=cuentaActivaProductiva(); registrarAperturaOnboardingUPP(ca); renderTodoProductor(); verificarVigenciaProductor(); setTimeout(revisarAlertasMoonitor, 1200); actualizarBadgeChatProductor(); setTimeout(()=>{activarReferidoSiCorresponde(); mostrarOnboardingUPP(false); instalarAccionCompartirHome();},700); }
else {
// Administración sí necesita actualización global; si esta sesión viene
// después de un productor, hacemos una sola lectura fresca en lugar de dejar
// un listener duplicado. La cola administrativa continúa con su listener propio.
if (typeof window.firebaseLeerGlobal === 'function') window.firebaseLeerGlobal().then(r => {
  if (!r?.datos) return;
  if (guardadoLocalPendiente || sincronizandoConFirebase) return;
  Object.assign(estado, r.datos); normalizarEstadoCargado(); renderTodoAdmin();
});
renderTodoAdmin(); irAdmin(quiereAbrirChatDirecto ? 'mensajes' : 'home'); revisarMensajesProgramadosDebidos(); actualizarBadgeChatAdmin();
// Sin este candado, entrar como admin varias veces en la misma sesión
// (ej. cerrar sesión y volver a entrar sin recargar la página) iba creando
// un temporizador nuevo cada vez, sin cancelar los anteriores — se
// acumulaban corriendo en paralelo para siempre, con el riesgo real de
// mandar el mismo mensaje programado más de una vez.
if (intervaloMensajesProgramadosActivo) clearInterval(intervaloMensajesProgramadosActivo);
intervaloMensajesProgramadosActivo = setInterval(revisarMensajesProgramadosDebidos, 60000);
}
};
const modulosRol = rol === 'productor' ? ['producer-core','chat'] : ['producer-core','chat','tb','admin-reports'];
const cargaModulos = typeof window.cargarModuloIRanch === 'function'
  ? Promise.all(modulosRol.map(nombre => window.cargarModuloIRanch(nombre)))
  : Promise.resolve();
const cargaVista = (destino && destino.dataset.iranchViewSource && !destino.querySelector('.screen') && typeof window.cargarVistaIRanch === 'function')
  ? window.cargarVistaIRanch(rol === 'productor' ? 'productor' : 'admin', destino)
  : Promise.resolve();
Promise.all([cargaModulos, cargaVista]).then(continuar).catch(error => {
  console.error('No se pudo cargar el paquete modular:', error);
  mostrarToast('No se pudo cargar esta sección. Recarga la app e inténtalo de nuevo.');
});
return true;
}
// ================= CREDENCIALES LEGACY: HASH + MIGRACIÓN =================
const IRANCH_CREDENCIAL_ITERACIONES=120000;
async function hashClaveMiRanch(clave,salt){
  if(!globalThis.crypto?.subtle) throw new Error('Web Crypto no disponible; la autenticación segura requiere HTTPS.');
  const enc=new TextEncoder(), base=enc.encode(String(clave||''));
  const material=await crypto.subtle.importKey('raw',base,{name:'PBKDF2'},false,['deriveBits']);
  const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:enc.encode(String(salt||'')),iterations:IRANCH_CREDENCIAL_ITERACIONES,hash:'SHA-256'},material,256);
  return [...new Uint8Array(bits)].map(b=>b.toString(16).padStart(2,'0')).join('');
}
function nuevoSaltCredencialMiRanch(){
  const a=new Uint8Array(16); crypto.getRandomValues(a); return [...a].map(b=>b.toString(16).padStart(2,'0')).join('');
}
async function asegurarCredencialHashMiRanch(registro,clave){
  if(!registro||!clave) return false;
  const salt=registro.claveSalt||nuevoSaltCredencialMiRanch();
  registro.claveSalt=salt; registro.claveAlg='PBKDF2-SHA256'; registro.claveIteraciones=IRANCH_CREDENCIAL_ITERACIONES;
  registro.claveHash=await hashClaveMiRanch(clave,salt);
  delete registro.clave; delete registro.password; delete registro.contrasena;
  return true;
}
async function verificarCredencialLegacy(usuarioIngresado,claveIngresada,registro){
  if(!registro || String(registro.usuario||'').toLowerCase()!==String(usuarioIngresado||'').toLowerCase()) return false;
  if(registro.claveHash){
    try{return (await hashClaveMiRanch(claveIngresada,registro.claveSalt||''))===String(registro.claveHash);}catch(e){console.warn('MiRanch: no se pudo verificar hash',e);return false;}
  }
  // Migración transparente de cuentas antiguas que todavía traen la clave en RAM.
  if(Object.prototype.hasOwnProperty.call(registro,'clave') && String(registro.clave||'')===String(claveIngresada||'')){
    try{await asegurarCredencialHashMiRanch(registro,claveIngresada);return true;}catch(e){console.warn('MiRanch: no se pudo migrar credencial legacy',e);return true;}
  }
  return false;
}
let migracionCredencialesProgramada=false;
window.iranchAsegurarCredencialHash=asegurarCredencialHashMiRanch;
async function migrarCredencialesLegacyMiRanch(){
  if(migracionCredencialesProgramada)return;
  migracionCredencialesProgramada=true;
  try{
    const grupos=[estado.cuentasProductores,estado.usuarios,estado.trabajadores,estado.veterinarios,estado.operadoresQueseria,estado.solicitudesCEFP,estado.solicitudesRegistro];
    for(const grupo of grupos||[]) for(const r of (grupo||[])) if(r?.clave){try{await asegurarCredencialHashMiRanch(r,r.clave);}catch(e){console.warn('MiRanch: migración de credencial pendiente',e);}}
    if(estado.queseria?.claveAdmin){try{estado.queseria.claveAdminHash=await hashClaveMiRanch(estado.queseria.claveAdmin,'queseria-admin-v1');estado.queseria.claveAdminSalt='queseria-admin-v1';delete estado.queseria.claveAdmin;}catch(e){}}
    guardarEstadoEnLocalSeguro();
  }finally{migracionCredencialesProgramada=false;}
}
setTimeout(()=>migrarCredencialesLegacyMiRanch(),1200);
// ================= AUTENTICACIÓN LEGACY CENTRALIZADA =================
// La autenticación actual sigue siendo de compatibilidad y almacena claves en
// el modelo legado. Centralizar esta comparación permite migrarla después a
// Firebase Auth sin repartir lógica de contraseñas por toda la interfaz.
// Esto NO convierte el sistema actual en autenticación segura de backend.
// ================= IDENTIDAD FEDERADA MiRanch =================
function normalizarTelefonoMiRanch(v){ return String(v||'').replace(/\D/g,''); }
function correoAuthMiRanch(user){ return String(user?.email||'').trim().toLowerCase(); }
function buscarRegistroPorIdentidadFirebase(user){
  if(!user) return null;
  const uid=String(user.uid||''); const email=correoAuthMiRanch(user);
  const cat=[...(Array.isArray(estado.cuentasProductores)?estado.cuentasProductores:[]),...(Array.isArray(estado.usuarios)?estado.usuarios:[]),...(Array.isArray(estado.trabajadores)?estado.trabajadores:[]),...(Array.isArray(estado.veterinarios)?estado.veterinarios:[])];
  return cat.find(r=>r && ((r.authUid && String(r.authUid)===uid) || (email && String(r.correo||r.email||r.correoElectronico||'').trim().toLowerCase()===email))) || null;
}
function guardarIdentidadLocalMiRanch(user, registro){
  if(!user) return;
  const tel=normalizarTelefonoMiRanch(registro?.telefono||estado.productor?.telefono||'');
  estado.personaMiRanch={...(estado.personaMiRanch||{}),uid:user.uid,nombre:registro?.nombre||user.displayName||estado.productor?.nombre||'',telefono:tel,correo:correoAuthMiRanch(user),telefonoVerificado:registro?.telefonoVerificado===true};
  if(!Array.isArray(estado.perfilesIdentidad)) estado.perfilesIdentidad=[];
  const perfilId=registro?.id || 'productor';
  if(!estado.perfilesIdentidad.some(p=>p.id===perfilId)){ estado.perfilesIdentidad.push({id:perfilId,rol:registro?.rol||'productor',nombre:registro?.nombre||user.displayName||'Mi perfil',descripcion:registro?.rol==='veterinario'?'Médico veterinario':'Perfil personal',icono:registro?.rol==='veterinario'?'🩺':'🐄',cuentaId:registro?.id||null}); }
  if(registro && !registro.authUid) registro.authUid=user.uid;
  if(registro && !registro.authProvider) registro.authProvider=user.providerData?.[0]?.providerId||'federated';
  if(registro && !registro.authEmail) registro.authEmail=correoAuthMiRanch(user);
  if(registro) registro.authVinculadaEn=registro.authVinculadaEn||new Date().toISOString();
  guardarEstadoEnLocalSeguro();
}
async function completarLoginConIdentidadFirebase(user){
  if(!user) return false;
  const registro=buscarRegistroPorIdentidadFirebase(user);
  if(registro){
    guardarIdentidadLocalMiRanch(user,registro);
    const rol=String(registro.rol||'productor').toLowerCase();
    if(estado.cuentasProductores.includes(registro)){
      estado.cuentaActivaId=registro.id; sesionRolAutenticado='productor'; estado.rolActual='productor';
      estado.productor.nombre=registro.nombre||user.displayName||''; estado.productor.telefono=registro.telefono||''; estado.productor.predio=registro.predio||''; estado.productor.upp=registro.upp||''; estado.tipoGanado=registro.tipo||estado.tipoGanado;
      cargarDatosDeCuenta(registro); mostrarApp('productor'); activarEscuchaCuentaActiva(); detenerEscuchaGlobalIRanch();
      return true;
    }
    if(rol==='admin' || rol==='veterinario' || rol==='capturista' || rol==='comite'){
      sesionRolAutenticado='admin'; estado.rolActual='admin'; estado.modoVeterinario=rol==='veterinario'; estado.modoComite=rol==='comite'; mostrarApp('admin'); return true;
    }
    if(rol==='queseria'){
      sesionRolAutenticado='queseria'; estado.rolActual='queseria'; await cargarQueseriaIRanch(); document.getElementById('screen-login')?.classList.remove('active'); document.getElementById('app-quesera')?.classList.remove('hidden'); await entrarQueseriaComo('admin',registro.nombre||'Administrador'); return true;
    }
  }
  // Usuario federado nuevo: NO se contabiliza como referido todavía y NO se crea una cuenta automáticamente.
  // Primero debe completar teléfono y el perfil que desea usar.
  const correo=correoAuthMiRanch(user); const regCorreo=document.getElementById('reg-correo'); if(regCorreo && !regCorreo.value) regCorreo.value=correo;
  const regNombre=document.getElementById('reg-nombre'); if(regNombre && !regNombre.value && user.displayName) regNombre.value=user.displayName;
  const m=document.getElementById('modal-registro-cuenta'); if(m){m.classList.remove('hidden');m.style.display='flex';}
  if(typeof seleccionarTipoRegistro==='function') seleccionarTipoRegistro('leche');
  document.getElementById('reg-paso1')?.classList.remove('hidden'); document.getElementById('reg-paso2')?.classList.add('hidden');
  mostrarToast('Completa tu teléfono y perfil para activar tu cuenta MiRanch.');
  return false;
}
async function iniciarSesionConGoogle(){
  const b=document.getElementById('btn-login-google'); if(b)b.disabled=true;
  try{ if(typeof window.firebaseIniciarSesionGoogle!=='function'){mostrarToast('Google todavía no está configurado en Firebase.');return;} await window.firebaseIniciarSesionGoogle(); }
  finally{if(b)b.disabled=false;}
}
async function iniciarSesionConFacebook(){
  const b=document.getElementById('btn-login-facebook'); if(b)b.disabled=true;
  try{ if(typeof window.firebaseIniciarSesionFacebook!=='function'){mostrarToast('Facebook todavía no está configurado en Firebase.');return;} await window.firebaseIniciarSesionFacebook(); }
  finally{if(b)b.disabled=false;}
}
window.addEventListener('miranch:auth-state',(ev)=>{ const u=ev.detail; if(u){ setTimeout(()=>completarLoginConIdentidadFirebase(u).catch(e=>console.warn('No se pudo completar la identidad federada:',e)),150); } });
window.addEventListener('miranch:auth-error',(ev)=>{ const e=ev.detail||{}; const code=e.code||''; if(code!=='auth/popup-closed-by-user') mostrarToast('No se pudo completar la autenticación. Revisa la configuración de Firebase e inténtalo nuevamente.'); });

async function iniciarSesion(){
const usuario = valor('login-usuario').trim().toLowerCase();
// Se recorta también la contraseña: es una causa muy común de "no me deja
// entrar" — el teclado del celular deja un espacio invisible al final sin que
// la persona se dé cuenta, y como las contraseñas de esta app nunca llevan
// espacios intencionalmente, quitarlo nunca causa un falso rechazo.
const clave = valor('login-clave').trim();
if (!usuario || !clave){ mostrarToast(tr('login_seleccion_rol__ingresa_usuario_y_contrasena')); return; }
const boton = document.getElementById('btn-iniciar-sesion');
const textoBoton = document.getElementById('btn-iniciar-sesion-texto');
const spinnerBoton = document.getElementById('btn-iniciar-sesion-spinner');
if (boton) boton.disabled = true;
if (spinnerBoton) spinnerBoton.classList.remove('hidden');
try {
// Si este dispositivo ya tiene un índice de cuentas guardado localmente (de una
// sesión anterior), no hace falta esperar a que baje de la nube para poder
// intentar el login: se valida contra la copia local al instante y, si hay
// conexión, el índice ya se está actualizando en paralelo en segundo plano.
// Solo se espera la primera carga global cuando el dispositivo está realmente
// vacío (primer uso, sin nada en caché).
const hayIndiceLocal = Array.isArray(estado.cuentasProductores) && estado.cuentasProductores.length > 0;
if (!primeraCargaGlobalHecha && !hayIndiceLocal){
if (textoBoton) textoBoton.textContent = tr('login_seleccion_rol__verificando_tu_cuenta');
await esperarPrimeraCargaGlobal(2500);
}
if (textoBoton) textoBoton.textContent = tr('login_seleccion_rol__procesando');
let encontrado = await intentarLoginConEstadoActual(usuario, clave);
// Si no se encontró nada Y este dispositivo entró con la caché local (sin
// esperar datos frescos de la nube), es posible que la cuenta exista pero
// se haya creado/editado en otro dispositivo después de la última vez que
// este se sincronizó — antes esto fallaba con "usuario o contraseña
// incorrectos" aunque la cuenta sí existiera. Se espera una actualización
// fresca del índice global (hasta 3s) y se reintenta antes de rendirse.
if (!encontrado && hayIndiceLocal && navigator.onLine){
if (textoBoton) textoBoton.textContent = tr('login_seleccion_rol__verificando_tu_cuenta');
await esperarNuevaActualizacionGlobal(3000);
encontrado = await intentarLoginConEstadoActual(usuario, clave);
}
if (encontrado){
guardarCuentaEnDispositivo(usuario, clave, obtenerNombreParaUsuario(usuario));
// Se guarda la sesión en el dispositivo DE INMEDIATO (sin el retraso normal
// de guardado, que agrupa cambios para no saturar la nube) — así, si la
// página se recarga justo después de entrar (por la cámara, poca memoria,
// etc.), el reinicio ya encuentra la sesión guardada y entra directo, en vez
// de mandar de vuelta al login como si nunca se hubiera iniciado sesión.
guardarEstadoEnLocalSeguro();
} else {
mostrarToast((primeraCargaGlobalHecha || hayIndiceLocal) ? tr('login_seleccion_rol__usuario_o_contrasena_incorrectos') : tr('login_seleccion_rol__no_se_pudo_verificar_conexion'));
}
} catch(error){
// Nunca se debe dejar el botón girando sin explicación — se registra el error
// exacto en consola para poder diagnosticarlo y se avisa a la persona en
// pantalla que algo falló, en vez de dejarla adivinando.
console.error('Error al iniciar sesión:', error);
mostrarToast('Ocurrió un error al iniciar sesión — inténtalo de nuevo. Si sigue fallando, revisa tu conexión.');
} finally {
if (boton) boton.disabled = false;
if (spinnerBoton) spinnerBoton.classList.add('hidden');
if (textoBoton) textoBoton.textContent = tr('login_seleccion_rol__iniciar_sesion_mayus');
}
}
// Busca la pareja usuario/clave en todos los catálogos posibles (cuentas de
// productor, usuarios genéricos, trabajadores, quesería) contra lo que HAY EN
// ESTE MOMENTO en `estado` y entra si encuentra algo. Regresa true si encontró
// y procesó un login, false si no coincidió con nada — así iniciarSesion()
// puede reintentar después de refrescar los datos sin duplicar toda la lógica.
async function cargarQueseriaIRanch(){
const destino=document.getElementById('app-quesera');
if(!destino) return null;
const cargas=[];
if(typeof window.cargarModuloIRanch==='function') cargas.push(window.cargarModuloIRanch('queseria'));
if(!destino.querySelector('.screen')){
  if(typeof window.cargarVistaIRanch!=='function') throw new Error('Cargador de vistas no disponible');
  cargas.push(window.cargarVistaIRanch('queseria',destino));
}
await Promise.all(cargas);
return document.getElementById('app-quesera');
}

async function intentarLoginConEstadoActual(usuario, clave){
// 1) cuentas de productor reales (multi-tenant, creadas por el admin)
let cuenta = null; for (const c of (estado.cuentasProductores||[])){ if(await verificarCredencialLegacy(usuario,clave,c)){ cuenta=c; break; }}
if (cuenta && cuenta.tipo === 'punto'){
establecerValor('login-usuario', ''); establecerValor('login-clave', '');
estado.puntoActivoId = cuenta.id;
estado.queseria.operadorActivo = { id: cuenta.id, nombre: cuenta.nombre };
estado.queseria.rolActivoQueseria = 'admin';
await cargarQueseriaIRanch();
document.getElementById('screen-login').classList.remove('active');
document.getElementById('app-quesera').classList.remove('hidden');
irAQueseraPantalla('menu');
return true;
}
if (cuenta){
estado.cuentaActivaId = cuenta.id;
sesionRolAutenticado = 'productor';
estado.rolActual = 'productor';
estado.productor.nombre = cuenta.nombre;
estado.productor.predio = cuenta.predio;
estado.productor.upp = cuenta.upp;
estado.productor.telefono = cuenta.telefono;
// Antes esto asumía que cuenta.suscripcion SIEMPRE existe — si una cuenta vieja
// o mal sincronizada llegaba sin ese campo, `cuenta.suscripcion.diasVigencia`
// lanzaba un TypeError (no se puede leer una propiedad de undefined) y el login
// fallaba con el error genérico en vez de entrar. Se pone un respaldo por si
// falta, para que nunca sea la causa de que una cuenta válida no abra.
const suscripcionCuenta = cuenta.suscripcion || { diasVigencia: 365, fechaVencimiento: null };
estado.productor.suscripcion = { fechaAlta: cuenta.fechaAlta, diasVigencia: suscripcionCuenta.diasVigencia, fechaVencimiento: suscripcionCuenta.fechaVencimiento };
estado.tipoGanado = cuenta.tipo;
// Entra de inmediato con lo que ya haya en caché local (instantáneo, sin esperar
// a la nube) y deja que activarEscuchaCuentaActiva() traiga/actualice los datos
// reales de Firestore en segundo plano en cuanto lleguen. Antes se esperaba aquí
// una descarga completa de la cuenta (cargarDatosDeCuentaConFirestore) antes de
// poder entrar, lo cual hacía que las cuentas con más historial tardaran mucho
// o incluso parecieran no abrir.
cargarDatosDeCuenta(cuenta);
establecerValor('login-usuario', ''); establecerValor('login-clave', '');
registrarEvento('login', cuenta.tipo === 'punto' ? 'punto' : 'productor');
mostrarApp('productor');
activarEscuchaCuentaActiva();
// El productor ya no necesita el documento global en tiempo real: desde aquí
// trabaja únicamente con su cuenta y sus dominios. El catálogo global solo se
// necesita para descubrir/validar cuentas y se evita mantenerlo escuchando.
detenerEscuchaGlobalIRanch();
return true;
}
// 2) usuarios genéricos (administradores, o productores de prueba sin cuenta multi-tenant)
let usr = null; for (const u of (estado.usuarios||[])){ if(await verificarCredencialLegacy(usuario,clave,u)){ usr=u; break; }}
if (usr){
establecerValor('login-usuario', ''); establecerValor('login-clave', '');
if (usr.rol === 'admin'){ sesionRolAutenticado = 'admin'; estado.rolActual = 'admin'; mostrarApp('admin'); return true; }
if (usr.rol === 'veterinario'){
sesionRolAutenticado = 'admin';
estado.rolActual = 'admin';
estado.modoVeterinario = true;
estado.vistaVeterinario = true;
const vet = estado.veterinarios.find(v => (v.usuario || '').toLowerCase() === usuario);
estado.veterinarioActivoId = vet ? vet.id : null;
mostrarApp('admin');
registrarEvento('login', 'veterinario');
return true;
}
if (usr.rol === 'capturista'){
sesionRolAutenticado = 'admin';
estado.rolActual = 'admin';
estado.modoCapturista = true;
mostrarApp('admin');
registrarEvento('login', 'capturista');
return true;
}
if (usr.rol === 'capturista_tb'){
sesionRolAutenticado = 'admin';
estado.rolActual = 'admin';
estado.modoCapturistaTB = true;
mostrarApp('admin');
registrarEvento('login', 'capturista_tb');
return true;
}
if (usr.rol === 'almita'){
sesionRolAutenticado = 'admin';
estado.rolActual = 'admin';
estado.modoAlmita = true;
mostrarApp('admin');
registrarEvento('login', 'almita');
return true;
}
if (usr.rol === 'medico_campo_tb'){
sesionRolAutenticado = 'admin';
estado.rolActual = 'admin';
estado.modoMedicoCampoTB = true;
const medico = estado.medicosComiteTB.find(m => (m.usuario || '').toLowerCase() === usuario);
estado.medicoComiteActivoId = medico ? medico.id : null;
mostrarApp('admin');
registrarEvento('login', 'medico_campo_tb');
return true;
}
if (!estado.tipoGanado) mostrarPantallaTipoGanado();
else mostrarApp('productor');
return true;
}
// 3) trabajadores (hasta 2 por cuenta, permisos limitados)
let trabajador = null; for (const t of (estado.trabajadores||[])){ if(await verificarCredencialLegacy(usuario,clave,t)){ trabajador=t; break; }}
if (trabajador){
sesionRolAutenticado = 'productor';
estado.rolActual = 'productor';
estado.modoTrabajador = true;
estado.trabajadorActualId = trabajador.id;
if (trabajador.cuentaId){
const cuentaT = estado.cuentasProductores.find(c => c.id === trabajador.cuentaId);
if (cuentaT){
estado.cuentaActivaId = cuentaT.id;
estado.productor.nombre = cuentaT.nombre;
estado.productor.predio = cuentaT.predio;
estado.productor.upp = cuentaT.upp;
estado.tipoGanado = cuentaT.tipo;
cargarDatosDeCuenta(cuentaT);
}
}
establecerValor('login-usuario', ''); establecerValor('login-clave', '');
registrarEvento('login', 'trabajador');
mostrarApp('productor');
if (trabajador.cuentaId) activarEscuchaCuentaActiva();
mostrarToast(`${tr('login_seleccion_rol__bienvenido')}, ${trabajador.nombre}`);
return true;
}
// 4) quesería (administrador u operadores)
if (String(usuario)==='quesero' && estado.queseria?.claveAdminHash && (await hashClaveMiRanch(clave,estado.queseria.claveAdminSalt||'queseria-admin-v1'))===estado.queseria.claveAdminHash){
sesionRolAutenticado = 'queseria';
estado.rolActual = 'queseria';
establecerValor('login-usuario', ''); establecerValor('login-clave', '');
await cargarQueseriaIRanch();
document.getElementById('screen-login').classList.remove('active');
document.getElementById('app-quesera').classList.remove('hidden');
await entrarQueseriaComo('admin', tr('queseria__administrador'));
return true;
}
let operador = null; for (const o of (estado.operadoresQueseria||[])){ if(await verificarCredencialLegacy(usuario,clave,o)){ operador=o; break; }}
if (operador){
establecerValor('login-usuario', ''); establecerValor('login-clave', '');
await cargarQueseriaIRanch();
document.getElementById('screen-login').classList.remove('active');
document.getElementById('app-quesera').classList.remove('hidden');
await entrarQueseriaComo(operador.id, operador.nombre);
return true;
}
return false;
}
// ---------- Olvidé mi contraseña / Registro de nueva cuenta ----------
function abrirRecuperarContrasena(){ const m = document.getElementById('modal-recuperar-contrasena'); m.classList.remove('hidden'); m.style.display = 'flex'; }
function cerrarRecuperarContrasena(){ const m = document.getElementById('modal-recuperar-contrasena'); m.classList.add('hidden'); m.style.removeProperty('display'); }
function enviarCodigoRecuperacion(){
const nombre = valor('rec-nombre').trim();
const telefono = valor('rec-telefono').trim().replace(/\D/g,'');
if (!nombre || telefono.length < 10){ mostrarToast(tr('login_seleccion_rol__completa_nombre_y_telefono')); return; }
const codigo = String(Math.floor(100000 + Math.random()*900000));
const cuenta = estado.cuentasProductores.find(c => c.nombre.toLowerCase().includes(nombre.toLowerCase()) && (c.telefono || '').replace(/\D/g,'') === telefono);
const mensaje = cuenta
? `Hola ${nombre}, tu código de recuperación de MiRanch es: ${codigo}\nTu usuario es: ${cuenta.usuario}`
: `Hola ${nombre}, tu código de recuperación de MiRanch es: ${codigo}`;
const numero = telefono.length === 10 ? '52' + telefono : telefono;
window.open(`https://wa.me/${numero}?text=${encodeURIComponent(mensaje)}`, '_blank');
registrarEvento('whatsapp', 'recuperar_contrasena');
cerrarRecuperarContrasena();
mostrarToast(tr('login_seleccion_rol__codigo_enviado'));
}
function abrirRegistroCuenta(){ const m = document.getElementById('modal-registro-cuenta'); m.classList.remove('hidden'); m.style.display = 'flex'; seleccionarTipoRegistro('leche'); document.getElementById('reg-paso1').classList.remove('hidden'); document.getElementById('reg-paso2').classList.add('hidden'); if (typeof aplicarIconosBotonesEstaticos === 'function') aplicarIconosBotonesEstaticos(); }
function cerrarRegistroCuenta(){ const m = document.getElementById('modal-registro-cuenta'); m.classList.add('hidden'); m.style.removeProperty('display'); }
function obtenerUbicacionRegistro(){
const estadoTxt = document.getElementById('reg-ubicacion-estado');
if (!navigator.geolocation){ if (estadoTxt) estadoTxt.textContent = tr('render_modulos_f__geolocalizacion_no_disponible'); return; }
if (window.isSecureContext === false){
if (estadoTxt) estadoTxt.textContent = tr('login_seleccion_rol__gps_requiere_https');
return;
}
if (estadoTxt) estadoTxt.textContent = tr('render_modulos_f__ubicando');
navigator.geolocation.getCurrentPosition(pos => {
establecerValor('reg-lat', pos.coords.latitude);
establecerValor('reg-lng', pos.coords.longitude);
if (estadoTxt) estadoTxt.textContent = `✓ ${pos.coords.latitude.toFixed(5)}, ${pos.coords.longitude.toFixed(5)}`;
}, (err) => {
let msg = tr('render_modulos_f__no_se_pudo_obtener_ubicacion');
if (err && err.code === 1) msg = tr('login_seleccion_rol__gps_permiso_denegado');
else if (err && err.code === 2) msg = tr('login_seleccion_rol__gps_no_disponible');
else if (err && err.code === 3) msg = tr('login_seleccion_rol__gps_tiempo_agotado');
if (estadoTxt) estadoTxt.textContent = msg;
}, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
}
function existeSolicitudRegistroDuplicada(campo, valorBuscado){
if (!valorBuscado) return false;
const v = valorBuscado.toLowerCase();
const enCuentas = estado.cuentasProductores.some(c => (c[campo] || '').toLowerCase() === v);
const enSolicitudes = estado.solicitudesRegistro.some(s => s.estatus === 'pendiente' && String(s[campo] || '').toLowerCase() === v);
return enCuentas || enSolicitudes;
}
function existeCorreoDuplicado(correo){
if (!correo) return false;
const c = String(correo).trim().toLowerCase();
const colecciones = [estado.cuentasProductores, estado.veterinarios, estado.usuarios, estado.trabajadores, estado.operadoresQueseria, estado.solicitudesCEFP, estado.solicitudesRegistro];
return colecciones.some(lista => Array.isArray(lista) && lista.some(x => String(x && (x.correo || x.email || '') || '').trim().toLowerCase() === c));
}
function existeUsuarioDuplicado(usuario){
if (!usuario) return false;
const u = usuario.toLowerCase();
return estado.cuentasProductores.some(c => (c.usuario || '').toLowerCase() === u)
|| estado.usuarios.some(x => (x.usuario || '').toLowerCase() === u)
|| estado.trabajadores.some(t => (t.usuario || '').toLowerCase() === u)
|| estado.operadoresQueseria.some(o => (o.usuario || '').toLowerCase() === u)
|| estado.veterinarios.some(v => (v.usuario || '').toLowerCase() === u)
|| (estado.queseria.usuarioAdmin || '').toLowerCase() === u;
}
function existeCedulaDuplicada(cedula){
if (!cedula) return false;
const c = cedula.toLowerCase();
return estado.veterinarios.some(v => (v.cedula || '').toLowerCase() === c);
}
function validarPaso1Registro(){
const tipo = valor('reg-tipo');
const nombre = valor('reg-nombre').trim();
const telefono = valor('reg-telefono').trim().replace(/\D/g,'');
const correo = valor('reg-correo').trim().toLowerCase();
let faltaAlgo = false;
if (correo && existeCorreoDuplicado(correo)){ mostrarMoonitorRegistro('Ese correo electrónico ya está registrado o tiene una solicitud pendiente. Usa otro correo.'); return; }
if (!nombre || telefono.length < 10 || !iranchCorreoValido(correo)) faltaAlgo = true;
if (tipo === 'mvz'){
const cedula = valor('reg-cedula').trim();
const residencia = valor('reg-residencia').trim();
if (!cedula || !residencia) faltaAlgo = true;
else if (existeCedulaDuplicada(cedula)){ mostrarMoonitorRegistro(tr('login_seleccion_rol__moonitor_ya_existe')); return; }
} else if (tipo === 'cefp'){
const centro = valor('reg-cefp-centro').trim();
const curp = valor('reg-cefp-curp').trim();
const estadoCefp = valor('reg-cefp-estado').trim();
const municipioCefp = valor('reg-cefp-municipio').trim();
if (!centro || !curp || !estadoCefp || !municipioCefp) faltaAlgo = true;
} else if (tipo === 'punto'){
const local = valor('reg-local').trim();
if (!local) faltaAlgo = true;
else if (existeSolicitudRegistroDuplicada('telefono', telefono) || estado.cuentasProductores.some(c => (c.predio||'').toLowerCase()===local.toLowerCase())){
mostrarMoonitorRegistro(tr('login_seleccion_rol__moonitor_ya_existe')); return;
}
} else {
const predio = valor('reg-predio').trim();
const upp = valor('reg-upp').trim();
// El alta de identidad NO exige UPP. La UPP se registra después como cuenta productiva.
if (predio && upp && !/^\d{12}$/.test(upp.replace(/\D/g,''))){ mostrarMoonitorRegistro('Si proporcionas una UPP durante el alta debe contener 12 dígitos.'); return; }
if (existeSolicitudRegistroDuplicada('telefono', telefono)){ mostrarMoonitorRegistro(tr('login_seleccion_rol__moonitor_ya_existe')); return; }
}
if (faltaAlgo){ mostrarMoonitorRegistro(tr('login_seleccion_rol__moonitor_faltan_datos')); return; }
document.getElementById('reg-paso1').classList.add('hidden');
document.getElementById('reg-paso2').classList.remove('hidden');
mostrarMoonitorRegistro(tr('login_seleccion_rol__moonitor_datos_validados'));
setTimeout(async () => { const u = document.getElementById('reg-usuario'); if (u) u.focus(); }, 150);
}
function volverPaso1Registro(){
document.getElementById('reg-paso2').classList.add('hidden');
document.getElementById('reg-paso1').classList.remove('hidden');
ocultarMoonitor();
}
function mostrarMoonitorRegistro(mensaje){
mostrarMoonitor(mensaje, { botones: [ { texto: tr('moonitor__entendido') || 'Entendido', accion: () => {} } ] });
}
async function enviarSolicitudRegistro(){
const tipo = valor('reg-tipo');
const nombre = valor('reg-nombre').trim();
const telefono = valor('reg-telefono').trim().replace(/\D/g,'');
const correo = valor('reg-correo').trim().toLowerCase();
const usuario = valor('reg-usuario').trim();
const clave = valor('reg-clave');
// Alta de perfil para una identidad federada existente: no crea otra persona ni exige
// otra contraseña. Esto permite, por ejemplo, Productor + Médico Veterinario con el
// mismo teléfono, mientras cada perfil conserva sus permisos independientes.
const authUser = typeof window.firebaseObtenerUsuarioActual==='function' ? window.firebaseObtenerUsuarioActual() : null;
if(authUser && (tipo==='mvz' || tipo==='leche')){
  const cedula = tipo==='mvz' ? valor('reg-cedula').trim() : '';
  const residencia = tipo==='mvz' ? valor('reg-residencia').trim() : '';
  if(!nombre || telefono.length<10 || !iranchCorreoValido(correo)){ mostrarMoonitorRegistro('Completa nombre, teléfono y correo válido.'); return; }
  if(tipo==='mvz' && (!cedula || !residencia)){ mostrarMoonitorRegistro('Para el perfil de médico veterinario necesitas cédula y lugar de residencia.'); return; }
  if(tipo==='mvz' && existeCedulaDuplicada(cedula)){ mostrarMoonitorRegistro('Esa cédula profesional ya está registrada.'); return; }
  if(!Array.isArray(estado.perfilesIdentidad)) estado.perfilesIdentidad=[];
  const perfil={id:'perfil_'+tipo+'_'+Date.now(),rol:tipo==='mvz'?'veterinario':'productor',nombre,descripcion:tipo==='mvz'?'Médico veterinario':'Productor',icono:tipo==='mvz'?'🩺':'🐄',telefono,correo,authUid:authUser.uid,cedula:cedula||null,residencia:residencia||null,cuentaId:estado.cuentaActivaId||null,creadoEn:new Date().toISOString()};
  estado.perfilesIdentidad.push(perfil);
  estado.personaMiRanch={...(estado.personaMiRanch||{}),uid:authUser.uid,nombre,telefono,correo,telefonoVerificado:false};
  if(typeof window.firebaseGuardarPersona==='function'){ const personaId=estado.personaMiRanch.id || 'persona_'+authUser.uid; estado.personaMiRanch.id=personaId; await window.firebaseGuardarPersona(personaId,estado.personaMiRanch).catch(()=>false); }
  if(typeof window.firebaseGuardarIdentidadAuth==='function') await window.firebaseGuardarIdentidadAuth({personaId:estado.personaMiRanch.id||null,email:correo,telefono,telefonoVerificado:false,roles:estado.perfilesIdentidad.filter(p=>p.authUid===authUser.uid).map(p=>p.rol)}).catch(()=>false);
  guardarEstadoEnLocalSeguro(); cerrarRegistroCuenta(); ocultarMoonitor(); if(typeof window.renderSelectorEspacios==='function')window.renderSelectorEspacios(); mostrarToast('Perfil agregado. Sigue usando el selector de espacios para cambiar de función.'); return;
}
if (usuario.length < 6 || clave.length < 6){ mostrarMoonitorRegistro(tr('login_seleccion_rol__usuario_y_contrasena_6_caracteres')); return; }
if (existeUsuarioDuplicado(usuario)){ mostrarMoonitorRegistro(tr('login_seleccion_rol__ese_usuario_ya_existe')); return; }
if (tipo === 'cefp'){
const centro = valor('reg-cefp-centro').trim();
const curp = valor('reg-cefp-curp').trim().toUpperCase();
const estadoCefp = valor('reg-cefp-estado').trim();
const municipioCefp = valor('reg-cefp-municipio').trim();
const puesto = valor('reg-cefp-puesto');
const boton = document.getElementById('btn-enviar-solicitud-registro');
const textoBoton = document.getElementById('btn-enviar-solicitud-texto');
if (boton) boton.disabled = true;
if (textoBoton) textoBoton.textContent = tr('login_seleccion_rol__procesando');
setTimeout(async () => {
if (!Array.isArray(estado.solicitudesCEFP)) estado.solicitudesCEFP = [];
const solicitudCEFP={
id: 'solcefp_' + Date.now(), nombre, curp, telefono, correo, centroTrabajo: centro, estado: estadoCefp, municipio: municipioCefp, puesto,
rolOrganizacional: puesto, permisos: iranchPlantillaPermisos(puesto), cuentaPadreId: null, organizacionId: 'cefpp_' + estadoCefp.toLowerCase().replace(/[^a-z0-9]+/g,'_'),
usuario, clave, fecha: hoyISO(), estatus: 'pendiente',
};
try{await asegurarCredencialHashMiRanch(solicitudCEFP,clave);}catch(e){mostrarMoonitorRegistro('No se pudo crear la credencial segura. Abre MiRanch mediante HTTPS.');if (boton) boton.disabled=false;return;}
estado.solicitudesCEFP.push(solicitudCEFP);
guardarEstadoLocal();
establecerValor('reg-nombre',''); establecerValor('reg-cefp-centro',''); establecerValor('reg-cefp-estado',''); establecerValor('reg-cefp-municipio',''); establecerValor('reg-cefp-curp',''); establecerValor('reg-telefono',''); establecerValor('reg-correo','');
establecerValor('reg-clave','');
if (boton) boton.disabled = false;
if (textoBoton) textoBoton.textContent = tr('login_seleccion_rol__enviar_solicitud');
cerrarRegistroCuenta();
establecerValor('reg-usuario', '');
mostrarMoonitorRegistro('¡Listo! Tu solicitud de cuenta CEFP quedó enviada. Un administrador debe autorizarla antes de que puedas entrar — te avisarán cuando esté lista.');
}, 900);
return;
}
if (tipo === 'mvz'){
const cedula = valor('reg-cedula').trim();
const residencia = valor('reg-residencia').trim();
const boton = document.getElementById('btn-enviar-solicitud-registro');
const textoBoton = document.getElementById('btn-enviar-solicitud-texto');
if (boton) boton.disabled = true;
if (textoBoton) textoBoton.textContent = tr('login_seleccion_rol__procesando');
setTimeout(async () => {
const vet = {
id:'vet_' + Date.now(), nombre, cedula, telefono, correo, residencia, usuario, clave, fechaAlta: hoyISO(), rolOrganizacional:'mvz_libre', tipoCuenta:'individual', emailVerificado:false, estatusCuenta:'pendiente_verificacion',
especialidad:'', descripcion:'', foto:null, zonaAtencion:[], notas:[]
};
try{await asegurarCredencialHashMiRanch(vet,clave);}catch(e){mostrarMoonitorRegistro('No se pudo crear la credencial segura. Abre MiRanch mediante HTTPS.');return;}
const usrVet={ nombre: nombre + ' (MVZ)', usuario, clave, rol:'veterinario' };
try{await asegurarCredencialHashMiRanch(usrVet,clave);}catch(e){mostrarMoonitorRegistro('No se pudo crear la credencial segura. Abre MiRanch mediante HTTPS.');return;}
estado.veterinarios.push(vet);
estado.usuarios.push(usrVet);
guardarEstadoLocal();
establecerValor('reg-nombre',''); establecerValor('reg-cedula',''); establecerValor('reg-residencia',''); establecerValor('reg-telefono',''); establecerValor('reg-correo','');
establecerValor('reg-clave','');
if (boton) boton.disabled = false;
if (textoBoton) textoBoton.textContent = tr('login_seleccion_rol__enviar_solicitud');
cerrarRegistroCuenta();
establecerValor('login-usuario', usuario);
establecerValor('reg-usuario', '');
mostrarMoonitorRegistro(tr('login_seleccion_rol__moonitor_bienvenida').replace('%VAR%', nombre).replace('%VAR2%', usuario));
}, 900);
return;
}
let datos = { id:'cta_' + Date.now(), tipo, telefono, correo, usuario, clave, fechaAlta: hoyISO(), tipoCuenta:'individual', rolOrganizacional:'productor', emailVerificado:false, estatusCuenta:'pendiente_verificacion', estadoProductivo:'pendiente_upp', suscripcion: { diasVigencia: 60, fechaAlta:hoyISO(), fechaVencimiento: sumarDiasISO(hoyISO(), 60) }, hato: [], salud: [], pesajes: [], reproduccion: [] };
if (tipo === 'punto'){
const local = valor('reg-local').trim();
datos.nombre = nombre;
datos.predio = local;
datos.upp = '';
datos.lat = valor('reg-lat') || null;
datos.lng = valor('reg-lng') || null;
} else {
const predio = valor('reg-predio').trim();
const upp = valor('reg-upp').trim();
datos.nombre = nombre;
datos.predio = predio;
datos.upp = (/^\d{12}$/.test(upp.replace(/\D/g,'')) ? upp.replace(/\D/g,'') : '');
datos.estadoProductivo = datos.upp ? 'activo' : 'pendiente_upp';
}
const boton = document.getElementById('btn-enviar-solicitud-registro');
const textoBoton = document.getElementById('btn-enviar-solicitud-texto');
const usuarioRegistro={ nombre: '', usuario, clave, rol:'productor' };
try{await asegurarCredencialHashMiRanch(datos,clave);await asegurarCredencialHashMiRanch(usuarioRegistro,clave);}catch(e){mostrarMoonitorRegistro('No se pudo crear la credencial segura. Abre MiRanch mediante HTTPS.');return;}
usuarioRegistro.nombre = datos.nombre + ' (' + (tipo === 'punto' ? tr('login_seleccion_rol__punto_receptor_de_leche') : tr('cuentas_productores_alta__productor')) + ')';
if (boton) boton.disabled = true;
if (textoBoton) textoBoton.textContent = tr('login_seleccion_rol__procesando');
setTimeout(() => {
estado.cuentasProductores.push(datos);
sincronizarAliasCuentasProductivas();
estado.usuarios.push(usuarioRegistro);
estado.solicitudesRegistro.push({ id:'solreg_' + Date.now(), tipo:'nuevaCuenta', tipoModulo: tipo, nombre: datos.nombre, telefono, fecha: hoyISO(), estatus:'creada' });
guardarEstadoLocal();
renderCuentas(); renderListaUsuarios(); renderResumenAdmin();
establecerValor('reg-nombre',''); establecerValor('reg-predio',''); establecerValor('reg-upp',''); establecerValor('reg-telefono',''); establecerValor('reg-correo',''); establecerValor('reg-local','');
establecerValor('reg-lat',''); establecerValor('reg-lng',''); establecerValor('reg-clave','');
const estadoTxt = document.getElementById('reg-ubicacion-estado');
if (estadoTxt) estadoTxt.textContent = '';
if (boton) boton.disabled = false;
if (textoBoton) textoBoton.textContent = tr('login_seleccion_rol__enviar_solicitud');
cerrarRegistroCuenta();
establecerValor('login-usuario', usuario);
establecerValor('reg-usuario', '');
mostrarMoonitorRegistro(tr('login_seleccion_rol__moonitor_bienvenida').replace('%VAR%', datos.nombre).replace('%VAR2%', usuario));
}, 700);
}

// [iRANCH MODULAR] queseria cargado bajo demanda.
// ================= MOO-NITOR (avisos, sin la imagen de la vaca) =================
let moonitorColaAlertas = [];
let moonitorActual = null;
let moonitorTimeoutAutoOcultar = null;
function mostrarMoonitor(mensaje, opciones){
opciones = opciones || {};
const widget0 = document.getElementById('moonitor-widget');
const yaVisible = widget0 && !widget0.classList.contains('hidden');
moonitorActual = { mensaje, opciones };
const widget = document.getElementById('moonitor-widget');
const icono = document.getElementById('moonitor-icono');
const texto = document.getElementById('moonitor-mensaje');
const acciones = document.getElementById('moonitor-acciones');
if (!widget || !texto) return;
// Ícono y color según el tipo de aviso (antes esto lo comunicaba la imagen
// de la vaca; ahora un ícono chico y directo, sin imagen que cargar).
const tipo = opciones.sonido || 'moo';
const iconosPorTipo = { alerta: ['fa-triangle-exclamation', 'var(--red)'], exito: ['fa-circle-check', 'var(--green)'], moo: ['fa-bell', 'var(--pine)'] };
const [claseIcono, colorIcono] = iconosPorTipo[tipo] || iconosPorTipo.moo;
if (icono) icono.innerHTML = `<i class="fa-solid ${claseIcono}"></i>`;
if (icono) icono.style.color = colorIcono;
texto.textContent = mensaje;
acciones.innerHTML = (opciones.botones || []).map((b, i) => `
<button onclick="(${b.accion ? b.accion.toString().replace(/"/g,'&quot;') : 'null'})(); ${opciones.cerrarAlAccionar !== false ? 'ocultarMoonitor();' : ''}" class="text-xs font-bold px-3 py-2 rounded-full" style="background:${b.color || 'var(--pine)'}; color:#fff;">${b.texto}</button>`).join('');
widget.classList.remove('hidden');
widget.style.display = 'block';
// Entra deslizándose desde abajo (un frame después de quitar "hidden" para
// que la transición sí se note, en vez de aparecer de golpe).
requestAnimationFrame(() => { widget.style.transform = 'translateY(0)'; widget.style.opacity = '1'; });
if (!yaVisible) reproducirSonidoMoonitor(opciones.sonido);
// Se oculta solo después de unos segundos, salvo que traiga 2+ botones de
// decisión (ej. "Sí"/"No") — ahí se espera a que la persona responda, para no
// desaparecer justo cuando le está pidiendo confirmar algo importante. Con 1
// botón o ninguno, sí se oculta sola (es un aviso informativo, no una decisión).
clearTimeout(moonitorTimeoutAutoOcultar);
const requiereDecision = (opciones.botones || []).length >= 2;
if (opciones.autoOcultar !== false && !requiereDecision){
moonitorTimeoutAutoOcultar = setTimeout(() => {
if (moonitorActual && moonitorActual.mensaje === mensaje) ocultarMoonitor();
}, opciones.autoOcultarMs || 4500);
}
}
// ---------- Sonido sintetizado (sin archivos de audio externos) ----------
// Un solo tono con "sawtooth" sonaba más a sintetizador que a vaca — ahora se
// combinan dos osciladores (uno grave con vibrato, otro una octava abajo más
// tenue) para dar un timbre más grueso/animal, y hay sonidos distintos según
// el tipo de aviso: 'moo' (default, avisos normales), 'alerta' (urgente/reactor,
// dos "mu" cortos) y 'exito' (confirmación, un tono suave ascendente, sin moo).
let moonitorAudioCtx = null;
function reproducirSonidoMoonitor(tipo){
if (estado.moonitor && estado.moonitor.sonidoActivado === false) return;
try {
if (!moonitorAudioCtx) moonitorAudioCtx = new (window.AudioContext || window.webkitAudioContext)();
const ctx = moonitorAudioCtx;
if (ctx.state === 'suspended') ctx.resume();
if (tipo === 'exito'){ sonidoMoonitorExito(ctx); return; }
if (tipo === 'alerta'){ sonidoMoonitorMoo(ctx, ctx.currentTime); sonidoMoonitorMoo(ctx, ctx.currentTime + 0.5); return; }
sonidoMoonitorMoo(ctx, ctx.currentTime);
} catch(e){}
}
function sonidoMoonitorMoo(ctx, inicio){
const gainMaestro = ctx.createGain();
gainMaestro.gain.setValueAtTime(0.001, inicio);
gainMaestro.connect(ctx.destination);
// Oscilador principal grave con un ligero vibrato (como el temblor natural
// de un mugido) y una caída de tono al final, típica del "muuu".
const osc = ctx.createOscillator();
osc.type = 'sawtooth';
const vibrato = ctx.createOscillator();
vibrato.frequency.setValueAtTime(6.5, inicio);
const gananciaVibrato = ctx.createGain();
gananciaVibrato.gain.setValueAtTime(4, inicio);
vibrato.connect(gananciaVibrato);
gananciaVibrato.connect(osc.frequency);
osc.frequency.setValueAtTime(140, inicio);
osc.frequency.linearRampToValueAtTime(155, inicio + 0.15);
osc.frequency.exponentialRampToValueAtTime(90, inicio + 0.85);
// Segundo oscilador una octava abajo, más suave, le da cuerpo/grosor.
const oscGrave = ctx.createOscillator();
oscGrave.type = 'triangle';
oscGrave.frequency.setValueAtTime(70, inicio);
oscGrave.frequency.exponentialRampToValueAtTime(45, inicio + 0.85);
const filtro = ctx.createBiquadFilter();
filtro.type = 'lowpass';
filtro.frequency.setValueAtTime(500, inicio);
filtro.frequency.linearRampToValueAtTime(280, inicio + 0.8);
const gainOsc = ctx.createGain();
gainOsc.gain.setValueAtTime(0, inicio);
gainOsc.gain.linearRampToValueAtTime(0.22, inicio + 0.12);
gainOsc.gain.linearRampToValueAtTime(0.16, inicio + 0.5);
gainOsc.gain.linearRampToValueAtTime(0, inicio + 0.9);
const gainGrave = ctx.createGain();
gainGrave.gain.setValueAtTime(0, inicio);
gainGrave.gain.linearRampToValueAtTime(0.12, inicio + 0.12);
gainGrave.gain.linearRampToValueAtTime(0, inicio + 0.9);
osc.connect(filtro); filtro.connect(gainOsc); gainOsc.connect(gainMaestro);
oscGrave.connect(gainGrave); gainGrave.connect(gainMaestro);
gainMaestro.gain.setValueAtTime(1, inicio);
osc.start(inicio); osc.stop(inicio + 0.95);
oscGrave.start(inicio); oscGrave.stop(inicio + 0.95);
vibrato.start(inicio); vibrato.stop(inicio + 0.95);
}
function sonidoMoonitorExito(ctx){
const inicio = ctx.currentTime;
const osc = ctx.createOscillator();
osc.type = 'sine';
osc.frequency.setValueAtTime(520, inicio);
osc.frequency.exponentialRampToValueAtTime(780, inicio + 0.18);
const gain = ctx.createGain();
gain.gain.setValueAtTime(0, inicio);
gain.gain.linearRampToValueAtTime(0.18, inicio + 0.05);
gain.gain.linearRampToValueAtTime(0, inicio + 0.3);
osc.connect(gain); gain.connect(ctx.destination);
osc.start(inicio); osc.stop(inicio + 0.32);
}
function ocultarMoonitor(){
clearTimeout(moonitorTimeoutAutoOcultar);
const widget = document.getElementById('moonitor-widget');
widget.style.transform = 'translateY(14px)';
widget.style.opacity = '0';
setTimeout(() => { widget.classList.add('hidden'); widget.style.display = 'none'; }, 220);
if (moonitorActual && moonitorActual.opciones && typeof moonitorActual.opciones.alCerrar === 'function') moonitorActual.opciones.alCerrar();
moonitorActual = null;
procesarSiguienteAlertaMoonitor();
}
function encolarAlertaMoonitor(generador){
moonitorColaAlertas.push(generador);
if (!moonitorActual) procesarSiguienteAlertaMoonitor();
}
function procesarSiguienteAlertaMoonitor(){
if (moonitorActual || moonitorColaAlertas.length === 0) return;
const generador = moonitorColaAlertas.shift();
generador();
}
function hablarMoonitorSiEstaVisible(){
const widget = document.getElementById('moonitor-widget');
if (widget && !widget.classList.contains('hidden') && moonitorActual && moonitorActual.opciones && moonitorActual.opciones.regenerar){
moonitorActual.opciones.regenerar();
}
}
function moonitorAvisarTelefonoFaltante(){
if (estado.productor && estado.productor.telefono) return;
encolarAlertaMoonitor(() => {
const regenerar = () => mostrarMoonitor(tr('moonitor__falta_telefono'), { regenerar, botones: [
{ texto: tr('moonitor__entendido'), accion: () => irA('datos-productor') },
] });
regenerar();
});
}
function moonitorRevisarRecordatorioCompartir(){
const cfg = estado.moonitor;
if (!cfg || !cfg.recordatorioCompartirActivo) return;
const hoy = hoyISO();
const diaSemana = new Date().getDay();
if (diaSemana !== Number(cfg.diaRecordatorioCompartir || 1)) return;
if (cfg.ultimoRecordatorioCompartir === hoy) return;
encolarAlertaMoonitor(() => {
const regenerar = () => mostrarMoonitor(tr('moonitor__favor_de_compartir'), { regenerar, cerrarAlAccionar: false, botones: [
{ texto: tr('moonitor__compartir_por_whatsapp'), color: '#25D366', accion: 'compartirAppPorWhatsApp', cerrarAlAccionar: true },
{ texto: tr('moonitor__ahora_no'), color: 'var(--slate)', accion: 'ocultarMoonitor' },
] });
regenerar();
});
estado.moonitor.ultimoRecordatorioCompartir = hoy;
}
function compartirAppPorWhatsApp(){
const mensaje = encodeURIComponent(tr('moonitor__mensaje_compartir_app') + ' https://mi-ranchapp.netlify.app');
window.open(`https://wa.me/?text=${mensaje}`, '_blank');
registrarEvento('whatsapp', 'compartir_app');
ocultarMoonitor();
}
function revisarAlertasMoonitor(){
// El saludo inicial ("Buenas noches, Nombre!") ya no se muestra aquí — es
// exactamente el mismo texto que ya aparece de forma permanente en la
// tarjeta de bienvenida de arriba, así que era un mensaje duplicado que
// además tapaba los accesos rápidos.
moonitorAvisarTelefonoFaltante();
moonitorAvisarNotificacionesPendientes();
moonitorAvisarBoletinNuevo();
moonitorRevisarRecordatorioCompartir();
}
function moonitorSaludoInicial(){
encolarAlertaMoonitor(() => {
const nombre = (estado.productor && estado.productor.nombre) ? estado.productor.nombre.trim().split(' ')[0] : '';
const regenerar = () => mostrarMoonitor(`${saludoSegunHora()}${nombre ? ', ' + nombre : ''}! 👋`, { regenerar, botones: [
{ texto: tr('moonitor__entendido'), accion: 'ocultarMoonitor' },
] });
regenerar();
});
}
function moonitorAvisarNotificacionesPendientes(){
const notas = (typeof calcularNotificaciones === 'function') ? calcularNotificaciones() : [];
if (!notas.length) return;
const hoy = hoyISO();
const clave = 'miRanchAppMoonitorNotifs';
let visto = null;
try { visto = localStorage.getItem(clave); } catch(e){}
if (visto === hoy + ':' + notas.length) return;
encolarAlertaMoonitor(() => {
const regenerar = () => mostrarMoonitor(`${tr('moonitor__tienes_avisos_pendientes')} (${notas.length})`, { regenerar, botones: [
{ texto: tr('moonitor__ver_notificaciones'), accion: () => irA('notificaciones') },
] });
regenerar();
});
try { localStorage.setItem(clave, hoy + ':' + notas.length); } catch(e){}
}
function moonitorAvisarBoletinNuevo(){
if (!estado.boletines.length) return;
const ultimo = estado.boletines[0];
const firma = (ultimo.titulo || '') + '|' + (ultimo.fecha || '');
const clave = 'miRanchAppMoonitorBoletin';
let visto = null;
try { visto = localStorage.getItem(clave); } catch(e){}
if (visto === firma) return;
encolarAlertaMoonitor(() => {
const regenerar = () => mostrarMoonitor(`${tr('moonitor__nuevo_boletin')}: ${ultimo.titulo}`, { regenerar, botones: [
{ texto: tr('moonitor__ver_boletines'), accion: () => irA('boletines') },
] });
regenerar();
});
try { localStorage.setItem(clave, firma); } catch(e){}
}
function pintarPrevisualizacionesMoonitor(){
const defaults = { imagenDefault: MOONITOR_DEFAULT_LECHE_B64, imagenCarne: MOONITOR_DEFAULT_CARNE_B64, imagenLeche: MOONITOR_DEFAULT_LECHE_B64 };
const claves = { imagenDefault: 'previsualizacion-moonitor-default', imagenCarne: 'previsualizacion-moonitor-carne', imagenLeche: 'previsualizacion-moonitor-leche' };
Object.keys(claves).forEach(clave => {
const cont = document.getElementById(claves[clave]);
if (!cont) return;
const img = (estado.moonitor && estado.moonitor[clave]) || defaults[clave];
cont.style.backgroundImage = `url('${img}')`;
cont.style.backgroundSize = 'contain';
cont.style.backgroundPosition = 'center';
cont.style.backgroundRepeat = 'no-repeat';
});
const switchEl = document.getElementById('switch-recordatorio-compartir');
if (switchEl) switchEl.checked = !!(estado.moonitor && estado.moonitor.recordatorioCompartirActivo);
const switchSonido = document.getElementById('switch-sonido-moonitor');
if (switchSonido) switchSonido.checked = !(estado.moonitor && estado.moonitor.sonidoActivado === false);
}
function subirImagenMoonitor(archivo, clave){
if (!archivo) return;
const lector = new FileReader();
lector.onload = e => {
const img = new Image();
img.onload = () => {
const anchoObjetivo = 300;
const escala = Math.min(1, anchoObjetivo / img.width);
const canvas = document.createElement('canvas');
canvas.width = img.width * escala;
canvas.height = img.height * escala;
const ctx = canvas.getContext('2d');
ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
estado.moonitor[clave] = canvas.toDataURL('image/webp', 0.75);
pintarPrevisualizacionesMoonitor();
};
img.src = e.target.result;
};
lector.readAsDataURL(archivo);
}
function restaurarImagenesMoonitorDefault(){
estado.moonitor.imagenDefault = null;
estado.moonitor.imagenCarne = null;
estado.moonitor.imagenLeche = null;
pintarPrevisualizacionesMoonitor();
}
function toggleRecordatorioCompartir(activo){
estado.moonitor.recordatorioCompartirActivo = activo;
}
function toggleSonidoMoonitor(activo){
estado.moonitor.sonidoActivado = activo;
if (activo) reproducirSonidoMoonitor();
}
// ================= CÓDIGO QR DE ACCESO =================
let qrAccesoInstancia = null;
function inicializarQrAcceso(){
const campo = document.getElementById('qr-enlace');
if (!campo) return;
if (!campo.value) campo.value = (estado.configuracion && estado.configuracion.enlaceQr) || window.location.origin + window.location.pathname;
generarQrAcceso();
}
function generarQrAcceso(){
const cont = document.getElementById('qr-contenedor');
const campo = document.getElementById('qr-enlace');
if (!cont || !campo) return;
const enlace = campo.value.trim();
if (!/^https?:\/\/.+/i.test(enlace)){ mostrarToast(tr('admin_qr__escribe_un_enlace_valido')); return; }
estado.configuracion.enlaceQr = enlace;
const separador = enlace.includes('?') ? '&' : '?';
const enlaceConMarcador = enlace + separador + 'src=qr';
cont.innerHTML = '';
// El generador de QR solo lo usa el administrador desde esta pantalla — se
// descarga la primera vez que se abre, no para todos los roles siempre.
cargarQRCodeSiNecesario().then(() => {
qrAccesoInstancia = new QRCode(cont, { text: enlaceConMarcador, width: 200, height: 200, colorDark: '#1F3A2E', colorLight: '#ffffff', correctLevel: QRCode.CorrectLevel.M });
});
}
function descargarQrAcceso(){
const cont = document.getElementById('qr-contenedor');
if (!cont) return;
const canvas = cont.querySelector('canvas');
const img = cont.querySelector('img');
const dataUrl = canvas ? canvas.toDataURL('image/png') : (img ? img.src : null);
if (!dataUrl) return;
const link = document.createElement('a');
link.download = 'qr-mi-ranchapp.png';
link.href = dataUrl;
link.click();
}
let historialPantallasAdmin = [];
function irAdmin(nombre){
const actual = document.querySelector('#app-admin .screen.active');
const actualId = actual ? actual.id.replace('screen-admin-', '') : null;
if (actualId && actualId !== nombre && document.getElementById('screen-admin-' + nombre)){
historialPantallasAdmin.push(actualId);
if (historialPantallasAdmin.length > 30) historialPantallasAdmin.shift();
registrarPasoHistorialNavegador();
}
cambiarPantallaAdmin(nombre);
}
function volverAtrasAdmin(destinoRespaldo){
let anterior = historialPantallasAdmin.pop();
while (anterior && !document.getElementById('screen-admin-' + anterior)) anterior = historialPantallasAdmin.pop();
cambiarPantallaAdmin(anterior || destinoRespaldo || 'home');
}
// En vez de mantener una lista de lo que está PROHIBIDO (que ya demostró
// que se le escapan pantallas nuevas cada vez que se agrega algo), esto
// funciona al revés: para cada rol restringido, se dice exactamente qué SÍ
// puede ver — todo lo que no esté en su lista se bloquea por default. Así,
// cualquier pantalla nueva que se agregue después queda bloqueada
// automáticamente para estos roles, sin tener que acordarse de venir aquí
// a prohibirla a mano cada vez.
const PANTALLAS_PERMITIDAS_POR_ROL_RESTRINGIDO = {
comite: ['home','cefpp','comitecefpp','nueva-solicitud-cefpp','solicitudescefp','capturapcc','generartb','reportestb','ventanageneraltb','tbhub','mensajes','boletines'],
medicocampotb: ['home','medicocampotb','capturapcc','mensajes','boletines'],
capturistatb: ['home','capturistatb','capturapcc','mensajes','boletines'],
capturista: ['home','pruebascapturista','capturapcc','mensajes','boletines'],
almita: ['home','almita','mensajes','boletines'],
veterinario: ['home','boletines','pruebascampo','vetnotas','vetproductores','nueva-prueba-campo','productor','mensajes','tbhub','generartb','reportestb','ventanageneraltb'],
};
function rolRestringidoActivo(){
if (estado.modoComite) return 'comite';
if (estado.modoMedicoCampoTB) return 'medicocampotb';
if (estado.modoCapturistaTB) return 'capturistatb';
if (estado.modoCapturista) return 'capturista';
if (estado.modoAlmita) return 'almita';
if (estado.vistaVeterinario || estado.modoVeterinario) return 'veterinario';
return null; // administrador completo — sin restricción, ve todo
}
// Guardia reutilizable por módulos: distingue al administrador completo de los
// roles que comparten la misma carcasa app-admin. No depende de CSS ni de botones.
function puedeAdministrarCompletoIRanch(){
return sesionRolAutenticado === 'admin' && estado.rolActual === 'admin' && !estado.modoDemoActivo && !rolRestringidoActivo();
}
window.iranchPuedeAdministrarCompleto = puedeAdministrarCompletoIRanch;

function cambiarPantallaAdmin(nombre){
const rolRestringido = rolRestringidoActivo();
if (rolRestringido && !PANTALLAS_PERMITIDAS_POR_ROL_RESTRINGIDO[rolRestringido].includes(nombre)){
mostrarToast('Esta sección es solo para el administrador');
nombre = 'home';
}
document.querySelectorAll('#app-admin .screen').forEach(s => s.classList.remove('active'));
document.getElementById('screen-admin-' + nombre).classList.add('active');
document.querySelectorAll('#app-admin .navbar-item').forEach(b => b.classList.remove('active'));
const nav = document.querySelector('[data-nav-admin="' + nombre + '"]');
if (nav) nav.classList.add('active');
if (nombre === 'mas') renderResumenAdmin();
if (nombre === 'usuarios') renderListaUsuarios();
if (nombre === 'cuentas') renderCuentas();
if (nombre === 'info') renderInfoSistema();
if (nombre === 'cefpp') renderListaCefpp();
if (nombre === 'mensajes'){ revisarMensajesProgramadosDebidos(); cambiarSubtabMensajes('conversaciones'); }
if (nombre === 'config-apariencia'){ pintarPrevisualizacionFondoHome(); pintarPrevisualizacionFondoHeader(); pintarPrevisualizacionLogo(); pintarPrevisualizacionesMoonitor(); renderListaIconosBotones(); }
if (nombre === 'config-orden'){ renderTogglesModulos(); renderListaOrdenMas(); renderListaOrdenGraficas(); renderTogglesCampos(); renderCamposPersonalizadosAdmin(); }
if (nombre === 'config-permisos'){ renderTogglesPermisosTrabajador(); inicializarQrAcceso(); }
if (nombre === 'config-pagos') { renderMetodosPago(); actualizarBadgeConfirmacionesPago(); }
if (nombre === 'confirmaciones-pago') renderConfirmacionesPago();
if (nombre === 'config-contenido'){ renderListaPlanSanitario(); renderTogglesVentanasExtra(); renderListaBanners(); renderListaPredios(); }
if (nombre === 'pruebascampo'){ renderListaPruebasCampo(); renderSolicitudesAretesVet(); renderSolicitudesPruebaVet(); renderSolicitudesCEFPPVet(); if (typeof hayBorradorPruebaCampoActivo === 'function' && hayBorradorPruebaCampoActivo()) mostrarAvisoBorradorPruebaCampoPendiente(); }
if (nombre === 'pruebascapturista') renderPruebasCapturista(false);
if (nombre === 'capturistatb') renderPruebasCapturista(true);
if (nombre === 'pruebasrealizadas') renderPruebasRealizadas();
if (nombre === 'almita'){ renderEnviosAlmita(); renderSolicitudesCEFPPGeneradas(); }
if (nombre === 'comitecefpp'){ actualizarBadgesComiteCEFPP(); cambiarTabComiteCEFPP('general'); }
if (nombre === 'ventanageneraltb'){ renderAvisosReactoresTB(); renderMedicosComiteTB(); }
if (nombre === 'medicocampotb'){ renderCasosMedicoCampoTB(); }
if (nombre === 'reportestb'){ renderReportesTB(); }
if (nombre === 'generartb'){ renderGenerarInformeTB(); }
if (nombre === 'solicitudescefp') renderSolicitudesCEFP();
if (nombre === 'reportes') actualizarReportesRegionales();
if (nombre === 'metricas') renderMetricasInteraccion();
const fabChatAdmin = document.getElementById('btn-chat-flotante-admin');
if (fabChatAdmin) fabChatAdmin.classList.toggle('hidden', nombre === 'mensajes');
window.scrollTo(0,0);
}
let animalEditandoIndice = null;
function irModulo(letra){
if (estado.modoTrabajador && !estado.permisosTrabajador['modulo' + letra]){ mostrarToast(tr('trabajadores__acceso_no_disponible')); return; }
// Si se llega aquí por la navegación normal (tocando el módulo desde el
// menú), se sale de cualquier modo de edición que hubiera quedado abierto
// — evita editar por accidente un animal viejo si alguien empezó a editar,
// se salió sin guardar, y luego entra a dar de alta uno nuevo.
animalEditandoIndice = null;
irA('estatus');
letraActual = letra;
subtabActual = 'registrar';
const dominiosModulo = { A:['hato'], B:['salud'], C:['reproduccion'], D:['pesajes'], G:['produccionLeche'], H:['tanqueLeche'], I:['alimentacionLeche'] }[letra];
const debePreparar = typeof asegurarDominioCuentaCargado === 'function' && !!estado.cuentaActivaId && Array.isArray(dominiosModulo);
const contModulo = document.getElementById('modulo-contenido');
if (debePreparar && contModulo) contModulo.innerHTML = '<div class="p-6 text-center" style="color:var(--sage);"><i class="fa-solid fa-spinner fa-spin mr-2"></i>Cargando datos…</div>';
const preparar = debePreparar ? Promise.all(dominiosModulo.map(d => asegurarDominioCuentaCargado(estado.cuentaActivaId, d))) : Promise.resolve();
preparar.then(() => renderModulo());
}
function renderResumenConteosInventarioProductor(){
const cont = document.getElementById('resumen-conteos-inventario-productor');
if (!cont) return;
const vigentes = estado.animales.filter(a => a.estatus !== 'vendido' && a.estatus !== 'finado').length;
const bajas = estado.animales.filter(a => a.estatus === 'vendido' || a.estatus === 'finado').length;
const machos = estado.animales.filter(a => a.sexo === 'macho').length;
const hembras = estado.animales.filter(a => a.sexo === 'hembra').length;
cont.innerHTML = `
<div class="rounded-xl p-2" style="background:rgba(76,153,89,0.12);"><p class="text-lg font-bold" style="color:var(--green);">${vigentes}</p><p class="text-xs" style="color:var(--sage);">Vigentes</p></div>
<div class="rounded-xl p-2" style="background:rgba(211,71,71,0.1);"><p class="text-lg font-bold" style="color:var(--red);">${bajas}</p><p class="text-xs" style="color:var(--sage);">Bajas</p></div>
<div class="rounded-xl p-2" style="background:var(--parchment);"><p class="text-lg font-bold">${machos}</p><p class="text-xs" style="color:var(--sage);">Machos</p></div>
<div class="rounded-xl p-2" style="background:var(--parchment);"><p class="text-lg font-bold">${hembras}</p><p class="text-xs" style="color:var(--sage);">Hembras</p></div>`;
}
function renderResumenProductor(){
const cont = document.getElementById('resumen-productor');
const contExtra = document.getElementById('resumen-productor-extra');
const p = estado.productor;
const activos = estado.animales.filter(a => a.estatus !== 'vendido' && a.estatus !== 'finado').length;
// Solo lo esencial se ve de entrada (nombre, predio, UPP, animales) — el
// resto (fechas de vigencia, ubicación, CURP, etc.) se queda detrás de
// "Ver más datos", para que esta pantalla no sea puro scroll de algo que
// casi nadie necesita ver a cada rato.
const camposPrincipales = [
['nombre','Nombre', p.nombre],
['predio','Predio', p.predio],
['upp','UPP', p.upp],
['animales', tr('render_home_productor__animales_activos'), activos + ' cabezas'],
];
const camposExtra = [
['actualizacionUPP','Act. UPP', p.actualizacionUPP],
['folio','Folio fierro', p.folio],
['vencimientoFierro','Vence fierro', p.vencimientoFierro],
['estado','Estado', p.estado],
['municipio','Municipio', p.municipio],
['ejido','Ejido/parcela', p.ejido],
['curp','CURP', p.curp],
['actividad','Actividad', p.actividad],
];
const pintarCampo = ([clave, etiqueta, valor]) => `
<div>
<p style="color:var(--sage);">${etiqueta}</p>
<p class="font-bold text-base">${valor && valor !== '0 cabezas' ? valor : (clave==='animales' ? valor : '<span style="color:var(--line);">Sin datos</span>')}</p>
</div>`;
if (cont) cont.innerHTML = camposPrincipales.filter(([clave]) => estado.camposProductor[clave]).map(pintarCampo).join('');
if (contExtra) contExtra.innerHTML = camposExtra.filter(([clave]) => estado.camposProductor[clave]).map(pintarCampo).join('');
renderResumenConteosInventarioProductor();
}
function toggleDatosProductorExtra(){
const cont = document.getElementById('resumen-productor-extra');
const boton = document.getElementById('btn-ver-mas-datos-productor');
if (!cont || !boton) return;
const abrir = cont.classList.contains('hidden');
cont.classList.toggle('hidden', !abrir);
boton.innerHTML = abrir
? '<i class="fa-solid fa-chevron-up mr-1"></i>Ver menos'
: '<i class="fa-solid fa-chevron-down mr-1"></i>Ver más datos';
}
function saludoSegunHora(){
const hora = new Date().getHours();
if (hora < 12) return tr('inicio_productor__buen_dia');
if (hora < 19) return tr('inicio_productor__buenas_tardes');
return tr('inicio_productor__buenas_noches');
}
function renderTarjetaDatosGenerales(){
const cont = document.getElementById('tarjeta-datos-generales');
if (!cont) return;
const p = estado.productor;
const fondoHero = document.getElementById('fondo-hero-home');
if (fondoHero) fondoHero.style.backgroundImage = `url('${estado.configuracion.fondoHome || fondoHomeSemanal()}')`;
const primerNombre = (p.nombre || '').trim().split(' ')[0];
cont.innerHTML = `
<div class="flex flex-col gap-1.5">
<p class="font-display text-base font-bold leading-snug">${primerNombre ? `${saludoSegunHora()}, ${primerNombre}! 👋` : `${saludoSegunHora()}!`}</p>
${estado.tipoGanado ? `<span class="text-xs font-bold px-2 py-1 rounded-full self-start" style="background:rgba(255,255,255,0.18);"><i class="fa-solid ${estado.tipoGanado === 'leche' ? 'fa-jug-detergent' : 'fa-drumstick-bite'} mr-1"></i>${estado.tipoGanado === 'leche' ? tr('seleccion_tipo_ganado__ganado_vacuno_de_leche') : tr('seleccion_tipo_ganado__ganado_vacuno_de_carne')}</span>` : ''}
</div>
<div class="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1 text-sm" style="color:#CFE0D2;">
${p.predio ? `<span><i class="fa-solid fa-house-chimney mr-1"></i>${p.predio}</span>` : ''}
${p.upp ? `<span><i class="fa-solid fa-hashtag mr-1"></i>UPP ${p.upp}</span>` : ''}
${p.municipio ? `<span><i class="fa-solid fa-location-dot mr-1"></i>${p.municipio}</span>` : ''}
<button onclick="irA('datos-productor')" class="text-xs font-bold ml-auto" style="color:#fff; text-decoration:underline;">${tr('inicio_productor__ver_mis_datos')}</button>
</div>
${estado.tipoGanado === 'leche' ? (() => {
const hoy = hoyISO();
const litrosHoy = estado.produccionLeche.filter(r => r.fecha === hoy).reduce((s, r) => s + (Number(r.total) || 0), 0);
const litrosAcumulado = estado.produccionLeche.reduce((s, r) => s + (Number(r.total) || 0), 0);
return `<div class="flex items-center gap-4 mt-2 pt-2 text-sm" style="border-top:1px solid rgba(255,255,255,0.2); color:#fff;">
<span><i class="fa-solid fa-jug-detergent mr-1"></i>Hoy: <strong>${litrosHoy} L</strong></span>
<span><i class="fa-solid fa-chart-line mr-1"></i>Acumulado: <strong>${litrosAcumulado} L</strong></span>
</div>`;
})() : ''}
${estado.predios.length > 1 ? `
<select onchange="cambiarPredioActivo(this.value)" class="mt-3 w-full" style="background:rgba(255,255,255,0.15); color:#fff; border:1px solid rgba(255,255,255,0.4); border-radius:12px; padding:.5rem .75rem;">
<option value="">Cambiar predio activo...</option>
${estado.predios.map(pr => `<option value="${pr.id}">${pr.nombre}</option>`).join('')}
</select>` : ''}`;
}
let climaHomeCache = null;
// Limita cuánto tiempo espera una petición antes de darla por fallida — sin esto,
// con señal débil o intermitente (común en el campo) el fetch se queda "colgado"
// indefinidamente y el clima nunca sale del estado "Cargando...".
function fetchConTiempoLimite(url, opciones, milisegundos){
const controlador = new AbortController();
const id = setTimeout(() => controlador.abort(), milisegundos || 8000);
return fetch(url, { ...(opciones || {}), signal: controlador.signal }).finally(() => clearTimeout(id));
}
async function renderClimaHome(){
const cont = document.getElementById('clima-home');
if (!cont) return;
if (!navigator.onLine){
cont.innerHTML = `<p class="text-sm" style="color:var(--sage);"><i class="fa-solid fa-cloud-exclamation mr-1"></i>${tr('inicio_productor__clima_no_disponible')}</p><button onclick="renderClimaHome()" class="text-xs font-bold" style="color:var(--pine);">${tr('inicio_productor__reintentar')}</button>`;
return;
}
cont.innerHTML = `<p class="text-sm" style="color:var(--sage);"><i class="fa-solid fa-spinner fa-spin mr-1"></i>${tr('inicio_productor__clima_cargando')}</p>`;
try {
let lat, lng, aproximado = false;
if (typeof estadoUbicacion !== 'undefined' && estadoUbicacion){
lat = estadoUbicacion.lat; lng = estadoUbicacion.lng;
} else {
const pos = await new Promise((resolve, reject) => {
if (!navigator.geolocation){ reject(); return; }
navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 6000, maximumAge: 600000 });
}).catch(() => null);
if (pos){ lat = pos.coords.latitude; lng = pos.coords.longitude; }
else { lat = 23.75; lng = -104.75; aproximado = true; }
}
const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation_probability,weather_code,wind_speed_10m&hourly=temperature_2m,precipitation_probability,weather_code&forecast_days=1&timezone=auto`;
const resp = await fetchConTiempoLimite(url, null, 8000);
if (!resp.ok) throw new Error('respuesta no válida del servicio meteorológico');
const datos = await resp.json();
let lugar = '';
try {
const geoResp = await fetchConTiempoLimite(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=10`, { headers: { 'Accept-Language': idiomaActual || 'es' } }, 5000);
const geoDatos = await geoResp.json();
lugar = geoDatos.address ? (geoDatos.address.town || geoDatos.address.village || geoDatos.address.city || geoDatos.address.county || '') : '';
} catch(e){ /* si falla solo el nombre del lugar, seguimos igual mostrando el clima */ }
climaHomeCache = { datos, lugar, aproximado, lat, lng };
pintarClimaHome();
} catch(e){
cont.innerHTML = `<p class="text-sm" style="color:var(--sage);"><i class="fa-solid fa-cloud-exclamation mr-1"></i>${tr('inicio_productor__clima_no_disponible')}</p><button onclick="renderClimaHome()" class="text-xs font-bold" style="color:var(--pine);">${tr('inicio_productor__reintentar')}</button>`;
}
}
function iconoClima(codigo){
if (codigo === 0) return '☀️';
if ([1,2].includes(codigo)) return '⛅';
if (codigo === 3) return '☁️';
if ([45,48].includes(codigo)) return '🌫️';
if ([51,53,55,56,57,61,63,65,66,67,80,81,82].includes(codigo)) return '🌧️';
if ([71,73,75,77,85,86].includes(codigo)) return '❄️';
if ([95,96,99].includes(codigo)) return '⛈️';
return '⛅';
}
function pintarClimaHome(){
const cont = document.getElementById('clima-home');
if (!cont || !climaHomeCache) return;
const c = climaHomeCache.datos.current;
cont.innerHTML = `
<span style="font-size:2rem;">${iconoClima(c.weather_code)}</span>
<div class="flex-1">
<p class="font-display text-xl font-bold">${Math.round(c.temperature_2m)}°C</p>
<p class="text-xs" style="color:var(--sage);"><i class="fa-solid fa-location-dot mr-1"></i>${climaHomeCache.lugar || tr('render_modulos_f__ubicacion_central')}${climaHomeCache.aproximado ? ' · ' + tr('inicio_productor__ubicacion_aproximada') : ''}</p>
</div>
<i class="fa-solid fa-chevron-right" style="color:var(--sage);"></i>`;
}
function abrirDetalleClima(){
if (!climaHomeCache) return;
const c = climaHomeCache.datos.current;
const h = climaHomeCache.datos.hourly;
const horaActual = new Date().getHours();
let filasHoras = '';
for (let i = horaActual; i < Math.min(horaActual + 12, h.time.length); i++){
const hEtiqueta = new Date(h.time[i]).getHours().toString().padStart(2,'0') + ':00';
filasHoras += `<div class="flex flex-col items-center gap-1 flex-shrink-0" style="width:56px;">
<p class="text-xs" style="color:var(--sage);">${hEtiqueta}</p>
<span style="font-size:1.3rem;">${iconoClima(h.weather_code[i])}</span>
<p class="text-sm font-bold">${Math.round(h.temperature_2m[i])}°</p>
<p class="text-xs" style="color:var(--blue);">${h.precipitation_probability[i]}%</p>
</div>`;
}
const modal = document.createElement('div');
modal.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:80; display:flex; align-items:flex-end;';
modal.innerHTML = `
<div class="w-full bg-white rounded-t-3xl p-5 space-y-4" style="max-height:80vh; overflow-y:auto;">
<div class="flex items-center justify-between">
<p class="font-display text-lg font-bold"><i class="fa-solid fa-location-dot mr-1"></i>${climaHomeCache.lugar || ''}</p>
<button onclick="this.closest('div[style*=fixed]').remove()" style="color:var(--sage);"><i class="fa-solid fa-xmark text-xl"></i></button>
</div>
<div class="grid grid-cols-2 gap-3">
<div class="rounded-2xl p-3" style="background:var(--parchment);"><p class="text-xs" style="color:var(--sage);">${tr('inicio_productor__sensacion')}</p><p class="font-bold">${Math.round(c.apparent_temperature)}°C</p></div>
<div class="rounded-2xl p-3" style="background:var(--parchment);"><p class="text-xs" style="color:var(--sage);">${tr('inicio_productor__humedad')}</p><p class="font-bold">${c.relative_humidity_2m}%</p></div>
<div class="rounded-2xl p-3" style="background:var(--parchment);"><p class="text-xs" style="color:var(--sage);">${tr('inicio_productor__viento')}</p><p class="font-bold">${Math.round(c.wind_speed_10m)} km/h</p></div>
<div class="rounded-2xl p-3" style="background:var(--parchment);"><p class="text-xs" style="color:var(--sage);">${tr('inicio_productor__probabilidad_de_lluvia')}</p><p class="font-bold">${c.precipitation_probability ?? 0}%</p></div>
</div>
<div>
<p class="font-bold mb-2">${tr('inicio_productor__pronostico_por_horas')}</p>
<div class="flex gap-3 overflow-x-auto pb-1">${filasHoras}</div>
</div>
<p class="text-xs text-center" style="color:var(--line);">Open-Meteo</p>
</div>`;
document.body.appendChild(modal);
modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
}
function renderActividadesRecientesHome(){
const cont = document.getElementById('actividades-recientes-home');
if (!cont) return;
const mias = estado.tareas.filter(t => !t.asignadoA || t.asignadoA === estado.trabajadorActualId).slice(0, 4);
if (mias.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-list-check"></i><p>${tr('inicio_productor__aun_no_tienes_actividades')}</p></div>`;
return;
}
cont.innerHTML = mias.map(t => `
<div class="item-registro flex items-center justify-between gap-3" style="border-left:6px solid ${t.hecha ? 'var(--green)' : 'var(--blue)'};">
<div>
<p class="font-bold" style="${t.hecha ? 'text-decoration:line-through; opacity:.6;' : ''}">${t.texto}</p>
<p class="text-sm" style="color:var(--sage);">${t.fecha}</p>
</div>
<button onclick="toggleTareaHecha('${t.id}'); renderActividadesRecientesHome();" class="text-xs font-bold px-3 py-2 rounded-full flex-shrink-0" style="background:${t.hecha ? 'var(--parchment)' : 'var(--green)'}; color:${t.hecha ? 'var(--pine)' : '#fff'};">
<i class="fa-solid ${t.hecha ? 'fa-rotate-left' : 'fa-check'}"></i>
</button>
</div>`).join('');
}
function puedeVerModuloTrabajador(letra){
return !estado.modoTrabajador || estado.permisosTrabajador['modulo' + letra];
}
function renderAccesoRapidoHome(){
const cont = document.getElementById('acceso-rapido-home');
if (!cont) return;
const esLeche = estado.tipoGanado === 'leche';
const items = [
{ mostrar: estado.visibilidad.hato, clave:'hato', icono:'fa-list-ul', emoji:'🐄', color:'var(--blue)', texto: tr('hato_inventario_animales__estatus_del_hato'), accion:"irA('hato')" },
{ mostrar: estado.visibilidad.moduloC && puedeVerModuloTrabajador('C'), clave:'C', icono:'fa-heart', emoji:'❤️', color:'var(--pink)', texto: nombreModulo('C'), accion:"irModulo('C')" },
{ mostrar: estado.visibilidad.moduloK && puedeVerModuloTrabajador('K'), clave:'K', icono:'fa-warehouse', emoji:'📦', color:'var(--orange)', texto: nombreModulo('K'), accion:"irModulo('K')" },
{ mostrar: true, clave:'transferencias', icono:'fa-tag', emoji:'🏷️', color:'var(--orange)', texto: tr('menu_mas_productor__transferencias_de_aretes'), accion:"irA('transferencias')" },
esLeche
? { mostrar: estado.visibilidad.moduloG && puedeVerModuloTrabajador('G'), clave:'G', icono:'fa-jug-detergent', emoji:'🥛', color:'var(--blue)', texto: nombreModulo('G'), accion:"irModulo('G')" }
: { mostrar: estado.visibilidad.moduloD && puedeVerModuloTrabajador('D'), clave:'D', icono:'fa-weight-scale', emoji:'⚖️', color:'var(--green)', texto: nombreModulo('D'), accion:"irModulo('D')" },
{ mostrar: true, clave:'', icono:'fa-headset', emoji:'🤠', color:'#25D366', texto: tr('menu_mas_productor__mensajes_con_tu_veterinario'), accion:"irA('mensajes')" },
];
cont.innerHTML = items.filter(it => it.mostrar).slice(0, 6).map(it => {
const url = it.clave && estado.iconosBotones && estado.iconosBotones[it.clave];
// Si el admin subió un ícono propio, ese manda. Si no, se usa un emoji en
// vez del ícono plano de siempre — se ve con relieve real en cualquier
// celular, sin necesitar ninguna imagen generada aparte.
const iconoHTML = url
? `<span class="icono-cuadro" style="background-image:url('${url}'); background-size:cover; background-position:center; background-color:transparent;"></span>`
: `<span class="icono-cuadro" style="font-size:1.6rem;">${it.emoji}</span>`;
return `
<button class="tile-cuadro" onclick="${it.accion}" style="background:${it.color};">
${iconoHTML}
<span class="texto-cuadro">${it.texto}</span>
</button>`;
}).join('');
}
function renderTiles(){
renderTarjetaDatosGenerales();
renderAccesoRapidoHome();
renderBannerHome();
renderAlertasMotor();
dispararPushPendientes();
revisarResumenSemanal();
const hayNotificaciones = calcularNotificaciones().length > 0;
const badgeCampana = document.getElementById('badge-campana-header');
if (badgeCampana) badgeCampana.classList.toggle('hidden', !hayNotificaciones);
renderClimaHome();
renderActividadesRecientesHome();
const contMas = document.getElementById('grid-menu-mas');
const bannerPorClave = {
hato: estado.visibilidad.hato ? `
<button onclick="irA('hato')" class="tile-btn" style="background:linear-gradient(155deg, var(--blue), #1d4f8f); --tile-color:var(--blue);">
<span class="tile-texto">${tr('hato_inventario_animales__estatus_del_hato')}</span>
${iconoTileHTML('hato', 'fa-list-ul')}
</button>` : '',
};
Object.entries(MODULOS).forEach(([letra, m]) => {
if (!estado.visibilidad['modulo' + letra] || (estado.modoTrabajador && !estado.permisosTrabajador['modulo' + letra])){
bannerPorClave[letra] = '';
return;
}
if ((letra === 'G' || letra === 'H' || letra === 'I' || letra === 'J') && estado.tipoGanado !== 'leche'){
bannerPorClave[letra] = '';
return;
}
bannerPorClave[letra] = `
<button onclick="irModulo('${letra}')" class="tile-btn" style="background:linear-gradient(155deg, ${m.color}, ${m.color}); --tile-color:${m.color};">
<span class="tile-texto">${nombreModulo(letra)}</span>
${iconoTileHTML(letra, m.icono)}
</button>`;
});
const ordenValido = estado.ordenMas.filter(c => bannerPorClave.hasOwnProperty(c));
Object.keys(bannerPorClave).forEach(c => { if (!ordenValido.includes(c)) ordenValido.push(c); });
const modulosHtml = ordenValido.map(c => bannerPorClave[c]).join('');
const extraHtml = estado.ventanasExtra
.filter(v => v.visible)
.map(v => `
<button onclick="abrirVentanaExtra('${v.id}')" class="tile-row-flat bg-purple">
<span>${v.nombre}</span>
<i class="fa-solid fa-chevron-right ml-auto opacity-70"></i>
</button>`).join('');
contMas.innerHTML = modulosHtml + extraHtml;
}
function renderNavbar(){
const nav = document.getElementById('navbar-productor');
const base = [
{ id:'home', icono:'fa-house', labelKey:'nav_inicio', siempre:true },
{ id:'hato', icono:'fa-list-ul', labelKey:'nav_hato' },
{ id:'graficas', icono:'fa-chart-column', labelKey:'nav_graficas' },
{ id:'boletines', icono:'fa-bullhorn', labelKey:'nav_boletines' },
];
nav.innerHTML = base
.filter(b => (b.siempre || estado.visibilidad[b.clave || b.id]) && !(estado.modoTrabajador && b.id === 'graficas'))
.map(b => `
<button class="navbar-item" data-nav="${b.id}" onclick="irA('${b.id}')">
<i class="fa-solid ${b.icono}"></i><span>${tr(b.labelKey)}</span>
</button>`).join('');
const pantallaActiva = document.querySelector('#app-productor .screen.active');
const idActivo = pantallaActiva ? pantallaActiva.id.replace('screen-', '') : 'home';
const botonActivo = document.querySelector(`[data-nav="${idActivo}"]`) || document.querySelector('[data-nav="home"]');
if (botonActivo) botonActivo.classList.add('active');
}
function calcularSemaforoAnimal(a){
const clave = a.arete || a.nombre;
if (!clave) return { color:'var(--sage)', texto: tr('render_estatus_hato__sin_datos') };
const urgente = estado.salud.some(r => r.animal === clave && !r.recuperado && (r.tipo === 'muerte_subita' || r.tipo === 'sospecha_exotica'));
if (urgente) return { color:'var(--red)', texto: tr('render_estatus_hato__atencion_urgente') };
const dosisVencida = estado.salud.some(r => r.animal === clave && r.proxima && diasHasta(r.proxima) < 0);
const enTratamiento = estado.salud.some(r => r.animal === clave && !r.recuperado && r.tipo === 'enfermedad');
if (dosisVencida || enTratamiento) return { color:'var(--orange)', texto: enTratamiento ? tr('render_estatus_hato__en_tratamiento') : tr('render_estatus_hato__dosis_vencida') };
return { color:'var(--green)', texto: tr('render_estatus_hato__activo_sano') };
}
function calcularFechaClaveAnimal(a){
const clave = a.arete || a.nombre;
if (!clave) return null;
const proximas = estado.salud.filter(r => r.animal === clave && r.proxima && !r.recuperado).map(r => r.proxima).sort();
if (proximas.length) return { etiqueta: tr('render_estatus_hato__proxima_revision'), fecha: proximas[0] };
const partos = estado.reproduccion.filter(r => r.vaca === clave && r.partoReal).map(r => r.partoReal).sort().reverse();
if (partos.length) return { etiqueta: tr('render_estatus_hato__ultimo_parto'), fecha: partos[0] };
const partosEst = estado.reproduccion.filter(r => r.vaca === clave && r.parto && r.diagnostico === 'confirmada').map(r => r.parto).sort();
if (partosEst.length) return { etiqueta: tr('render_estatus_hato__parto_estimado'), fecha: partosEst[0] };
return null;
}
function renderResumenVientresToros(){
const cont = document.getElementById('resumen-vientres-toros');
if (!cont) return;
const vigentes = estado.animales.filter(a => a.estatus !== 'vendido' && a.estatus !== 'finado');
const edadMesesDe = a => {
if (!a.fecha) return null;
try { return Math.floor(diasEntreISO(hoyISO(), a.fecha) / 30); } catch(e){ return null; }
};
const vientres = vigentes.filter(a => a.sexo === 'hembra' && edadMesesDe(a) !== null && edadMesesDe(a) > 36).length;
const toros = vigentes.filter(a => a.sexo === 'macho' && edadMesesDe(a) !== null && edadMesesDe(a) > 36).length;
cont.innerHTML = `
<div class="rounded-2xl p-3 text-center" style="background:var(--pink); color:#fff;">
<p class="text-2xl font-bold">${vientres}</p>
<p class="text-xs font-bold">Vientres (hembras &gt;36 meses)</p>
</div>
<div class="rounded-2xl p-3 text-center" style="background:var(--slate); color:#fff;">
<p class="text-2xl font-bold">${toros}</p>
<p class="text-xs font-bold">Toros (machos &gt;36 meses)</p>
</div>`;
}
function renderHato(){
const cont = document.getElementById('lista-hato');
const filtroEl = document.getElementById('hato-search');
const filtro = filtroEl ? filtroEl.value.trim().toLowerCase() : '';
const fEstatus = valor('hato-filtro-estatus');
const fSexo = valor('hato-filtro-sexo');
const lista = estado.animales.filter(a =>
(!filtro || (a.nombre||'').toLowerCase().includes(filtro) || (a.arete||'').toLowerCase().includes(filtro)) &&
(!fEstatus || a.estatus === fEstatus) &&
(!fSexo || a.sexo === fSexo)
);
if (estado.animales.length === 0){
cont.innerHTML = `
<div class="vacio">
<i class="fa-solid fa-cow"></i>
<p>${tr('render_estatus_hato__aun_no_has_registrado_animales')}</p>
</div>
<button onclick="irModulo('A')" class="w-full btn-primario-plano" style="background:var(--blue);">
<i class="fa-solid fa-plus"></i><span>${tr('render_estatus_hato__registrar_el_primer_animal')}</span>
</button>`;
return;
}
if (lista.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-magnifying-glass"></i><p>${tr('render_estatus_hato__no_hay_animales_que_coincidan')}</p></div>`;
return;
}
cont.innerHTML = lista.map(a => { const i = estado.animales.indexOf(a);
const pot = estado.potreros.find(p => p.nombre === a.potrero);
const semaforo = calcularSemaforoAnimal(a);
const fechaClave = calcularFechaClaveAnimal(a);
return `
<div class="item-registro flex gap-3 cursor-pointer transition-transform active:scale-[0.98]" style="border-left:6px solid ${semaforo.color};" onclick="verHistorialAnimal(${i})">
${a.foto && a.foto.startsWith('indexeddb://')
? `<div class="w-16 h-16 rounded-xl flex items-center justify-center flex-shrink-0" style="background:var(--parchment); color:var(--yellow-d);" title="Foto pendiente de subir (sin señal)"><i class="fa-solid fa-clock-rotate-left text-xl"></i></div>`
: a.foto
? `<img loading="lazy" decoding="async" src="${a.foto}" class="w-16 h-16 rounded-xl object-cover flex-shrink-0">`
: `<div class="w-16 h-16 rounded-xl flex items-center justify-center flex-shrink-0" style="background:var(--parchment); color:var(--line);"><i class="fa-solid fa-cow text-2xl"></i></div>`}
<div class="flex-1">
<div class="flex items-center justify-between gap-2">
<p class="font-display font-bold text-xl">${a.arete || a.nombre || '(sin arete)'}</p>
<span class="text-xs font-bold px-2 py-1 rounded-full flex-shrink-0" style="background:${semaforo.color}; color:#fff;"><span style="display:inline-block; width:7px; height:7px; border-radius:999px; background:#fff; margin-right:4px;"></span>${semaforo.texto}</span>
</div>
<p class="text-sm mt-0.5" style="color:var(--sage);">${a.nombre ? a.nombre + ' · ' : ''}${a.raza || 'Raza no especificada'}</p>
${fechaClave ? `<p class="text-sm mt-1 font-semibold"><i class="fa-solid fa-calendar-day mr-1" style="color:var(--sage);"></i>${fechaClave.etiqueta}: ${fechaClave.fecha}</p>` : ''}
${a.potrero ? `<span class="text-xs font-bold mt-1 inline-block px-2 py-0.5 rounded-full" style="background:${pot ? pot.color : 'var(--sage)'}; color:#fff;"><i class="fa-solid fa-map-pin mr-1"></i>${a.potrero}</span>` : ''}
</div>
</div>`; }).join('');
}
let animalHistorialActual = null;
// Reusa el mismo formulario de "dar de alta" (Módulo A) para editar un
// animal ya existente — así hereda automáticamente todas sus validaciones
// (arete duplicado, fecha futura, etc.) en vez de duplicar ese código en un
// formulario aparte, que sería más fácil que se desincronizara con el
// tiempo.
function editarAnimalDesdeHistorial(){
const i = animalHistorialActual;
const a = estado.animales[i];
if (a == null) return;
cerrarHistorial();
irModulo('A'); // esto ya deja animalEditandoIndice en null — se pone después, a propósito
animalEditandoIndice = i;
establecerValor('f-arete', a.arete || '');
establecerValor('f-chip', a.chip || '');
establecerValor('f-nombre', a.nombre || '');
establecerValor('f-raza', a.raza || '');
establecerValor('f-sexo', a.sexo || 'hembra');
establecerValor('f-fecha', a.fecha || '');
establecerValor('f-estatus', a.estatus || 'activo');
if (typeof toggleCamposBaja === 'function') toggleCamposBaja();
establecerValor('f-proposito', a.proposito || 'reemplazo');
if (a.proposito === 'engorda' && typeof toggleCamposEngorda === 'function') toggleCamposEngorda();
establecerValor('f-engorda-dias', a.engordaDiasObjetivo || '');
establecerValor('f-engorda-peso-meta', a.engordaPesoMeta || '');
establecerValor('f-madre', a.madre || '');
establecerValor('f-padre', a.padre || '');
establecerValor('f-potrero', a.potrero || '');
establecerValor('f-motivobaja', a.motivoBaja || '');
const botonGuardar = document.querySelector('#modulo-cuerpo button[onclick="guardarAnimal()"]');
if (botonGuardar) botonGuardar.innerHTML = `<i class="fa-solid fa-check"></i> Guardar cambios`;
const cuerpo = document.getElementById('modulo-cuerpo');
if (cuerpo){
const aviso = document.createElement('div');
aviso.className = 'rounded-2xl p-3 text-xs font-bold mb-1';
aviso.style.cssText = 'background:#FEF3C7; color:#92400E; border:2px solid #F59E0B;';
aviso.innerHTML = `<i class="fa-solid fa-pen"></i> Editando a ${a.nombre || a.arete || 'este animal'} — los cambios reemplazan sus datos actuales.`;
cuerpo.prepend(aviso);
}
mostrarToast('Corrige lo que haga falta y toca "Guardar cambios"');
}
function verHistorialAnimal(i){
const a = estado.animales[i];
if (!a) return;
animalHistorialActual = i;
const coincide = (valor) => valor && (valor === a.arete || valor === a.nombre || valor === a.chip);
const eventos = [];
if (a.fecha) eventos.push({ fecha:a.fecha, icono:'fa-cow', color:'var(--blue)', texto: tr('historial_bitacora_animal__nacimiento_alta_del_animal') });
estado.salud.filter(r => coincide(r.animal)).forEach(r => eventos.push({ fecha:r.fecha, icono:'fa-syringe', color:'var(--purple)', texto:`${r.tipo}${r.producto ? ' — ' + r.producto : ''}` }));
estado.reproduccion.filter(r => coincide(r.vaca)).forEach(r => eventos.push({ fecha:r.fecha, icono:'fa-heart', color:'var(--pink)', texto:`Servicio (${r.servicio}) — ${r.diagnostico}` }));
estado.pesajes.filter(r => coincide(r.animal)).forEach(r => eventos.push({ fecha:r.fecha, icono:'fa-weight-scale', color:'var(--green)', texto:`Pesaje: ${r.peso} kg` }));
if (a.estatus === 'vendido' || a.estatus === 'finado') eventos.push({ fecha: a.motivoBaja ? '' : '', icono:'fa-circle-minus', color:'var(--red)', texto:`Baja del hato${a.motivoBaja ? ' — ' + a.motivoBaja : ''}` });
eventos.sort((x,y) => new Date(x.fecha||0) - new Date(y.fecha||0));
const modal = document.getElementById('modal-historial');
document.getElementById('historial-titulo').textContent = a.nombre || a.arete || 'Animal';
document.getElementById('historial-subtitulo').textContent = `SINIIGA ${a.arete || '—'} · ${a.sexo || ''} · ${a.estatus || ''}`;
const miniFoto = document.getElementById('historial-foto-mini');
if (a.foto){ miniFoto.src = a.foto; miniFoto.classList.remove('hidden'); }
else { miniFoto.classList.add('hidden'); miniFoto.src = ''; }
const cuerpo = document.getElementById('historial-cuerpo');
if (eventos.length === 0){
cuerpo.innerHTML = `<div class="vacio"><i class="fa-solid fa-clock-rotate-left"></i><p>${tr('historial_bitacora_animal__aun_no_hay_eventos_registrados')}</p></div>`;
} else {
cuerpo.innerHTML = eventos.map(e => `
<div class="flex gap-3">
<span class="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0" style="background:${e.color}; color:#fff;"><i class="fa-solid ${e.icono} text-xs"></i></span>
<div class="pb-1">
<p class="text-xs font-mono font-bold" style="color:var(--sage);">${e.fecha || 'Sin fecha'}</p>
<p class="text-sm font-semibold">${e.texto}</p>
</div>
</div>`).join('');
}
modal.classList.remove('hidden');
renderChartHistorialPeso(a, coincide);
renderChartHistorialLactancia(a, coincide);
renderGastosRendimiento(a, coincide);
}
// ================= ÁRBOL GENEALÓGICO =================
// Se arma con lo que YA existe en cada ficha (campos madre/padre, texto
// libre) — busca en el hato un animal cuyo arete o nombre coincida con lo
// escrito ahí, y repite lo mismo con los abuelos. No inventa parentescos: si
// un ancestro no está dado de alta en el hato, se muestra en gris con "Sin
// datos" en vez de dejarlo vacío sin explicación.
function buscarAncestroPorIdentificador(identificador){
if (!identificador) return null;
const id = String(identificador).trim();
if (!id) return null;
return estado.animales.find(a => a.arete === id || a.nombre === id) || null;
}
function nodoArbolGenealogico(animalOIdentificador, generacionesRestantes){
const animal = (typeof animalOIdentificador === 'string') ? buscarAncestroPorIdentificador(animalOIdentificador) : animalOIdentificador;
if (!animal){
return animalOIdentificador ? { nombre: animalOIdentificador, encontrado: false } : null;
}
const nodo = { nombre: animal.nombre || animal.arete || 'Sin nombre', arete: animal.arete || '', sexo: animal.sexo, encontrado: true, madre: null, padre: null };
if (generacionesRestantes > 0){
if (animal.madre) nodo.madre = nodoArbolGenealogico(animal.madre, generacionesRestantes - 1);
if (animal.padre) nodo.padre = nodoArbolGenealogico(animal.padre, generacionesRestantes - 1);
}
return nodo;
}
function tarjetaNodoArbol(nodo, esPadreMadre){
if (!nodo) return `<div class="arbol-nodo arbol-nodo-vacio"><span>Sin datos</span></div>`;
if (!nodo.encontrado) return `<div class="arbol-nodo arbol-nodo-vacio"><span>${nodo.nombre}</span><small>No está en el hato</small></div>`;
const badge = nodo.sexo === 'macho'
? `<span class="arbol-badge-sexo arbol-badge-macho">♂ Semental</span>`
: `<span class="arbol-badge-sexo arbol-badge-hembra">♀ Hembra</span>`;
const clasePM = esPadreMadre ? ' arbol-nodo-padres' : '';
return `<div class="arbol-nodo${clasePM}"><span class="font-bold">${nodo.nombre}</span>${nodo.arete ? `<small>${nodo.arete}</small>` : ''}${badge}</div>`;
}
function renderArbolGenealogico(nodo){
const cont = document.getElementById('arbol-genealogico-cuerpo');
if (!cont) return;
const abuelaM = nodo.madre ? nodo.madre.madre : null;
const abueloM = nodo.madre ? nodo.madre.padre : null;
const abuelaP = nodo.padre ? nodo.padre.madre : null;
const abueloP = nodo.padre ? nodo.padre.padre : null;
// Mismo orden que en el prototipo de referencia: abuelos arriba, después
// padre/madre, y hasta abajo el "Animal Central" en tarjeta oscura — como
// una raíz de árbol que crece hacia la persona que se está revisando.
cont.innerHTML = `<div style="min-width:480px; padding:4px;">
<div style="display:grid; grid-template-columns:1fr 1fr 1fr 1fr; gap:6px; margin-bottom:8px;">
${tarjetaNodoArbol(abueloP)}${tarjetaNodoArbol(abuelaP)}${tarjetaNodoArbol(abueloM)}${tarjetaNodoArbol(abuelaM)}
</div>
<div style="height:18px; display:flex; justify-content:center;"><div style="width:2px; background:var(--bg-cafe);"></div></div>
<div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:10px;">
<div style="display:flex; justify-content:center;">${tarjetaNodoArbol(nodo.padre, true)}</div>
<div style="display:flex; justify-content:center;">${tarjetaNodoArbol(nodo.madre, true)}</div>
</div>
<div style="height:18px; display:flex; justify-content:center;"><div style="width:2px; background:var(--bg-cafe);"></div></div>
<div class="arbol-nodo arbol-nodo-central" style="text-align:left;">
<span style="font-size:9px; text-transform:uppercase; letter-spacing:.05em; color:var(--bg-borde);">Animal Central</span>
<span class="font-bold" style="font-size:15px;">${nodo.nombre}</span>
${nodo.arete ? `<small style="color:var(--bg-borde);">${nodo.arete}</small>` : ''}
</div>
</div>`;
}
function abrirArbolGenealogico(indice){
const animal = estado.animales[indice];
if (!animal){ mostrarToast('No se encontró el animal'); return; }
renderArbolGenealogico(nodoArbolGenealogico(animal, 2));
document.getElementById('modal-arbol-genealogico').classList.remove('hidden');
}
function cerrarArbolGenealogico(){
document.getElementById('modal-arbol-genealogico').classList.add('hidden');
}
function calcularGDP(pesajesAnimal){
if (pesajesAnimal.length < 2) return null;
const ordenados = [...pesajesAnimal].filter(p => p.fecha && p.peso).sort((x,y) => new Date(x.fecha) - new Date(y.fecha));
if (ordenados.length < 2) return null;
const primero = ordenados[0], ultimo = ordenados[ordenados.length - 1];
const dias = Math.max(1, Math.round((new Date(ultimo.fecha) - new Date(primero.fecha)) / 86400000));
const gdpPromedio = (ultimo.peso - primero.peso) / dias;
const penultimo = ordenados[ordenados.length - 2];
const diasUltimoTramo = Math.max(1, Math.round((new Date(ultimo.fecha) - new Date(penultimo.fecha)) / 86400000));
const gdpUltimo = (ultimo.peso - penultimo.peso) / diasUltimoTramo;
return { gdpPromedio, gdpUltimo, gananciaTotal: ultimo.peso - primero.peso, dias };
}
let claveMovimientoActual = null;
function agregarMovimientoAnimal(){
if (!claveMovimientoActual) return;
const tipo = valor('mov-tipo');
const concepto = valor('mov-concepto').trim();
const monto = Number(valor('mov-monto')) || 0;
const fecha = valor('mov-fecha');
if (!concepto || monto <= 0){ mostrarToast(tr('gastos_rendimiento_animal__escribe_el_concepto_y_un')); return; }
estado.movimientosAnimal.push({ animal: claveMovimientoActual, tipo, concepto, monto, fecha: fecha || hoyISO() });
limpiarCampos(['mov-concepto','mov-monto','mov-fecha']);
const a = estado.animales[animalHistorialActual];
const coincide = (valor) => valor && (valor === a.arete || valor === a.nombre || valor === a.chip);
renderGastosRendimiento(a, coincide);
mostrarToast(tr('gastos_rendimiento_animal__movimiento_registrado'));
}
function renderGastosRendimiento(a, coincide){
claveMovimientoActual = a.arete || a.nombre || a.chip;
const movimientos = estado.movimientosAnimal.filter(m => coincide(m.animal)).sort((x,y) => (y.fecha||'').localeCompare(x.fecha||''));
const gastos = movimientos.filter(m => m.tipo === 'gasto').reduce((s,m) => s + m.monto, 0);
const ingresos = movimientos.filter(m => m.tipo === 'ingreso').reduce((s,m) => s + m.monto, 0);
const resumen = document.getElementById('historial-rendimiento-resumen');
if (resumen){
resumen.innerHTML = `
<div><p class="text-xs" style="color:var(--sage);">${tr('gastos_rendimiento_animal__gastos')}</p><p class="font-bold" style="color:var(--red);">$${gastos.toFixed(0)}</p></div>
<div><p class="text-xs" style="color:var(--sage);">${tr('gastos_rendimiento_animal__ingresos')}</p><p class="font-bold" style="color:var(--green);">$${ingresos.toFixed(0)}</p></div>
<div><p class="text-xs" style="color:var(--sage);">${tr('gastos_rendimiento_animal__neto')}</p><p class="font-bold" style="color:${ingresos-gastos>=0?'var(--green)':'var(--red)'};">$${(ingresos-gastos).toFixed(0)}</p></div>`;
}
const lista = document.getElementById('historial-movimientos');
if (lista){
lista.innerHTML = movimientos.length === 0
? `<p class="text-xs text-center py-1" style="color:var(--sage);">${tr('gastos_rendimiento_animal__sin_movimientos_registrados')}</p>`
: movimientos.map(m => `
<div class="flex items-center justify-between text-sm py-1" style="border-top:1px solid var(--line);">
<span>${m.concepto} <span class="text-xs" style="color:var(--sage);">· ${m.fecha||''}</span></span>
<span class="font-bold" style="color:${m.tipo==='gasto'?'var(--red)':'var(--green)'};">${m.tipo==='gasto'?'-':'+'}$${m.monto.toFixed(0)}</span>
</div>`).join('');
}
}
let chartHistorialPeso = null;
let chartHistorialLactancia = null;
async function renderChartHistorialPeso(a, coincide){
await cargarChartJsSiNecesario();
const caja = document.getElementById('historial-peso-box');
const gdpBox = document.getElementById('historial-gdp-box');
const pesajesAnimal = estado.pesajes.filter(r => coincide(r.animal)).sort((x,y) => new Date(x.fecha||0) - new Date(y.fecha||0));
if (chartHistorialPeso){ chartHistorialPeso.destroy(); chartHistorialPeso = null; }
if (pesajesAnimal.length < 2){
caja.classList.add('hidden');
if (gdpBox) gdpBox.classList.add('hidden');
return;
}
caja.classList.remove('hidden');
const ctx = document.getElementById('chart-historial-peso').getContext('2d');
chartHistorialPeso = new Chart(ctx, {
type: 'line',
data: {
labels: pesajesAnimal.map(p => p.fecha),
datasets: [{ label:'Peso (kg)', data: pesajesAnimal.map(p => p.peso), borderColor:'#3C6B4F', backgroundColor:'rgba(60,107,79,0.15)', tension:.3, fill:true, pointRadius:4 }],
},
options: { responsive:true, maintainAspectRatio:false, plugins:{ legend:{ display:false } }, scales:{ y:{ beginAtZero:false } } },
});
const gdp = calcularGDP(pesajesAnimal);
if (gdp && gdpBox){
gdpBox.classList.remove('hidden');
gdpBox.innerHTML = `<i class="fa-solid fa-arrow-trend-up mr-1" style="color:var(--green);"></i><strong>${tr('gastos_rendimiento_animal__gdp_promedio_kg_dia').replace('%VAR%', gdp.gdpPromedio.toFixed(2))}</strong> ${tr('gastos_rendimiento_animal__ultimo_tramo_kg_dia_ganancia').replace('%VAR%', gdp.gdpUltimo.toFixed(2)).replace('%VAR%', gdp.gananciaTotal.toFixed(1)).replace('%VAR%', gdp.dias)}`;
}
}
// Curva de lactancia — usa los mismos registros del control lechero diario
// (Módulo G, litros AM+PM) que ya se capturan por animal; aquí solo se
// grafican en línea de tiempo para ver de un vistazo cómo va subiendo o
// bajando la producción de esta vaca a lo largo de su lactancia.
async function renderChartHistorialLactancia(a, coincide){
await cargarChartJsSiNecesario();
const caja = document.getElementById('historial-lactancia-box');
const resumenBox = document.getElementById('historial-lactancia-resumen');
if (!caja) return;
const registrosLeche = estado.produccionLeche.filter(r => coincide(r.animal)).sort((x,y) => new Date(x.fecha||0) - new Date(y.fecha||0));
if (chartHistorialLactancia){ chartHistorialLactancia.destroy(); chartHistorialLactancia = null; }
if (registrosLeche.length < 2){
caja.classList.add('hidden');
if (resumenBox) resumenBox.classList.add('hidden');
return;
}
caja.classList.remove('hidden');
const ctx = document.getElementById('chart-historial-lactancia').getContext('2d');
chartHistorialLactancia = new Chart(ctx, {
type: 'line',
data: {
labels: registrosLeche.map(r => r.fecha),
datasets: [{ label:'Litros/día', data: registrosLeche.map(r => Number(r.total) || 0), borderColor:'#4A7C59', backgroundColor:'rgba(74,124,89,0.15)', borderWidth:3, tension:.3, fill:true, pointRadius:0 }],
},
options: { responsive:true, maintainAspectRatio:false, plugins:{ legend:{ display:false } }, scales:{ x:{ ticks:{ font:{ weight:'bold', size:10 } }, grid:{ display:false } }, y:{ beginAtZero:true, ticks:{ font:{ weight:'bold', size:10 } }, grid:{ display:false } } } },
});
if (resumenBox){
const litros = registrosLeche.map(r => Number(r.total) || 0);
const promedio = litros.reduce((s,v) => s+v, 0) / litros.length;
const pico = Math.max(...litros);
const diaPico = registrosLeche[litros.indexOf(pico)]?.fecha || '';
const diasLactancia = Math.round((new Date(registrosLeche[registrosLeche.length-1].fecha) - new Date(registrosLeche[0].fecha)) / 86400000);
resumenBox.classList.remove('hidden');
resumenBox.innerHTML = `<div class="grid grid-cols-3 gap-2">
<div style="background:#fff; border:1px solid var(--bg-borde); border-radius:12px; padding:8px; text-align:center;">
<p style="font-size:18px; font-weight:800; margin:0; line-height:1;">${promedio.toFixed(1)}L</p>
<p style="font-size:9px; font-weight:bold; text-transform:uppercase; color:var(--bg-cafe); margin:2px 0 0;">Promedio</p>
</div>
<div style="background:var(--bg-oscuro); color:#fff; border-radius:12px; padding:8px; text-align:center;">
<p style="font-size:18px; font-weight:800; margin:0; line-height:1;">${pico.toFixed(1)}L</p>
<p style="font-size:9px; font-weight:bold; text-transform:uppercase; color:var(--bg-borde); margin:2px 0 0;">Pico ${diaPico}</p>
</div>
<div style="background:#fff; border:1px solid var(--bg-borde); border-radius:12px; padding:8px; text-align:center;">
<p style="font-size:18px; font-weight:800; margin:0; line-height:1;">${diasLactancia}</p>
<p style="font-size:9px; font-weight:bold; text-transform:uppercase; color:var(--bg-cafe); margin:2px 0 0;">Días reg.</p>
</div>
</div>`;
}
}
function cerrarHistorial(){ document.getElementById('modal-historial').classList.add('hidden'); }
function abrirLightboxAnimal(){
const src = document.getElementById('historial-foto-mini').src;
if (!src) return;
document.getElementById('lightbox-foto-grande').src = src;
document.getElementById('lightbox-animal').classList.remove('hidden');
}
function cerrarLightboxAnimal(){
document.getElementById('lightbox-animal').classList.add('hidden');
document.getElementById('lightbox-foto-grande').src = '';
}
function imprimirFichaAnimal(){
const a = estado.animales[animalHistorialActual];
if (!a) return;
const p = estado.productor;
const coincide = (valor) => valor && (valor === a.arete || valor === a.nombre || valor === a.chip);
const saludAnimal = estado.salud.filter(r => coincide(r.animal));
const pesajesAnimal = estado.pesajes.filter(r => coincide(r.animal));
const ventana = window.open('', '_blank');
ventana.document.write(`
<html><head><title>${tr('gastos_rendimiento_animal__ficha')}${a.nombre || a.arete}</title>
<style>
body{ font-family: Arial, sans-serif; padding:24px; color:#222; }
h1{ font-size:20px; margin-bottom:2px; } h2{ font-size:15px; margin:18px 0 8px; border-bottom:2px solid #3C6B4F; padding-bottom:4px;}
table{ width:100%; border-collapse:collapse; margin-bottom:10px; }
td,th{ border:1px solid #ccc; padding:6px 8px; font-size:13px; text-align:left; }
.foto{ max-width:140px; border-radius:8px; float:right; }
.meta{ font-size:12px; color:#666; }
</style></head><body>
${a.foto ? `<img loading="lazy" decoding="async" class="foto" src="${a.foto}">` : ''}
<h1>${tr('gastos_rendimiento_animal__ficha_del_animal')}${a.nombre || '(sin nombre)'}</h1>
<p class="meta">${tr('gastos_rendimiento_animal__predio_upp_municipio')}: ${p.predio || '—'} · ${p.upp || '—'} · ${p.municipio || '—'}</p>
<h2>${tr('gastos_rendimiento_animal__datos_de_identificacion')}</h2>
<table>
<tr><th>${tr('gastos_rendimiento_animal__arete_siniiga')}</th><td>${a.arete || '—'}</td><th>${tr('gastos_rendimiento_animal__arete_chip_campana')}</th><td>${a.chip || '—'}</td></tr>
<tr><th>${tr('gastos_rendimiento_animal__raza')}</th><td>${a.raza || '—'}</td><th>${tr('gastos_rendimiento_animal__sexo')}</th><td>${a.sexo || '—'}</td></tr>
<tr><th>${tr('gastos_rendimiento_animal__fecha_de_nacimiento')}</th><td>${a.fecha || '—'}</td><th>${tr('gastos_rendimiento_animal__estatus')}</th><td>${a.estatus || '—'}</td></tr>
<tr><th>${tr('gastos_rendimiento_animal__madre')}</th><td>${a.madre || '—'}</td><th>${tr('gastos_rendimiento_animal__padre')}</th><td>${a.padre || '—'}</td></tr>
<tr><th>${tr('csv_extra__potrero')}</th><td colspan="3">${a.potrero || '—'}</td></tr>
</table>
<h2>${tr('gastos_rendimiento_animal__historial_de_salud')}</h2>
<table><tr><th>${tr('gastos_rendimiento_animal__fecha')}</th><th>${tr('gastos_rendimiento_animal__tipo')}</th><th>${tr('gastos_rendimiento_animal__producto_diagnostico')}</th><th>${tr('gastos_rendimiento_animal__proxima')}</th></tr>
${saludAnimal.length ? saludAnimal.map(r => `<tr><td>${r.fecha||''}</td><td>${r.tipo||''}</td><td>${r.producto||''}</td><td>${r.proxima||''}</td></tr>`).join('') : `<tr><td colspan="4">${tr('csv_extra5__sin_registros')}</td></tr>`}
</table>
<h2>${tr('gastos_rendimiento_animal__historial_de_pesajes')}</h2>
<table><tr><th>${tr('gastos_rendimiento_animal__fecha')}</th><th>${tr('gastos_rendimiento_animal__peso_kg')}</th><th>${tr('csv_extra2__lote')}</th></tr>
${pesajesAnimal.length ? pesajesAnimal.map(r => `<tr><td>${r.fecha||''}</td><td>${r.peso||''}</td><td>${r.lote||''}</td></tr>`).join('') : `<tr><td colspan="3">${tr('csv_extra5__sin_registros')}</td></tr>`}
</table>
<p class="meta">${tr('gastos_rendimiento_animal__ficha_generada_el')}${new Date().toLocaleDateString('es-MX')}</p>
</body></html>`);
ventana.document.close();
ventana.focus();
setTimeout(() => ventana.print(), 300);
}
function mostrarLetra(letra, btn){
letraActual = letra;
subtabActual = 'registrar';
document.querySelectorAll('.tab-letra').forEach(t => { t.classList.remove('active'); t.style.background = '#fff'; });
if (btn){ btn.classList.add('active'); btn.style.background = btn.dataset.color; }
renderModulo();
}
function cambiarSubtab(sub){
subtabActual = sub;
renderModulo();
}
function renderModulo(){
const info = MODULOS[letraActual];
const cont = document.getElementById('modulo-contenido');
const subtabsHtml = letraActual === 'A'
? `<div class="mb-4">
<button onclick="irA('hato')" class="text-sm font-bold flex items-center gap-1" style="color:${info.color};">
<i class="fa-solid fa-list-ul"></i><span>${tr('render_modulos_f__ver_estatus_del_hato')}</span><i class="fa-solid fa-arrow-right text-xs"></i>
</button>
</div>`
: `<div class="flex items-center justify-between gap-2 mb-4">
<div class="flex gap-2">
<button class="subtab ${subtabActual==='registrar'?'active':''}" onclick="cambiarSubtab('registrar')">${tr('modal_historial_bitacora__registrar')}</button>
<button class="subtab ${subtabActual==='ver'?'active':''}" onclick="cambiarSubtab('ver')">${tr('render_modulos_f__ver_registros')}</button>
</div>
${subtabActual === 'ver' ? `<button onclick="abrirMenuExportar('modulo')" class="text-xs font-bold px-3 py-2 rounded-full flex-shrink-0" style="background:var(--parchment); color:var(--pine); border:2px solid var(--line);"><i class="fa-solid fa-file-arrow-down"></i></button>` : ''}
${letraActual === 'C' && subtabActual === 'ver' ? `<button onclick="abrirCalendarioReproductivo()" class="text-xs font-bold px-3 py-2 rounded-full flex-shrink-0" style="background:var(--parchment); color:var(--pine); border:2px solid var(--line);"><i class="fa-solid fa-calendar-days"></i></button>` : ''}
</div>`;
const encabezado = `
<div class="bg-white rounded-3xl p-5 mt-4" style="border:2px solid var(--line); border-top:6px solid ${info.color};">
<p class="font-display font-bold text-lg mb-3">${info.nombre}</p>
${subtabsHtml}
<div id="modulo-cuerpo"></div>
</div>
${letraActual === 'I' ? `
<div class="bg-white rounded-3xl p-5 mt-4" style="border:2px solid var(--line);">
<p class="font-display font-bold mb-3">${tr('campo_f__inventario_de_alimento')}</p>
<div class="grid grid-cols-2 gap-3 mb-2">
<input id="inv-producto" type="text" placeholder="${tr('campo_f__producto_ej_concentrado')}">
<input id="inv-kg" type="number" placeholder="${tr('campo_f__kg_disponibles')}">
</div>
<button onclick="actualizarInventarioAlimento()" class="w-full btn-primario-plano" style="background:${info.color};">
<i class="fa-solid fa-boxes-stacked"></i><span>${tr('campo_f__actualizar_existencia')}</span>
</button>
<div id="lista-inventario-alimento" class="space-y-2 pt-3"></div>
</div>` : ''}`;
cont.innerHTML = encabezado;
if (letraActual === 'I') renderInventarioAlimento();
if (letraActual === 'A' || subtabActual === 'registrar') renderFormularioModulo(letraActual);
else renderListaModulo(letraActual);
}
function campo(id, label, tipo, opciones, onchange){
const atrOnchange = onchange ? ` onchange="${onchange}"` : '';
if (tipo === 'select'){
return `<div><label class="campo-label">${label}</label><select id="${id}"${atrOnchange}>${opciones.map(o=>`<option value="${o}">${o}</option>`).join('')}</select></div>`;
}
return `<div><label class="campo-label">${label}</label><input id="${id}" type="${tipo}"${atrOnchange}></div>`;
}
function campoArete(id, label){
return `<div>
<label class="campo-label">${label}</label>
<div class="flex gap-2">
<input id="${id}" type="text" placeholder="${tr('render_modulos_f__escanea_o_escribe')}">
<button type="button" onclick="abrirEscanerCamara('${id}')" class="w-12 flex-shrink-0 rounded-2xl flex items-center justify-center" style="background:var(--pine); color:#fff;">
<i class="fa-solid fa-camera"></i>
</button>
<button type="button" onclick="activarEscaneoArete('${id}')" class="w-12 flex-shrink-0 rounded-2xl flex items-center justify-center" style="background:var(--slate); color:#fff;">
<i class="fa-solid fa-barcode"></i>
</button>
</div>
<p class="text-xs mt-1" style="color:var(--sage);">${tr('render_modulos_f__camara_del_celular_o_lector')}</p>
</div>`;
}
// ================= BORRADOR LOCAL DEL FORMULARIO "REGISTRO DE GANADO" (módulo A) =================
// Guarda lo que se va escribiendo en el formulario de alta de un animal nuevo en
// localStorage, y lo restaura si la app se cierra o se pierde la conexión antes de
// terminar de guardar el registro — para que no se pierda el trabajo ya hecho.
// No incluye la foto (f-foto) porque un <input type="file"> no se puede restaurar
// por seguridad del navegador.
const CAMPOS_BORRADOR_REGISTRO_GANADO = ['f-arete','f-chip','f-nombre','f-raza','f-sexo','f-fecha','f-estatus','f-proposito','f-engorda-dias','f-engorda-peso-meta','f-madre','f-padre','f-potrero','f-motivobaja'];
const CLAVE_BORRADOR_REGISTRO_GANADO = 'miRanchAppBorradorRegistroGanado';
function guardarBorradorRegistroGanado(){
if (letraActual !== 'A' || subtabActual !== 'registrar') return;
const datos = {};
let tieneAlgo = false;
CAMPOS_BORRADOR_REGISTRO_GANADO.forEach(id => {
const el = document.getElementById(id);
if (el && el.value){ datos[id] = el.value; tieneAlgo = true; }
});
try {
if (tieneAlgo) localStorage.setItem(CLAVE_BORRADOR_REGISTRO_GANADO, JSON.stringify(datos));
else localStorage.removeItem(CLAVE_BORRADOR_REGISTRO_GANADO);
} catch(e){}
}
function restaurarBorradorRegistroGanado(){
let datos = null;
try { datos = JSON.parse(localStorage.getItem(CLAVE_BORRADOR_REGISTRO_GANADO) || 'null'); } catch(e){ datos = null; }
if (!datos) return;
let tieneAlgo = false;
CAMPOS_BORRADOR_REGISTRO_GANADO.forEach(id => {
const el = document.getElementById(id);
if (el && datos[id]){ el.value = datos[id]; tieneAlgo = true; }
});
if (tieneAlgo){
if (typeof toggleCamposEngorda === 'function') toggleCamposEngorda();
if (typeof toggleCamposBaja === 'function') toggleCamposBaja();
mostrarToast('Se restauraron los datos que habías empezado a llenar');
}
}
function limpiarBorradorRegistroGanado(){
try { localStorage.removeItem(CLAVE_BORRADOR_REGISTRO_GANADO); } catch(e){}
}
// Un solo listener delegado (nunca se duplica aunque el formulario se re-renderice
// muchas veces al cambiar de pestaña) que guarda el borrador con cada tecleo o
// selección en cualquiera de los campos del formulario de registro de ganado.
document.addEventListener('input', e => { if (e.target && CAMPOS_BORRADOR_REGISTRO_GANADO.includes(e.target.id)) guardarBorradorRegistroGanado(); });
document.addEventListener('change', e => { if (e.target && CAMPOS_BORRADOR_REGISTRO_GANADO.includes(e.target.id)) guardarBorradorRegistroGanado(); });
function renderFormularioModulo(letra){
const cuerpo = document.getElementById('modulo-cuerpo');
let camposHtml = '', accion = '', colorBtn = MODULOS[letra].color;
if (letra === 'A'){
camposHtml = `
<div class="grid grid-cols-2 gap-2">
${campoArete('f-arete', tr('campo_f__arete_siniiga'))}
${campo('f-chip', tr('campo_f__arete_campana_chip'),'text')}
</div>
${campo('f-nombre', tr('campo_f__nombre_o_alias'),'text')}
<div class="grid grid-cols-2 gap-2">
${campo('f-raza', tr('campo_f__raza'),'text')}
${campo('f-sexo', tr('campo_f__sexo'),'select',['hembra','macho'])}
</div>
<div class="grid grid-cols-2 gap-2">
${campo('f-fecha', tr('campo_f__fecha_de_nacimiento'),'date')}
<div>
<label class="campo-label">${tr('campo_f__estatus')}</label>
<select id="f-estatus" onchange="toggleCamposBaja()">
${['activo','engorda','gestante','lactando','vaquilla','semental','vendido','finado'].map(o=>`<option value="${o}">${o}</option>`).join('')}
</select>
</div>
</div>
<div>
<label class="campo-label">${tr('render_modulos_f__proposito_del_animal')}</label>
<select id="f-proposito" onchange="toggleCamposEngorda()">
<option value="reemplazo">${tr('render_modulos_f__reemplazo')}</option>
<option value="engorda">${tr('render_modulos_f__engorda_venta')}</option>
</select>
</div>
<div id="campos-engorda" class="hidden grid grid-cols-2 gap-2">
<div><label class="campo-label">${tr('render_modulos_f__dias_objetivo_de_engorda')}</label><input id="f-engorda-dias" type="number" placeholder="${tr('render_modulos_f__ej_120')}"></div>
<div><label class="campo-label">${tr('render_modulos_f__peso_meta_kg_opcional')}</label><input id="f-engorda-peso-meta" type="number"></div>
</div>
<p id="nota-engorda" class="hidden text-xs -mt-2" style="color:var(--sage);"><i class="fa-solid fa-stopwatch mr-1"></i>${tr('render_modulos_f__los_dias_correran_de_forma')}</p>
<div class="grid grid-cols-2 gap-2">
${campo('f-madre', tr('campo_f__madre_arete_nombre'),'text')}
${campo('f-padre', tr('campo_f__padre_pajuela'),'text')}
</div>
<div>
<label class="campo-label">${tr('campo_f__potrero')}</label>
<select id="f-potrero">
<option value="">${tr('render_modulos_f__sin_asignar')}</option>
${estado.potreros.map(p => `<option value="${p.nombre}">${p.nombre}</option>`).join('')}
</select>
</div>
<div id="grupo-motivobaja" class="hidden">
<label class="campo-label">${tr('render_modulos_f__motivo_de_baja_solo_si')}</label>
<input id="f-motivobaja" type="text" placeholder="${tr('render_modulos_f__ej_venta_enfermedad_robo')}">
</div>
<div>
<label class="campo-label">${tr('render_modulos_f__foto_del_animal')}</label>
<input id="f-foto" type="file" accept="image/*" capture="environment">
<p class="text-xs mt-1" style="color:var(--sage);">${tr('render_modulos_f__puedes_tomar_la_foto_directo')}</p>
</div>`;
accion = 'guardarAnimal()';
} else if (letra === 'B'){
camposHtml = `
<div class="flex items-center gap-2 bg-white rounded-2xl p-3 mb-1" style="border:2px solid var(--line);">
<input type="checkbox" id="f-modo-lote" onchange="toggleModoLoteSalud()" style="width:20px; height:20px;">
<label for="f-modo-lote" class="text-sm font-bold">${tr('render_modulos_f__aplicar_a_todo_un_lote')}</label>
</div>
<div id="f-animal-individual">${campoArete('f-animal', tr('campo_f__animal_arete_o_nombre'))}</div>
<div id="f-animal-lote" class="hidden">
<label class="campo-label">${tr('render_modulos_f__potrero_lote')}</label>
<select id="f-potrero-lote">
<option value="">${tr('render_modulos_f__selecciona_un_potrero')}</option>
${estado.potreros.map(p => `<option value="${p.nombre}">${p.nombre} (${estado.animales.filter(a => a.potrero === p.nombre).length} animales)</option>`).join('')}
</select>
<p class="text-xs mt-1" style="color:var(--sage);">${tr('render_modulos_f__se_creara_un_registro_para')}</p>
</div>
<div class="grid grid-cols-2 gap-2">
${campo('f-tipo', tr('campo_f__tipo'),'select',['vacuna','vacuna_brucelosis_obligatoria','vacuna_tuberculosis_obligatoria','desparasitacion','tratamiento','diagnostico','revision','enfermedad','muerte_subita','sospecha_exotica','mastitis_clinica','mastitis_subclinica','diarrea_becerro','problema_respiratorio_becerro','onfalitis_ombligo'])}
${campo('f-producto', tr('campo_f__producto_diagnostico'),'text')}
</div>
<div class="grid grid-cols-2 gap-2">
${campo('f-fecha', tr('campo_f__fecha_de_aplicacion'),'date')}
${campo('f-proxima', tr('campo_f__proxima_dosis'),'date')}
</div>
${estado.tipoGanado === 'leche' ? `
<div class="grid grid-cols-2 gap-2">
${campo('f-cuarto-mastitis', tr('campo_f__cuarto_afectado_mastitis'),'select',['no_aplica','delantero_izq','delantero_der','trasero_izq','trasero_der'])}
${campo('f-cmt', tr('campo_f__resultado_cmt'),'select',['no_aplica','negativo','trazas','+1','+2','+3'])}
</div>
<div>
<label class="campo-label">${tr('campo_f__dias_retiro_leche')}</label>
<input id="f-dias-retiro" type="number" placeholder="Ej. 4">
<p class="text-xs mt-1" style="color:var(--sage);">${tr('campo_f__app_calculara_aviso_tanque')}</p>
</div>` : ''}
<div>
<label class="campo-label">${tr('render_modulos_f__insumo_de_bodega_usado_opcional')}</label>
<div class="grid grid-cols-2 gap-2">
<select id="f-insumo-bodega">
<option value="">${tr('render_modulos_f__sin_descontar_de_bodega')}</option>
${estado.bodega.map(i => `<option value="${i.id}">${i.producto} (${i.cantidad} ${i.unidad})</option>`).join('')}
</select>
<input id="f-insumo-cantidad" type="number" placeholder="${tr('render_modulos_f__cantidad_usada')}">
</div>
<p class="text-xs mt-1" style="color:var(--sage);">${tr('render_modulos_f__si_seleccionas_un_insumo_se')}</p>
</div>
${campo('f-notas', tr('campo_f__notas'),'text')}`;
accion = 'guardarSalud()';
} else if (letra === 'C'){
camposHtml = `
${campoArete('f-vaca', tr('campo_f__vaca_arete_o_nombre'))}
<div class="grid grid-cols-2 gap-2">
${campo('f-servicio', tr('campo_f__tipo_de_servicio'),'select',['monta_directa','inseminacion_artificial'])}
<div><label class="campo-label">${tr('render_modulos_f__fecha_de_servicio_monta')}</label><input id="f-fecha" type="date" onchange="autocalcularParto()"></div>
</div>
<div>
<label class="campo-label">${tr('campo_f__toro_pajuela_utilizada')}</label>
<input id="f-toro" list="lista-sementales-datalist" type="text"/>
<datalist id="lista-sementales-datalist">${estado.sementales.map(s => `<option value="${s.nombre}">${s.dosisDisponibles} dosis disponibles</option>`).join('')}</datalist>
<button class="text-xs font-bold mt-1" onclick="abrirCatalogoSementales()" style="color:var(--pine);" type="button"><i class="fa-solid fa-list"></i> Catálogo de sementales/pajillas</button>
</div>
<div class="grid grid-cols-2 gap-2">
${campo('f-diagnostico', tr('campo_f__diagnostico_de_gestacion'),'select',['sin_diagnostico','confirmada','no_confirmada'])}
<div><label class="campo-label">${tr('render_modulos_f__fecha_probable_de_parto')}</label><input id="f-parto" type="date" onchange="autocalcularSecado()"></div>
</div>
<p class="text-xs -mt-2" style="color:var(--sage);"><i class="fa-solid fa-wand-magic-sparkles mr-1"></i>${tr('render_modulos_f__la_fecha_de_parto_se')}</p>
${campo('f-parto-real', tr('campo_f__fecha_real_de_parto'),'date', null, 'actualizarVisibilidadCria()')}
<div class="hidden rounded-2xl p-3" id="grupo-cria-nacida" style="background:var(--parchment);">
<p class="text-xs font-bold mb-2" style="color:var(--pine);"><i class="fa-solid fa-cow"></i> Si ya nació, registra la cría (opcional)</p>
<p class="text-xs mb-2" style="color:var(--sage);">Si llenas al menos el sexo, la cría se da de alta sola como animal nuevo del hato, ligada a esta madre.</p>
<div class="grid grid-cols-2 gap-2">
${campo('f-cria-arete', 'Arete de la cría (si ya tiene)','text')}
${campo('f-cria-sexo', 'Sexo de la cría','select',['hembra','macho'])}
</div>
<div class="mt-2"><label class="campo-label">Peso al nacer (kg, opcional)</label><input id="f-cria-peso" min="0" step="0.5" type="number"></div>
</div>
${estado.tipoGanado === 'leche' ? `
<div class="grid grid-cols-2 gap-2">
<div><label class="campo-label">${tr('campo_f__fecha_programada_secado')}</label><input id="f-secado" type="date"></div>
</div>
<p class="text-xs -mt-2" style="color:var(--sage);"><i class="fa-solid fa-wand-magic-sparkles mr-1"></i>${tr('campo_f__secado_se_calcula_solo')}</p>
<div class="grid grid-cols-2 gap-2">
<div><label class="campo-label">${tr('campo_f__fecha_cierre_lactancia')}</label><input id="f-cierre-lactancia" type="date" onchange="autocalcularFinSecado()"></div>
<div><label class="campo-label">${tr('campo_f__fin_periodo_seco')}</label><input id="f-fin-periodo-seco" type="date"></div>
</div>
<p class="text-xs -mt-2" style="color:var(--sage);"><i class="fa-solid fa-wand-magic-sparkles mr-1"></i>${tr('campo_f__cuando_dejes_ordenarla')}</p>` : ''}`;
accion = 'guardarReproduccion()';
} else if (letra === 'D'){
camposHtml = `
${campoArete('f-animal', tr('campo_f__animal_arete_o_nombre'))}
<div class="grid grid-cols-2 gap-2">
${campo('f-fecha', tr('campo_f__fecha_de_pesaje'),'date')}
${campo('f-peso', tr('campo_f__peso_kg'),'number')}
</div>
${campo('f-lote', tr('campo_f__lote_potrero'),'select',['destete','engorda','vacas_secas','maternidad','sementales'])}
${campo('f-condicion', tr('campo_f__condicion_corporal_opcional'),'select',['no_evaluada','1','1.5','2','2.5','3','3.5','4','4.5','5'])}`;
accion = 'guardarPesaje()';
} else if (letra === 'E'){
camposHtml = `
${campo('f-nombre', tr('campo_f__nombre_del_potrero'),'text')}
<div class="grid grid-cols-2 gap-2">
${campo('f-capacidad', tr('campo_f__capacidad_animal'),'number')}
<div><label class="campo-label">${tr('render_modulos_f__color_de_etiqueta')}</label><input id="f-color" type="color" value="#3C6B4F"></div>
</div>
<div>
<label class="campo-label"><i class="fa-solid fa-draw-polygon mr-1"></i>${tr('render_modulos_f__trazar_potrero_en_el_mapa')}</label>
<div class="flex gap-2 mb-2">
<input id="mapa-potrero-buscar" type="text" placeholder="${tr('render_modulos_f__buscar_poblacion_camino_lugar')}" class="flex-1" onkeydown="if(event.key==='Enter'){event.preventDefault(); buscarLugarPotrero();}">
<button type="button" onclick="buscarLugarPotrero()" class="w-12 flex-shrink-0 rounded-2xl flex items-center justify-center" style="background:var(--pine); color:#fff;"><i class="fa-solid fa-magnifying-glass"></i></button>
<button type="button" onclick="ubicarmePotrero()" title="${tr('render_modulos_f__usar_mi_ubicacion_actual')}" class="w-12 flex-shrink-0 rounded-2xl flex items-center justify-center" style="background:var(--slate); color:#fff;"><i class="fa-solid fa-location-crosshairs"></i></button>
</div>
<div id="mapa-potrero" style="height:340px; border-radius:1rem; overflow:hidden; border:2px solid var(--line);"></div>
<p class="text-xs mt-1" style="color:var(--sage);">${tr('render_modulos_f__usa_el_icono_de_poligono')}</p>
<button type="button" onclick="activarGoogleMapsPotrero()" id="btn-google-maps-potrero" class="text-xs font-bold mt-2" style="color:var(--pine);"><i class="fa-brands fa-google mr-1"></i>${tr('render_modulos_f__usar_google_maps_mas_detalle')}</button>
</div>
<div id="mapa-potrero-resumen" class="hidden grid grid-cols-2 gap-2 text-sm">
<div><span class="campo-label">${tr('campo_f__hectareas')}</span><p class="font-bold" id="mapa-potrero-hectareas">—</p></div>
<div><span class="campo-label">${tr('render_modulos_f__ubicacion_central')}</span><p class="font-bold" id="mapa-potrero-centro">—</p></div>
</div>`;
accion = 'guardarPotrero()';
} else if (letra === 'F'){
camposHtml = `
<div class="grid grid-cols-2 gap-2">
${campo('f-tipo-mov', tr('campo_f__tipo_de_movimiento'),'select',['gasto','ingreso'])}
${campo('f-monto', tr('campo_f__monto'),'number')}
</div>
<div class="grid grid-cols-2 gap-2">
${campo('f-categoria', tr('campo_f__categoria'),'select',['alimento','medicina','mantenimiento','mano_obra','venta_animal','otro'])}
</div>
<div class="grid grid-cols-2 gap-2">
${campo('f-fecha', tr('campo_f__fecha'),'date')}
${campo('f-imputar', tr('campo_f__imputar_a'),'text')}
</div>
<div>
<label class="campo-label">Cliente / proveedor (opcional)</label>
<input id="f-contacto" list="lista-contactos-datalist" type="text"/>
<datalist id="lista-contactos-datalist">${estado.contactosComerciales.map(c => `<option value="${c.nombre}">${c.tipo === 'cliente' ? 'Cliente' : 'Proveedor'}</option>`).join('')}</datalist>
<button class="text-xs font-bold mt-1" onclick="abrirCatalogoContactos()" style="color:var(--pine);" type="button"><i class="fa-solid fa-address-book"></i> Catálogo de clientes/proveedores</button>
</div>
${campo('f-descripcion', tr('campo_f__descripcion'),'text')}`;
accion = 'guardarCosto()';
} else if (letra === 'G'){
camposHtml = `
${campoArete('f-animal', tr('campo_f__vaca_arete_o_nombre'))}
<div class="grid grid-cols-2 gap-2">
${campo('f-fecha', tr('campo_f__fecha_de_ordena'),'date')}
${campo('f-ordenador', tr('campo_f__quien_ordeno'),'text')}
</div>
<div class="grid grid-cols-2 gap-2">
${campo('f-litros-am', tr('campo_f__litros_ordena_am'),'number')}
${campo('f-litros-pm', tr('campo_f__litros_ordena_pm'),'number')}
</div>
<div class="grid grid-cols-2 gap-2">
${campo('f-grasa', tr('campo_f__grasa_opcional'),'number')}
${campo('f-celulas', tr('campo_f__celulas_somaticas_opcional'),'number')}
</div>
${campo('f-proteina', tr('campo_f__proteina_opcional'),'number')}
${campo('f-notas', tr('campo_f__notas'),'text')}`;
accion = 'guardarLeche()';
} else if (letra === 'H'){
camposHtml = `
<div class="grid grid-cols-2 gap-2">
${campo('f-fecha', tr('campo_f__fecha'),'date')}
${campo('f-litros-acopiados', tr('campo_f__litros_acopiados_tanque'),'number')}
</div>
<div class="grid grid-cols-2 gap-2">
${campo('f-temperatura', tr('campo_f__temperatura_tanque'),'number')}
${campo('f-recolectado', tr('campo_f__ya_paso_recolector'),'select',['si','no'])}
</div>
<div class="grid grid-cols-2 gap-2">
${campo('f-comprador', tr('campo_f__comprador_pasteurizadora'),'text')}
${campo('f-precio-litro', tr('campo_f__precio_pagado_litro'),'number')}
</div>
<div class="grid grid-cols-2 gap-2">
${campo('f-bonos', tr('campo_f__bonos_calidad'),'number')}
${campo('f-descuentos', tr('campo_f__descuentos_calidad'),'number')}
</div>
${campo('f-notas', tr('campo_f__notas'),'text')}`;
accion = 'guardarTanque()';
} else if (letra === 'I'){
camposHtml = `
${campoArete('f-animal', tr('campo_f__vaca_arete_o_nombre_lote'))}
<div class="grid grid-cols-2 gap-2">
${campo('f-fecha', tr('campo_f__fecha'),'date')}
${campo('f-etapa', tr('campo_f__etapa_de_lactancia'),'select',['inicio','pico','media','seca'])}
</div>
<div class="grid grid-cols-2 gap-2">
${campo('f-racion', tr('campo_f__tipo_de_racion'),'text')}
${campo('f-kg-concentrado', tr('campo_f__kg_concentrado_dia'),'number')}
</div>
${campo('f-notas', tr('campo_f__notas'),'text')}`;
accion = 'guardarAlimentacionLeche()';
} else if (letra === 'J'){
camposHtml = `
${campoArete('f-animal', tr('campo_f__becerro_arete_o_nombre'))}
<div class="grid grid-cols-2 gap-2">
${campo('f-fecha', tr('campo_f__fecha_de_nacimiento'),'date')}
${campo('f-peso-nacer', tr('campo_f__peso_al_nacer_kg'),'number')}
</div>
<div class="grid grid-cols-2 gap-2">
${campo('f-litros-calostro', tr('campo_f__litros_calostro_dados'),'number')}
${campo('f-horas-calostro', tr('campo_f__horas_despues_del_parto'),'number')}
</div>
<div class="grid grid-cols-2 gap-2">
${campo('f-alojamiento', tr('campo_f__tipo_de_alojamiento'),'select',['cunero_individual','corral_grupo'])}
${campo('f-alimentacion', tr('campo_f__alimentacion_actual'),'select',['calostro','leche_sustituto','iniciador_solido','pastoreo'])}
</div>
<div class="grid grid-cols-2 gap-2">
${campo('f-fecha-destete', tr('campo_f__fecha_de_destete'),'date')}
${campo('f-peso-destete', tr('campo_f__peso_al_destete_kg'),'number')}
</div>
${campo('f-notas', tr('campo_f__notas'),'text')}`;
accion = 'guardarBecerro()';
} else if (letra === 'K'){
camposHtml = `
<div id="alertas-bodega" class="space-y-2"></div>
${campo('f-producto', tr('campo_f__nombre_del_insumo'),'text')}
<div class="grid grid-cols-2 gap-2">
${campo('f-categoria', tr('campo_f__categoria'),'select',['alimento','sal_mineral','vacuna','medicamento','desparasitante','otro'])}
${campo('f-unidad', tr('campo_f__unidad'),'select',['kg','litro','saco','dosis','pieza'])}
</div>
<div class="grid grid-cols-2 gap-2">
${campo('f-cantidad', tr('campo_f__cantidad_comprada'),'number')}
${campo('f-costo', tr('campo_f__costo_total'),'number')}
</div>
${campo('f-stock-minimo', tr('campo_f__alerta_menos_de'),'number')}`;
accion = 'guardarBodegaItem()';
}
cuerpo.innerHTML = `
<div class="space-y-3">
${camposHtml}
<button onclick="${accion}" class="w-full btn-primario-plano" style="background:${colorBtn};">
<i class="fa-solid fa-check"></i><span>${tr('render_modulos_f__guardar_registro')}</span>
</button>
</div>`;
if (letra === 'K') renderAlertasBodega();
if (letra === 'E') inicializarMapaPotrero();
if (letra === 'A') restaurarBorradorRegistroGanado();
}
function renderListaModulo(letra){
const cuerpo = document.getElementById('modulo-cuerpo');
const mapas = {
A: { arr: estado.animales, render: a => `<p class="font-bold">${a.nombre || a.arete}</p><p class="text-sm" style="color:var(--sage);">${tr('render_modulos_f__siniiga').replace('%VAR%', a.arete || '—').replace('%VAR%', a.sexo).replace('%VAR%', a.estatus).replace('%VAR%', a.potrero ? ' · ' + a.potrero : '')}</p>` },
B: { arr: estado.salud, render: r => `<p class="font-bold">${r.tipo} — ${r.animal}</p><p class="text-sm" style="color:var(--sage);">${r.producto || ''} · ${r.fecha || 'sin fecha'}</p>` },
C: { arr: estado.reproduccion, render: r => `<p class="font-bold">${r.vaca}</p><p class="text-sm" style="color:var(--sage);">${r.servicio} · ${r.fecha || 'sin fecha'} · ${r.diagnostico}</p>` },
D: { arr: estado.pesajes, render: r => `<p class="font-bold">${tr('render_modulos_f__kg').replace('%VAR%', r.animal).replace('%VAR%', r.peso)}</p><p class="text-sm" style="color:var(--sage);">${r.fecha || 'sin fecha'} · ${r.lote}${r.condicionCorporal ? ' · Condición: ' + r.condicionCorporal : ''}</p>` },
E: { arr: estado.potreros, render: r => `<p class="font-bold">${r.nombre}</p><p class="text-sm" style="color:var(--sage);">${tr('render_modulos_f__ha_capacidad_animales').replace('%VAR%', r.hectareas || '—').replace('%VAR%', r.capacidad || '—')}</p>${r.geojson ? `<button onclick="verMapaPotrero('${r.nombre.replace(/'/g, "\\'")}')" class="text-xs font-bold mt-1" style="color:var(--pine);"><i class="fa-solid fa-map mr-1"></i>${tr('render_modulos_f__ver_mapa') || 'Ver mapa'}</button>` : ''}` },
F: { arr: estado.costos, render: r => `<p class="font-bold">${r.tipo === 'ingreso' ? '+' : '-'}$${r.monto} — ${r.categoria}</p><p class="text-sm" style="color:var(--sage);">${r.descripcion || ''} · ${r.fecha || 'sin fecha'}${r.contacto ? ' · ' + r.contacto : ''}</p>${r.contacto ? `<button onclick="generarReciboPDF(${estado.costos.indexOf(r)})" class="text-xs font-bold mt-1" style="color:var(--pine);"><i class="fa-solid fa-file-invoice mr-1"></i>Generar recibo</button>` : ''}` },
G: { arr: estado.produccionLeche, render: r => `<p class="font-bold">${tr('render_modulos_f__l').replace('%VAR%', r.animal).replace('%VAR%', r.total)}</p><p class="text-sm" style="color:var(--sage);">${tr('render_modulos_f__am_l_pm_l').replace('%VAR%', r.litrosAM || 0).replace('%VAR%', r.litrosPM || 0).replace('%VAR%', r.fecha || 'sin fecha').replace('%VAR%', r.ordenador ? ' · Ordeñó: ' + r.ordenador : '')}</p>` },
H: { arr: estado.tanqueLeche, render: r => `<p class="font-bold">${tr('render_modulos_f__l_acopiados').replace('%VAR%', r.litrosAcopiados).replace('%VAR%', r.comprador ? ' — ' + r.comprador : '')}</p><p class="text-sm" style="color:var(--sage);">${r.fecha || 'sin fecha'} · ${r.temperatura ? r.temperatura + '°C · ' : ''}${r.recolectado === 'si' ? 'Recolectado' : 'Pendiente de recoger'}${r.precioLitro ? ' · $' + r.precioLitro + '/L' : ''}</p>` },
I: { arr: estado.alimentacionLeche, render: r => `<p class="font-bold">${r.animal || 'Lote'} — ${r.etapa}</p><p class="text-sm" style="color:var(--sage);">${tr('render_modulos_f__kg_dia').replace('%VAR%', r.racion || '').replace('%VAR%', r.kgConcentrado || 0).replace('%VAR%', r.fecha || 'sin fecha')}</p>` },
J: { arr: estado.becerros, render: r => `<p class="font-bold">${tr('render_modulos_f__kg_al_nacer').replace('%VAR%', r.animal || '(sin nombre)').replace('%VAR%', r.pesoNacer || '—')}</p><p class="text-sm" style="color:var(--sage);">${tr('render_modulos_f__calostro_l').replace('%VAR%', r.fecha || 'sin fecha').replace('%VAR%', r.litrosCalostro || 0).replace('%VAR%', r.horasCalostro ? ' a las ' + r.horasCalostro + 'h' : '').replace('%VAR%', r.horasCalostro && r.horasCalostro > 6 ? ' ⚠️' : '').replace('%VAR%', r.alimentacion || '').replace('%VAR%', r.fechaDestete ? ' · Destetado ' + r.fechaDestete : '')}</p>` },
K: { arr: estado.bodega, render: r => `<p class="font-bold">${r.producto} <span class="text-xs px-2 py-0.5 rounded-full ml-1" style="background:${r.cantidad <= r.stockMinimo ? 'var(--red)' : 'var(--green)'}; color:#fff;">${r.cantidad} ${r.unidad}</span></p><p class="text-sm" style="color:var(--sage);">${tr('render_modulos_f__costo_total_actualizado').replace('%VAR%', r.categoria).replace('%VAR%', r.costo).replace('%VAR%', r.fecha || 'sin fecha')}</p>` },
};
const { arr, render } = mapas[letra];
if (arr.length === 0){
cuerpo.innerHTML = `<div class="vacio"><i class="fa-solid fa-inbox"></i><p>${tr('render_modulos_f__aun_no_hay_registros_en')}</p></div>`;
return;
}
cuerpo.innerHTML = `<div class="space-y-2">` + arr.map(r => `<div class="item-registro">${render(r)}</div>`).join('') + `</div>`;
}
function valor(id){
const el = document.getElementById(id);
if (!el){
console.warn(`Campo "${id}" no encontrado en la pantalla actual — devolviendo vacío en vez de fallar.`);
return '';
}
return el.value;
}
// ============================================================
// ===== VALIDACIÓN GENÉRICA: campos faltantes en rojo =====
// ============================================================
// Antes, la mayoría de los formularios (salud, reproducción, pesajes, costos,
// leche, tanque, alimentación, becerros) guardaban lo que hubiera en pantalla
// sin revisar si algo faltaba — se podían guardar registros vacíos o a medias
// sin ningún aviso. Esto se usa igual en cualquier formulario: se le pasa la
// lista de campos obligatorios, y si falta alguno, lo marca en rojo, muestra
// un mensaje debajo de cada uno, sube la pantalla hasta el primero que falte,
// y avisa con un mensaje — sin guardar nada hasta que se corrija.
function marcarCamposFaltantes(camposRequeridos){
let primerCampoFaltanteId = null;
camposRequeridos.forEach(({id, etiqueta}) => {
const el = document.getElementById(id);
if (!el) return;
quitarErrorCampo(id);
const val = (el.value || '').toString().trim();
if (!val){
marcarErrorCampo(id, etiqueta);
if (!primerCampoFaltanteId) primerCampoFaltanteId = id;
}
});
if (primerCampoFaltanteId){
const el = document.getElementById(primerCampoFaltanteId);
if (el) el.scrollIntoView({ behavior:'smooth', block:'center' });
mostrarToast('Faltan datos por llenar — revisa los campos marcados en rojo');
return false;
}
return true;
}
function marcarErrorCampo(id, etiqueta){
const el = document.getElementById(id);
if (!el) return;
el.classList.add('campo-con-error');
let msg = document.getElementById('error-' + id);
if (!msg){
msg = document.createElement('p');
msg.id = 'error-' + id;
msg.className = 'text-xs font-bold mt-1';
msg.style.color = 'var(--red)';
el.insertAdjacentElement('afterend', msg);
}
msg.textContent = (etiqueta || 'Este campo') + ' es obligatorio';
}
function quitarErrorCampo(id){
const el = document.getElementById(id);
if (el) el.classList.remove('campo-con-error');
const msg = document.getElementById('error-' + id);
if (msg) msg.remove();
}
// Fuerza mayúsculas mientras se escribe (indistintamente del idioma/teclado usado),
// conservando la posición del cursor para no interrumpir al usuario mientras teclea.
function forzarMayusculas(el){
if (!el) return;
const inicio = el.selectionStart, fin = el.selectionEnd;
const nuevo = (el.value || '').toUpperCase();
if (el.value !== nuevo){
el.value = nuevo;
try { el.setSelectionRange(inicio, fin); } catch(e){}
}
if (el.dataset && el.dataset.marcarLleno) marcarCampoLleno(el);
}
// ================= UTILIDADES DE IMAGEN: COMPRESIÓN Y SUBIDA A STORAGE =================
// Reescala/comprime cualquier imagen (dataURL o File) a un ancho máximo y calidad
// JPEG dados antes de guardarla — así las fotos no inflan el documento de Firestore
// ni tardan una eternidad en subir con datos móviles en el campo.
function comprimirImagenDataUrl(dataUrl, maxAncho, calidad){
maxAncho = maxAncho || 800; calidad = calidad || 0.75;
return new Promise((resolve, reject) => {
const img = new Image();
img.onload = () => {
const escala = Math.min(1, maxAncho / img.width);
const w = Math.max(1, Math.round(img.width * escala));
const h = Math.max(1, Math.round(img.height * escala));
const canvas = document.createElement('canvas');
canvas.width = w; canvas.height = h;
canvas.getContext('2d').drawImage(img, 0, 0, w, h);
resolve(canvas.toDataURL('image/jpeg', calidad));
};
img.onerror = reject;
img.src = dataUrl;
});
}
function archivoADataUrl(archivo){
return new Promise((resolve, reject) => {
// Límite de seguridad ANTES de intentar leer el archivo: una foto
// gigantesca (más de 25 MB — fuera de rango incluso para una foto normal de
// celular) puede agotar la memoria del navegador al procesarla y cerrar la
// pestaña de golpe en celulares con poca RAM — eso no es un error de
// JavaScript que un try/catch pueda atrapar, así que hay que evitar
// intentarlo siquiera.
const LIMITE_ARCHIVO_BYTES = 25 * 1024 * 1024;
if (archivo.size > LIMITE_ARCHIVO_BYTES){
reject(new Error('ARCHIVO_DEMASIADO_GRANDE'));
return;
}
const lector = new FileReader();
lector.onload = () => resolve(lector.result);
lector.onerror = reject;
lector.readAsDataURL(archivo);
});
}
async function comprimirArchivoImagen(archivo, maxAncho, calidad){
const dataUrl = await archivoADataUrl(archivo);
return comprimirImagenDataUrl(dataUrl, maxAncho, calidad);
}
// Comprime específicamente para que la lea el OCR (Tesseract). Antes el OCR leía
// el archivo ORIGINAL sin comprimir — una foto de celular normal (3000-4000px,
// varios MB) podía agotar la memoria del navegador y cerrar la app de golpe,
// sobre todo en celulares con poca RAM. 1600px de ancho conserva letra legible
// para el OCR y sigue siendo una fracción del tamaño de la foto original.
// Además se preprocesa a escala de grises con más contraste — el color y las
// sombras de una foto tomada con celular (reflejos, luz pareja) confunden
// mucho al lector de texto; en blanco y negro con más contraste, las letras
// resaltan mejor contra el fondo y sube bastante la precisión de la lectura.
async function comprimirParaOCR(archivo, maxAncho){
try {
const comprimida = await comprimirArchivoImagen(archivo, maxAncho || 1600, 0.85);
return await escalaDeGrisesConContraste(comprimida);
} catch(e){ console.warn('No se pudo comprimir/preprocesar la imagen para OCR, se intenta con el archivo original', e); return archivoADataUrl(archivo); }
}
function escalaDeGrisesConContraste(dataUrl, contraste){
contraste = contraste == null ? 45 : contraste;
return new Promise((resolve, reject) => {
const img = new Image();
img.onload = () => {
const canvas = document.createElement('canvas');
canvas.width = img.width; canvas.height = img.height;
const ctx = canvas.getContext('2d');
ctx.drawImage(img, 0, 0);
const datos = ctx.getImageData(0, 0, canvas.width, canvas.height);
const px = datos.data;
// El factor de contraste convierte un valor de -100 a 100 en la fórmula
// estándar de ajuste de contraste sobre el punto medio (128).
const factor = (259 * (contraste + 255)) / (255 * (259 - contraste));
for (let i = 0; i < px.length; i += 4){
// Escala de grises ponderada (percepción humana de luminancia).
let gris = px[i] * 0.299 + px[i+1] * 0.587 + px[i+2] * 0.114;
gris = factor * (gris - 128) + 128;
gris = gris < 0 ? 0 : (gris > 255 ? 255 : gris);
px[i] = px[i+1] = px[i+2] = gris;
}
ctx.putImageData(datos, 0, 0);
resolve(canvas.toDataURL('image/jpeg', 0.9));
};
img.onerror = reject;
img.src = dataUrl;
});
}
// Sube una imagen ya comprimida a Firebase Storage bajo la ruta indicada y regresa
// su downloadURL; si no hay conexión o Storage no está disponible, regresa la
// misma imagen comprimida en base64 como respaldo (para no perder el trabajo y
// seguir funcionando en modo local/offline, igual que el resto de la app).
// ================= INDEXEDDB PARA FOTOS QUE NO SE PUDIERON SUBIR =================
// Cuando no hay señal para subir una foto a Firebase Storage, antes se
// guardaba completa (texto base64, cientos de KB) dentro del mismo paquete
// que se guarda en localStorage — que en la mayoría de los celulares tiene
// un límite de apenas 5-10 MB en total para TODA la app. Unas 200 fotos así
// ya se lo comían completo, con riesgo de que el navegador borrara todo.
// Ahora esa foto se guarda en IndexedDB — otra "bodega" del navegador, aparte
// de localStorage, con mucho más espacio (cientos de MB o más). En su lugar,
// en el "estado" normal solo queda una referencia de texto chiquita
// ("indexeddb://ruta") hasta que se pueda subir de verdad a Storage.
const NOMBRE_BD_FOTOS_PENDIENTES = 'miranchapp-fotos-pendientes';
let dbFotosPendientesPromise = null;
function abrirBaseDeFotosPendientes(){
if (dbFotosPendientesPromise) return dbFotosPendientesPromise;
dbFotosPendientesPromise = new Promise((resolve, reject) => {
if (!window.indexedDB){ reject(new Error('Este navegador no soporta guardar fotos pendientes localmente')); return; }
const peticion = indexedDB.open(NOMBRE_BD_FOTOS_PENDIENTES, 1);
peticion.onupgradeneeded = (ev) => {
const db = ev.target.result;
if (!db.objectStoreNames.contains('fotos')) db.createObjectStore('fotos', { keyPath: 'ruta' });
};
peticion.onsuccess = (ev) => resolve(ev.target.result);
peticion.onerror = () => reject(peticion.error);
});
return dbFotosPendientesPromise;
}
async function guardarFotoPendienteLocal(ruta, dataUrl){
try {
const db = await abrirBaseDeFotosPendientes();
await new Promise((resolve, reject) => {
const tx = db.transaction('fotos', 'readwrite');
tx.objectStore('fotos').put({ ruta, dataUrl, fecha: new Date().toISOString() });
tx.oncomplete = resolve; tx.onerror = () => reject(tx.error);
});
return true;
} catch(e){
console.warn('No se pudo guardar la foto pendiente en IndexedDB, se usará el respaldo de siempre', e);
return false;
}
}
async function leerFotoPendienteLocal(ruta){
try {
const db = await abrirBaseDeFotosPendientes();
return await new Promise((resolve, reject) => {
const tx = db.transaction('fotos', 'readonly');
const peticion = tx.objectStore('fotos').get(ruta);
peticion.onsuccess = () => resolve(peticion.result ? peticion.result.dataUrl : null);
peticion.onerror = () => reject(peticion.error);
});
} catch(e){ return null; }
}
async function eliminarFotoPendienteLocal(ruta){
try {
const db = await abrirBaseDeFotosPendientes();
await new Promise((resolve, reject) => {
const tx = db.transaction('fotos', 'readwrite');
tx.objectStore('fotos').delete(ruta);
tx.oncomplete = resolve; tx.onerror = () => reject(tx.error);
});
} catch(e){}
}
async function listarTodasFotosPendientesLocal(){
try {
const db = await abrirBaseDeFotosPendientes();
return await new Promise((resolve, reject) => {
const tx = db.transaction('fotos', 'readonly');
const peticion = tx.objectStore('fotos').getAll();
peticion.onsuccess = () => resolve(peticion.result || []);
peticion.onerror = () => reject(peticion.error);
});
} catch(e){ return []; }
}
// Busca y reemplaza un valor de texto exacto en CUALQUIER parte de "estado"
// (arreglos y objetos anidados) — así, cuando una foto pendiente por fin se
// sube, no hace falta saber de antemano en qué campo específico quedó
// guardada su referencia (foto de animal, fierro, ticket, QR...), se
// actualiza sola donde sea que esté.
function reemplazarReferenciaEnEstado(valorViejo, valorNuevo){
function recorrer(obj, profundidad){
if (profundidad > 6 || !obj || typeof obj !== 'object') return; // límite de seguridad, nunca debería anidar tanto
if (Array.isArray(obj)){
for (let i = 0; i < obj.length; i++){
if (obj[i] === valorViejo) obj[i] = valorNuevo;
else if (obj[i] && typeof obj[i] === 'object') recorrer(obj[i], profundidad + 1);
}
} else {
Object.keys(obj).forEach(k => {
if (obj[k] === valorViejo) obj[k] = valorNuevo;
else if (obj[k] && typeof obj[k] === 'object') recorrer(obj[k], profundidad + 1);
});
}
}
recorrer(estado, 0);
}
// Revisa las fotos pendientes en IndexedDB y, si ya hay señal, intenta
// subirlas de verdad — al lograrlo, reemplaza la referencia "indexeddb://"
// por el link real y borra la copia local pendiente.
async function sincronizarFotosPendientes(){
if (!navigator.onLine || typeof window.firebaseSubirImagen !== 'function') return;
const pendientes = await listarTodasFotosPendientesLocal();
if (pendientes.length === 0) return;
let algunaSubida = false;
for (const foto of pendientes){
try {
const url = await window.firebaseSubirImagen(foto.ruta, foto.dataUrl);
if (url){
reemplazarReferenciaEnEstado('indexeddb://' + foto.ruta, url);
await eliminarFotoPendienteLocal(foto.ruta);
algunaSubida = true;
}
} catch(e){ /* sigue sin poderse subir esta en particular, se reintenta después */ }
}
if (algunaSubida){ guardarEstadoLocal(); if (typeof mostrarToast === 'function') mostrarToast('Fotos que estaban pendientes ya se subieron'); }
}
window.addEventListener('online', sincronizarFotosPendientes);
// Para mostrar una imagen que puede venir de 3 lugares distintos: un link
// normal (ya subida), una referencia a una foto pendiente en IndexedDB
// (offline todavía), o una imagen base64 completa de respaldo (casos donde
// ni IndexedDB estaba disponible) — regresa algo que sí sirve como src de
// una etiqueta <img>.
async function resolverImagenParaMostrar(valor){
if (!valor) return '';
if (typeof valor === 'string' && valor.startsWith('indexeddb://')){
const ruta = valor.replace('indexeddb://', '');
const dataUrl = await leerFotoPendienteLocal(ruta);
return dataUrl || '';
}
return valor;
}
async function subirImagenOGuardarLocal(ruta, dataUrlComprimido){
if (typeof window.firebaseSubirImagen === 'function'){
try {
const url = await window.firebaseSubirImagen(ruta, dataUrlComprimido);
if (url) return { url, esRemota: true };
} catch(e){ console.warn('Falló la subida a Storage, se intenta guardar localmente', e); }
}
const guardadoLocal = await guardarFotoPendienteLocal(ruta, dataUrlComprimido);
if (guardadoLocal) return { url: 'indexeddb://' + ruta, esRemota: false, pendiente: true };
// Último recurso, solo si ni IndexedDB funcionó (navegador muy viejo/raro)
// — para nunca perder la foto, aunque sea pesada.
return { url: dataUrlComprimido, esRemota: false };
}
// Marca visualmente (borde/fondo verde + check) el campo contenedor .grupo-campo
// del elemento como "ya registrado" cuando tiene valor, para que se note de un
// vistazo rápido qué falta. requerido=true además marca en rojo si sigue vacío.
function marcarCampoLleno(el, requerido){
const grupo = el.closest('.grupo-campo');
if (!grupo) return;
const lleno = !!(el.value && String(el.value).trim());
grupo.classList.toggle('campo-lleno', lleno);
grupo.classList.toggle('campo-vacio-requerido', !!requerido && !lleno);
}
function establecerValor(id, val){
const el = document.getElementById(id);
if (!el){
console.warn(`Campo "${id}" no encontrado en la pantalla actual — no se pudo escribir el valor.`);
return false;
}
el.value = val;
return true;
}
function limpiarCampos(ids){ ids.forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; }); }
let guardandoAnimalEnCurso = false;
async function guardarAnimal(){
// Sin este candado, si el registro lleva foto (que tarda en comprimirse y
// subirse), un segundo toque al botón mientras el primero todavía está
// esperando puede colarse, pasar la misma revisión de arete duplicado antes
// de que el primero termine de guardar, y crear 2 animales con el mismo
// arete — justo lo que esa revisión estaba tratando de evitar.
if (guardandoAnimalEnCurso) return;
const arete = valor('f-arete').trim();
const nombreAnimal = valor('f-nombre').trim();
quitarErrorCampo('f-arete'); quitarErrorCampo('f-nombre');
if (!arete && !nombreAnimal){
marcarErrorCampo('f-arete', 'Arete (o el nombre)');
mostrarToast(tr('guardar_registros__escribe_al_menos_el_arete'));
return;
}
// La fecha de nacimiento no debería quedar en el futuro — es un dato de
// algo que ya pasó.
if (valor('f-fecha') && valor('f-fecha') > hoyISO()){
mostrarToast('La fecha de nacimiento no puede ser futura — revisa el campo Fecha');
marcarErrorCampo('f-fecha', 'Fecha');
return;
}
if (arete && estado.animales.some((a, idx) => a.arete === arete && idx !== animalEditandoIndice)){
mostrarToast(tr('guardar_registros__ya_tienes_un_animal_registrado'));
return;
}
if (arete){
const conflicto = buscarAreteEnOtraUPP(arete);
// Si se está editando, un "conflicto" contra la MISMA cuenta activa con el
// mismo arete es en realidad el propio animal, no un choque de verdad.
if (conflicto && !(animalEditandoIndice !== null && conflicto.cuentaId === estado.cuentaActivaId)){
mostrarConflictoArete(arete, conflicto);
return;
}
}
guardandoAnimalEnCurso = true;
try {
const archivoFoto = document.getElementById('f-foto')?.files?.[0];
let foto = animalEditandoIndice !== null ? estado.animales[animalEditandoIndice].foto : null;
if (archivoFoto){
try {
const comprimida = await comprimirArchivoImagen(archivoFoto, 800, 0.75);
const rutaStorage = `imagenes_hato/${estado.cuentaActivaId || 'local'}/${(arete || 'sin_arete_' + Date.now()).replace(/[^a-zA-Z0-9_-]/g,'_')}.jpg`;
const subida = await subirImagenOGuardarLocal(rutaStorage, comprimida);
foto = subida.url;
} catch(e){
console.warn('No se pudo comprimir/subir la foto, se usa la original', e);
foto = await archivoADataUrl(archivoFoto);
}
}
const proposito = valor('f-proposito');
const esEngorda = proposito === 'engorda';
const datosAnimal = {
arete, chip: valor('f-chip'), nombre: valor('f-nombre'),
raza: valor('f-raza'), sexo: valor('f-sexo'), fecha: valor('f-fecha'),
estatus: valor('f-estatus'), madre: valor('f-madre'), padre: valor('f-padre'),
potrero: valor('f-potrero'), motivoBaja: valor('f-motivobaja'), foto,
proposito, engordaDiasObjetivo: esEngorda ? Number(valor('f-engorda-dias')) || null : null,
engordaPesoMeta: esEngorda ? Number(valor('f-engorda-peso-meta')) || null : null,
engordaInicio: esEngorda ? (valor('f-fecha') && new Date() ? new Date().toISOString().slice(0,10) : null) : null,
engordaFinalizado: false, engordaDiasFinal: null,
};
if (animalEditandoIndice !== null && estado.animales[animalEditandoIndice]){
// Se actualiza el mismo objeto (en vez de reemplazarlo por uno nuevo) para
// no perder campos que este formulario no toca — como engordaFinalizado si
// ya se había cerrado esa engorda antes de editar los datos básicos.
Object.assign(estado.animales[animalEditandoIndice], datosAnimal);
mostrarToast('Datos del animal actualizados');
animalEditandoIndice = null;
} else {
estado.animales.push(datosAnimal);
mostrarToast(tr('guardar_registros__animal_registrado'));
}
limpiarCampos(['f-arete','f-chip','f-nombre','f-raza','f-fecha','f-madre','f-padre','f-motivobaja','f-engorda-dias','f-engorda-peso-meta']);
limpiarBorradorRegistroGanado();
cambiarSubtab('ver'); renderResumenProductor(); renderHato();
renderResumenVientresToros();
} finally {
guardandoAnimalEnCurso = false;
}
}
function diasEnEngorda(a){
if (a.engordaFinalizado) return a.engordaDiasFinal;
if (!a.engordaInicio) return 0;
return Math.floor((Date.now() - new Date(a.engordaInicio)) / 86400000);
}
function renderMisTareas(){
const cont = document.getElementById('lista-mis-tareas');
if (!cont) return;
const mias = estado.tareas.filter(t => !t.asignadoA || t.asignadoA === estado.trabajadorActualId);
if (mias.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-list-check"></i><p>${tr('manejo_engorda_corral__no_tienes_tareas_pendientes_por')}</p></div>`;
return;
}
cont.innerHTML = mias.map(t => `
<div class="item-registro flex items-center justify-between gap-3" style="border-left:6px solid ${t.hecha ? 'var(--green)' : 'var(--blue)'};">
<div>
<p class="font-bold" style="${t.hecha ? 'text-decoration:line-through; opacity:.6;' : ''}">${t.texto}</p>
<p class="text-sm" style="color:var(--sage);">${t.fecha}${t.asignadoA ? '' : ' · General'}</p>
</div>
<button onclick="toggleTareaHecha('${t.id}')" class="text-xs font-bold px-3 py-2 rounded-full flex-shrink-0" style="background:${t.hecha ? 'var(--parchment)' : 'var(--green)'}; color:${t.hecha ? 'var(--pine)' : '#fff'};">
<i class="fa-solid ${t.hecha ? 'fa-rotate-left' : 'fa-check'}"></i> ${t.hecha ? 'Reabrir' : 'Hecha'}
</button>
</div>`).join('');
}
function toggleTareaHecha(id){
const t = estado.tareas.find(x => x.id === id);
if (!t) return;
t.hecha = !t.hecha;
renderMisTareas();
renderListaTareasAdmin();
}
function renderEngorda(){
const enCurso = estado.animales.filter(a => a.proposito === 'engorda' && !a.engordaFinalizado && a.estatus !== 'vendido' && a.estatus !== 'finado');
const finalizados = estado.animales.filter(a => a.proposito === 'engorda' && a.engordaFinalizado);
document.getElementById('resumen-engorda').innerHTML = `
<div class="bg-white rounded-3xl p-4" style="border:2px solid var(--line);">
<p class="text-xs font-bold uppercase" style="color:var(--sage);">${tr('manejo_engorda_corral__en_engorda_ahora')}</p>
<p class="font-display text-2xl font-bold mt-1">${enCurso.length}</p>
</div>
<div class="bg-white rounded-3xl p-4" style="border:2px solid var(--line);">
<p class="text-xs font-bold uppercase" style="color:var(--sage);">${tr('manejo_engorda_corral__engordas_finalizadas')}</p>
<p class="font-display text-2xl font-bold mt-1">${finalizados.length}</p>
</div>`;
const cont = document.getElementById('lista-engorda');
if (enCurso.length === 0 && finalizados.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-drumstick-bite"></i><p>${tr('manejo_engorda_corral__aun_no_tienes_animales_marcados')}</p></div>`;
return;
}
const filasEnCurso = enCurso.map(a => {
const i = estado.animales.indexOf(a);
const dias = diasEnEngorda(a);
const objetivo = a.engordaDiasObjetivo;
const pct = objetivo ? Math.min(100, Math.round((dias/objetivo)*100)) : null;
return `<div class="item-registro" style="border-left:6px solid var(--orange);">
<p class="font-bold">${a.nombre || a.arete || 'Animal'}</p>
<p class="text-sm" style="color:var(--sage);">${tr('manejo_engorda_corral__dias_corriendo').replace('%VAR%', dias).replace('%VAR%', objetivo ? ' de ' + objetivo + ' días objetivo' : ' (sin objetivo definido)').replace('%VAR%', a.engordaPesoMeta ? ' · Meta: ' + a.engordaPesoMeta + ' kg' : '')}</p>
${pct !== null ? `<div style="background:var(--parchment); border-radius:999px; height:8px; margin-top:6px; overflow:hidden;"><div style="background:var(--orange); height:100%; width:${pct}%;"></div></div>` : ''}
<button onclick="finalizarEngorda(${i})" class="text-xs font-bold px-3 py-2 rounded-full mt-3" style="background:var(--green); color:#fff;"><i class="fa-solid fa-flag-checkered"></i> ${tr('manejo_engorda_corral__marcar_engorda_finalizada')}</button>
</div>`;
}).join('');
const filasFinalizadas = finalizados.map(a => `
<div class="item-registro" style="border-left:6px solid var(--sage); opacity:.75;">
<p class="font-bold">${a.nombre || a.arete || 'Animal'}</p>
<p class="text-sm" style="color:var(--sage);">${tr('manejo_engorda_corral__finalizada_en_dias').replace('%VAR%', a.engordaDiasFinal)}</p>
</div>`).join('');
cont.innerHTML = (enCurso.length ? `<p class="font-display text-lg font-bold px-1">${tr('manejo_engorda_corral__en_curso')}</p>${filasEnCurso}` : '') +
(finalizados.length ? `<p class="font-display text-lg font-bold px-1 pt-2">${tr('manejo_engorda_corral__finalizadas')}</p>${filasFinalizadas}` : '');
}
function finalizarEngorda(i){
const a = estado.animales[i];
if (!a) return;
a.engordaFinalizado = true;
a.engordaDiasFinal = diasEnEngorda(a);
renderEngorda();
mostrarToast(`Engorda finalizada — ${a.engordaDiasFinal} días en total`);
}
function toggleCamposEngorda(){
const esEngorda = valor('f-proposito') === 'engorda';
document.getElementById('campos-engorda').classList.toggle('hidden', !esEngorda);
document.getElementById('nota-engorda').classList.toggle('hidden', !esEngorda);
}
// El motivo de baja solo tiene sentido cuando el animal de verdad se está
// dando de baja — mostrarlo siempre alargaba el formulario sin necesidad,
// ya que el 99% de las veces que se usa esta pantalla es para dar de ALTA
// un animal nuevo (estatus "activo"), no para darlo de baja.
function toggleCamposBaja(){
const esBaja = valor('f-estatus') === 'vendido' || valor('f-estatus') === 'finado';
const grupo = document.getElementById('grupo-motivobaja');
if (grupo) grupo.classList.toggle('hidden', !esBaja);
}
// El bloque para registrar la cría solo tiene caso si ya se puso la fecha
// real de parto (osea que ya nació de verdad) — antes se mostraba siempre,
// aunque el parto todavía ni ocurriera.
function actualizarVisibilidadCria(){
const grupo = document.getElementById('grupo-cria-nacida');
if (grupo) grupo.classList.toggle('hidden', !valor('f-parto-real'));
}
function revisarResumenSemanal(){
const hoy = new Date();
if (hoy.getDay() !== 1) return; 
const claveSemana = hoy.toISOString().slice(0,10);
if (estado.ultimaSemanaResumen === claveSemana) return;
estado.ultimaSemanaResumen = claveSemana;
setTimeout(() => abrirResumenRapido(), 400);
}
// Esconde/muestra los 3 botones flotantes (voz, +, chat) — se usa en
// modales de pantalla completa cuyo fondo semitransparente cubre justo
// donde viven estos botones, para que no se vean "encimados" ni queden
// bloqueados sin poder tocarlos mientras el modal está abierto.
function ocultarFabsFlotantes(ocultar){
['fab-comando-voz','fab-mas-productor','btn-chat-flotante-productor'].forEach(id => {
const el = document.getElementById(id);
if (el) el.classList.toggle('fabs-ocultos-temporalmente', ocultar);
});
}
function abrirResumenRapido(){
const activos = estado.animales.filter(a => a.estatus !== 'vendido' && a.estatus !== 'finado').length;
const notas = calcularNotificaciones();
const vencidos = notas.filter(n => n.categoria === 'vencido').length;
const hoy = notas.filter(n => n.categoria === 'hoy').length;
const proximos = notas.filter(n => n.categoria === 'proximo' || n.categoria === 'tramite').length;
const enfermos = estado.salud.filter(r => (r.tipo === 'enfermedad' || r.tipo === 'muerte_subita' || r.tipo === 'sospecha_exotica') && !r.recuperado).length;
const urgentesPendientes = estado.salud.filter(r => r.estadoCEFPP === 'pendiente').length;
const filas = [
{ icono:'fa-cow', color:'var(--blue)', texto:`${activos} animales activos en el hato` },
{ icono:'fa-triangle-exclamation', color:'var(--red)', texto:`${vencidos} vencidos · ${hoy} para hoy · ${proximos} próximos` },
{ icono:'fa-notes-medical', color:'var(--purple)', texto:`${enfermos} animal(es) en chequeo por enfermedad` },
];
if (urgentesPendientes > 0) filas.push({ icono:'fa-shield-virus', color:'var(--red)', texto:`${urgentesPendientes} caso(s) urgente(s) pendientes de enviar a CEFPP` });
document.getElementById('cuerpo-resumen-rapido').innerHTML = filas.map(f => `
<div class="flex items-center gap-3 py-1">
<span class="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0" style="background:${f.color}; color:#fff;"><i class="fa-solid ${f.icono} text-sm"></i></span>
<p class="text-sm font-semibold">${f.texto}</p>
</div>`).join('');
document.getElementById('modal-resumen-rapido').classList.remove('hidden');
ocultarFabsFlotantes(true);
}
function cerrarResumenRapido(){ document.getElementById('modal-resumen-rapido').classList.add('hidden'); ocultarFabsFlotantes(false); }
let scannerCampoDestino = null;
let scannerStream = null;
let scannerActivo = false;
async function abrirEscanerCamara(idCampo){
scannerCampoDestino = idCampo;
const modal = document.getElementById('modal-scanner-camara');
const video = document.getElementById('video-scanner');
const estado_txt = document.getElementById('texto-estado-scanner');
modal.classList.remove('hidden');
if (!('BarcodeDetector' in window)){
estado_txt.textContent = tr('escaneo_camara_barcodedetector__tu_navegador_no_soporta_escaneo');
return;
}
try {
scannerStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
video.srcObject = scannerStream;
scannerActivo = true;
const detector = new BarcodeDetector({ formats: ['code_128','ean_13','ean_8','upc_a','upc_e','codabar','code_39','itf'] });
const bucle = async () => {
if (!scannerActivo) return;
try {
const codigos = await detector.detect(video);
if (codigos.length > 0){
procesarCodigoEscaneado(codigos[0].rawValue);
return;
}
} catch (err) {  }
requestAnimationFrame(bucle);
};
bucle();
} catch (err) {
estado_txt.textContent = tr('escaneo_camara_barcodedetector__no_se_pudo_acceder_a');
}
}
function procesarCodigoEscaneado(codigo){
const el = document.getElementById(scannerCampoDestino);
if (el) el.value = codigo.slice(-10);
cerrarEscanerCamara();
mostrarToast(tr('escaneo_camara_barcodedetector__codigo_escaneado'));
}
function cerrarEscanerCamara(){
scannerActivo = false;
if (scannerStream){ scannerStream.getTracks().forEach(t => t.stop()); scannerStream = null; }
document.getElementById('modal-scanner-camara').classList.add('hidden');
}
function activarEscaneoArete(id){
const el = document.getElementById(id);
if (!el) return;
el.value = '';
el.focus();
mostrarToast(tr('escaneo_codigo_barras__listo_escanea_el_arete_ahora'));
let temporizador = null;
const alEscribir = () => {
if (el.value.length > 10) el.value = el.value.slice(-10);
clearTimeout(temporizador);
temporizador = setTimeout(() => {
if (el.value.length > 10) el.value = el.value.slice(-10);
el.removeEventListener('input', alEscribir);
}, 600);
};
el.addEventListener('input', alEscribir);
}
function toggleModoLoteSalud(){
const enLote = document.getElementById('f-modo-lote').checked;
document.getElementById('f-animal-individual').classList.toggle('hidden', enLote);
document.getElementById('f-animal-lote').classList.toggle('hidden', !enLote);
}
function guardarSalud(){
const tipo = valor('f-tipo');
const enLote = document.getElementById('f-modo-lote') && document.getElementById('f-modo-lote').checked;
const camposRequeridos = [{ id:'f-producto', etiqueta:'Producto/tratamiento' }, { id:'f-fecha', etiqueta:'Fecha' }];
if (!enLote) camposRequeridos.unshift({ id:'f-animal', etiqueta:'Arete o nombre del animal' });
if (!marcarCamposFaltantes(camposRequeridos)) return;
// La fecha del evento (vacuna, tratamiento, etc.) no debería quedar en el
// futuro — es un registro de algo que YA se hizo. Se avisa y se deja
// corregir, en vez de guardar una fecha que no tiene sentido.
if (valor('f-fecha') && valor('f-fecha') > hoyISO()){
mostrarToast('La fecha no puede ser futura — revisa el campo Fecha');
marcarErrorCampo('f-fecha', 'Fecha');
return;
}
const esUrgente = tipo === 'muerte_subita' || tipo === 'sospecha_exotica';
// Días de retiro de leche: un número negativo produciría una fecha de
// retiro ANTES del propio tratamiento, algo sin sentido — se fuerza a que
// nunca sea menor a 0.
const diasRetiro = document.getElementById('f-dias-retiro') ? Math.max(0, Number(valor('f-dias-retiro')) || 0) : 0;
let retiroHasta = null;
if (diasRetiro > 0 && valor('f-fecha')){
const f = new Date(valor('f-fecha'));
f.setDate(f.getDate() + diasRetiro);
retiroHasta = f.toISOString().slice(0,10);
}
const cuartoMastitis = document.getElementById('f-cuarto-mastitis') ? valor('f-cuarto-mastitis') : null;
const cmt = document.getElementById('f-cmt') ? valor('f-cmt') : null;
const base = { tipo, producto: valor('f-producto'), fecha: valor('f-fecha'), proxima: valor('f-proxima'), notas: valor('f-notas'), recuperado: false, estadoCEFPP: esUrgente ? 'pendiente' : null, retiroLecheHasta: retiroHasta, cuartoMastitis: (cuartoMastitis && cuartoMastitis !== 'no_aplica') ? cuartoMastitis : null, cmt: (cmt && cmt !== 'no_aplica') ? cmt : null };
const idInsumo = document.getElementById('f-insumo-bodega') ? valor('f-insumo-bodega') : '';
const cantidadInsumo = Number(valor('f-insumo-cantidad')) || 0;
if (idInsumo && cantidadInsumo > 0){
const cantidadTotal = enLote
? cantidadInsumo * estado.animales.filter(a => a.potrero === valor('f-potrero-lote') && a.estatus !== 'vendido' && a.estatus !== 'finado').length
: cantidadInsumo;
descontarInsumoBodega(idInsumo, cantidadTotal);
}
if (enLote){
const potrero = valor('f-potrero-lote');
if (!potrero){ mostrarToast(tr('escaneo_codigo_barras__selecciona_un_potrero_para_aplicar')); return; }
const animalesLote = estado.animales.filter(a => a.potrero === potrero && a.estatus !== 'vendido' && a.estatus !== 'finado');
if (animalesLote.length === 0){ mostrarToast(tr('escaneo_codigo_barras__no_hay_animales_activos_en')); return; }
animalesLote.forEach(a => estado.salud.push({ ...base, animal: a.arete || a.nombre }));
limpiarCampos(['f-producto','f-fecha','f-proxima','f-notas','f-dias-retiro','f-insumo-cantidad']);
mostrarToast(`Registro aplicado a ${animalesLote.length} animales de ${potrero}`);
} else {
estado.salud.push({ ...base, animal: valor('f-animal') });
limpiarCampos(['f-animal','f-producto','f-fecha','f-proxima','f-notas','f-dias-retiro','f-insumo-cantidad']);
mostrarToast(esUrgente ? tr('escaneo_codigo_barras__caso_urgente_registrado_se_agrego') : (retiroHasta ? `Registrado — leche no apta hasta ${retiroHasta}` : tr('escaneo_codigo_barras__registro_de_salud_guardado')));
}
cambiarSubtab('ver'); actualizarBadgeNotificaciones();
}
function sumarDias(fechaStr, dias){
const f = new Date(fechaStr);
f.setDate(f.getDate() + dias);
return f.toISOString().slice(0,10);
}
function autocalcularParto(){
const fechaServicio = valor('f-fecha');
const campoParto = document.getElementById('f-parto');
if (!fechaServicio || !campoParto) return;
campoParto.value = sumarDias(fechaServicio, 283); 
autocalcularSecado();
}
function autocalcularSecado(){
const campoSecado = document.getElementById('f-secado');
const fechaParto = valor('f-parto');
if (!campoSecado || !fechaParto) return;
campoSecado.value = sumarDias(fechaParto, -60); 
}
// ================= CONFIRMACIONES DE PAGO (ticket + folio único) =================
let imagenTicketPagoTemp = null;
let tabConfirmacionesPagoActual = 'pendiente';
async function previsualizarTicketPago(inputEl){
const archivo = inputEl.files && inputEl.files[0];
if (!archivo) return;
try {
imagenTicketPagoTemp = await comprimirArchivoImagen(archivo, 900, 0.8);
const img = document.getElementById('tp-foto-preview');
img.src = imagenTicketPagoTemp; img.classList.remove('hidden');
} catch(e){ console.warn('No se pudo procesar la foto del ticket', e); mostrarToast('No se pudo leer esa imagen'); }
}
let enviandoConfirmacionPago = false;
async function enviarConfirmacionPago(){
// Evita el caso de doble toque/doble clic: sin este candado, dos llamadas
// podían quedar esperando la respuesta de red al mismo tiempo, revisar el
// folio contra los mismos datos viejos (ninguna había alcanzado a guardar
// todavía), y las dos "ver" el folio como nuevo — coliendo la protección
// contra folios duplicados que se hizo justo para evitar eso.
if (enviandoConfirmacionPago) return;
const folio = valor('tp-folio').trim();
if (!folio){ mostrarToast('Escribe el número de folio/referencia del ticket'); return; }
if (!imagenTicketPagoTemp){ mostrarToast('Sube la foto del ticket'); return; }
enviandoConfirmacionPago = true;
const botonEnviar = document.querySelector('#screen-suscripcion button[onclick="enviarConfirmacionPago()"]');
if (botonEnviar) botonEnviar.disabled = true;
try {
// Antes de revisar si el folio ya se usó, se trae la versión más reciente de
// la cola de administración — la copia local de un productor puede no traer
// lo que mandaron otros productores mientras tanto (ya no se queda
// escuchando esto en vivo) y, sin este paso, se podría dejar pasar por error
// un folio que alguien más ya usó.
if (typeof window.firebaseLeerColaAdmin === 'function'){
const remoto = await window.firebaseLeerColaAdmin();
if (remoto) CAMPOS_COLA_ADMIN.forEach(clave => { if (Array.isArray(remoto[clave])) estado[clave] = remoto[clave]; });
}
// El folio se compara sin mayúsculas/espacios de más, para que "abc123" y
// "ABC 123" cuenten como el mismo número y no se puedan colar variaciones.
const folioNormalizado = folio.toUpperCase().replace(/\s+/g, '');
const yaExiste = estado.solicitudesPago.some(s => s.folio.toUpperCase().replace(/\s+/g, '') === folioNormalizado);
if (yaExiste){ mostrarToast('Este folio ya fue registrado antes en el sistema — si crees que es un error, contacta a tu administrador directamente'); return; }
const idTicket = 'tp_' + Date.now();
// Estos tickets se van acumulando con el tiempo (uno por cada pago que
// manda cada productor) — si se guardaran como texto de imagen completo
// dentro del documento compartido, unos cuantos ya lo dejarían pesadísimo
// y arriesgarían el límite de tamaño de Firestore. Subiéndolos a Storage,
// el documento compartido solo carga con un link chiquito por ticket.
const subida = await subirImagenOGuardarLocal(`tickets_pago/${idTicket}.jpg`, imagenTicketPagoTemp);
estado.solicitudesPago.push({
id: idTicket,
cuentaId: estado.cuentaActivaId || null,
nombre: estado.productor.nombre || '',
predio: estado.productor.predio || '',
upp: estado.productor.upp || '',
folio,
fotoTicket: subida.url,
fecha: hoyISO(),
estatus: 'pendiente',
notasAdmin: '',
});
// Ya se trajo lo más reciente de arriba y se le agregó lo nuevo — se guarda
// directo, sin volver a leer (evita un viaje de más a Firestore).
if (typeof window.firebaseGuardarColaAdmin === 'function') await window.firebaseGuardarColaAdmin(construirPayloadColaAdmin());
guardarEstadoLocal();
limpiarCampos(['tp-folio']);
imagenTicketPagoTemp = null;
document.getElementById('tp-foto-preview').classList.add('hidden');
document.getElementById('tp-foto-input').value = '';
renderMisConfirmacionesPago();
mostrarToast('Confirmación enviada — tu administrador la va a revisar');
} finally {
enviandoConfirmacionPago = false;
if (botonEnviar) botonEnviar.disabled = false;
}
}
function renderMisConfirmacionesPago(){
const cont = document.getElementById('lista-mis-confirmaciones-pago');
if (!cont) return;
const mias = estado.solicitudesPago.filter(s => s.cuentaId === estado.cuentaActivaId).sort((a,b) => new Date(b.fecha) - new Date(a.fecha));
if (mias.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-3" style="color:var(--sage);">Aún no has enviado ninguna confirmación</p>`;
return;
}
const etiquetas = { pendiente: ['En revisión', 'var(--yellow)'], aprobado: ['Aprobado', 'var(--green)'], rechazado: ['Rechazado', 'var(--red)'] };
cont.innerHTML = mias.map(s => {
const [texto, color] = etiquetas[s.estatus];
return `<div class="flex items-center justify-between py-1.5" style="border-top:1px solid var(--line);">
<div><span class="text-sm font-bold">Folio ${s.folio}</span><span class="text-xs" style="color:var(--sage);"> · ${s.fecha}</span></div>
<span class="text-xs font-bold px-2 py-0.5 rounded-full" style="background:${color}; color:#fff;">${texto}</span>
</div>`;
}).join('');
}
function cambiarTabConfirmacionesPago(tab){
tabConfirmacionesPagoActual = tab;
document.querySelectorAll('[data-tab-confirmacion]').forEach(b => b.classList.toggle('active', b.dataset.tabConfirmacion === tab));
renderConfirmacionesPago();
}
function renderConfirmacionesPago(){
const cont = document.getElementById('lista-confirmaciones-pago');
if (!cont) return;
const filtradas = estado.solicitudesPago.filter(s => s.estatus === tabConfirmacionesPagoActual).sort((a,b) => new Date(b.fecha) - new Date(a.fecha));
actualizarBadgeConfirmacionesPago();
if (filtradas.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-4" style="color:var(--sage);">No hay confirmaciones ${tabConfirmacionesPagoActual === 'pendiente' ? 'pendientes' : (tabConfirmacionesPagoActual === 'aprobado' ? 'aprobadas' : 'rechazadas')}</p>`;
return;
}
cont.innerHTML = filtradas.map(s => `
<div class="bg-white rounded-2xl p-3" style="border:2px solid var(--line);">
<div class="flex gap-3">
<img loading="lazy" onclick="abrirLightboxTicketPago('${s.fotoTicket.replace(/'/g,"\\'")}')" src="${s.fotoTicket}" style="width:56px; height:56px; object-fit:cover; border-radius:10px; border:1px solid var(--line); cursor:pointer; flex-shrink:0;"/>
<div class="flex-1 min-w-0">
<p class="text-sm font-bold">${s.nombre || '(sin nombre)'}</p>
<p class="text-xs" style="color:var(--sage);">${s.predio || ''} ${s.upp ? '· UPP ' + s.upp : ''}</p>
<p class="text-xs font-bold mt-0.5">Folio: <span class="font-mono">${s.folio}</span> · ${s.fecha}</p>
${s.notasAdmin ? `<p class="text-xs mt-0.5" style="color:var(--sage);">${s.notasAdmin}</p>` : ''}
</div>
</div>
${s.estatus === 'pendiente' ? `<div class="flex gap-2 mt-2">
<button onclick="aprobarConfirmacionPago('${s.id}')" class="flex-1 text-xs font-bold py-2 rounded-full" style="background:var(--green); color:#fff;"><i class="fa-solid fa-check"></i> Aprobar y extender</button>
<button onclick="rechazarConfirmacionPago('${s.id}')" class="flex-1 text-xs font-bold py-2 rounded-full" style="background:#FEE2E2; color:#B91C1C;"><i class="fa-solid fa-xmark"></i> Rechazar</button>
</div>` : ''}
</div>`).join('');
}
function actualizarBadgeConfirmacionesPago(){
const badge = document.getElementById('badge-confirmaciones-pago-pendientes');
if (!badge) return;
const n = estado.solicitudesPago.filter(s => s.estatus === 'pendiente').length;
badge.classList.toggle('hidden', n === 0);
badge.textContent = n;
}
function abrirLightboxTicketPago(src){
document.getElementById('lightbox-ticket-pago-img').src = src;
document.getElementById('lightbox-ticket-pago').classList.remove('hidden');
}
function cerrarLightboxTicketPago(){
document.getElementById('lightbox-ticket-pago').classList.add('hidden');
}
// Aprobar: extiende la suscripción de la cuenta del productor a partir de HOY
// o de su fecha de vencimiento actual (la que sea más adelante) — así
// renovar antes de que venza no le "recorta" días ya pagados.
function aprobarConfirmacionPago(id){
const s = estado.solicitudesPago.find(x => x.id === id);
if (!s) return;
const cuenta = estado.cuentasProductores.find(c => c.id === s.cuentaId);
if (!cuenta){ mostrarToast('No se encontró la cuenta de este productor (puede que ya no exista)'); return; }
if (!cuenta.suscripcion) cuenta.suscripcion = { diasVigencia: 365, fechaVencimiento: hoyISO() };
const base = (cuenta.suscripcion.fechaVencimiento && cuenta.suscripcion.fechaVencimiento > hoyISO()) ? cuenta.suscripcion.fechaVencimiento : hoyISO();
cuenta.suscripcion.fechaVencimiento = sumarDiasISO(base, cuenta.suscripcion.diasVigencia || 365);
s.estatus = 'aprobado';
s.notasAdmin = `Suscripción extendida hasta ${cuenta.suscripcion.fechaVencimiento}`;
guardarEstadoLocal();
renderConfirmacionesPago();
mostrarToast(`Suscripción de ${s.nombre} extendida hasta ${cuenta.suscripcion.fechaVencimiento}`);
}
function rechazarConfirmacionPago(id){
const s = estado.solicitudesPago.find(x => x.id === id);
if (!s) return;
const motivo = prompt('¿Por qué se rechaza? (se lo puede ver el productor, opcional)') || '';
s.estatus = 'rechazado';
s.notasAdmin = motivo;
guardarEstadoLocal();
renderConfirmacionesPago();
}
// ================= MÉTODOS DE PAGO (para la suscripción) =================
let imagenQRPagoTemp = null;
function actualizarCamposTipoPago(){
const tipo = valor('pago-tipo');
document.getElementById('pago-campos-tarjeta').classList.toggle('hidden', tipo !== 'tarjeta');
document.getElementById('pago-campos-qr').classList.toggle('hidden', tipo !== 'qr');
document.getElementById('pago-campos-oxxo').classList.toggle('hidden', tipo !== 'oxxo');
}
async function previsualizarQRPago(inputEl){
const archivo = inputEl.files && inputEl.files[0];
if (!archivo) return;
try {
imagenQRPagoTemp = await comprimirArchivoImagen(archivo, 500, 0.85);
const img = document.getElementById('pago-qr-preview');
img.src = imagenQRPagoTemp; img.classList.remove('hidden');
} catch(e){ console.warn('No se pudo procesar la imagen del QR', e); mostrarToast('No se pudo leer esa imagen'); }
}
async function guardarMetodoPago(){
const nombre = valor('pago-nombre').trim();
if (!nombre){ mostrarToast('Escribe un nombre para identificar este método (solo lo ves tú)'); return; }
const tipo = valor('pago-tipo');
const metodo = { id: 'pago_' + Date.now(), nombre, tipo, notas: valor('pago-notas').trim(), activo: estado.metodosPago.length === 0 };
if (tipo === 'tarjeta'){
const numero = valor('pago-numero').trim();
if (!numero){ mostrarToast('Escribe el número de tarjeta o CLABE'); return; }
metodo.numero = numero; metodo.banco = valor('pago-banco').trim();
} else if (tipo === 'qr'){
if (!imagenQRPagoTemp){ mostrarToast('Sube la imagen del código QR'); return; }
// El QR se sube a Storage y en la cuenta solo queda el link — este método
// de pago lo ve TODO productor, así que mantenerlo liviano ayuda más que
// cualquier otra imagen de la app.
const subida = await subirImagenOGuardarLocal(`metodos_pago/${metodo.id}.jpg`, imagenQRPagoTemp);
metodo.imagenQR = subida.url;
} else if (tipo === 'oxxo'){
const referencia = valor('pago-referencia').trim();
if (!referencia){ mostrarToast('Escribe la referencia/código de pago'); return; }
metodo.referencia = referencia;
}
// El primero que se agrega queda activo automáticamente (para que no se
// quede la pantalla del productor sin ningún método que mostrar); los
// siguientes se agregan inactivos hasta que el admin decida usarlos.
estado.metodosPago.push(metodo);
guardarEstadoLocal();
limpiarCampos(['pago-nombre','pago-numero','pago-banco','pago-referencia','pago-notas']);
imagenQRPagoTemp = null;
document.getElementById('pago-qr-preview').classList.add('hidden');
document.getElementById('pago-qr-input').value = '';
renderMetodosPago();
mostrarToast(metodo.activo ? 'Método guardado y marcado como activo' : 'Método guardado');
}
// Marca UNO como activo y automáticamente desactiva todos los demás — nunca
// hay más de uno activo a la vez, para que el productor no vea dos formas de
// pago distintas y no sepa cuál usar.
function marcarMetodoPagoActivo(id){
estado.metodosPago.forEach(m => { m.activo = (m.id === id); });
guardarEstadoLocal();
renderMetodosPago();
mostrarToast('Listo — a partir de ahora los productores ven este método');
}
function eliminarMetodoPago(id){
const eraActivo = estado.metodosPago.find(m => m.id === id)?.activo;
estado.metodosPago = estado.metodosPago.filter(m => m.id !== id);
// Si se borró el que estaba activo y quedan otros, se activa el primero que
// quede — así nunca se queda la pantalla del productor sin nada que mostrar.
if (eraActivo && estado.metodosPago.length > 0) estado.metodosPago[0].activo = true;
guardarEstadoLocal();
renderMetodosPago();
}
function renderMetodosPago(){
const cont = document.getElementById('lista-metodos-pago');
if (!cont) return;
if (estado.metodosPago.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-3" style="color:var(--sage);">Aún no has guardado ningún método de pago</p>`;
return;
}
const iconos = { tarjeta:'fa-credit-card', qr:'fa-qrcode', oxxo:'fa-store' };
cont.innerHTML = estado.metodosPago.map(m => {
let resumen = '';
if (m.tipo === 'tarjeta') resumen = `${m.banco ? m.banco + ' · ' : ''}terminación ${m.numero.slice(-4)}`;
else if (m.tipo === 'qr') resumen = 'Código QR';
else if (m.tipo === 'oxxo') resumen = `Referencia: ${m.referencia}`;
return `<div class="rounded-2xl p-3" style="background:#fff; border:2px solid ${m.activo ? 'var(--green)' : 'var(--line)'};">
<div class="flex items-center gap-2">
<i class="fa-solid ${iconos[m.tipo]}" style="color:var(--pine); width:20px;"></i>
<div class="flex-1">
<p class="text-sm font-bold">${m.nombre} ${m.activo ? '<span class="text-xs px-2 py-0.5 rounded-full" style="background:var(--green); color:#fff;">ACTIVO</span>' : ''}</p>
<p class="text-xs" style="color:var(--sage);">${resumen}${m.notas ? ' · ' + m.notas : ''}</p>
</div>
</div>
<div class="flex gap-2 mt-2">
${!m.activo ? `<button onclick="marcarMetodoPagoActivo('${m.id}')" class="flex-1 text-xs font-bold py-2 rounded-full" style="background:var(--parchment); color:var(--pine); border:2px solid var(--line);">Usar este</button>` : ''}
<button onclick="eliminarMetodoPago('${m.id}')" class="text-xs font-bold py-2 px-3 rounded-full" style="background:#FEE2E2; color:#B91C1C;"><i class="fa-solid fa-trash"></i></button>
</div>
</div>`;
}).join('');
}
// Lo que ve el PRODUCTOR — su fecha de vencimiento y el método de pago activo.
function renderMiSuscripcion(){
// Cada vez que se abre esta pantalla se pregunta una sola vez (no en vivo)
// si hay algo nuevo sobre los tickets de pago que este productor mandó —
// así se entera si ya se los aprobaron sin tener que reiniciar la app, pero
// sin quedarse "escuchando" todo el tiempo como antes.
if (typeof window.firebaseLeerColaAdmin === 'function'){
window.firebaseLeerColaAdmin().then((remoto) => {
if (!remoto || !Array.isArray(remoto.solicitudesPago)) return;
estado.solicitudesPago = remoto.solicitudesPago;
renderMisConfirmacionesPago();
}).catch(() => {});
}
const s = estado.productor.suscripcion || {};
const contEstado = document.getElementById('suscripcion-estado-cuerpo');
if (contEstado){
const dias = s.fechaVencimiento ? diasEntreISO(s.fechaVencimiento, hoyISO()) : null;
const vencida = dias != null && dias < 0;
contEstado.innerHTML = `<div class="rounded-3xl p-5" style="background:${vencida ? '#FEE2E2' : 'var(--parchment)'}; border:2px solid ${vencida ? '#B91C1C' : 'var(--line)'};">
<p class="text-xs font-bold uppercase" style="color:${vencida ? '#B91C1C' : 'var(--sage)'};">${vencida ? 'Vencida' : 'Vigente'}</p>
<p class="text-lg font-bold">${s.fechaVencimiento ? 'Vence el ' + s.fechaVencimiento : 'Sin fecha de vencimiento registrada'}</p>
${dias != null ? `<p class="text-sm" style="color:var(--sage);">${vencida ? `Vencida hace ${Math.abs(dias)} días` : `Quedan ${dias} días`}</p>` : ''}
</div>`;
}
const contPago = document.getElementById('suscripcion-metodo-pago-cuerpo');
renderMisConfirmacionesPago();
if (!contPago) return;
const activo = estado.metodosPago.find(m => m.activo);
if (!activo){
contPago.innerHTML = `<p class="text-xs text-center py-3" style="color:var(--sage);">Tu administrador aún no ha registrado un método de pago — contáctalo directamente.</p>`;
return;
}
if (activo.tipo === 'tarjeta'){
contPago.innerHTML = `<div class="rounded-2xl p-4" style="background:var(--parchment);">
<p class="text-xs font-bold uppercase" style="color:var(--sage);">${activo.banco || 'Tarjeta / CLABE'}</p>
<p class="text-xl font-bold font-mono">${activo.numero}</p>
${activo.notas ? `<p class="text-xs mt-1" style="color:var(--sage);">${activo.notas}</p>` : ''}
</div>`;
} else if (activo.tipo === 'qr'){
contPago.innerHTML = `<div class="flex flex-col items-center gap-2">
<img src="${activo.imagenQR}" style="width:180px; height:180px; object-fit:contain; border:2px solid var(--line); border-radius:16px; background:#fff;"/>
${activo.notas ? `<p class="text-xs text-center" style="color:var(--sage);">${activo.notas}</p>` : ''}
</div>`;
} else if (activo.tipo === 'oxxo'){
contPago.innerHTML = `<div class="rounded-2xl p-4" style="background:var(--parchment);">
<p class="text-xs font-bold uppercase" style="color:var(--sage);">Referencia OXXO/tienda</p>
<p class="text-xl font-bold font-mono">${activo.referencia}</p>
${activo.notas ? `<p class="text-xs mt-1" style="color:var(--sage);">${activo.notas}</p>` : ''}
</div>`;
}
}
// ================= CATÁLOGO DE CLIENTES / PROVEEDORES =================
function abrirCatalogoContactos(){
document.getElementById('modal-catalogo-contactos').classList.remove('hidden');
renderCatalogoContactos();
}
function cerrarCatalogoContactos(){
document.getElementById('modal-catalogo-contactos').classList.add('hidden');
const datalist = document.getElementById('lista-contactos-datalist');
if (datalist) datalist.innerHTML = estado.contactosComerciales.map(c => `<option value="${c.nombre}">${c.tipo === 'cliente' ? 'Cliente' : 'Proveedor'}</option>`).join('');
}
function guardarContacto(){
const nombre = valor('cont-nombre').trim();
if (!nombre){ mostrarToast('Escribe el nombre del cliente o proveedor'); return; }
estado.contactosComerciales.push({ id: 'cont_' + Date.now(), nombre, tipo: valor('cont-tipo'), telefono: valor('cont-telefono').trim(), notas: valor('cont-notas').trim() });
guardarEstadoLocal();
limpiarCampos(['cont-nombre','cont-telefono','cont-notas']);
renderCatalogoContactos();
mostrarToast('Contacto agregado');
}
function eliminarContacto(id){
estado.contactosComerciales = estado.contactosComerciales.filter(c => c.id !== id);
guardarEstadoLocal();
renderCatalogoContactos();
}
function renderCatalogoContactos(){
const cont = document.getElementById('lista-catalogo-contactos');
if (!cont) return;
if (estado.contactosComerciales.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-3" style="color:var(--bg-cafe);">Aún no hay clientes/proveedores guardados</p>`;
return;
}
cont.innerHTML = estado.contactosComerciales.map(c => {
const esCliente = c.tipo === 'cliente';
return `<div class="rounded-2xl p-3 flex items-center gap-2.5" style="background:#fff; border:1.5px solid var(--bg-borde);">
<div style="width:36px; height:36px; border-radius:10px; flex-shrink:0; display:flex; align-items:center; justify-content:center; color:#fff; font-weight:bold; font-size:13px; background:${esCliente ? 'var(--bg-verde)' : 'var(--bg-cafe)'};">${(c.nombre || '?').charAt(0).toUpperCase()}</div>
<div class="flex-1">
<p class="text-sm font-bold" style="color:var(--bg-oscuro);">${c.nombre}</p>
<p class="text-xs" style="color:var(--bg-cafe);">${esCliente ? 'Cliente' : 'Proveedor'}${c.telefono ? ' · ' + c.telefono : ''}${c.notas ? ' · ' + c.notas : ''}</p>
</div>
<button onclick="eliminarContacto('${c.id}')" style="color:#B91C1C; width:28px; height:28px;"><i class="fa-solid fa-trash"></i></button>
</div>`;
}).join('');
}
// Recibo/factura simple en PDF (jsPDF) para un movimiento de dinero ya ligado
// a un cliente/proveedor — no es un sistema de facturación fiscal (no genera
// CFDI ni folios ante el SAT), es un comprobante simple para entregar en mano.
async function generarReciboPDF(indice){
const r = estado.costos[indice];
if (!r){ mostrarToast('No se encontró el movimiento'); return; }
await cargarJsPDFSiNecesario();
const { jsPDF } = window.jspdf;
const doc = new jsPDF();
const folio = 'REC-' + (r.fecha || '').replace(/-/g,'') + '-' + String(indice).padStart(3,'0');
doc.setFontSize(16); doc.text('MiRanch', 14, 18);
doc.setFontSize(11); doc.text(r.tipo === 'ingreso' ? 'RECIBO DE VENTA' : 'RECIBO DE COMPRA', 14, 26);
doc.setFontSize(9); doc.text(`Folio: ${folio}`, 14, 34); doc.text(`Fecha: ${r.fecha || '—'}`, 14, 40);
doc.text(`${r.tipo === 'ingreso' ? 'Cliente' : 'Proveedor'}: ${r.contacto || '—'}`, 14, 48);
doc.setFontSize(10);
doc.text(`Concepto: ${r.descripcion || r.categoria || '—'}`, 14, 60);
doc.setFontSize(14); doc.text(`Monto: $${Number(r.monto).toLocaleString('es-MX', {minimumFractionDigits:2})}`, 14, 72);
doc.setFontSize(8); doc.setTextColor(120);
doc.text(`Generado desde MiRanch el ${formatoFechaHora()} — comprobante interno, no es factura fiscal (CFDI).`, 14, 285);
doc.save(`${folio}.pdf`);
mostrarToast('Recibo generado');
}
// ================= CATÁLOGO DE SEMENTALES / PAJILLAS =================
function abrirCatalogoSementales(){
document.getElementById('modal-catalogo-sementales').classList.remove('hidden');
renderCatalogoSementales();
}
function cerrarCatalogoSementales(){
document.getElementById('modal-catalogo-sementales').classList.add('hidden');
// Al cerrar, se refresca el datalist del formulario de reproducción por si
// se agregó/quitó algo mientras el catálogo estaba abierto.
const datalist = document.getElementById('lista-sementales-datalist');
if (datalist) datalist.innerHTML = estado.sementales.map(s => `<option value="${s.nombre}">${s.dosisDisponibles} dosis disponibles</option>`).join('');
}
function guardarSemental(){
const nombre = valor('sem-nombre').trim();
if (!nombre){ mostrarToast('Escribe el nombre del semental o pajilla'); return; }
const dosis = Number(valor('sem-dosis')) || 0;
estado.sementales.push({ id: 'sem_' + Date.now(), nombre, raza: valor('sem-raza').trim(), dosisDisponibles: dosis });
guardarEstadoLocal();
limpiarCampos(['sem-nombre','sem-raza','sem-dosis']);
renderCatalogoSementales();
mostrarToast('Semental agregado al catálogo');
}
function eliminarSemental(id){
estado.sementales = estado.sementales.filter(s => s.id !== id);
guardarEstadoLocal();
renderCatalogoSementales();
}
function ajustarDosisSemental(id, delta){
const s = estado.sementales.find(s => s.id === id);
if (!s) return;
s.dosisDisponibles = Math.max(0, (s.dosisDisponibles || 0) + delta);
guardarEstadoLocal();
renderCatalogoSementales();
}
function renderCatalogoSementales(){
const cont = document.getElementById('lista-catalogo-sementales');
if (!cont) return;
if (estado.sementales.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-3" style="color:var(--bg-cafe);">Aún no hay sementales en el catálogo</p>`;
return;
}
cont.innerHTML = estado.sementales.map(s => {
const pocasDosis = s.dosisDisponibles <= 0;
const dosisBaja = s.dosisDisponibles > 0 && s.dosisDisponibles < 10;
const colorBadge = pocasDosis ? '#B91C1C' : (dosisBaja ? '#B45309' : 'var(--bg-verde)');
const fondoBadge = pocasDosis ? '#FEE2E2' : (dosisBaja ? '#FEF3C7' : '#DCFCE7');
const barras = Array.from({length:5}).map((_,i) => `<div style="height:5px; flex:1; border-radius:99px; background:${i < Math.ceil(s.dosisDisponibles/5) ? 'var(--bg-verde)' : 'var(--bg-tan)'};"></div>`).join('');
return `<div class="rounded-2xl p-2.5" style="background:#fff; border:2px solid var(--bg-borde);">
<div class="flex items-start justify-between gap-2">
<div>
<p class="text-sm font-bold" style="color:var(--bg-oscuro);">${s.nombre}</p>
<p class="text-xs" style="color:var(--bg-cafe);">${s.raza || 'Sin raza registrada'}</p>
</div>
<span style="font-size:10px; font-weight:bold; padding:2px 8px; border-radius:999px; background:${fondoBadge}; color:${colorBadge}; white-space:nowrap;">${s.dosisDisponibles} dosis</span>
</div>
<div class="flex gap-1 mt-2">${barras}</div>
<div class="flex justify-end gap-2 mt-2">
<button onclick="ajustarDosisSemental('${s.id}', -1)" style="color:#B91C1C; width:28px; height:28px;"><i class="fa-solid fa-minus"></i></button>
<button onclick="ajustarDosisSemental('${s.id}', 1)" style="color:var(--bg-verde); width:28px; height:28px;"><i class="fa-solid fa-plus"></i></button>
<button onclick="eliminarSemental('${s.id}')" style="color:#B91C1C; width:28px; height:28px;"><i class="fa-solid fa-trash"></i></button>
</div>
</div>`;
}).join('');
}
// Descuenta una dosis del semental usado, solo si el servicio fue
// inseminación artificial y el nombre coincide con uno del catálogo — si el
// productor escribió un nombre que no está en el catálogo (monta directa con
// un toro propio, por ejemplo), no se descuenta nada, simplemente se guarda
// el texto tal como lo escribió.
function descontarDosisSementalSiAplica(nombreUsado, tipoServicio){
if (tipoServicio !== 'inseminacion_artificial' || !nombreUsado) return;
const s = estado.sementales.find(s => s.nombre.trim().toLowerCase() === nombreUsado.trim().toLowerCase());
if (!s) return;
if (s.dosisDisponibles <= 0){ mostrarToast(`Aviso: ${s.nombre} ya no tenía dosis registradas — de todos modos se guardó el servicio`); return; }
s.dosisDisponibles -= 1;
}
// ================= CALENDARIO REPRODUCTIVO VISUAL (tipo Gantt) =================
// En vez de ver los registros de reproducción en una lista de texto, aquí se
// ven acomodados en el tiempo — una fila por vaca, con barras de color que
// muestran en qué etapa estuvo/está cada quien a lo largo del año: en
// servicio (sin diagnóstico todavía), gestando, seca, o lactando.
let anioCalendarioReproductivo = new Date().getFullYear();
const COLORES_ETAPA_REPRO = { servicio:'#7C3AED', gestando:'#DB2777', seca:'#F59E0B', lactando:'#16A34A' };
const ETIQUETAS_ETAPA_REPRO = { servicio:'Servicio (sin diagnóstico)', gestando:'Gestando', seca:'Seca', lactando:'Lactando' };
function calcularPeriodosReproductivos(){
const porVaca = {};
estado.reproduccion.forEach(r => {
if (!r.vaca) return;
(porVaca[r.vaca] = porVaca[r.vaca] || []).push(r);
});
const resultado = [];
Object.keys(porVaca).forEach(vaca => {
const registros = porVaca[vaca].slice().sort((a,b) => new Date(a.fecha||0) - new Date(b.fecha||0));
const periodos = [];
registros.forEach((r, i) => {
const finGestacion = r.partoReal || (r.diagnostico === 'confirmada' ? r.parto : null);
if (r.fecha && finGestacion){
periodos.push({ tipo:'gestando', inicio:r.fecha, fin:finGestacion });
} else if (r.fecha && r.diagnostico !== 'confirmada'){
// Todavía sin diagnóstico — se marca un tramo corto (21 días, el ciclo
// de celo) nada más para que se vea el punto de partida en el calendario.
periodos.push({ tipo:'servicio', inicio:r.fecha, fin: sumarDias(r.fecha, 21) });
}
if (r.secado && r.partoReal){
periodos.push({ tipo:'seca', inicio:r.secado, fin:r.partoReal });
}
if (r.partoReal){
const siguienteFecha = (registros[i+1] && registros[i+1].fecha) ? registros[i+1].fecha : hoyISO();
periodos.push({ tipo:'lactando', inicio:r.partoReal, fin: siguienteFecha });
}
});
resultado.push({ vaca, periodos });
});
return resultado;
}
function renderCalendarioReproductivo(){
document.getElementById('calendario-repro-anio-label').textContent = anioCalendarioReproductivo;
const cont = document.getElementById('calendario-repro-cuerpo');
if (!cont) return;
const datos = calcularPeriodosReproductivos();
if (datos.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-4" style="color:var(--sage);">Aún no hay registros de reproducción</p>`;
return;
}
const inicioAnio = new Date(anioCalendarioReproductivo, 0, 1);
const finAnio = new Date(anioCalendarioReproductivo, 11, 31);
const diasAnio = Math.round((finAnio - inicioAnio) / 86400000) + 1;
const mesesHtml = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'].map(m => `<div style="flex:1; text-align:center; font-size:9px; font-weight:bold; color:var(--sage);">${m}</div>`).join('');
const filas = datos.map(d => {
const barras = d.periodos.map(p => {
let ini = new Date(p.inicio); let fin = new Date(p.fin);
if (isNaN(ini) || isNaN(fin) || fin < inicioAnio || ini > finAnio) return '';
if (ini < inicioAnio) ini = inicioAnio;
if (fin > finAnio) fin = finAnio;
const left = ((ini - inicioAnio) / 86400000) / diasAnio * 100;
const width = Math.max(0.8, ((fin - ini) / 86400000) / diasAnio * 100);
return `<div title="${ETIQUETAS_ETAPA_REPRO[p.tipo]}: ${p.inicio} a ${p.fin}" style="position:absolute; left:${left}%; width:${width}%; top:2px; bottom:2px; background:${COLORES_ETAPA_REPRO[p.tipo]}; border-radius:4px;"></div>`;
}).join('');
return `<div class="flex items-center gap-2 mb-1.5">
<div style="width:66px; flex-shrink:0; font-size:10px; font-weight:bold; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${d.vaca}">${d.vaca}</div>
<div style="flex:1; height:16px; background:var(--parchment); border-radius:4px; position:relative;">${barras}</div>
</div>`;
}).join('');
cont.innerHTML = `
<div class="flex gap-2 mb-1"><div style="width:66px; flex-shrink:0;"></div><div style="flex:1; display:flex;">${mesesHtml}</div></div>
${filas}
<div class="flex gap-3 flex-wrap mt-3">
${Object.keys(COLORES_ETAPA_REPRO).map(k => `<span style="display:flex; align-items:center; gap:4px; font-size:10px;"><span style="width:10px; height:10px; border-radius:3px; background:${COLORES_ETAPA_REPRO[k]}; display:inline-block;"></span>${ETIQUETAS_ETAPA_REPRO[k]}</span>`).join('')}
</div>`;
}
function abrirCalendarioReproductivo(){
anioCalendarioReproductivo = new Date().getFullYear();
document.getElementById('modal-calendario-reproductivo').classList.remove('hidden');
renderCalendarioReproductivo();
}
function cerrarCalendarioReproductivo(){
document.getElementById('modal-calendario-reproductivo').classList.add('hidden');
}
function cambiarAnioCalendarioReproductivo(delta){
anioCalendarioReproductivo += delta;
renderCalendarioReproductivo();
}
function guardarReproduccion(){
if (!marcarCamposFaltantes([{ id:'f-vaca', etiqueta:'Arete o nombre de la vaca' }, { id:'f-fecha', etiqueta:'Fecha' }])) return;
// El campo de la vaca es de texto libre con autocompletar — no filtra por
// sexo, así que por error se podría seleccionar un macho. Si el animal está
// registrado en el hato y su sexo es macho, se avisa y se detiene el
// guardado (a diferencia de otros avisos de este pack, este sí bloquea,
// porque un registro reproductivo de un macho como "vaca" no tiene sentido
// y ensuciaría los reportes).
const animalVaca = buscarAncestroPorIdentificador(valor('f-vaca'));
if (animalVaca && animalVaca.sexo === 'macho'){
mostrarToast(`${valor('f-vaca')} está registrado como macho en tu hato — un parto/servicio no se le puede asignar a él`);
marcarErrorCampo('f-vaca', 'Arete o nombre de la vaca');
return;
}
const secado = document.getElementById('f-secado') ? valor('f-secado') : '';
const partoReal = document.getElementById('f-parto-real') ? valor('f-parto-real') : '';
const cierreLactancia = document.getElementById('f-cierre-lactancia') ? valor('f-cierre-lactancia') : '';
const finPeriodoSeco = document.getElementById('f-fin-periodo-seco') ? valor('f-fin-periodo-seco') : '';
const fecha = valor('f-fecha');
const fechaProximoCelo = fecha ? sumarDias(fecha, 21) : null;
estado.reproduccion.push({ vaca: valor('f-vaca'), servicio: valor('f-servicio'), fecha, toro: valor('f-toro'), diagnostico: valor('f-diagnostico'), parto: valor('f-parto'), secado, partoReal, cierreLactancia, finPeriodoSeco, fechaProximoCelo, celoDescartado: false });
descontarDosisSementalSiAplica(valor('f-toro'), valor('f-servicio'));
// Alta automática de la cría: si se registró fecha real de parto y al menos
// el sexo de la cría, se da de alta sola como animal nuevo del hato, ligada
// a esta madre — antes había que ir al Módulo A y capturarla toda a mano.
const criaSexo = document.getElementById('f-cria-sexo') ? valor('f-cria-sexo') : '';
if (partoReal && criaSexo){
const criaArete = (document.getElementById('f-cria-arete') ? valor('f-cria-arete') : '').trim();
// Mismo resguardo que se usa al dar de alta un animal a mano — sin esto, se
// podía escribir por error el arete de un animal que ya existe y quedar
// duplicado sin ningún aviso, ya que esta alta automática no pasaba por la
// misma revisión.
if (criaArete && estado.animales.some(a => a.arete === criaArete)){
mostrarToast(`Ya existe un animal con el arete ${criaArete} — el registro reproductivo sí se guardó, pero da de alta la cría a mano en el Módulo A con un arete distinto`);
} else {
const criaPeso = document.getElementById('f-cria-peso') ? valor('f-cria-peso') : '';
const nuevaCria = {
arete: criaArete, chip:'', nombre:'', raza:'', sexo: criaSexo, fecha: partoReal,
estatus:'activo', proposito:'', potrero:'', madre: valor('f-vaca'), padre: valor('f-toro') || '',
motivoBaja:'', engordaFinalizado:false,
};
estado.animales.push(nuevaCria);
if (criaPeso){
estado.pesajes.push({ animal: criaArete || nuevaCria.nombre || `cría de ${valor('f-vaca')}`, fecha: partoReal, peso: Number(criaPeso), lote:'', condicionCorporal: null });
}
mostrarToast(`Registro guardado — cría dada de alta sola en el hato (${criaSexo})`);
}
limpiarCampos(['f-cria-arete','f-cria-sexo','f-cria-peso']);
} else {
mostrarToast(tr('escaneo_codigo_barras__registro_reproductivo_guardado_se'));
}
limpiarCampos(['f-vaca','f-fecha','f-toro','f-parto','f-secado','f-parto-real','f-cierre-lactancia','f-fin-periodo-seco']);
cambiarSubtab('ver'); actualizarBadgeNotificaciones();
}
function autocalcularFinSecado(){
const campo = document.getElementById('f-fin-periodo-seco');
const cierre = valor('f-cierre-lactancia');
if (!campo || !cierre) return;
campo.value = sumarDias(cierre, 55); 
}
function marcarAnimalCargado(i){
const r = estado.reproduccion[i];
if (!r) return;
r.diagnostico = 'confirmada';
renderNotificaciones();
mostrarToast(`${r.vaca} marcada como cargada — corriendo días de gestación`);
}
function descartarAlertaCelo(i){
const r = estado.reproduccion[i];
if (!r || !r.fechaProximoCelo) return;
r.fechaProximoCelo = sumarDias(r.fechaProximoCelo, 5);
renderNotificaciones();
mostrarToast(tr('escaneo_codigo_barras__se_seguira_vigilando_5_dias'));
}
function guardarPesaje(){
if (!marcarCamposFaltantes([{ id:'f-animal', etiqueta:'Arete o nombre del animal' }, { id:'f-fecha', etiqueta:'Fecha' }, { id:'f-peso', etiqueta:'Peso' }])) return;
const condicion = valor('f-condicion');
estado.pesajes.push({ animal: valor('f-animal'), fecha: valor('f-fecha'), peso: Number(valor('f-peso')), lote: valor('f-lote'), condicionCorporal: (condicion && condicion !== 'no_evaluada') ? condicion : null });
limpiarCampos(['f-animal','f-fecha','f-peso']);
cambiarSubtab('ver'); mostrarToast(tr('escaneo_codigo_barras__pesaje_guardado'));
}
let mapaPotreroInstancia = null;
let dibujoPotreroCapa = null;
let poligonoPotreroActual = null;
let marcadorUbicacionPotrero = null;
let modoMapaPotrero = 'leaflet';
let googleMapsPotreroInstancia = null;
let googleDrawingManagerPotrero = null;
let googlePoligonoPotrero = null;

function inicializarMapaPotrero(){
const contenedor = document.getElementById('mapa-potrero');
if (!contenedor) return;
modoMapaPotrero = 'leaflet';
setTimeout(() => {
// Leaflet/Draw/Turf se descargan aquí, solo la primera vez que alguien
// abre un mapa de potrero — antes se cargaban siempre, para todos.
cargarMapasSiNecesario().then(() => {
if (mapaPotreroInstancia){ mapaPotreroInstancia.remove(); mapaPotreroInstancia = null; }
poligonoPotreroActual = null;
marcadorUbicacionPotrero = null;
document.getElementById('mapa-potrero-resumen').classList.add('hidden');

const centroInicial = (typeof estadoUbicacion !== 'undefined' && estadoUbicacion) ? [estadoUbicacion.lat, estadoUbicacion.lng] : [23.75, -104.75];
mapaPotreroInstancia = L.map('mapa-potrero').setView(centroInicial, 15);
// Esri World Imagery: satélite libre, sin registro ni token
L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
maxZoom: 19,
attribution: 'Tiles © Esri'
}).addTo(mapaPotreroInstancia);
// Nombres de poblaciones, caminos y referencias, superpuestos sobre el satélite
L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}', {
maxZoom: 19,
attribution: 'Tiles © Esri'
}).addTo(mapaPotreroInstancia);

dibujoPotreroCapa = new L.FeatureGroup();
mapaPotreroInstancia.addLayer(dibujoPotreroCapa);

const controlDibujo = new L.Control.Draw({
draw: {
polygon: { allowIntersection: false, showArea: true, shapeOptions: { color: '#3C6B4F' } },
marker: false, circle: false, circlemarker: false, polyline: false, rectangle: false
},
edit: { featureGroup: dibujoPotreroCapa, remove: true }
});
mapaPotreroInstancia.addControl(controlDibujo);

mapaPotreroInstancia.on(L.Draw.Event.CREATED, e => {
dibujoPotreroCapa.clearLayers();
const capa = e.layer;
dibujoPotreroCapa.addLayer(capa);
procesarPoligonoPotrero(capa.toGeoJSON());
});
mapaPotreroInstancia.on(L.Draw.Event.EDITED, e => {
e.layers.eachLayer(capa => procesarPoligonoPotrero(capa.toGeoJSON()));
});
mapaPotreroInstancia.on(L.Draw.Event.DELETED, () => {
poligonoPotreroActual = null;
document.getElementById('mapa-potrero-resumen').classList.add('hidden');
});

setTimeout(() => mapaPotreroInstancia.invalidateSize(), 200);
// Intenta centrar automáticamente en la ubicación real del productor
ubicarmePotrero(true);
});
}, 50);
}

function procesarPoligonoPotrero(geoJsonFeatureOGeometria){
const geoJson = geoJsonFeatureOGeometria.type === 'Feature' ? geoJsonFeatureOGeometria : { type: 'Feature', properties: {}, geometry: geoJsonFeatureOGeometria };
const areaM2 = turf.area(geoJson);
const hectareas = Number((areaM2 / 10000).toFixed(2));
const centro = turf.centroid(geoJson).geometry.coordinates;
poligonoPotreroActual = { geojson: geoJson.geometry, hectareas, ubicacionCentral: { lat: centro[1], lng: centro[0] } };
document.getElementById('mapa-potrero-hectareas').textContent = hectareas + ' ha';
document.getElementById('mapa-potrero-centro').textContent = centro[1].toFixed(5) + ', ' + centro[0].toFixed(5);
document.getElementById('mapa-potrero-resumen').classList.remove('hidden');
}

function ubicarmePotrero(silencioso){
if (!navigator.geolocation){
if (!silencioso) mostrarToast(tr('render_modulos_f__geolocalizacion_no_disponible'));
return;
}
if (!silencioso) mostrarToast(tr('render_modulos_f__ubicando'));
navigator.geolocation.getCurrentPosition(pos => {
const lat = pos.coords.latitude, lng = pos.coords.longitude;
if (modoMapaPotrero === 'google' && googleMapsPotreroInstancia){
googleMapsPotreroInstancia.setCenter({ lat, lng });
googleMapsPotreroInstancia.setZoom(17);
if (marcadorUbicacionPotrero) marcadorUbicacionPotrero.setMap(null);
marcadorUbicacionPotrero = new google.maps.Marker({ position: { lat, lng }, map: googleMapsPotreroInstancia, title: tr('render_modulos_f__usar_mi_ubicacion_actual') });
} else if (mapaPotreroInstancia){
mapaPotreroInstancia.setView([lat, lng], 17);
if (marcadorUbicacionPotrero) mapaPotreroInstancia.removeLayer(marcadorUbicacionPotrero);
marcadorUbicacionPotrero = L.circleMarker([lat, lng], { radius: 8, color: '#2563EB', fillColor: '#3B82F6', fillOpacity: 0.9, weight: 2 }).addTo(mapaPotreroInstancia);
}
}, () => {
if (!silencioso) mostrarToast(tr('render_modulos_f__no_se_pudo_obtener_ubicacion'));
}, { enableHighAccuracy: true, timeout: 8000 });
}

async function buscarLugarPotrero(){
const texto = valor('mapa-potrero-buscar');
if (!texto) return;
mostrarToast(tr('render_modulos_f__buscando'));
try {
const url = `https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=mx&q=${encodeURIComponent(texto)}`;
const resp = await fetch(url, { headers: { 'Accept-Language': idiomaActual || 'es' } });
const resultados = await resp.json();
if (!resultados.length){ mostrarToast(tr('render_modulos_f__no_se_encontro_el_lugar')); return; }
const lat = Number(resultados[0].lat), lng = Number(resultados[0].lon);
if (modoMapaPotrero === 'google' && googleMapsPotreroInstancia){
googleMapsPotreroInstancia.setCenter({ lat, lng });
googleMapsPotreroInstancia.setZoom(15);
} else if (mapaPotreroInstancia){
mapaPotreroInstancia.setView([lat, lng], 15);
}
} catch(e){
mostrarToast(tr('render_modulos_f__no_se_encontro_el_lugar'));
}
}

function activarGoogleMapsPotrero(){
if (!GOOGLE_MAPS_API_KEY){
mostrarToast(tr('render_modulos_f__falta_api_key_google'));
return;
}
if (window.google && window.google.maps){
inicializarGoogleMapsPotrero();
return;
}
mostrarToast(tr('render_modulos_f__cargando_google_maps'));
window.callbackGoogleMapsPotrero = inicializarGoogleMapsPotrero;
const script = document.createElement('script');
script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=drawing,geometry,places&callback=callbackGoogleMapsPotrero`;
script.async = true;
document.head.appendChild(script);
}

function inicializarGoogleMapsPotrero(){
modoMapaPotrero = 'google';
poligonoPotreroActual = null;
marcadorUbicacionPotrero = null;
document.getElementById('mapa-potrero-resumen').classList.add('hidden');
const contenedor = document.getElementById('mapa-potrero');
if (!contenedor) return;
if (mapaPotreroInstancia){ mapaPotreroInstancia.remove(); mapaPotreroInstancia = null; }
contenedor.innerHTML = '';

const centroInicial = (typeof estadoUbicacion !== 'undefined' && estadoUbicacion) ? { lat: estadoUbicacion.lat, lng: estadoUbicacion.lng } : { lat: 23.75, lng: -104.75 };
googleMapsPotreroInstancia = new google.maps.Map(contenedor, {
center: centroInicial, zoom: 15, mapTypeId: 'hybrid',
streetViewControl: false, fullscreenControl: false
});

googleDrawingManagerPotrero = new google.maps.drawing.DrawingManager({
drawingMode: google.maps.drawing.OverlayType.POLYGON,
drawingControl: true,
drawingControlOptions: { drawingModes: [google.maps.drawing.OverlayType.POLYGON] },
polygonOptions: { fillColor: '#3C6B4F', fillOpacity: 0.35, strokeColor: '#3C6B4F', strokeWeight: 3, editable: true }
});
googleDrawingManagerPotrero.setMap(googleMapsPotreroInstancia);

const procesarPoligonoGoogle = poligono => {
if (googlePoligonoPotrero && googlePoligonoPotrero !== poligono) googlePoligonoPotrero.setMap(null);
googlePoligonoPotrero = poligono;
const anillo = poligono.getPath().getArray().map(p => [p.lng(), p.lat()]);
if (anillo.length) anillo.push(anillo[0]);
procesarPoligonoPotrero({ type: 'Polygon', coordinates: [anillo] });
['insert_at', 'set_at', 'remove_at'].forEach(evento => {
google.maps.event.clearListeners(poligono.getPath(), evento);
poligono.getPath().addListener(evento, () => procesarPoligonoGoogle(poligono));
});
};

google.maps.event.addListener(googleDrawingManagerPotrero, 'polygoncomplete', poligono => {
googleDrawingManagerPotrero.setDrawingMode(null);
procesarPoligonoGoogle(poligono);
});

ubicarmePotrero(true);
}

function guardarPotrero(){
if (!marcarCamposFaltantes([{ id:'f-nombre', etiqueta:'Nombre del potrero' }])) return;
if (!poligonoPotreroActual){ mostrarToast(tr('render_modulos_f__traza_el_poligono_en_el_mapa') || 'Traza el polígono del potrero en el mapa'); return; }
estado.potreros.push({
nombre: valor('f-nombre'),
hectareas: poligonoPotreroActual.hectareas,
ubicacionCentral: poligonoPotreroActual.ubicacionCentral,
geojson: poligonoPotreroActual.geojson,
capacidad: Number(valor('f-capacidad')) || 0,
color: valor('f-color') || '#3C6B4F',
animales: 0
});
poligonoPotreroActual = null;
limpiarCampos(['f-nombre','f-capacidad']);
cambiarSubtab('ver'); mostrarToast(tr('escaneo_codigo_barras__potrero_guardado'));
}

function verMapaPotrero(nombre){
const p = estado.potreros.find(x => x.nombre === nombre);
if (!p || !p.geojson){ mostrarToast(tr('render_modulos_f__este_potrero_no_tiene_mapa') || 'Este potrero no tiene un polígono guardado'); return; }
const cuerpo = document.getElementById('modulo-cuerpo');
cuerpo.innerHTML = `
<div class="space-y-3">
<button onclick="renderListaModulo('E')" class="text-sm font-bold" style="color:var(--pine);"><i class="fa-solid fa-arrow-left mr-1"></i>${tr('render_modulos_f__volver_a_la_lista') || 'Volver a la lista'}</button>
<p class="font-bold">${p.nombre} — ${p.hectareas || 0} ha</p>
<div id="mapa-potrero-consulta" style="height:320px; border-radius:1rem; overflow:hidden; border:2px solid var(--line);"></div>
<button onclick="descargarMapaPotrero('${p.nombre.replace(/'/g, "\\'")}')" class="w-full btn-primario-plano" style="background:var(--pine);">
<i class="fa-solid fa-download"></i><span>${tr('render_modulos_f__descargar_mapa') || 'Descargar mapa'}</span>
</button>
</div>`;
setTimeout(() => {
cargarMapasSiNecesario().then(() => {
const mapaConsulta = L.map('mapa-potrero-consulta');
L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
maxZoom: 19, attribution: 'Tiles © Esri'
}).addTo(mapaConsulta);
const capa = L.geoJSON(p.geojson, { style: { color: p.color || '#3C6B4F', weight: 3 } }).addTo(mapaConsulta);
mapaConsulta.fitBounds(capa.getBounds(), { padding: [20, 20] });
setTimeout(() => mapaConsulta.invalidateSize(), 200);
});
}, 50);
}

function descargarMapaPotrero(nombre){
const contenedor = document.getElementById('mapa-potrero-consulta');
if (!contenedor) return;
// html2canvas es pesada y casi nadie descarga el mapa como imagen — se
// descarga solo la primera vez que se usa este botón puntual.
cargarHtml2CanvasSiNecesario().then(() => {
html2canvas(contenedor, { useCORS: true, allowTaint: true }).then(canvas => {
const link = document.createElement('a');
link.download = `potrero_${nombre}.png`.replace(/\s+/g, '_');
link.href = canvas.toDataURL('image/png');
link.click();
}).catch(() => {
mostrarToast(tr('render_modulos_f__no_se_pudo_generar_la_imagen') || 'No se pudo generar la imagen del mapa');
});
});
}
function guardarCosto(){
if (!marcarCamposFaltantes([{ id:'f-monto', etiqueta:'Monto' }, { id:'f-fecha', etiqueta:'Fecha' }])) return;
estado.costos.push({ tipo: valor('f-tipo-mov'), categoria: valor('f-categoria'), monto: Number(valor('f-monto')), fecha: valor('f-fecha'), imputar: valor('f-imputar'), descripcion: valor('f-descripcion'), contacto: (document.getElementById('f-contacto') ? valor('f-contacto') : '').trim() });
limpiarCampos(['f-monto','f-fecha','f-imputar','f-descripcion','f-contacto']);
cambiarSubtab('ver'); mostrarToast(tr('escaneo_codigo_barras__movimiento_guardado'));
}
function guardarLeche(){
if (!marcarCamposFaltantes([{ id:'f-animal', etiqueta:'Arete o nombre del animal' }, { id:'f-fecha', etiqueta:'Fecha' }])) return;
const am = Number(valor('f-litros-am')) || 0, pm = Number(valor('f-litros-pm')) || 0;
estado.produccionLeche.push({ animal: valor('f-animal'), fecha: valor('f-fecha'), ordenador: valor('f-ordenador'), litrosAM: am, litrosPM: pm, total: am + pm, grasa: valor('f-grasa'), proteina: valor('f-proteina'), celulas: valor('f-celulas'), notas: valor('f-notas') });
limpiarCampos(['f-animal','f-fecha','f-ordenador','f-litros-am','f-litros-pm','f-grasa','f-proteina','f-celulas','f-notas']);
cambiarSubtab('ver'); mostrarToast(tr('escaneo_codigo_barras__ordena_registrada'));
}
function guardarTanque(){
if (!marcarCamposFaltantes([{ id:'f-fecha', etiqueta:'Fecha' }, { id:'f-litros-acopiados', etiqueta:'Litros acopiados' }])) return;
estado.tanqueLeche.push({ fecha: valor('f-fecha'), litrosAcopiados: Number(valor('f-litros-acopiados'))||0, temperatura: valor('f-temperatura'), recolectado: valor('f-recolectado'), comprador: valor('f-comprador'), precioLitro: Number(valor('f-precio-litro'))||0, bonos: Number(valor('f-bonos'))||0, descuentos: Number(valor('f-descuentos'))||0, notas: valor('f-notas') });
limpiarCampos(['f-fecha','f-litros-acopiados','f-temperatura','f-comprador','f-precio-litro','f-bonos','f-descuentos','f-notas']);
cambiarSubtab('ver'); mostrarToast(tr('escaneo_codigo_barras__registro_de_tanque_guardado'));
}
function guardarAlimentacionLeche(){
if (!marcarCamposFaltantes([{ id:'f-animal', etiqueta:'Arete o nombre del animal' }, { id:'f-fecha', etiqueta:'Fecha' }])) return;
estado.alimentacionLeche.push({ animal: valor('f-animal'), fecha: valor('f-fecha'), etapa: valor('f-etapa'), racion: valor('f-racion'), kgConcentrado: Number(valor('f-kg-concentrado'))||0, notas: valor('f-notas') });
limpiarCampos(['f-animal','f-fecha','f-racion','f-kg-concentrado','f-notas']);
cambiarSubtab('ver'); mostrarToast(tr('escaneo_codigo_barras__registro_de_alimentacion_guardado'));
}
function actualizarInventarioAlimento(){
const producto = valor('inv-producto').trim();
const kg = Number(valor('inv-kg'));
if (!marcarCamposFaltantes([{ id:'inv-producto', etiqueta:'Producto' }, { id:'inv-kg', etiqueta:'Kilos' }])) return;
if (isNaN(kg)){ mostrarToast(tr('inventario_alimento__escribe_el_producto_y_los')); return; }
const hoy = new Date().toISOString().slice(0,10);
const existente = estado.inventarioAlimento.find(i => i.producto.toLowerCase() === producto.toLowerCase());
if (existente){ existente.kg = kg; existente.fecha = hoy; }
else estado.inventarioAlimento.push({ producto, kg, fecha: hoy });
limpiarCampos(['inv-producto','inv-kg']);
renderInventarioAlimento();
mostrarToast(tr('inventario_alimento__inventario_actualizado'));
}
function consumoDiarioPromedio(){
if (estado.alimentacionLeche.length === 0) return 0;
const fechas = new Set(estado.alimentacionLeche.map(r => r.fecha).filter(Boolean));
const totalKg = estado.alimentacionLeche.reduce((s,r) => s + (r.kgConcentrado || 0), 0);
return fechas.size > 0 ? totalKg / fechas.size : 0;
}
function renderInventarioAlimento(){
const cont = document.getElementById('lista-inventario-alimento');
if (!cont) return;
if (estado.inventarioAlimento.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-2" style="color:var(--sage);">${tr('inventario_alimento__aun_no_registras_existencias')}</p>`;
return;
}
const consumoDiario = consumoDiarioPromedio();
cont.innerHTML = estado.inventarioAlimento.map(i => {
const diasRestantes = consumoDiario > 0 ? Math.floor(i.kg / consumoDiario) : null;
const bajo = diasRestantes !== null && diasRestantes <= 7;
return `<div class="flex items-center justify-between py-2" style="border-top:2px solid var(--line);">
<div><p class="font-semibold text-sm">${i.producto}</p><p class="text-xs" style="color:var(--sage);">${tr('inventario_alimento__kg_actualizado').replace('%VAR%', i.kg).replace('%VAR%', i.fecha)}</p></div>
${diasRestantes !== null ? `<span class="text-xs font-bold px-2 py-1 rounded-full" style="background:${bajo ? 'var(--red)' : 'var(--parchment)'}; color:${bajo ? '#fff' : 'var(--pine)'};">${diasRestantes} días</span>` : ''}
</div>`;
}).join('');
}
function guardarBecerro(){
if (!marcarCamposFaltantes([{ id:'f-animal', etiqueta:'Arete o nombre del becerro' }, { id:'f-fecha', etiqueta:'Fecha' }])) return;
const horasCalostro = Number(valor('f-horas-calostro')) || null;
estado.becerros.push({
animal: valor('f-animal'), fecha: valor('f-fecha'), pesoNacer: Number(valor('f-peso-nacer'))||0,
litrosCalostro: Number(valor('f-litros-calostro'))||0, horasCalostro,
alojamiento: valor('f-alojamiento'), alimentacion: valor('f-alimentacion'),
fechaDestete: valor('f-fecha-destete'), pesoDestete: Number(valor('f-peso-destete'))||null,
notas: valor('f-notas'),
});
limpiarCampos(['f-animal','f-fecha','f-peso-nacer','f-litros-calostro','f-horas-calostro','f-fecha-destete','f-peso-destete','f-notas']);
cambiarSubtab('ver');
mostrarToast(horasCalostro && horasCalostro > 6 ? tr('inventario_alimento__guardado_atencion_el_calostro_se') : tr('inventario_alimento__becerro_registrado'));
}
function guardarBodegaItem(){
const producto = valor('f-producto').trim();
const categoria = valor('f-categoria');
const unidad = valor('f-unidad');
const cantidadComprada = Number(valor('f-cantidad')) || 0;
const costo = Number(valor('f-costo')) || 0;
const stockMinimo = Number(valor('f-stock-minimo')) || 0;
if (!marcarCamposFaltantes([{ id:'f-producto', etiqueta:'Nombre del insumo' }, { id:'f-cantidad', etiqueta:'Cantidad' }])) return;
const hoy = hoyISO();
const existente = estado.bodega.find(i => i.producto.toLowerCase() === producto.toLowerCase() && i.categoria === categoria);
if (existente){
existente.cantidad += cantidadComprada;
existente.costo += costo;
existente.unidad = unidad;
if (stockMinimo) existente.stockMinimo = stockMinimo;
existente.fecha = hoy;
} else {
estado.bodega.push({ id: 'bod_' + Date.now(), producto, categoria, unidad, cantidad: cantidadComprada, costo, stockMinimo, fecha: hoy });
}
limpiarCampos(['f-producto','f-cantidad','f-costo','f-stock-minimo']);
cambiarSubtab('ver');
renderAlertasBodega();
mostrarToast(tr('bodega_e_insumos__existencias_de_bodega_actualizadas'));
}
function renderAlertasBodega(){
const cont = document.getElementById('alertas-bodega');
if (!cont) return;
const bajos = estado.bodega.filter(i => i.cantidad <= i.stockMinimo);
if (bajos.length === 0){ cont.innerHTML = ''; return; }
cont.innerHTML = `<div class="rounded-2xl p-3" style="background:var(--red); color:#fff;">
<p class="font-bold text-sm"><i class="fa-solid fa-triangle-exclamation mr-1"></i>${tr('bodega_e_insumos__existencias_por_agotarse')}</p>
${bajos.map(i => `<p class="text-sm">${i.producto}: quedan ${i.cantidad} ${i.unidad}</p>`).join('')}
</div>`;
}
function descontarInsumoBodega(idInsumo, cantidadUsada){
const item = estado.bodega.find(i => i.id === idInsumo);
if (!item || !cantidadUsada) return;
item.cantidad = Math.max(0, item.cantidad - cantidadUsada);
if (item.cantidad <= item.stockMinimo){
mostrarToast(`Quedan ${item.cantidad} ${item.unidad} de ${item.producto} — considera reabastecer`);
}
}
let carruselIndex = 0;
let carruselInterval = null;
function renderCarruselBoletines(){
const wrap = document.getElementById('carrusel-boletines');
const track = document.getElementById('carrusel-track');
if (!wrap || !track) return;
clearInterval(carruselInterval);
const conImagen = estado.boletines.filter(b => b.imagen);
if (conImagen.length === 0){ wrap.classList.add('hidden'); track.innerHTML = ''; return; }
wrap.classList.remove('hidden');
track.style.transform = 'translateX(0%)';
track.innerHTML = conImagen.map(b => `
<div style="position:relative; width:100%; height:100%; flex-shrink:0;">
<img loading="lazy" decoding="async" src="${b.imagen}" onclick="abrirBoletinDesdeCarrusel(${estado.boletines.indexOf(b)})" style="width:100%; height:100%; object-fit:cover; cursor:pointer;">
<button onclick="abrirBoletinDesdeCarrusel(${estado.boletines.indexOf(b)})" class="text-xs font-bold" style="position:absolute; left:12px; bottom:12px; padding:.5rem 1rem; border-radius:999px; background:rgba(0,0,0,0.55); color:#fff;">
<span>${tr('bodega_e_insumos__leer_mas')}</span> <i class="fa-solid fa-arrow-right text-xs ml-1"></i>
</button>
</div>`).join('');
carruselIndex = 0;
if (conImagen.length > 1){
carruselInterval = setInterval(() => {
carruselIndex = (carruselIndex + 1) % conImagen.length;
track.style.transform = `translateX(-${carruselIndex * 100}%)`;
}, 4000);
}
}
function abrirBoletinDesdeCarrusel(i){
clearInterval(carruselInterval);
abrirModalBoletin(i);
}
function abrirModalBoletin(i){
const b = estado.boletines[i];
if (!b) return;
clearInterval(carruselInterval);
const imgEl = document.getElementById('modal-boletin-imagen');
if (b.imagen){ imgEl.src = b.imagen; imgEl.classList.remove('hidden'); } else { imgEl.classList.add('hidden'); }
document.getElementById('modal-boletin-fecha').textContent = b.fecha;
document.getElementById('modal-boletin-titulo').textContent = b.titulo;
document.getElementById('modal-boletin-texto').textContent = b.texto;
document.getElementById('modal-boletin').classList.remove('hidden');
}
function cerrarModalBoletin(){
document.getElementById('modal-boletin').classList.add('hidden');
renderCarruselBoletines();
}
function renderBoletines(){
renderCarruselBoletines();
const cont = document.getElementById('lista-boletines');
if (estado.boletines.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-bullhorn"></i><p>${tr('bodega_e_insumos__aun_no_hay_boletines_publicados')}</p></div>`;
return;
}
const colores = ['var(--purple)','var(--red)','var(--yellow)','var(--blue)','var(--teal)'];
cont.innerHTML = estado.boletines.map((b,i) => `
<div class="item-registro" style="border-left:6px solid ${colores[i % colores.length]};">
<p class="text-xs font-bold" style="color:${colores[i % colores.length]};">${b.fecha}</p>
<p class="font-bold text-lg mt-1">${b.titulo}</p>
<button onclick="abrirModalBoletin(${i})" class="text-sm font-bold mt-2 flex items-center gap-1" style="color:${colores[i % colores.length]};">
<span>${tr('bodega_e_insumos__leer_mas')}</span><i class="fa-solid fa-arrow-right text-xs"></i>
</button>
</div>`).join('');
}
function reordenarGraficas(){
const cont = document.getElementById('detalle-grafica-cont');
if (!cont) return;
estado.ordenGraficas.forEach(clave => {
const el = document.getElementById('grafica-card-' + clave);
if (!el) return;
cont.appendChild(el);
});
}
// Mapa de cada gráfica: ícono para la lista, nombre para mostrar, y la
// función exacta que la dibuja (se llama solo esa, no todas).
const CATALOGO_GRAFICAS = {
indicadoresLeche: { icono:'fa-droplet', nombre:'Indicadores de leche', fn: () => renderPanelIndicadoresLeche() },
crecimiento: { icono:'fa-arrow-trend-up', nombre:'Crecimiento del hato', fn: () => renderPanelCrecimiento() },
financiero: { icono:'fa-sack-dollar', nombre:'Resumen financiero', fn: () => renderPanelFinanciero() },
sexo: { icono:'fa-chart-pie', nombre:'Composición por sexo', fn: () => renderGraficaSexo() },
prenez: { icono:'fa-heart', nombre:'Tasa de preñez', fn: () => actualizarChartPrenez() },
pesajes: { icono:'fa-weight-scale', nombre:'Evolución de pesajes', fn: () => renderGraficaPesajes() },
costos: { icono:'fa-file-invoice-dollar', nombre:'Costos por categoría', fn: () => renderGraficaCostos() },
fechas: { icono:'fa-calendar-days', nombre:'Próximas fechas importantes', fn: () => renderTimelineFechas() },
potreros: { icono:'fa-map-location-dot', nombre:'Ocupación de potreros', fn: () => actualizarChartPotreros() },
gastosingresos: { icono:'fa-scale-balanced', nombre:'Gastos vs. ingresos', fn: () => actualizarChartGastosIngresos() },
edades: { icono:'fa-chart-simple', nombre:'Edades del hato', fn: () => actualizarChartEdades() },
bajas: { icono:'fa-circle-minus', nombre:'Bajas por causa', fn: () => actualizarChartBajas() },
};
function renderListaGraficasMenu(){
const cont = document.getElementById('lista-graficas-menu');
if (!cont) return;
const orden = (estado.ordenGraficas || Object.keys(CATALOGO_GRAFICAS)).filter(c => CATALOGO_GRAFICAS[c] && estado.visibilidadGraficas[c] !== false);
cont.innerHTML = orden.map(clave => {
const g = CATALOGO_GRAFICAS[clave];
return `<button class="w-full flex items-center gap-3 bg-white rounded-2xl p-4" onclick="abrirGraficaIndividual('${clave}')" style="border:2px solid var(--line); text-align:left;">
<i class="fa-solid ${g.icono}" style="color:var(--pine); width:24px; text-align:center;"></i>
<span class="font-bold flex-1">${g.nombre}</span>
<i class="fa-solid fa-chevron-right" style="color:var(--sage);"></i>
</button>`;
}).join('');
}
// Abre UNA gráfica: esconde la lista, esconde todas las demás tarjetas, y
// solo dibuja la que se pidió — así nunca se cargan las 12 de un jalón.
async function abrirGraficaIndividual(clave){
const g = CATALOGO_GRAFICAS[clave];
if (!g) return;
await cargarChartJsSiNecesario();
document.getElementById('lista-graficas-menu').classList.add('hidden');
document.getElementById('detalle-grafica-cont').classList.remove('hidden');
Object.keys(CATALOGO_GRAFICAS).forEach(otraClave => {
const el = document.getElementById('grafica-card-' + otraClave);
if (el) el.classList.toggle('hidden', otraClave !== clave);
});
try { g.fn(); } catch(e){ console.warn('No se pudo dibujar la gráfica ' + clave, e); }
}
function volverAListaGraficas(){
document.getElementById('detalle-grafica-cont').classList.add('hidden');
document.getElementById('lista-graficas-menu').classList.remove('hidden');
renderListaGraficasMenu();
}
async function actualizarGraficas(){
reordenarGraficas();
renderListaGraficasMenu();
}
function renderGraficaSexo(){
const ctxSexo = document.getElementById('chart-sexo');
if (!ctxSexo) return;
const hembras = estado.animales.filter(a => a.sexo === 'hembra').length;
const machos = estado.animales.filter(a => a.sexo === 'macho').length;
document.getElementById('vacio-chart-sexo').classList.toggle('hidden', estado.animales.length > 0);
if (charts.sexo) charts.sexo.destroy();
charts.sexo = new Chart(ctxSexo, {
type:'doughnut',
data:{ labels:['Hembras','Machos'], datasets:[{ data:[hembras, machos], backgroundColor:['#DB2777','#2563EB'], borderWidth:0 }] },
options:{ responsive:true, maintainAspectRatio:false, cutout:'65%' }
});
}
function renderGraficaPesajes(){
const ctxPesajes = document.getElementById('chart-pesajes');
if (!ctxPesajes) return;
document.getElementById('vacio-chart-pesajes').classList.toggle('hidden', estado.pesajes.length > 0);
if (charts.pesajes) charts.pesajes.destroy();
charts.pesajes = new Chart(ctxPesajes, {
type:'line',
data:{ labels: estado.pesajes.map(p => p.fecha || ''), datasets:[{ label:'Peso (kg)', data: estado.pesajes.map(p => p.peso), borderColor:'#16A34A', backgroundColor:'rgba(22,163,74,0.15)', fill:true, tension:.3 }] },
options:{ responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}} }
});
}
function renderGraficaCostos(){
const ctxCostos = document.getElementById('chart-costos');
if (!ctxCostos) return;
const categorias = ['alimento','medicina','mantenimiento','mano_obra','otro'];
const totales = categorias.map(c => estado.costos.filter(x => x.categoria === c && x.tipo !== 'ingreso').reduce((s,x)=>s+(x.monto||0),0));
document.getElementById('vacio-chart-costos').classList.toggle('hidden', estado.costos.filter(x => x.tipo !== 'ingreso').length > 0);
if (charts.costos) charts.costos.destroy();
charts.costos = new Chart(ctxCostos, {
type:'bar',
data:{ labels:categorias, datasets:[{ label:'Monto', data:totales, backgroundColor:'#F97316' }] },
options:{ responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}} }
});
}
function renderIndicadores(){
const cont = document.getElementById('indicadores-clave');
const total = estado.animales.length;
const bajas = estado.animales.filter(a => a.estatus === 'finado').length;
const mortalidad = total > 0 ? Math.round((bajas / total) * 100) : 0;
const totalReprod = estado.reproduccion.length;
const confirmadas = estado.reproduccion.filter(r => r.diagnostico === 'confirmada').length;
const gestacion = totalReprod > 0 ? Math.round((confirmadas / totalReprod) * 100) : 0;
let pesoProm = '—';
if (estado.pesajes.length > 0){
const suma = estado.pesajes.reduce((s,p) => s + (Number(p.peso) || 0), 0);
pesoProm = Math.round(suma / estado.pesajes.length) + ' kg';
}
const tarjetas = [
{ valor: mortalidad + '%', label: tr('graficas__mortalidad_del_hato'), icono:'fa-heart-pulse', color:'var(--red)' },
{ valor: gestacion + '%', label: tr('graficas__gestaciones_confirmadas'), icono:'fa-heart', color:'var(--pink)' },
{ valor: pesoProm, label: tr('graficas__peso_promedio_registrado'), icono:'fa-weight-scale', color:'var(--green)' },
];
cont.innerHTML = tarjetas.map(t => `
<div class="bg-white rounded-2xl p-3 text-center" style="border:2px solid var(--line); border-top:4px solid ${t.color};">
<i class="fa-solid ${t.icono} mb-1" style="color:${t.color};"></i>
<p class="font-display font-bold text-lg leading-tight">${t.valor}</p>
<p class="text-[11px] leading-tight mt-1" style="color:var(--sage);">${t.label}</p>
</div>`).join('');
}
function renderTimelineFechas(){
const cont = document.getElementById('timeline-fechas');
const hoy = new Date();
const eventos = [];
estado.salud.forEach(r => {
if (r.proxima) eventos.push({ fecha: r.proxima, texto: `Vacuna/tratamiento: ${r.animal || 'animal'} (${r.tipo})`, color:'var(--purple)' });
});
estado.reproduccion.forEach(r => {
if (r.parto && r.diagnostico === 'confirmada') eventos.push({ fecha: r.parto, texto: `Parto estimado: ${r.vaca || 'vaca'}`, color:'var(--pink)' });
});
eventos.sort((a,b) => new Date(a.fecha) - new Date(b.fecha));
const proximos = eventos.filter(e => (new Date(e.fecha) - hoy) / 86400000 <= 90);
if (proximos.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-calendar"></i><p>${tr('graficas__no_hay_fechas_proximas_registradas')}</p></div>`;
return;
}
cont.innerHTML = proximos.map(e => `
<div class="flex items-center gap-3">
<span class="w-3 h-3 rounded-full flex-shrink-0" style="background:${e.color};"></span>
<p class="text-sm"><span class="font-mono font-bold">${e.fecha}</span> — ${e.texto}</p>
</div>`).join('');
}
async function actualizarChartPotreros(){
await cargarChartJsSiNecesario();
const ctx = document.getElementById('chart-potreros');
document.getElementById('vacio-chart-potreros').classList.toggle('hidden', estado.potreros.length > 0);
if (charts.potreros) charts.potreros.destroy();
const nombres = estado.potreros.map(p => p.nombre);
const capacidades = estado.potreros.map(p => Number(p.capacidad) || 0);
const asignados = estado.potreros.map(p => estado.animales.filter(a => a.potrero === p.nombre).length);
charts.potreros = new Chart(ctx, {
type:'bar',
data:{ labels: nombres, datasets:[
{ label:'Capacidad', data: capacidades, backgroundColor:'#E7E1CF' },
{ label: tr('graficas__animales_asignados'), data: asignados, backgroundColor:'#0D9488' },
]},
options:{ responsive:true, maintainAspectRatio:false, plugins:{legend:{position:'bottom'}} }
});
}
function actualizarChartGastosIngresos(){
const ctx = document.getElementById('chart-gastosingresos');
document.getElementById('vacio-chart-gastosingresos').classList.toggle('hidden', estado.costos.length > 0);
if (charts.gastosIngresos) charts.gastosIngresos.destroy();
const meses = {};
estado.costos.forEach(c => {
if (!c.fecha) return;
const mes = c.fecha.slice(0,7); 
if (!meses[mes]) meses[mes] = { gasto:0, ingreso:0 };
meses[mes][c.tipo === 'ingreso' ? 'ingreso' : 'gasto'] += (c.monto || 0);
});
const etiquetas = Object.keys(meses).sort();
charts.gastosIngresos = new Chart(ctx, {
type:'bar',
data:{ labels: etiquetas, datasets:[
{ label:'Gastos', data: etiquetas.map(m => meses[m].gasto), backgroundColor:'#EF4444' },
{ label:'Ingresos', data: etiquetas.map(m => meses[m].ingreso), backgroundColor:'#16A34A' },
]},
options:{ responsive:true, maintainAspectRatio:false, plugins:{legend:{position:'bottom'}} }
});
}
function actualizarChartEdades(){
const ctx = document.getElementById('chart-edades');
const conFecha = estado.animales.filter(a => a.fecha);
document.getElementById('vacio-chart-edades').classList.toggle('hidden', conFecha.length > 0);
if (charts.edades) charts.edades.destroy();
const rangos = [tr('graficas__0_1_ano'),tr('graficas__1_2_anos'),tr('graficas__2_4_anos'),tr('graficas__4_8_anos'),tr('graficas__8_anos')];
function rango(fecha){
const edad = (Date.now() - new Date(fecha)) / (365.25*86400000);
if (edad < 1) return 0; if (edad < 2) return 1; if (edad < 4) return 2; if (edad < 8) return 3; return 4;
}
const hembras = [0,0,0,0,0], machos = [0,0,0,0,0];
conFecha.forEach(a => {
const i = rango(a.fecha);
if (a.sexo === 'hembra') hembras[i]++; else machos[i]++;
});
charts.edades = new Chart(ctx, {
type:'bar',
data:{ labels: rangos, datasets:[
{ label:'Hembras', data: hembras.map(v => -v), backgroundColor:'#DB2777' },
{ label:'Machos', data: machos, backgroundColor:'#2563EB' },
]},
options:{
indexAxis:'y', responsive:true, maintainAspectRatio:false,
plugins:{ legend:{position:'bottom'}, tooltip:{ callbacks:{ label: c => `${c.dataset.label}: ${Math.abs(c.raw)}` } } },
scales:{ x:{ ticks:{ callback: v => Math.abs(v) } } },
}
});
}
function actualizarChartBajas(){
const ctx = document.getElementById('chart-bajas');
const bajas = estado.animales.filter(a => (a.estatus === 'vendido' || a.estatus === 'finado') && a.motivoBaja);
document.getElementById('vacio-chart-bajas').classList.toggle('hidden', bajas.length > 0);
if (charts.bajas) charts.bajas.destroy();
const conteo = {};
bajas.forEach(a => { conteo[a.motivoBaja] = (conteo[a.motivoBaja] || 0) + 1; });
const etiquetas = Object.keys(conteo);
charts.bajas = new Chart(ctx, {
type:'doughnut',
data:{ labels: etiquetas, datasets:[{ data: etiquetas.map(k => conteo[k]), backgroundColor:['#EF4444','#F97316','#F59E0B','#7C3AED','#0D9488','#2563EB'] }] },
options:{ responsive:true, maintainAspectRatio:false, cutout:'60%', plugins:{legend:{position:'bottom'}} }
});
}
function agregarVisitaVet(){
const fecha = valor('visita-fecha'), veterinario = valor('visita-veterinario').trim(), motivo = valor('visita-motivo').trim();
if (!fecha || !veterinario){ mostrarToast(tr('bitacora_visitas_veterinarias__escribe_al_menos_la_fecha')); return; }
estado.visitasVet.unshift({ fecha, veterinario, motivo, observaciones: valor('visita-observaciones') });
limpiarCampos(['visita-fecha','visita-veterinario','visita-motivo','visita-observaciones']);
renderVisitasVet();
mostrarToast(tr('bitacora_visitas_veterinarias__visita_registrada'));
}
function eliminarVisitaVet(i){
const [borrada] = estado.visitasVet.splice(i, 1);
renderVisitasVet();
mostrarToast(tr('bitacora_visitas_veterinarias__visita_eliminada'), () => { estado.visitasVet.splice(i, 0, borrada); renderVisitasVet(); mostrarToast(tr('bitacora_visitas_veterinarias__visita_restaurada')); });
}
function renderVisitasVet(){
const cont = document.getElementById('lista-visitas-vet');
if (!cont) return;
if (estado.visitasVet.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-user-doctor"></i><p>${tr('bitacora_visitas_veterinarias__aun_no_hay_visitas_registradas')}</p></div>`;
return;
}
cont.innerHTML = estado.visitasVet.map((v,i) => `
<div class="item-registro" style="border-left:6px solid var(--purple);">
<div class="flex items-start justify-between gap-2">
<div>
<p class="text-xs font-bold" style="color:var(--purple);">${v.fecha || 'sin fecha'}</p>
<p class="font-bold text-lg mt-1">${v.veterinario}</p>
<p class="text-sm mt-1" style="color:var(--sage);">${v.motivo || 'Sin motivo especificado'}</p>
${v.observaciones ? `<p class="text-sm mt-1">${v.observaciones}</p>` : ''}
</div>
<button onclick="eliminarVisitaVet(${i})" style="color:var(--red);"><i class="fa-solid fa-trash"></i></button>
</div>
</div>`).join('');
}
function renderPanelIndicadoresLeche(){
const panel = document.getElementById('panel-indicadores-leche');
if (!panel) return;
if (estado.tipoGanado !== 'leche'){ panel.classList.add('hidden'); panel.innerHTML = ''; return; }
panel.classList.remove('hidden');
const totalesPorAnimal = {};
estado.produccionLeche.forEach(r => { totalesPorAnimal[r.animal] = (totalesPorAnimal[r.animal] || 0) + (r.total || 0); });
const ranking = Object.entries(totalesPorAnimal).sort((a,b) => b[1] - a[1]).slice(0, 8);
const totalLitros = estado.produccionLeche.reduce((s,r) => s + (r.total || 0), 0);
const totalCostos = estado.costos.filter(c => c.tipo === 'gasto').reduce((s,c) => s + (c.monto || 0), 0);
const costoPorLitro = totalLitros > 0 ? (totalCostos / totalLitros).toFixed(2) : null;
const totalKgConcentrado = estado.alimentacionLeche.reduce((s,r) => s + (r.kgConcentrado || 0), 0);
const eficiencia = totalKgConcentrado > 0 ? (totalLitros / totalKgConcentrado).toFixed(2) : null;
const hoy = new Date(); hoy.setHours(0,0,0,0);
const vacasEnLactancia = estado.reproduccion.filter(r => r.partoReal);
const filasDEL = vacasEnLactancia.map(r => {
const del = Math.round((hoy - new Date(r.partoReal)) / 86400000);
const tieneNuevaPrenez = estado.reproduccion.some(r2 => r2.vaca === r.vaca && r2.diagnostico === 'confirmada' && new Date(r2.fecha || 0) > new Date(r.partoReal));
return { vaca: r.vaca, del, diasAbiertos: tieneNuevaPrenez ? null : del };
});
function badgeRango(valor, rango, unidad){
if (valor === null || valor === undefined || isNaN(valor)) return `<span class="text-xs" style="color:var(--sage);">${tr('bitacora_visitas_veterinarias__sin_datos_suficientes')}</span>`;
const dentro = valor >= rango[0] && valor <= rango[1];
const color = dentro ? 'var(--green)' : 'var(--red)';
return `<span class="text-xs font-bold px-2 py-1 rounded-full" style="background:${color}; color:#fff;">${valor}${unidad} ${dentro ? '(dentro del rango)' : '(fuera de ' + rango[0] + '-' + rango[1] + unidad + ')'}</span>`;
}
const grasas = estado.produccionLeche.map(r => Number(r.grasa)).filter(v => !isNaN(v) && v > 0);
const proteinas = estado.produccionLeche.map(r => Number(r.proteina)).filter(v => !isNaN(v) && v > 0);
const grasaProm = grasas.length ? (grasas.reduce((a,b)=>a+b,0)/grasas.length).toFixed(2) : null;
const proteinaProm = proteinas.length ? (proteinas.reduce((a,b)=>a+b,0)/proteinas.length).toFixed(2) : null;
const serviciosConfirmados = estado.reproduccion.filter(r => r.diagnostico === 'confirmada').length;
const serviciosPorConcepcion = serviciosConfirmados > 0 ? (estado.reproduccion.length / serviciosConfirmados).toFixed(1) : null;
const partosPorVaca = {};
estado.reproduccion.forEach(r => { if (r.partoReal){ (partosPorVaca[r.vaca] = partosPorVaca[r.vaca] || []).push(r.partoReal); } });
const iepValores = [];
Object.values(partosPorVaca).forEach(fechas => {
const ordenadas = fechas.map(f => new Date(f)).sort((a,b) => a-b);
for (let i = 1; i < ordenadas.length; i++) iepValores.push(Math.round((ordenadas[i]-ordenadas[i-1])/86400000));
});
const iepProm = iepValores.length ? Math.round(iepValores.reduce((a,b)=>a+b,0)/iepValores.length) : null;
const diasAbiertosProm = (() => { const vals = filasDEL.filter(f => f.diasAbiertos !== null).map(f => f.diasAbiertos); return vals.length ? Math.round(vals.reduce((a,b)=>a+b,0)/vals.length) : null; })();
panel.innerHTML = `
<div class="grid grid-cols-2 gap-3">
<div class="bg-white rounded-3xl p-4" style="border:2px solid var(--line);">
<p class="text-xs font-bold uppercase" style="color:var(--sage);">${tr('bitacora_visitas_veterinarias__costo_por_litro')}</p>
<p class="font-display text-2xl font-bold mt-1">${costoPorLitro ? '$' + costoPorLitro : '—'}</p>
</div>
<div class="bg-white rounded-3xl p-4" style="border:2px solid var(--line);">
<p class="text-xs font-bold uppercase" style="color:var(--sage);">${tr('bitacora_visitas_veterinarias__eficiencia_alimenticia')}</p>
<p class="font-display text-2xl font-bold mt-1">${eficiencia ? eficiencia + ' L/kg' : '—'}</p>
</div>
</div>
<div class="bg-white rounded-3xl p-5" style="border:2px solid var(--line);">
<p class="font-bold mb-3">${tr('bitacora_visitas_veterinarias__comparativo_contra_referencia_hols')}</p>
<div class="space-y-3">
<div class="flex items-center justify-between"><span class="text-sm">${tr('bitacora_visitas_veterinarias__grasa_promedio')}</span>${badgeRango(grasaProm ? Number(grasaProm) : null, HOLSTEIN_REF.grasa, '%')}</div>
<div class="flex items-center justify-between"><span class="text-sm">${tr('bitacora_visitas_veterinarias__proteina_promedio')}</span>${badgeRango(proteinaProm ? Number(proteinaProm) : null, HOLSTEIN_REF.proteina, '%')}</div>
<div class="flex items-center justify-between"><span class="text-sm">${tr('bitacora_visitas_veterinarias__servicios_por_concepcion')}</span>${badgeRango(serviciosPorConcepcion ? Number(serviciosPorConcepcion) : null, HOLSTEIN_REF.serviciosPorConcepcion, '')}</div>
<div class="flex items-center justify-between"><span class="text-sm">${tr('bitacora_visitas_veterinarias__intervalo_entre_partos_iep')}</span>${badgeRango(iepProm, HOLSTEIN_REF.intervaloPartos, ' días')}</div>
<div class="flex items-center justify-between"><span class="text-sm">${tr('bitacora_visitas_veterinarias__dias_abiertos_promedio')}</span>${badgeRango(diasAbiertosProm, HOLSTEIN_REF.diasAbiertos, ' días')}</div>
</div>
<p class="text-xs mt-3" style="color:var(--sage);">${tr('bitacora_visitas_veterinarias__referencia_raza_holstein_se_necesi')}</p>
</div>
<div class="bg-white rounded-3xl p-5" style="border:2px solid var(--line);">
<p class="font-bold mb-3">${tr('bitacora_visitas_veterinarias__ranking_de_mejores_productoras_lit')}</p>
${ranking.length === 0 ? `<p class="vacio"><i class="fa-solid fa-ranking-star"></i>Aún no hay ordeñas registradas.</p>` :
ranking.map(([animal, litros], i) => `
<div class="flex items-center justify-between py-2" style="border-top:${i>0 ? '2px solid var(--line)' : 'none'};">
<span class="font-semibold text-sm">#${i+1} — ${animal}</span>
<span class="font-bold" style="color:var(--blue);">${litros.toFixed(1)} L</span>
</div>`).join('')}
</div>
<div class="bg-white rounded-3xl p-5" style="border:2px solid var(--line);">
<p class="font-bold mb-3">${tr('bitacora_visitas_veterinarias__dias_en_leche_del_y')}</p>
${filasDEL.length === 0 ? `<p class="vacio"><i class="fa-solid fa-calendar-day"></i>Registra la fecha real de parto en Reproducción para ver este cálculo.</p>` :
filasDEL.map(f => `
<div class="flex items-center justify-between py-2" style="border-top:2px solid var(--line);">
<span class="font-semibold text-sm">${f.vaca}</span>
<span class="text-sm" style="color:var(--sage);">DEL: <b style="color:var(--ink);">${f.del}</b> ${f.diasAbiertos !== null ? `· Días abiertos: <b style="color:var(--ink);">${f.diasAbiertos}</b>` : '· ya preñada'}</span>
</div>`).join('')}
</div>`;
}
function pesoEsperadoPorEdad(meses){
const curva = HOLSTEIN_REF.curvaCrecimiento;
if (meses <= curva[0][0]) return curva[0][1];
if (meses >= curva[curva.length-1][0]) return curva[curva.length-1][1];
for (let i = 1; i < curva.length; i++){
if (meses <= curva[i][0]){
const [m0,p0] = curva[i-1], [m1,p1] = curva[i];
return Math.round(p0 + (p1-p0) * (meses-m0)/(m1-m0));
}
}
return null;
}
function renderPanelCrecimiento(){
const panel = document.getElementById('panel-crecimiento');
if (!panel) return;
const pesajesPorAnimal = {};
estado.pesajes.forEach(r => { if (r.animal && r.fecha) (pesajesPorAnimal[r.animal] = pesajesPorAnimal[r.animal] || []).push(r); });
const alertasBajoCrecimiento = [];
Object.entries(pesajesPorAnimal).forEach(([animal, regs]) => {
const ordenados = regs.slice().sort((a,b) => new Date(a.fecha) - new Date(b.fecha));
if (ordenados.length < 2) return;
const u = ordenados[ordenados.length-1], p = ordenados[ordenados.length-2];
const dias = Math.round((new Date(u.fecha) - new Date(p.fecha)) / 86400000);
if (dias <= 0) return;
const gdp = ((u.peso - p.peso) / dias);
if (gdp <= 0.15) alertasBajoCrecimiento.push({ animal, gdp: gdp.toFixed(2) });
});
const comparativos = [];
estado.animales.filter(a => a.estatus !== 'vendido' && a.estatus !== 'finado' && a.fecha).forEach(a => {
const clave = a.arete || a.nombre;
const regs = pesajesPorAnimal[clave];
if (!regs || regs.length === 0) return;
const ultimo = regs.slice().sort((x,y) => new Date(y.fecha) - new Date(x.fecha))[0];
const meses = (Date.now() - new Date(a.fecha)) / (86400000*30.44);
const esperado = pesoEsperadoPorEdad(meses);
if (esperado === null) return;
comparativos.push({ animal: a.nombre || clave, pesoActual: ultimo.peso, esperado, meses: meses.toFixed(1) });
});
panel.innerHTML = `
<div class="bg-white rounded-3xl p-5" style="border:2px solid var(--line);">
<p class="font-bold mb-3">${tr('bitacora_visitas_veterinarias__crecimiento_y_desarrollo')}</p>
${alertasBajoCrecimiento.length > 0 ? `
<p class="text-xs font-bold uppercase mb-2" style="color:var(--red);">Ganancia de peso baja o nula</p>
${alertasBajoCrecimiento.map(a => `<div class="flex items-center justify-between py-1"><span class="text-sm">${a.animal}</span><span class="text-sm font-bold" style="color:var(--red);">${a.gdp} kg/día</span></div>`).join('')}
<div class="my-3" style="border-top:2px solid var(--line);"></div>` : ''}
${comparativos.length === 0 ? `<p class="vacio"><i class="fa-solid fa-chart-line"></i>Registra pesajes con fecha de nacimiento capturada para ver este comparativo.</p>` :
comparativos.map(c => {
const dentro = c.pesoActual >= c.esperado * 0.85;
return `<div class="flex items-center justify-between py-2" style="border-top:2px solid var(--line);">
<span class="text-sm font-semibold">${c.animal} (${c.meses} meses)</span>
<span class="text-xs font-bold px-2 py-1 rounded-full" style="background:${dentro ? 'var(--green)' : 'var(--red)'}; color:#fff;">${c.pesoActual} kg vs ${c.esperado} kg esperado</span>
</div>`;
}).join('')}
</div>`;
}
function renderPanelFinanciero(){
const panel = document.getElementById('panel-financiero');
if (!panel) return;
const porMes = {};
estado.costos.forEach(c => {
if (!c.fecha) return;
const clave = c.fecha.slice(0,7);
if (!porMes[clave]) porMes[clave] = { ingresos:0, gastos:0 };
if (c.tipo === 'ingreso') porMes[clave].ingresos += c.monto || 0;
else porMes[clave].gastos += c.monto || 0;
});
const meses = Object.keys(porMes).sort();
const porImputado = {};
estado.costos.forEach(c => {
if (!c.imputar) return;
if (!porImputado[c.imputar]) porImputado[c.imputar] = 0;
porImputado[c.imputar] += (c.tipo === 'ingreso' ? 1 : -1) * (c.monto || 0);
});
const rentabilidad = Object.entries(porImputado).sort((a,b) => b[1]-a[1]).slice(0,8);
const totalIngresos = estado.costos.filter(c=>c.tipo==='ingreso').reduce((s,c)=>s+(c.monto||0),0);
const totalGastos = estado.costos.filter(c=>c.tipo==='gasto').reduce((s,c)=>s+(c.monto||0),0);
const totalLitrosOKilos = estado.tipoGanado === 'leche'
? estado.produccionLeche.reduce((s,r)=>s+(r.total||0),0)
: estado.pesajes.reduce((s,r)=>s+(r.peso||0),0);
const precioPromedio = totalLitrosOKilos > 0 ? totalIngresos / totalLitrosOKilos : 0;
const puntoEquilibrio = precioPromedio > 0 ? Math.round(totalGastos / precioPromedio) : null;
const netosMensuales = meses.map(m => porMes[m].ingresos - porMes[m].gastos);
const proyeccion = netosMensuales.length ? (netosMensuales.reduce((a,b)=>a+b,0) / netosMensuales.length) : null;
panel.innerHTML = `
<div class="bg-white rounded-3xl p-5" style="border:2px solid var(--line);">
<p class="font-bold mb-3">${tr('bitacora_visitas_veterinarias__estado_de_resultados_por_mes')}</p>
${meses.length === 0 ? `<p class="vacio"><i class="fa-solid fa-file-invoice-dollar"></i>Aún no hay movimientos registrados en Costos.</p>` :
meses.map(m => `
<div class="flex items-center justify-between py-2" style="border-top:2px solid var(--line);">
<span class="text-sm font-semibold">${m}</span>
<span class="text-sm"><span style="color:var(--green);">+$${porMes[m].ingresos.toFixed(0)}</span> · <span style="color:var(--red);">-$${porMes[m].gastos.toFixed(0)}</span> · <b>${(porMes[m].ingresos-porMes[m].gastos) >= 0 ? '+' : ''}$${(porMes[m].ingresos-porMes[m].gastos).toFixed(0)}</b></span>
</div>`).join('')}
</div>
<div class="grid grid-cols-2 gap-3">
<div class="bg-white rounded-3xl p-4" style="border:2px solid var(--line);">
<p class="text-xs font-bold uppercase" style="color:var(--sage);">${tr('bitacora_visitas_veterinarias__punto_de_equilibrio')}</p>
<p class="font-display text-xl font-bold mt-1">${puntoEquilibrio !== null ? puntoEquilibrio + (estado.tipoGanado === 'leche' ? ' L' : ' kg') : '—'}</p>
</div>
<div class="bg-white rounded-3xl p-4" style="border:2px solid var(--line);">
<p class="text-xs font-bold uppercase" style="color:var(--sage);">${tr('bitacora_visitas_veterinarias__proyeccion_proximo_mes')}</p>
<p class="font-display text-xl font-bold mt-1" style="color:${proyeccion !== null && proyeccion >= 0 ? 'var(--green)' : 'var(--red)'};">${proyeccion !== null ? (proyeccion >= 0 ? '+' : '') + '$' + proyeccion.toFixed(0) : '—'}</p>
</div>
</div>
<div class="bg-white rounded-3xl p-5" style="border:2px solid var(--line);">
<p class="font-bold mb-3">${tr('bitacora_visitas_veterinarias__rentabilidad_por_animal_lote_imput')}</p>
${rentabilidad.length === 0 ? `<p class="vacio"><i class="fa-solid fa-scale-balanced"></i>Usa el campo "Imputar a" en Costos para ver esta rentabilidad.</p>` :
rentabilidad.map(([nombre, neto]) => `
<div class="flex items-center justify-between py-2" style="border-top:2px solid var(--line);">
<span class="text-sm font-semibold">${nombre}</span>
<span class="font-bold" style="color:${neto >= 0 ? 'var(--green)' : 'var(--red)'};">${neto >= 0 ? '+' : ''}$${neto.toFixed(0)}</span>
</div>`).join('')}
</div>`;
}
async function actualizarChartPrenez(){
await cargarChartJsSiNecesario();
const ctx = document.getElementById('chart-prenez');
const diagnosticadas = estado.reproduccion.filter(r => r.diagnostico === 'confirmada' || r.diagnostico === 'no_confirmada');
document.getElementById('vacio-chart-prenez').classList.toggle('hidden', diagnosticadas.length > 0);
if (charts.prenez) charts.prenez.destroy();
if (diagnosticadas.length === 0) return;
const porMes = {};
diagnosticadas.forEach(r => {
if (!r.fecha) return;
const clave = r.fecha.slice(0,7); 
if (!porMes[clave]) porMes[clave] = { confirmadas:0, total:0 };
porMes[clave].total++;
if (r.diagnostico === 'confirmada') porMes[clave].confirmadas++;
});
const meses = Object.keys(porMes).sort();
const tasas = meses.map(m => Math.round((porMes[m].confirmadas / porMes[m].total) * 100));
charts.prenez = new Chart(ctx, {
type:'bar',
data:{ labels: meses, datasets:[{ label: tr('bitacora_visitas_veterinarias__tasa_de_prenez'), data: tasas, backgroundColor:'#DB2777', borderRadius:8 }] },
options:{ responsive:true, maintainAspectRatio:false, plugins:{ legend:{ display:false } }, scales:{ y:{ beginAtZero:true, max:100 } } },
});
}
function renderTodoProductor(){
renderResumenProductor();
renderTiles();
aplicarIconosBotonesEstaticos();
renderNavbar();
renderHato();
renderResumenVientresToros();
renderBoletines();
actualizarBadgeNotificaciones();
actualizarBannerConexion();
renderPruebasCampoCompartidas();
letraActual = 'A'; subtabActual = 'registrar';
irA(quiereAbrirChatDirecto ? 'mensajes' : 'home');
}
function refrescarProductorSinNavegar(){
renderResumenProductor();
renderTiles();
aplicarIconosBotonesEstaticos();
renderNavbar();
renderHato();
renderResumenVientresToros();
renderBoletines();
actualizarBadgeNotificaciones();
actualizarBannerConexion();
renderModulo();
}
function renderGridAdminHome(){
const cont = document.getElementById('grid-admin-home');
if (!cont) return;
// "Métricas de interacción" y "Más funciones" llevan a información de TODO
// el sistema (cuentas de todos los productores, reportes generales,
// configuración) — son exclusivas del administrador de verdad. Antes se
// mostraban siempre, sin importar el rol, así que un veterinario (o
// comité, capturista, etc.) las veía igual que un administrador completo.
const esAdminCompleto = !rolRestringidoActivo();
const btnMetricas = document.getElementById('btn-metricas-admin');
if (btnMetricas) btnMetricas.classList.toggle('hidden', !esAdminCompleto);
const btnMas = document.getElementById('btn-mas-admin');
if (btnMas) btnMas.classList.toggle('hidden', !esAdminCompleto);
// El modo demo es exclusivo del administrador de verdad — ni veterinario,
// ni comité, ni ningún productor lo pueden ver, sin excepción.
const btnModoDemo = document.getElementById('btn-modo-demo-admin');
if (btnModoDemo) btnModoDemo.classList.toggle('hidden', !esAdminCompleto);
// Las pestañas de "Usuarios" (contraseñas de todo el sistema) y "Config"
// tampoco deben verse siquiera — ya están bloqueadas por dentro, pero
// mostrarlas igual sería confuso (tocar algo que rebota a Inicio).
const navUsuarios = document.querySelector('[data-nav-admin="usuarios"]');
if (navUsuarios) navUsuarios.classList.toggle('hidden', !esAdminCompleto);
const navConfig = document.querySelector('[data-nav-admin="config"]');
if (navConfig) navConfig.classList.toggle('hidden', !esAdminCompleto);
const navInfo = document.querySelector('[data-nav-admin="info"]');
if (navInfo) navInfo.classList.toggle('hidden', !esAdminCompleto);
if (estado.modoComite){
const pendTB = (estado.avisosReactoresTB || []).filter(a => a.estatus === 'pendiente').length;
const pendCEFPP = estado.salud.filter(r => r.estadoCEFPP && r.estadoCEFPP !== 'enviado').length;
cont.innerHTML = `
<button onclick="irAdmin('ventanageneraltb')" class="tile-row bg-red col-span-2" style="position:relative;">
<span class="icono"><i class="fa-solid fa-user-doctor"></i></span>
<span>Admin TB — avisos de reactores y médicos de campo</span>
${pendTB > 0 ? `<span class="absolute text-xs font-bold px-2 py-0.5 rounded-full" style="background:#fff; color:var(--red); top:8px; right:8px;"><i class="fa-solid fa-triangle-exclamation mr-1"></i>${pendTB} reactor(es) pendiente(s)</span>` : ''}
</button>
<button onclick="irAdmin('reportestb')" class="tile-row bg-purple col-span-2">
<span class="icono"><i class="fa-solid fa-chart-column"></i></span>
<span>Reportes de pruebas TB</span>
</button>
<button onclick="irAdmin('generartb')" class="tile-row bg-slate col-span-2">
<span class="icono"><i class="fa-solid fa-file-lines"></i></span>
<span>Generar informe general</span>
</button>
<button onclick="irAdmin('cefpp')" class="tile-row bg-teal col-span-2" style="position:relative;">
<span class="icono"><i class="fa-solid fa-shield-virus"></i></span>
<span>Reportes a CEFPP (casos urgentes)</span>
${pendCEFPP > 0 ? `<span class="absolute text-xs font-bold px-2 py-0.5 rounded-full" style="background:#fff; color:var(--red); top:8px; right:8px;">${pendCEFPP}</span>` : ''}
</button>`;
return;
}
if (estado.modoMedicoCampoTB){
const misCasos = (estado.avisosReactoresTB || []).filter(a => a.medicoAsignadoId === estado.medicoComiteActivoId);
const nuevosSinVer = misCasos.filter(a => a.estatus === 'asignado').length;
const cuarentenaLista = misCasos.filter(a => a.fechaFinCuarentena && !a.reProbado && hoyISO() >= a.fechaFinCuarentena).length;
const totalAvisoMedicoTB = nuevosSinVer + cuarentenaLista;
cont.innerHTML = `
<button onclick="irAdmin('medicocampotb')" class="tile-row bg-red col-span-2" style="position:relative;">
<span class="icono"><i class="fa-solid fa-notes-medical"></i></span>
<span>Mis pruebas cervicales comparativas</span>
${totalAvisoMedicoTB > 0 ? `<span class="absolute text-xs font-bold px-2 py-0.5 rounded-full" style="background:#fff; color:var(--red); top:8px; right:8px;">${nuevosSinVer > 0 ? nuevosSinVer + ' nueva(s)' : ''}${nuevosSinVer > 0 && cuarentenaLista > 0 ? ' · ' : ''}${cuarentenaLista > 0 ? cuarentenaLista + ' lista(s) para re-prueba' : ''}</span>` : ''}
</button>`;
return;
}
if (estado.modoCapturistaTB){
const pendientesTB = (estado.pruebasCampoVet || []).filter(p => (p.categoria === 'areteo' || p.leida) && p.tipoPrueba === 'TB' && !p.capturada).length;
cont.innerHTML = `
<button onclick="irAdmin('capturistatb')" class="tile-row bg-teal col-span-2" style="position:relative;">
<span class="icono"><i class="fa-solid fa-keyboard"></i></span>
<span>Capturista TB — pruebas listas para capturar</span>
${pendientesTB > 0 ? `<span class="absolute text-xs font-bold px-2 py-0.5 rounded-full" style="background:var(--red); color:#fff; top:8px; right:8px;">${pendientesTB}</span>` : ''}
</button>`;
return;
}
if (estado.modoCapturista){
const pendientes = (estado.pruebasCampoVet || []).filter(p => (p.categoria === 'areteo' || p.leida) && !p.capturada);
const conReactor = pendientes.filter(p => (p.animales || []).some(a => a.resultado === 'R')).length;
cont.innerHTML = `
<button onclick="irAdmin('pruebascapturista')" class="tile-row bg-teal col-span-2" style="position:relative;">
<span class="icono"><i class="fa-solid fa-keyboard"></i></span>
<span>Pruebas listas para capturar</span>
${pendientes.length > 0 ? `<span class="absolute text-xs font-bold px-2 py-0.5 rounded-full" style="background:${conReactor > 0 ? 'var(--red)' : 'var(--pine)'}; color:#fff; top:8px; right:8px;">${pendientes.length}${conReactor > 0 ? ' (' + conReactor + ' con reactor)' : ''}</span>` : ''}
</button>`;
return;
}
if (estado.modoAlmita){
const sinRevisar = (estado.enviosAlmita || []).filter(e => !e.revisado);
const conReactor = sinRevisar.filter(e => e.reactores > 0).length;
cont.innerHTML = `
<button onclick="irAdmin('almita')" class="tile-row bg-red col-span-2" style="position:relative;">
<span class="icono"><i class="fa-solid fa-envelope-open-text"></i></span>
<span>Centro de solicitudes CEFPP</span>
${sinRevisar.length > 0 ? `<span class="absolute text-xs font-bold px-2 py-0.5 rounded-full" style="background:#fff; color:var(--red); top:8px; right:8px;">${sinRevisar.length}${conReactor > 0 ? ' (' + conReactor + ' con reactor)' : ''}</span>` : ''}
</button>`;
return;
}
if (estado.vistaVeterinario){
const vetActivo = veterinarioActivo();
const idVet = vetActivo ? vetActivo.id : null;
const pendPruebas = (estado.solicitudesPrueba || []).filter(s => s.veterinarioId === idVet && s.estatus === 'pendiente').length;
const pendAretes = (estado.solicitudesAretes || []).filter(s => s.veterinarioId === idVet && s.estatus === 'pendiente').length;
const totalSolicitudesVet = pendPruebas + pendAretes;
cont.innerHTML = `
<button onclick="irAdmin('boletines')" class="tile-row bg-pink col-span-2">
${iconoChicoHTML('vet_boletines', 'fa-bullhorn')}
<span>Boletines</span>
</button>
<button onclick="irAdmin('vetproductores')" class="tile-row bg-orange col-span-2">
${iconoChicoHTML('vet_pacientes', 'fa-users')}
<span>${tr('vet_pacientes__personas_atendidas')}</span>
</button>
<button onclick="irAdmin('vetnotas')" class="tile-row bg-slate col-span-2">
${iconoChicoHTML('vet_notas', 'fa-note-sticky')}
<span>${tr('vet_notas__mis_notas')}</span>
</button>
<button onclick="irAdmin('pruebascampo')" class="tile-row bg-purple col-span-2" style="position:relative;">
${iconoChicoHTML('vet_pruebascampo', 'fa-vial-circle-check')}
<span>Pruebas de campo</span>
${totalSolicitudesVet > 0 ? `<span class="absolute text-xs font-bold px-2 py-0.5 rounded-full" style="background:var(--red); color:#fff; top:8px; right:8px;">${totalSolicitudesVet} solicitud(es)</span>` : ''}
</button>`;
return;
}
// Nota: existía aquí un bloque "if (estado.modoVeterinario)" que nunca se
// podía ejecutar — vistaVeterinario siempre está activo junto con
// modoVeterinario (se ponen juntos al iniciar sesión), así que el bloque de
// arriba (vistaVeterinario) siempre atrapaba primero y regresaba antes de
// llegar aquí. Se quitó por ser código muerto, confirmado por Luis.
cont.innerHTML = `
<button onclick="irAdmin('cuentas')" class="tile bg-red">
${iconoChicoHTML('adm_cuentas', 'fa-id-card-clip')}
<span>${tr('modo_veterinario__cuentas_de')}<br>${tr('modo_veterinario__productores')}</span>
</button>
<button onclick="irAdmin('usuarios')" class="tile bg-blue">
${iconoChicoHTML('adm_usuarios', 'fa-users')}
<span>${tr('modo_veterinario__usuarios_y')}<br>${tr('modo_veterinario__contrasenas')}</span>
</button>
<button onclick="irAdmin('productor')" class="tile bg-orange">
${iconoChicoHTML('adm_productor', 'fa-id-card')}
<span>${tr('modo_veterinario__datos_del')}<br>${tr('modo_veterinario__productor')}</span>
</button>
<button onclick="irAdmin('boletines')" class="tile bg-pink">
${iconoChicoHTML('adm_boletines', 'fa-bullhorn')}
<span>Boletines<br>${tr('modo_veterinario__informativos')}</span>
</button>
<button onclick="irAdmin('config')" class="tile bg-purple">
${iconoChicoHTML('adm_config', 'fa-sliders')}
<span>${tr('modo_veterinario__configuracion')}<br>${tr('modo_veterinario__de_ventanas')}</span>
</button>
<button onclick="irAdmin('solicitudescefp')" class="tile-row bg-teal col-span-2" style="position:relative;">
<span class="icono"><i class="fa-solid fa-user-clock"></i></span>
<span>Solicitudes de cuenta del comité</span>
${(estado.solicitudesCEFP || []).filter(s => s.estatus === 'pendiente').length > 0 ? `<span class="absolute text-xs font-bold px-2 py-0.5 rounded-full" style="background:var(--red); color:#fff; top:8px; right:8px;">${estado.solicitudesCEFP.filter(s => s.estatus === 'pendiente').length}</span>` : ''}
</button>`;
}
function veterinarioActivo(){
return estado.veterinarios.find(v => v.id === estado.veterinarioActivoId) || null;
}
function requiereVeterinarioActivo(silencioso = false){
const ok = !!(estado.vistaVeterinario && veterinarioActivo());
if (!ok && !silencioso && typeof mostrarToast === 'function') mostrarToast('Esta función es solo para el veterinario activo');
return ok;
}
window.iranchRequiereVeterinarioActivo = requiereVeterinarioActivo;
function aplicarVistaSegunRol(){
const btnMas = document.getElementById('btn-mas-admin');
const btnMetricas = document.getElementById('btn-metricas-admin');
const subtitulo = document.getElementById('subtitulo-panel-admin');
const btnPerfilVet = document.getElementById('btn-perfil-vet');
const cajaResumen = document.getElementById('caja-resumen-admin');
const tileInfo = document.getElementById('tile-info-general');
const esVet = !!estado.vistaVeterinario;
// "Más funciones" es la puerta de entrada a Cuentas de productores, Reportes
// regionales, Mensajes y Resumen general — información de negocio de TODAS
// las cuentas, no solo de lo que cada rol necesita ver. Antes solo se
// ocultaba para veterinario; se oculta para CUALQUIER rol que no sea la
// cuenta de administrador general (rueda/luis), incluyendo comité,
// capturista, almita (emisora de solicitudes), capturista TB y médico de
// campo TB — ellos son prestadores de servicio, no dueños del negocio.
const esAdminGeneral = !esVet && !estado.modoComite && !estado.modoCapturista && !estado.modoAlmita
&& !estado.modoMedicoCampoTB && !estado.modoCapturistaTB && !estado.modoTrabajador;
if (btnMas) btnMas.classList.toggle('hidden', !esAdminGeneral);
// Métricas de Interacción es SOLO para la cuenta de administrador general
// Nunca se crea una cuenta de acceso privilegiado por credenciales hardcodeadas;
// personal externo sin relación con la programación/diseño de la app) ni
// para ningún otro rol (capturista, almita, veterinario, médico TB, etc.).
// Se oculta apenas se detecta cualquier bandera de rol que NO sea el admin
// puro, sin importar por cuál entraron.
if (btnMetricas) btnMetricas.classList.toggle('hidden', !esAdminGeneral);
if (cajaResumen) cajaResumen.classList.toggle('hidden', !esAdminGeneral);
if (tileInfo) tileInfo.classList.toggle('hidden', !esAdminGeneral);
if (btnPerfilVet) btnPerfilVet.classList.toggle('hidden', !esVet);
if (subtitulo) subtitulo.textContent = esVet ? (veterinarioActivo() ? veterinarioActivo().nombre + ' · MVZ' : 'MVZ') : 'Panel de administrador';
document.querySelectorAll('#navbar-admin .navbar-item').forEach(btn => {
const nav = btn.getAttribute('data-nav-admin');
if (['usuarios','config','info'].includes(nav)) btn.classList.toggle('hidden', esVet);
});
}
function renderListaVetProductores(){
if (!requiereVeterinarioActivo()) return;
const cont = document.getElementById('lista-vet-productores');
if (!cont) return;
const filtro = (valor('vet-buscar-productor') || '').toLowerCase();
const lista = estado.cuentasProductores.filter(c => c.tipo !== 'punto').filter(c =>
!filtro || (c.nombre || '').toLowerCase().includes(filtro) || (c.predio || '').toLowerCase().includes(filtro)
);
if (!lista.length){ cont.innerHTML = `<p class="text-sm text-center" style="color:var(--sage);">Sin resultados.</p>`; return; }
cont.innerHTML = lista.map(c => `
<div class="bg-white rounded-2xl p-4 space-y-1" style="border:2px solid var(--line);">
<p class="font-display font-bold">${c.nombre || ''}</p>
<p class="text-xs" style="color:var(--sage);">${c.predio || ''} ${c.municipio ? '· ' + c.municipio : ''}</p>
<div class="flex gap-2 mt-2">
${c.telefono ? `<a href="tel:${c.telefono}" class="btn-primario-plano flex-1" style="background:var(--slate); text-align:center;"><i class="fa-solid fa-phone"></i> Llamar</a>` : ''}
${c.telefono ? `<a href="https://wa.me/${c.telefono.length===10 ? '52'+c.telefono : c.telefono}" target="_blank" rel="noopener" class="btn-primario-plano flex-1" style="background:#25D366; text-align:center;"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>` : ''}
</div>
</div>`).join('');
}
function agregarNotaVeterinario(){
if (!requiereVeterinarioActivo()) return;
const vet = veterinarioActivo();
if (!vet) return;
const titulo = valor('vetnota-titulo').trim();
const texto = valor('vetnota-texto').trim();
if (!texto){ mostrarToast('Escribe algo en la nota'); return; }
if (!vet.notas) vet.notas = [];
vet.notas.unshift({ id:'nota_' + Date.now(), titulo, texto, fecha: hoyISO() });
establecerValor('vetnota-titulo',''); establecerValor('vetnota-texto','');
renderListaVetNotas();
mostrarToast('Nota guardada');
}
function eliminarNotaVeterinario(id){
if (!requiereVeterinarioActivo()) return;
const vet = veterinarioActivo();
if (!vet || !vet.notas) return;
const i = vet.notas.findIndex(n => n.id === id);
if (i === -1) return;
vet.notas.splice(i, 1);
guardarEstadoLocal();
renderListaVetNotas();
}
function renderListaVetNotas(){
if (!requiereVeterinarioActivo()) return;
const cont = document.getElementById('lista-vet-notas');
if (!cont) return;
const vet = veterinarioActivo();
const notas = (vet && vet.notas) || [];
if (!notas.length){ cont.innerHTML = `<p class="text-sm text-center" style="color:var(--sage);">Aún no tienes notas.</p>`; return; }
cont.innerHTML = notas.map(n => `
<div class="bg-white rounded-2xl p-4 space-y-1" style="border:2px solid var(--line);">
<div class="flex items-center justify-between">
<p class="font-display font-bold">${n.titulo || n.fecha}</p>
<button onclick="eliminarNotaVeterinario('${n.id}')" style="color:var(--red);"><i class="fa-solid fa-trash"></i></button>
</div>
<p class="text-sm">${n.texto}</p>
<p class="text-xs" style="color:var(--sage);">${n.fecha}</p>
</div>`).join('');
}
// ================= PRUEBAS DE CAMPO (VETERINARIO) =================
let tabPruebasCampoActual = 'prueba';
let filasAnimalesPruebaCampo = [];
// Estado de vista de cada animal en la lista: colapsado (compacto, solo lo justo
// para reconocerlo), expandido de solo lectura ("Ver"), o en edición ("Editar").
// Es memoria de la pantalla, no se guarda en la prueba. El animal recién agregado
// se abre directo en edición; los anteriores quedan colapsados y se pueden volver
// a abrir para checar o corregir un dato sin perder el orden en que se probaron.
let animalesExpandidosPC = new Set();
let animalesEditandoPC = new Set();
let productorSeleccionadoPruebaCampo = null;
let editandoPruebaCampoId = null;
// ---- Borrador local de la captura activa (para no perder el trabajo si la app se
// cierra o se reinicia a medio llenar una prueba) ----
const CLAVE_BORRADOR_PRUEBA_CAMPO_ACTIVA = 'miRanchAppBorradorPruebaCampoActiva';
const CAMPOS_BORRADOR_PC_ENCABEZADO = ['pc-tipo-prueba','pc-motivo','pc-tipo-identificacion','pc-finalidad','pc-dosis','pc-lote','pc-fecha-inyeccion','pc-hora-inyeccion','pc-fecha-lectura','pc-hora-lectura','pc-fecha-caducidad','pc-fecha-muestra','pc-of-apellidopaterno','pc-of-apellidomaterno','pc-of-nombres','pc-of-domicilio','pc-of-localidad','pc-of-cp','pc-of-estado','pc-of-municipio','pc-of-telefono','pc-of-latitud','pc-of-longitud','pc-of-clave-upp','pc-of-folio-tb','pc-of-cc-no','pc-of-dictamen-tb','pc-of-tipo-aplicacion'];
function pantallaNuevaPruebaCampoActiva(){
const el = document.getElementById('screen-admin-nueva-prueba-campo');
return !!(el && el.classList.contains('active'));
}
function guardarBorradorPruebaCampoActivo(){
if (!pantallaNuevaPruebaCampoActiva()) return;
// Solo autoguardamos capturas nuevas — una prueba que ya se guardó y se está
// editando/leyendo vive en estado.pruebasCampoVet, con su propia persistencia.
if (editandoPruebaCampoId){ limpiarBorradorPruebaCampoActivo(); return; }
const encabezado = {};
CAMPOS_BORRADOR_PC_ENCABEZADO.forEach(id => { const el = document.getElementById(id); if (el) encabezado[id] = el.value; });
const datos = {
tabPruebasCampoActual, modoPruebaCampo,
productorSeleccionadoId: productorSeleccionadoPruebaCampo ? productorSeleccionadoPruebaCampo.id : null,
productoresSesionEjido, filasAnimalesPruebaCampo, encabezado,
guardadoEn: new Date().toISOString(),
};
const hayAlgo = datos.filasAnimalesPruebaCampo.length > 0 || datos.productorSeleccionadoId || datos.productoresSesionEjido.length > 0;
try {
if (hayAlgo) localStorage.setItem(CLAVE_BORRADOR_PRUEBA_CAMPO_ACTIVA, JSON.stringify(datos));
else localStorage.removeItem(CLAVE_BORRADOR_PRUEBA_CAMPO_ACTIVA);
} catch(e){}
}
function limpiarBorradorPruebaCampoActivo(){
try { localStorage.removeItem(CLAVE_BORRADOR_PRUEBA_CAMPO_ACTIVA); } catch(e){}
}
function hayBorradorPruebaCampoActivo(){
let datos = null;
try { datos = JSON.parse(localStorage.getItem(CLAVE_BORRADOR_PRUEBA_CAMPO_ACTIVA) || 'null'); } catch(e){ datos = null; }
if (!datos) return false;
return !!((datos.filasAnimalesPruebaCampo && datos.filasAnimalesPruebaCampo.length > 0) || datos.productorSeleccionadoId || (datos.productoresSesionEjido && datos.productoresSesionEjido.length > 0));
}
// Restaura la captura tal como quedó (encabezado, productor(es), animales) si
// detecta que quedó una prueba a medias en este dispositivo. Se llama al abrir
// la pantalla de Pruebas de campo.
async function restaurarBorradorPruebaCampoActivoSiExiste(){
let datos = null;
try { datos = JSON.parse(localStorage.getItem(CLAVE_BORRADOR_PRUEBA_CAMPO_ACTIVA) || 'null'); } catch(e){ datos = null; }
if (!datos || !hayBorradorPruebaCampoActivo()) { limpiarBorradorPruebaCampoActivo(); return false; }
tabPruebasCampoActual = datos.tabPruebasCampoActual || 'prueba';
modoPruebaCampo = datos.modoPruebaCampo || 'individual';
productoresSesionEjido = datos.productoresSesionEjido || [];
filasAnimalesPruebaCampo = datos.filasAnimalesPruebaCampo || [];
animalesExpandidosPC = new Set();
animalesEditandoPC = new Set();
editandoPruebaCampoId = null;
editandoEsLectura = false;
document.getElementById('titulo-nueva-prueba-campo').textContent = tabPruebasCampoActual === 'prueba' ? 'Nueva prueba' : 'Nuevo areteo';
document.getElementById('campo-tipo-prueba').classList.toggle('hidden', tabPruebasCampoActual !== 'prueba');
Object.keys(datos.encabezado || {}).forEach(id => establecerValor(id, datos.encabezado[id]));
actualizarCamposSegunTipoPrueba();
cambiarModoPruebaCampo(modoPruebaCampo);
if (datos.productorSeleccionadoId) await seleccionarProductorParaPrueba(datos.productorSeleccionadoId);
renderFilasAnimalesPruebaCampo();
renderProductoresEjido();
irAdmin('nueva-prueba-campo');
mostrarToast('Se restauró la prueba de campo que habías dejado a medias');
return true;
}
document.addEventListener('input', e => { if (e.target && CAMPOS_BORRADOR_PC_ENCABEZADO.includes(e.target.id)) guardarBorradorPruebaCampoActivo(); });
document.addEventListener('change', e => { if (e.target && CAMPOS_BORRADOR_PC_ENCABEZADO.includes(e.target.id)) guardarBorradorPruebaCampoActivo(); });
function mostrarAvisoBorradorPruebaCampoPendiente(){
const m = document.getElementById('modal-aviso-borrador-pc');
if (m){ m.classList.remove('hidden'); m.style.display = 'flex'; }
}
function cerrarAvisoBorradorPruebaCampoPendiente(){
const m = document.getElementById('modal-aviso-borrador-pc');
if (m){ m.classList.add('hidden'); m.style.removeProperty('display'); }
}
function descartarBorradorPruebaCampoActivo(){
limpiarBorradorPruebaCampoActivo();
cerrarAvisoBorradorPruebaCampoPendiente();
mostrarToast('Borrador descartado');
}
async function continuarBorradorPruebaCampoActivo(){
cerrarAvisoBorradorPruebaCampoPendiente();
await restaurarBorradorPruebaCampoActivoSiExiste();
}
function cambiarTabPruebasCampo(tab){
tabPruebasCampoActual = tab;
document.getElementById('tab-pc-prueba').style.background = tab === 'prueba' ? 'var(--pine)' : '';
document.getElementById('tab-pc-prueba').style.color = tab === 'prueba' ? '#fff' : '';
document.getElementById('tab-pc-areteo').style.background = tab === 'areteo' ? 'var(--pine)' : '';
document.getElementById('tab-pc-areteo').style.color = tab === 'areteo' ? '#fff' : '';
renderListaPruebasCampo();
}
function renderListaPruebasCampo(){
const cont = document.getElementById('lista-pruebas-campo');
if (!cont) return;
const items = estado.pruebasCampoVet.filter(p => p.categoria === tabPruebasCampoActual).sort((a,b) => (b.fecha||'').localeCompare(a.fecha||''));
if (items.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-vial-circle-check"></i><p>Aún no has registrado ${tabPruebasCampoActual === 'prueba' ? 'pruebas' : 'areteos'}.</p></div>`;
return;
}
const ETIQUETAS_ESTATUS = { pendiente:'Pendiente de respuesta', aceptada:'Aceptada por el productor', rechazada:'Descartada por el productor' };
const COLORES_ESTATUS = { pendiente:'var(--yellow)', aceptada:'var(--green)', rechazada:'var(--red)' };
cont.innerHTML = items.map(p => {
const esPrueba = p.categoria === 'prueba';
const diasTranscurridos = diasEntreISO(hoyISO(), p.fecha);
const listaParaLeer = diasTranscurridos >= 3;
const yaLeida = !esPrueba || p.leida;
let avisoLectura = '';
if (esPrueba && !yaLeida){
avisoLectura = listaParaLeer
? `<span class="text-xs px-2 py-0.5 rounded-full inline-block mt-1" style="background:var(--green); color:#fff;"><i class="fa-solid fa-circle-check mr-1"></i>Lista para leer (${diasTranscurridos} días desde la aplicación)</span>`
: `<span class="text-xs px-2 py-0.5 rounded-full inline-block mt-1" style="background:var(--parchment); color:var(--sage); border:2px solid var(--line);"><i class="fa-solid fa-clock mr-1"></i>Pendiente de lectura — faltan ${3 - diasTranscurridos} día(s) (72 h desde la aplicación)</span>`;
}
const numReactores = contarReactores(p);
const avisoReactores = (esPrueba && yaLeida && numReactores > 0)
? `<span class="text-xs px-2 py-0.5 rounded-full inline-block mt-1 ml-1" style="background:var(--red); color:#fff;"><i class="fa-solid fa-triangle-exclamation mr-1"></i>${numReactores} reactor(es)</span>`
: '';
return `
<div class="item-registro" style="border-left:6px solid ${p.categoria === 'prueba' ? 'var(--purple)' : 'var(--orange)'};">
<p class="font-bold">${p.tipoPrueba} — ${p.productorNombre}</p>
<p class="text-sm" style="color:var(--sage);">${p.predio || ''} ${p.upp ? '· UPP ' + p.upp : ''} · ${p.fecha}</p>
<p class="text-sm" style="color:var(--sage);">${p.animales.length} animal(es)</p>
${avisoLectura}${avisoReactores}
${p.estatusProductor ? `<span class="text-xs px-2 py-0.5 rounded-full inline-block mt-1" style="background:${COLORES_ESTATUS[p.estatusProductor]}; color:#fff;">${ETIQUETAS_ESTATUS[p.estatusProductor]}</span>` : ''}
<div class="flex flex-wrap gap-2 mt-3">
${!p.compartida ? `<button onclick="editarPruebaCampo('${p.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--parchment); color:var(--pine); border:2px solid var(--line);"><i class="fa-solid fa-pen"></i> Editar</button>` : ''}
<button onclick="abrirVistaPreviaDictamen('${p.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--slate); color:#fff;"><i class="fa-solid fa-print"></i> Vista previa / Imprimir dictamen</button>
${esPrueba && !yaLeida && listaParaLeer && !p.compartida ? `<button onclick="registrarLecturaPruebaCampo('${p.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--green); color:#fff;"><i class="fa-solid fa-magnifying-glass"></i> Registrar lectura</button>` : ''}
${!p.compartida && yaLeida ? `<button onclick="compartirPruebaCampo('${p.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--blue); color:#fff;"><i class="fa-solid fa-share"></i> Compartir con el productor</button>` : ''}
${yaLeida ? `<button onclick="exportarPruebaCampo('${p.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--parchment); color:var(--pine); border:2px solid var(--line);"><i class="fa-solid fa-file-export"></i> Exportar (para el comité)</button>` : ''}
${esPrueba && yaLeida && !p.enviadaAlmita ? `<button onclick="enviarAAlmita('${p.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--slate); color:#fff;"><i class="fa-solid fa-paper-plane"></i> Enviar al CEFPP</button>` : ''}
${p.enviadaAlmita ? `<span class="text-xs px-2 py-0.5 rounded-full inline-flex items-center" style="background:var(--slate); color:#fff;"><i class="fa-solid fa-check mr-1"></i>Enviada al CEFPP</span>` : ''}
${numReactores > 0 && yaLeida ? `<button onclick="exportarReporteReactores('${p.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--red); color:#fff;"><i class="fa-solid fa-file-medical"></i> Reporte de reactores</button>` : ''}
<button onclick="eliminarPruebaCampo('${p.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--parchment); color:var(--red); border:2px solid var(--line);"><i class="fa-solid fa-trash"></i></button>
</div>
</div>`;
}).join('');
}
function abrirNuevaPruebaCampo(categoria){
tabPruebasCampoActual = categoria;
filasAnimalesPruebaCampo = [];
animalesExpandidosPC = new Set();
animalesEditandoPC = new Set();
productorSeleccionadoPruebaCampo = null;
pcProductorActivoClave = null;
fierroImagenSesionPC = null;
editandoPruebaCampoId = null;
editandoEsLectura = false;
document.getElementById('titulo-nueva-prueba-campo').textContent = categoria === 'prueba' ? 'Nueva prueba' : 'Nuevo areteo';
document.getElementById('campo-tipo-prueba').classList.toggle('hidden', categoria !== 'prueba');
establecerValor('pc-buscar-productor', '');
document.getElementById('resultado-buscar-productor-pc').innerHTML = '';
document.getElementById('productor-seleccionado-pc').classList.add('hidden');
establecerValor('pc-tipo-prueba', 'TB');
establecerValor('pc-motivo', 'Cuarentena definitiva');
establecerValor('pc-tipo-identificacion', 'Arete');
establecerValor('pc-finalidad', 'Leche');
['pc-dosis','pc-lote','pc-fecha-inyeccion','pc-hora-inyeccion','pc-fecha-lectura','pc-hora-lectura','pc-fecha-caducidad','pc-fecha-muestra'].forEach(id => establecerValor(id, ''));
['pc-of-apellidopaterno','pc-of-apellidomaterno','pc-of-nombres','pc-of-domicilio','pc-of-localidad','pc-of-cp','pc-of-estado','pc-of-municipio','pc-of-telefono','pc-of-latitud','pc-of-longitud','pc-of-clave-upp','pc-of-folio-tb','pc-of-cc-no','pc-of-dictamen-tb'].forEach(id => establecerValor(id, ''));
establecerValor('pc-of-tipo-aplicacion', 'caudal');
document.getElementById('datos-oficiales-pc')?.classList.add('hidden');
const iconoDatosOf = document.getElementById('icono-toggle-datos-oficiales-pc');
if (iconoDatosOf) iconoDatosOf.className = 'fa-solid fa-chevron-down';
establecerValor('ba-terminacion', '');
establecerValor('pc-buscar-arete-campo', '');
const pcRes = document.getElementById('pc-resultados-busqueda-campo'); if (pcRes) pcRes.innerHTML = '';
const baResultado = document.getElementById('ba-resultado');
if (baResultado) baResultado.innerHTML = '';
productoresSesionEjido = [];
cambiarModoPruebaCampo('individual');
actualizarCamposSegunTipoPrueba();
renderFilasAnimalesPruebaCampo();
irAdmin('nueva-prueba-campo');
const productoresDisponiblesPC = (estado.cuentasProductores || []).filter(c => c && c.tipo !== 'punto');
if (categoria === 'prueba' || categoria === 'areteo') {
  if (productoresDisponiblesPC.length === 1) setTimeout(() => seleccionarProductorParaPrueba(productoresDisponiblesPC[0].id), 0);
}
}
function actualizarCamposSegunTipoPrueba(){
const esBrucelosis = tabPruebasCampoActual === 'prueba' && valor('pc-tipo-prueba') === 'Brucelosis';
const esTB = tabPruebasCampoActual === 'prueba' && valor('pc-tipo-prueba') !== 'Brucelosis';
document.getElementById('campos-tuberculina').classList.toggle('hidden', !esTB);
document.getElementById('campos-brucelosis').classList.toggle('hidden', !esBrucelosis);
const campoCaducidad = document.getElementById('campo-caducidad-junto-folio');
if (campoCaducidad) campoCaducidad.classList.toggle('hidden', !esTB);
}
let editandoEsLectura = false;
function editarPruebaCampo(id){
editandoEsLectura = false;
const p = estado.pruebasCampoVet.find(x => x.id === id);
if (!p) return;
tabPruebasCampoActual = p.categoria;
editandoPruebaCampoId = id;
filasAnimalesPruebaCampo = p.animales.map((a, i) => ({ id: 'fila_' + i, ...a }));
animalesExpandidosPC = new Set();
animalesEditandoPC = new Set();
document.getElementById('titulo-nueva-prueba-campo').textContent = p.categoria === 'prueba' ? 'Editar prueba' : 'Editar areteo';
document.getElementById('campo-tipo-prueba').classList.toggle('hidden', p.categoria !== 'prueba');
establecerValor('pc-tipo-prueba', p.tipoPrueba === 'Areteo' ? 'TB' : p.tipoPrueba);
establecerValor('pc-motivo', p.motivo || 'Cuarentena definitiva');
establecerValor('pc-tipo-identificacion', p.tipoIdentificacion || 'Arete');
establecerValor('pc-finalidad', p.finalidad || 'Leche');
establecerValor('pc-dosis', p.dosis || '10');
establecerValor('pc-lote', p.lote || '');
establecerValor('pc-fecha-inyeccion', p.fechaInyeccion || '');
establecerValor('pc-hora-inyeccion', p.horaInyeccion || '');
establecerValor('pc-fecha-lectura', p.fechaLectura || '');
establecerValor('pc-hora-lectura', p.horaLectura || '');
establecerValor('pc-fecha-caducidad', p.fechaCaducidad || '');
establecerValor('pc-fecha-muestra', p.fechaMuestra || '');
establecerValor('pc-of-apellidopaterno', p.apellidoPaterno || '');
establecerValor('pc-of-apellidomaterno', p.apellidoMaterno || '');
establecerValor('pc-of-nombres', p.nombres || '');
establecerValor('pc-of-domicilio', p.domicilio || '');
establecerValor('pc-of-localidad', p.localidad || '');
establecerValor('pc-of-cp', p.cp || '');
establecerValor('pc-of-estado', p.estadoMx || '');
establecerValor('pc-of-municipio', p.municipio || '');
establecerValor('pc-of-telefono', p.telefonoProductor || '');
establecerValor('pc-of-latitud', p.latitud || '');
establecerValor('pc-of-longitud', p.longitud || '');
establecerValor('pc-of-clave-upp', p.claveUpp || '');
establecerValor('pc-of-folio-tb', p.folioTB || '');
establecerValor('pc-of-cc-no', p.ccNo || '');
establecerValor('pc-of-dictamen-tb', p.dictamenTB || '');
establecerValor('pc-of-tipo-aplicacion', p.tipoAplicacion || 'caudal');
if (p.apellidoPaterno || p.domicilio || p.folioTB){
document.getElementById('datos-oficiales-pc')?.classList.remove('hidden');
const iconoDatosOf = document.getElementById('icono-toggle-datos-oficiales-pc');
if (iconoDatosOf) iconoDatosOf.className = 'fa-solid fa-chevron-up';
}
actualizarCamposSegunTipoPrueba();
const c = estado.cuentasProductores.find(x => x.id === p.productorId);
if (c) seleccionarProductorParaPrueba(c.id);
renderFilasAnimalesPruebaCampo();
irAdmin('nueva-prueba-campo');
}
function registrarLecturaPruebaCampo(id){
editarPruebaCampo(id);
editandoEsLectura = true;
// Para la lectura hay que capturar el resultado de cada animal, así que se abren
// todos en edición de una vez (a diferencia de una edición normal, donde solo el
// último animal agregado se abre y los demás quedan colapsados).
animalesExpandidosPC = new Set(filasAnimalesPruebaCampo.map(f => f.id));
animalesEditandoPC = new Set(filasAnimalesPruebaCampo.map(f => f.id));
renderFilasAnimalesPruebaCampo();
document.getElementById('titulo-nueva-prueba-campo').textContent = 'Registrar lectura';
mostrarToast('Actualiza el resultado (N/S/R/E) de cada animal y guarda');
}
function buscarProductorParaPrueba(){
const q = valor('pc-buscar-productor').trim().toLowerCase();
const cont = document.getElementById('resultado-buscar-productor-pc');
if (!q){ cont.innerHTML = ''; return; }
const resultados = estado.cuentasProductores.filter(c => c.tipo !== 'punto' &&
((c.nombre||'').toLowerCase().includes(q) || (c.predio||'').toLowerCase().includes(q) || (c.upp||'').toLowerCase().includes(q))
).slice(0, 8);
// Si la UPP escrita coincide exacta con una sola cuenta, la selecciona sola —
// así basta con teclear/escanear la UPP para que se autorrellenen sus datos.
const coincidenciaExactaUpp = resultados.filter(c => (c.upp || '').toLowerCase() === q);
if (coincidenciaExactaUpp.length === 1){
seleccionarProductorParaPrueba(coincidenciaExactaUpp[0].id);
return;
}
if (resultados.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-2" style="color:var(--sage);">Sin coincidencias.</p>
<button onclick="agregarProductorNuevoDesdePruebaCampo()" class="w-full text-xs font-bold py-2.5 rounded-full" style="background:var(--pine); color:#fff;" type="button"><i class="fa-solid fa-user-plus"></i> Dar de alta como productor nuevo</button>`;
return;
}
cont.innerHTML = resultados.map(c => `
<button onclick="seleccionarProductorParaPrueba('${c.id}')" class="w-full text-left bg-white rounded-xl p-2 flex items-center gap-2" style="border:2px solid var(--line);">
${avatarHtml(c.nombre, null, 34)}
<div class="flex-1 min-w-0"><p class="text-sm font-bold truncate">${c.nombre}</p><p class="text-xs" style="color:var(--sage);">${c.predio || ''} ${c.upp ? '· UPP ' + c.upp : ''}</p></div>
</button>`).join('');
}
let cacheAnimalesProductorPrueba = null;
let fierroImagenSesionPC = null;
// Cuando la búsqueda no encuentra al productor, se da de alta ahí mismo, sin
// salir de la prueba de campo — queda como una cuenta real (igual que si se
// hubiera dado de alta desde "Ligar nueva cuenta"), solo que arranca vacía y
// el veterinario la va llenando con el mismo resumen de siempre.
function agregarProductorNuevoDesdePruebaCampo(){
const nombreBuscado = valor('pc-buscar-productor').trim();
const nuevo = {
id: 'cta_' + Date.now(),
nombre: nombreBuscado || '',
predio: '', upp: '', apellidoPaterno: '', apellidoMaterno: '', nombres: nombreBuscado || '',
curp: '', rfc: '', municipio: '', estadoMx: '', localidad: '', latitud: null, longitud: null,
domicilio: '', codigoPostal: '', telefono: '', tipo: 'carne',
hato: [], salud: [], pesajes: [], reproduccion: [],
};
estado.cuentasProductores.push(nuevo);
productorSeleccionadoPruebaCampo = nuevo;
document.getElementById('resultado-buscar-productor-pc').innerHTML = '';
establecerValor('pc-buscar-productor', '');
fierroImagenSesionPC = null;
if (typeof actualizarTarjetaFierroChecklistPC === 'function') actualizarTarjetaFierroChecklistPC();
renderResumenPropietarioPC(nuevo);
guardarEstadoLocal();
mostrarToast('Productor nuevo agregado — completa sus datos abajo');
}
// Arma el resumen "solo lectura" del propietario en la pantalla de Nueva
// prueba: cada dato que ya existe en la cuenta del productor se muestra fijo
// (gris, no editable); el que falte se convierte en un campo de texto normal
// para capturarlo ahí mismo, sin tener que ir a otra pantalla — mismo
// espíritu que ya se usó para el GPS, aplicado a todo el bloque.
function celdaResumenPropietario(id, etiqueta, valorCuenta, ancho2){
const tieneValor = valorCuenta != null && String(valorCuenta).trim() !== '';
const claseAncho = ancho2 ? ' col-span-2' : '';
const valorSeguro = tieneValor ? String(valorCuenta).replace(/</g, '&lt;').replace(/"/g, '&quot;') : '';
if (tieneValor){
return `<div class="${claseAncho.trim()}"><label class="campo-label">${etiqueta}</label><input id="${id}" readonly style="background:var(--parchment); color:var(--ink);" type="text" value="${valorSeguro}"/></div>`;
}
return `<div class="${claseAncho.trim()}"><label class="campo-label">${etiqueta}</label><input id="${id}" oninput="guardarBorradorPruebaCampoActivo()" placeholder="Captúralo aquí" type="text"/></div>`;
}
function renderResumenPropietarioPC(c){
const cont = document.getElementById('resumen-propietario-pc');
const grid = document.getElementById('resumen-propietario-pc-grid');
if (!cont || !grid) return;
cont.classList.remove('hidden');
// Ya no hace falta ver el buscador una vez que el resumen está a la vista —
// se esconde para no repetir la misma información dos veces.
document.getElementById('pc-selector-productor-wrap')?.classList.add('hidden');
// Municipio y Estado se muestran juntos en una sola tarjeta (como en el
// dictamen impreso) cuando los dos existen; si falta alguno, se dejan dos
// campitos chicos lado a lado para completarlos ahí mismo.
const tieneMunicipioYEstado = (c.municipio || '').trim() && (c.estadoMx || '').trim();
const municipioEstadoHtml = tieneMunicipioYEstado
? `<div><label class="campo-label">Estado</label><input id="pc-of-estado" readonly style="background:var(--parchment); color:var(--ink);" type="text" value="${String(c.estadoMx).replace(/</g,'&lt;').replace(/"/g,'&quot;')}"/></div>
<div><label class="campo-label">Municipio</label><input id="pc-of-municipio" readonly style="background:var(--parchment); color:var(--ink);" type="text" value="${String(c.municipio).replace(/</g,'&lt;').replace(/"/g,'&quot;')}"/></div>`
: `<div><label class="campo-label">Estado</label><input id="pc-of-estado" oninput="guardarBorradorPruebaCampoActivo()" placeholder="Captúralo aquí" type="text" value="${(c.estadoMx||'').replace(/</g,'&lt;').replace(/"/g,'&quot;')}"/></div>
<div><label class="campo-label">Municipio</label><input id="pc-of-municipio" oninput="guardarBorradorPruebaCampoActivo()" placeholder="Captúralo aquí" type="text" value="${(c.municipio||'').replace(/</g,'&lt;').replace(/"/g,'&quot;')}"/></div>`;
// GPS: si el productor ya tiene coordenadas guardadas en su cuenta, se
// muestran fijas (como ya viene dado de alta); si no las tiene, se dejan
// dos campos chicos para capturarlas a mano.
const tieneGPS = c.latitud != null && c.longitud != null && String(c.latitud).trim() && String(c.longitud).trim();
const gpsHtml = `<div class="col-span-2">
<label class="campo-label">Número de GPS</label>
<div class="flex gap-2">
<input id="pc-of-latitud" placeholder="Latitud" style="flex:1;" type="text" value="${tieneGPS ? c.latitud : ''}" ${tieneGPS ? 'readonly' : "oninput=\"guardarBorradorPruebaCampoActivo()\""}/>
<input id="pc-of-longitud" placeholder="Longitud" style="flex:1;" type="text" value="${tieneGPS ? c.longitud : ''}" ${tieneGPS ? 'readonly' : "oninput=\"guardarBorradorPruebaCampoActivo()\""}/>
</div>
</div>`;
grid.innerHTML = [
celdaResumenPropietario('pc-of-apellidopaterno', 'Apellido paterno', c.apellidoPaterno),
celdaResumenPropietario('pc-of-apellidomaterno', 'Apellido materno', c.apellidoMaterno),
celdaResumenPropietario('pc-of-nombres', 'Nombre(s)', c.nombres, true),
celdaResumenPropietario('pc-of-curp', 'CURP', c.curp),
celdaResumenPropietario('pc-of-rfc', 'RFC', c.rfc),
municipioEstadoHtml,
celdaResumenPropietario('pc-of-domicilio', 'Calle y número', c.domicilio, true),
celdaResumenPropietario('pc-of-cp', 'C.P.', c.codigoPostal),
celdaResumenPropietario('pc-of-telefono', 'Teléfono', c.telefono),
celdaResumenPropietario('pc-of-clave-upp', 'Número de UPP', c.upp, true),
celdaResumenPropietario('pc-of-predio', 'Nombre del Rancho', c.predio, true),
celdaResumenPropietario('pc-of-localidad', 'Localidad', c.localidad, true),
gpsHtml,
celdaFierroResumenPC(c),
].join('');
}
// Regresa al buscador de productor (por si se seleccionó el que no era) —
// esconde el resumen y limpia la selección actual.
function cambiarProductorSeleccionadoPC(){
if (filasAnimalesPruebaCampo.length > 0){ mostrarToast('Ya hay animales capturados. Guarda esta prueba o elimina los renglones antes de cambiar de productor.'); return; }
productorSeleccionadoPruebaCampo = null;
pcProductorActivoClave = null;
cacheAnimalesProductorPrueba = null;
fierroImagenSesionPC = null;
document.getElementById('resumen-propietario-pc')?.classList.add('hidden');
document.getElementById('productor-seleccionado-pc')?.classList.add('hidden');
document.getElementById('pc-selector-productor-wrap')?.classList.remove('hidden');
establecerValor('pc-buscar-productor', '');
document.getElementById('pc-buscar-productor')?.focus();
}
// Muestra la figura del fierro en el resumen del productor — si ya existe,
// se ve como miniatura y se puede tocar para corregirla; si no existe, se ve
// como una tarjeta vacía invitando a dibujarla.
function celdaFierroResumenPC(c, prefijoAbrir){
prefijoAbrir = prefijoAbrir || 'pc';
if (c.fierroImagen && c.fierroImagen.startsWith('indexeddb://')){
// Se dibujó sin señal — todavía no se ha podido subir. Se avisa claro en
// vez de mostrar un ícono de imagen rota; en cuanto regrese la señal se
// sube sola y ya se ve normal.
return `<div class="resumen-tile col-span-2" onclick="abrirDibujoFierro('${prefijoAbrir}')" style="cursor:pointer;"><span class="resumen-tile-etiqueta"><i class="fa-solid fa-clock-rotate-left"></i> Fierro dibujado — pendiente de subir (sin señal todavía)</span></div>`;
}
if (c.fierroImagen){
return `<div class="resumen-tile col-span-2" onclick="abrirDibujoFierro('${prefijoAbrir}')" style="cursor:pointer; display:flex; align-items:center; gap:8px;">
<img loading="lazy" decoding="async" src="${c.fierroImagen}" style="width:38px; height:38px; object-fit:contain; background:#fff; border-radius:6px; border:1px solid var(--line); flex-shrink:0;"/>
<div><span class="resumen-tile-etiqueta">Fierro</span><span class="text-xs font-bold" style="color:var(--pine);">Toca para editar</span></div>
</div>`;
}
return `<div class="resumen-tile resumen-tile-vacio col-span-2" onclick="abrirDibujoFierro('${prefijoAbrir}')" style="cursor:pointer;"><span class="resumen-tile-etiqueta"><i class="fa-solid fa-pen-nib"></i> Fierro — sin figura, toca para dibujarla</span></div>`;
}
// ---- Dibujo a mano de la figura del fierro (lienzo estilo "pintar con el dedo") ----
// Misma herramienta usada en 3 lugares distintos de la app (por eso recibe un
// "prefijo" que dice dónde guardar el resultado al final):
//  'pc'  → prueba de campo del veterinario, en la cuenta del PRODUCTOR seleccionado
//  'ed'  → el propio productor editando los datos de su cuenta
//  'esc' → el propio productor, dentro del asistente de "Alta rápida por escaneo"
// Cada trazo que la persona dibuja se guarda como una lista de puntos — así
// "Deshacer" puede quitar el último trazo y redibujar todo desde cero con los
// que quedan, en vez de perder el dibujo completo por error.
let trazosFierroPC = [];
let trazoActualFierroPC = null;
let ctxDibujoFierroPC = null;
let imagenBaseFierroPC = null;
let prefijoDibujoFierroActivo = 'pc';
let dataUrlPreviewFierroPC = null;
// Trae la figura YA guardada (si hay) según en qué pantalla se abrió el
// lienzo, para mostrarla de fondo y poder corregirla en vez de partir de cero.
function obtenerFierroActualParaDibujo(prefijo){
if (prefijo === 'ed') return estado.productor.fierroImagen || null;
if (prefijo === 'esc') return fierroImagenEscaneoTemp || estado.productor.fierroImagen || null;
return productorSeleccionadoPruebaCampo ? (productorSeleccionadoPruebaCampo.fierroImagen || null) : null;
}
function abrirDibujoFierro(prefijo){
if (prefijo === 'pc' && !productorSeleccionadoPruebaCampo){ mostrarToast('Primero selecciona un productor'); return; }
prefijoDibujoFierroActivo = prefijo;
document.getElementById('modal-dibujar-fierro').classList.remove('hidden');
document.getElementById('dibujo-fierro-vista-lienzo').classList.remove('hidden');
document.getElementById('dibujo-fierro-vista-preview').classList.add('hidden');
document.getElementById('dibujo-fierro-botones-preview').classList.add('hidden');
const canvas = document.getElementById('dibujo-fierro-canvas');
requestAnimationFrame(() => {
const rect = canvas.getBoundingClientRect();
canvas.width = Math.round(rect.width); canvas.height = Math.round(rect.height);
ctxDibujoFierroPC = canvas.getContext('2d');
trazosFierroPC = []; trazoActualFierroPC = null; imagenBaseFierroPC = null;
const imgExistenteUrl = obtenerFierroActualParaDibujo(prefijo);
if (imgExistenteUrl){
// Si ya había una figura, se muestra como referencia de fondo para
// corregirla — dibujar encima y "Deshacer" no la borra (no es un trazo
// nuevo); solo "Borrar todo" empieza completamente de cero. Si la figura
// se dibujó sin señal (todavía no se subió), se resuelve desde donde de
// verdad está guardada (IndexedDB) en vez de intentar cargarla como si
// fuera un link normal.
resolverImagenParaMostrar(imgExistenteUrl).then(urlResuelta => {
if (!urlResuelta){ redibujarFierroPC(canvas); return; }
const img = new Image();
img.onload = () => { imagenBaseFierroPC = img; redibujarFierroPC(canvas); };
img.onerror = () => redibujarFierroPC(canvas);
img.src = urlResuelta;
});
} else {
redibujarFierroPC(canvas);
}
inicializarDibujoFierroPC(canvas);
});
}
function redibujarFierroPC(canvas){
const ctx = ctxDibujoFierroPC;
ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
if (imagenBaseFierroPC){
const escala = Math.min((canvas.width * 0.8) / imagenBaseFierroPC.width, (canvas.height * 0.8) / imagenBaseFierroPC.height);
const w = imagenBaseFierroPC.width * escala, h = imagenBaseFierroPC.height * escala;
ctx.drawImage(imagenBaseFierroPC, (canvas.width - w) / 2, (canvas.height - h) / 2, w, h);
}
ctx.strokeStyle = '#111827'; ctx.lineWidth = 6; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
for (const trazo of trazosFierroPC){
if (trazo.length < 2) continue;
ctx.beginPath();
ctx.moveTo(trazo[0].x, trazo[0].y);
for (let i = 1; i < trazo.length; i++) ctx.lineTo(trazo[i].x, trazo[i].y);
ctx.stroke();
}
}
function inicializarDibujoFierroPC(canvas){
let dibujando = false;
const posicion = (ev) => { const r = canvas.getBoundingClientRect(); return { x: ev.clientX - r.left, y: ev.clientY - r.top }; };
canvas.onpointerdown = (ev) => {
dibujando = true;
trazoActualFierroPC = [posicion(ev)];
trazosFierroPC.push(trazoActualFierroPC);
try { canvas.setPointerCapture(ev.pointerId); } catch(e){}
};
canvas.onpointermove = (ev) => {
if (!dibujando || !trazoActualFierroPC) return;
trazoActualFierroPC.push(posicion(ev));
const n = trazoActualFierroPC.length;
if (n >= 2){
ctxDibujoFierroPC.beginPath();
ctxDibujoFierroPC.moveTo(trazoActualFierroPC[n-2].x, trazoActualFierroPC[n-2].y);
ctxDibujoFierroPC.lineTo(trazoActualFierroPC[n-1].x, trazoActualFierroPC[n-1].y);
ctxDibujoFierroPC.stroke();
}
};
const terminarTrazo = () => { dibujando = false; trazoActualFierroPC = null; };
canvas.onpointerup = terminarTrazo;
canvas.onpointercancel = terminarTrazo;
}
// Quita el último trazo dibujado (no la figura de referencia, si había una) y
// redibuja todo desde cero con los trazos que quedan — "ir para atrás"
// borrando el diseño trazo por trazo, como se pidió.
function deshacerTrazoFierroPC(){
if (trazosFierroPC.length === 0){ mostrarToast('No hay ningún trazo que deshacer'); return; }
trazosFierroPC.pop();
redibujarFierroPC(document.getElementById('dibujo-fierro-canvas'));
}
function borrarTodoFierroPC(){
trazosFierroPC = [];
imagenBaseFierroPC = null;
redibujarFierroPC(document.getElementById('dibujo-fierro-canvas'));
}
function cancelarDibujoFierroPC(){
document.getElementById('modal-dibujar-fierro').classList.add('hidden');
trazosFierroPC = []; trazoActualFierroPC = null; imagenBaseFierroPC = null; dataUrlPreviewFierroPC = null;
}
// ---- Mejora vectorial de la figura dibujada (ImageTracer.js) ----
// Convierte el dibujo rayado (píxeles sueltos, bordes dentados por dibujar
// con el dedo) en un trazo vectorial: líneas curvas suaves y precisas en vez
// de puntos — como pasar de un boceto a rotulado a mano. Es una librería
// ligera (~30 KB) que corre completa en el celular; solo necesita descargarse
// una vez y ya funciona sin internet después. Si por algún motivo no está
// disponible (sin señal la primera vez, CDN caído), se guarda la versión
// dibujada tal cual — nunca se pierde el trabajo por no poder vectorizar.
let imageTracerCargando = null;
// ================= CARGA BAJO DEMANDA DE LIBRERÍAS PESADAS =================
// Varias librerías (ExcelJS, html2canvas, generador de QR, buscador difuso
// Fuse.js) solo las usa una función muy puntual de toda la app — antes se
// descargaban SIEMPRE al abrir la app, para TODOS los usuarios, aunque casi
// nadie tocara esa función ese día. Ahora se descargan la primera vez que
// alguien de verdad la usa, y de ahí en adelante quedan en memoria — mismo
// patrón ya probado con el lector de texto (Tesseract) y el vectorizador del
// fierro (ImageTracer). Esto reduce lo que descarga cada quien al abrir la
// app, sobre todo para roles que nunca tocan exportar a Excel, imprimir como
// imagen, o generar un código QR.
const librasCargando = {};
function cargarScriptSiNecesario(clave, url, variableGlobalEsperada){
if (window[variableGlobalEsperada]) return Promise.resolve();
if (librasCargando[clave]) return librasCargando[clave];
librasCargando[clave] = new Promise((resolve, reject) => {
const script = document.createElement('script');
script.src = url;
script.onload = () => resolve();
script.onerror = () => { librasCargando[clave] = null; reject(new Error('No se pudo descargar ' + clave)); };
document.head.appendChild(script);
});
return librasCargando[clave];
}
function cargarExcelJSSiNecesario(){ return cargarScriptSiNecesario('exceljs', 'https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.4.0/exceljs.min.js', 'ExcelJS'); }
function cargarFileSaverSiNecesario(){ return cargarScriptSiNecesario('filesaver', 'https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js', 'saveAs'); }
function cargarHtml2CanvasSiNecesario(){ return cargarScriptSiNecesario('html2canvas', 'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js', 'html2canvas'); }
function cargarQRCodeSiNecesario(){ return cargarScriptSiNecesario('qrcode', 'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js', 'QRCode'); }
function cargarJsPDFSiNecesario(){
return cargarScriptSiNecesario('jspdf', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', 'jspdf')
.then(() => cargarScriptSiNecesario('jspdf-autotable', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js', '__nuncaExiste__'));
}
function cargarChartJsSiNecesario(){ return cargarScriptSiNecesario('chartjs', 'https://cdn.jsdelivr.net/npm/chart.js', 'Chart'); }
function cargarFuseSiNecesario(){ return cargarScriptSiNecesario('fuse', 'https://cdn.jsdelivr.net/npm/fuse.js@7', 'Fuse'); }
function cargarHojaEstiloSiNecesaria(clave, url){
if (document.querySelector(`link[data-lib-css="${clave}"]`)) return;
const link = document.createElement('link');
link.rel = 'stylesheet'; link.href = url; link.dataset.libCss = clave;
document.head.appendChild(link);
}
// Los mapas (potreros) solo los usa quien de verdad dibuja o consulta un
// potrero — Leaflet + Leaflet.draw + Turf pesan bastante juntas y antes se
// descargaban para TODOS los roles siempre, aunque nunca abrieran un mapa.
function cargarMapasSiNecesario(){
cargarHojaEstiloSiNecesaria('leaflet', 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css');
cargarHojaEstiloSiNecesaria('leaflet-draw', 'https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.css');
return cargarScriptSiNecesario('leaflet', 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js', 'L')
.then(() => {
// Leaflet.draw agrega L.Draw sobre la L que ya existe — no crea una
// variable global nueva, así que aquí se checa aparte en vez de usar el
// cargador genérico (que solo sabe checar UNA variable global).
if (window.L && window.L.Draw) return Promise.resolve();
return cargarScriptSiNecesario('leaflet-draw', 'https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.js', '__nuncaExiste__');
})
.then(() => cargarScriptSiNecesario('turf', 'https://cdnjs.cloudflare.com/ajax/libs/Turf.js/6.5.0/turf.min.js', 'turf'));
}
function cargarImageTracerSiNecesario(){
if (window.ImageTracer) return Promise.resolve();
if (imageTracerCargando) return imageTracerCargando;
imageTracerCargando = new Promise((resolve, reject) => {
const script = document.createElement('script');
script.src = 'https://cdn.jsdelivr.net/npm/imagetracerjs@1.2.6/imagetracer_v1.2.6.min.js';
script.onload = () => resolve();
script.onerror = () => { imageTracerCargando = null; reject(new Error('No se pudo descargar el vectorizador')); };
document.head.appendChild(script);
});
return imageTracerCargando;
}
async function vectorizarFiguraFierro(canvas){
await cargarImageTracerSiNecesario();
const ctx = canvas.getContext('2d');
const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
const opciones = {
numberofcolors: 2, // el dibujo es blanco y negro nada más — más rápido y más limpio que tratar de adivinar colores
ltres: 1, qtres: 1, // qué tan fino sigue el trazo las curvas (más bajo = más preciso)
pathomit: 8, // ignora manchitas sueltas menores a 8px (ruido de dedo/temblor)
blurradius: 3, blurdelta: 20, // suaviza el borde dentado ANTES de trazar — es lo que redondea el rayón
scale: 1,
};
const svgString = ImageTracer.imagedataToSVG(imgData, opciones);
return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svgString);
}
// Paso 1: procesa el dibujo (intenta vectorizarlo) y lo muestra en una
// vista previa — NO guarda nada todavía, para que la persona lo revise
// primero, tal como se pidió.
function previsualizarDibujoFierroPC(){
if (trazosFierroPC.length === 0 && !imagenBaseFierroPC){ mostrarToast('Dibuja la figura antes de continuar'); return; }
const canvas = document.getElementById('dibujo-fierro-canvas');
const dataUrlRayado = canvas.toDataURL('image/png');
const botonVer = document.querySelector('#modal-dibujar-fierro button[onclick="previsualizarDibujoFierroPC()"]');
if (botonVer){ botonVer.disabled = true; botonVer.textContent = 'Mejorando trazo...'; }
const mostrarPreview = (dataUrlFinal, nota) => {
dataUrlPreviewFierroPC = dataUrlFinal;
document.getElementById('dibujo-fierro-preview-img').src = dataUrlFinal;
document.getElementById('dibujo-fierro-preview-nota').textContent = nota;
document.getElementById('dibujo-fierro-vista-lienzo').classList.add('hidden');
document.getElementById('dibujo-fierro-vista-preview').classList.remove('hidden');
document.getElementById('dibujo-fierro-botones-preview').classList.remove('hidden');
if (botonVer){ botonVer.disabled = false; botonVer.innerHTML = '<i class="fa-solid fa-eye"></i> Ver resultado'; }
};
vectorizarFiguraFierro(canvas)
.then(dataUrlVectorial => mostrarPreview(dataUrlVectorial, 'Trazo mejorado (vectorial, líneas limpias)'))
.catch(e => {
console.warn('No se pudo vectorizar la figura del fierro, se muestra tal como se dibujó', e);
mostrarPreview(dataUrlRayado, 'No se pudo mejorar el trazo esta vez — se guardaría tal como la dibujaste');
});
}
// Regresa al lienzo sin perder lo ya dibujado, por si quiere seguir
// corrigiendo antes de guardar.
function volverAEditarDibujoFierroPC(){
document.getElementById('dibujo-fierro-vista-preview').classList.add('hidden');
document.getElementById('dibujo-fierro-botones-preview').classList.add('hidden');
document.getElementById('dibujo-fierro-vista-lienzo').classList.remove('hidden');
dataUrlPreviewFierroPC = null;
}
// Paso 2: el guardado DEFINITIVO — solo se llega aquí después de haber visto
// la vista previa y confirmar que sí es la figura correcta.
function confirmarGuardarDibujoFierroPC(){
if (!dataUrlPreviewFierroPC) return;
guardarFierroEnCuenta(prefijoDibujoFierroActivo, dataUrlPreviewFierroPC);
document.getElementById('modal-dibujar-fierro').classList.add('hidden');
trazosFierroPC = []; trazoActualFierroPC = null; imagenBaseFierroPC = null; dataUrlPreviewFierroPC = null;
}
// Guarda la figura final en el lugar correcto según desde dónde se abrió el
// lienzo — cada pantalla tiene su propia forma de guardar el fierro que ya
// existía en la app; aquí solo se reutiliza cada una según el prefijo.
async function guardarFierroEnCuenta(prefijo, dataUrl){
// La figura del fierro se sube a Firebase Storage (igual que ya se hace con
// la foto del animal) y en la cuenta solo se guarda el LINK, no la imagen
// completa — antes se guardaba el texto de la imagen entera dentro del
// mismo documento que comparten todos los productores, lo cual lo hacía
// pesado y arriesgaba topar el límite de tamaño de Firestore. Si no hay
// señal en ese momento, se sigue guardando local como respaldo, igual que
// siempre — nunca se pierde el trabajo.
if (prefijo === 'ed'){
const ruta = `fierros/${estado.cuentaActivaId || 'local_' + Date.now()}.jpg`;
const subida = await subirImagenOGuardarLocal(ruta, dataUrl);
estado.productor.fierroImagen = subida.url;
if (estado.cuentaActivaId){
const cuenta = estado.cuentasProductores.find(x => x.id === estado.cuentaActivaId);
if (cuenta) cuenta.fierroImagen = subida.url;
}
guardarEstadoLocal();
renderVistaFierroGuardado('ed');
mostrarToast('Figura del fierro guardada');
} else if (prefijo === 'esc'){
const ruta = `fierros/escaneo_temp_${Date.now()}.jpg`;
const subida = await subirImagenOGuardarLocal(ruta, dataUrl);
fierroImagenEscaneoTemp = subida.url;
renderVistaFierroGuardado('esc');
if (typeof guardarBorradorEscaneoDoc === 'function') guardarBorradorEscaneoDoc();
mostrarToast('Figura del fierro guardada');
} else if (prefijo === 'pcc'){
const c = productorSeleccionadoPruebaCampo;
if (!c) return;
const ruta = `fierros/${c.id || 'local_' + Date.now()}.jpg`;
const subida = await subirImagenOGuardarLocal(ruta, dataUrl);
c.fierroImagen = subida.url;
guardarEstadoLocal();
const a = (estado.avisosReactoresTB || []).find(x => x.id === avisoTBEnCaptura);
if (a) renderResumenPropietarioPCC(a);
mostrarToast('Figura del fierro guardada en la cuenta del productor');
} else {
const c = productorSeleccionadoPruebaCampo;
if (!c) return;
const ruta = `fierros/${c.id || 'local_' + Date.now()}.jpg`;
const subida = await subirImagenOGuardarLocal(ruta, dataUrl);
c.fierroImagen = subida.url;
guardarEstadoLocal();
fierroImagenSesionPC = subida.url;
renderResumenPropietarioPC(c);
actualizarTarjetaFierroChecklistPC();
mostrarToast('Figura del fierro guardada en la cuenta del productor');
}
}
// Tarjeta chica de "usar esta figura en todos los animales" — separada del
// resumen porque solo tiene sentido mostrarla cuando SÍ hay una figura
// guardada; se actualiza tanto al seleccionar productor como al guardar un
// dibujo nuevo, para no repetir el mismo HTML en dos lugares distintos.
function actualizarTarjetaFierroChecklistPC(){
const cont = document.getElementById('productor-seleccionado-pc');
if (!cont) return;
if (fierroImagenSesionPC){
cont.classList.remove('hidden');
cont.innerHTML = `<div class="flex items-center gap-2">
<img loading="lazy" decoding="async" src="${fierroImagenSesionPC}" style="width:36px; height:36px; object-fit:contain; border-radius:6px; border:1px solid var(--line); background:#fff;"/>
<label class="text-xs flex-1" style="color:var(--sage);"><input checked id="pc-usar-fierro-productor" onchange="renderFilasAnimalesPruebaCampo()" type="checkbox"/> Usar la figura de fierro guardada de este productor en todos los animales</label>
</div>`;
} else {
cont.classList.add('hidden');
cont.innerHTML = '';
}
}
async function seleccionarProductorParaPrueba(cuentaId){
const c = estado.cuentasProductores.find(x => x.id === cuentaId);
if (!c) return;
productorSeleccionadoPruebaCampo = c;
document.getElementById('resultado-buscar-productor-pc').innerHTML = '';
establecerValor('pc-buscar-productor', '');
fierroImagenSesionPC = c.fierroImagen || null;
pcProductorActivoClave = c.id;
actualizarTarjetaFierroChecklistPC();
actualizarResumenProductorRapidoPC();
// Autorrellena los datos oficiales del dictamen con lo que ya tiene guardado
// el productor en su perfil — el veterinario solo corrige lo que falte,
// directo en el resumen de solo lectura.
renderResumenPropietarioPC(c);
cacheAnimalesProductorPrueba = null;
// Se intenta traer el inventario en vivo de Firebase. Si no hay conexión o
// falla, se usa la última copia guardada en el celular de ese productor (si
// existe) en vez de dejar la búsqueda de arete completamente vacía — con un
// aviso claro de que es una copia y de cuándo se guardó, para que el médico
// sepa que puede no estar 100% al día.
if (navigator.onLine && typeof window.firebaseLeerCuenta === 'function'){
try {
const datosCuenta = await window.firebaseLeerCuenta(cuentaId);
if (datosCuenta){
const inventarioRemoto = Array.isArray(datosCuenta.hato) ? datosCuenta.hato : (Array.isArray(datosCuenta.animales) ? datosCuenta.animales : []);
cacheAnimalesProductorPrueba = inventarioRemoto;
estado.inventariosOfflineProductores[cuentaId] = { animales: inventarioRemoto, fecha: new Date().toISOString() };
guardarEstadoLocal();
}
} catch(e){ console.warn('No se pudo traer el inventario del productor para verificar aretes', e); }
}
setTimeout(()=>document.getElementById('pc-buscar-arete-campo')?.focus(),60);
if (!cacheAnimalesProductorPrueba){
const respaldo = estado.inventariosOfflineProductores[cuentaId];
if (respaldo){
cacheAnimalesProductorPrueba = respaldo.animales;
const fechaTexto = new Date(respaldo.fecha).toLocaleDateString('es-MX', { day:'numeric', month:'short' });
mostrarToast(`Sin señal — usando el inventario guardado del ${fechaTexto} (puede no estar al día)`);
} else if (!navigator.onLine){
mostrarToast('Sin señal y sin copia guardada de este productor — agrega los animales manualmente');
}
}
guardarBorradorPruebaCampoActivo();
}
function buscarAnimalPorArete(arete){
if (!cacheAnimalesProductorPrueba || !arete) return null;
const buscado = arete.trim().toLowerCase();
return cacheAnimalesProductorPrueba.find(a => (a.arete || '').trim().toLowerCase() === buscado) || null;
}
let seleccionInventarioProductor = new Set();
// ================= MODO EJIDO (varios productores en una misma sesión de trabajo) =================
let modoPruebaCampo = 'individual';
let productoresSesionEjido = [];
function toggleDatosOficialesPC(){
const cont = document.getElementById('datos-oficiales-pc');
const icono = document.getElementById('icono-toggle-datos-oficiales-pc');
const abierto = !cont.classList.contains('hidden');
cont.classList.toggle('hidden');
if (icono) icono.className = abierto ? 'fa-solid fa-chevron-down' : 'fa-solid fa-chevron-up';
}
function cambiarModoPruebaCampo(modo){
modoPruebaCampo = modo;
document.getElementById('tab-modo-individual').style.background = modo === 'individual' ? 'var(--pine)' : '';
document.getElementById('tab-modo-individual').style.color = modo === 'individual' ? '#fff' : '';
document.getElementById('tab-modo-ejido').style.background = modo === 'ejido' ? 'var(--pine)' : '';
document.getElementById('tab-modo-ejido').style.color = modo === 'ejido' ? '#fff' : '';
document.getElementById('bloque-productor-individual').classList.toggle('hidden', modo !== 'individual');
document.getElementById('bloque-modo-ejido').classList.toggle('hidden', modo !== 'ejido');
document.getElementById('ejido-buscador-cuenta').classList.add('hidden');
document.getElementById('ejido-alta-manual').classList.add('hidden');
renderProductoresEjido();
actualizarSelectorProductorRapidoPC();
if (modo === 'individual') actualizarResumenProductorRapidoPC();
buscarPorTerminacionArete();
}
function mostrarBuscadorProductorEjido(){
document.getElementById('ejido-buscador-cuenta').classList.remove('hidden');
document.getElementById('ejido-alta-manual').classList.add('hidden');
establecerValor('ejido-buscar-productor', '');
document.getElementById('resultado-buscar-productor-ejido').innerHTML = '';
}
function mostrarAltaManualProductorEjido(){
document.getElementById('ejido-alta-manual').classList.remove('hidden');
document.getElementById('ejido-buscador-cuenta').classList.add('hidden');
llenarSelectorEstados('ejido-manual');
['ejido-manual-apellidopaterno','ejido-manual-apellidomaterno','ejido-manual-nombres','ejido-manual-localidad','ejido-manual-telefono','ejido-manual-curp','ejido-manual-upp','ejido-manual-predio'].forEach(id => establecerValor(id, ''));
establecerValor('ejido-manual-domicilio', 'CONOCIDO');
establecerValor('ejido-manual-estado', '');
cargarMunicipiosSelector('ejido-manual', '');
document.querySelectorAll('#ejido-alta-manual .grupo-campo').forEach(g => g.classList.remove('campo-lleno', 'campo-vacio-requerido'));
document.getElementById('ejido-alta-manual').querySelectorAll('[data-marcar-lleno]').forEach(el => marcarCampoLleno(el));
}
function buscarProductorParaEjido(){
const q = valor('ejido-buscar-productor').trim().toLowerCase();
const cont = document.getElementById('resultado-buscar-productor-ejido');
if (!q){ cont.innerHTML = ''; return; }
const yaAgregados = new Set(productoresSesionEjido.filter(p => p.cuentaId).map(p => p.cuentaId));
const resultados = estado.cuentasProductores.filter(c => c.tipo !== 'punto' && !yaAgregados.has(c.id) &&
((c.nombre||'').toLowerCase().includes(q) || (c.predio||'').toLowerCase().includes(q) || (c.upp||'').toLowerCase().includes(q))
).slice(0, 8);
// Igual que en modo individual: si la UPP escrita/escaneada coincide exacta con
// una sola cuenta, se agrega sola a la sesión sin tener que tocarla de la lista
// — así se puede ir metiendo UPP tras UPP rápido en campo.
const coincidenciaExactaUpp = resultados.filter(c => (c.upp || '').toLowerCase() === q);
if (coincidenciaExactaUpp.length === 1){
agregarProductorCuentaEjido(coincidenciaExactaUpp[0].id);
establecerValor('ejido-buscar-productor', '');
return;
}
if (resultados.length === 0){ cont.innerHTML = `<p class="text-xs text-center py-2" style="color:var(--sage);">Sin coincidencias.</p>`; return; }
cont.innerHTML = resultados.map(c => `
<button onclick="agregarProductorCuentaEjido('${c.id}')" class="w-full text-left bg-white rounded-xl p-2 flex items-center gap-2" style="border:2px solid var(--line);">
${avatarHtml(c.nombre, null, 34)}
<div class="flex-1 min-w-0"><p class="text-sm font-bold truncate">${c.nombre}</p><p class="text-xs" style="color:var(--sage);">${c.predio || ''} ${c.upp ? '· UPP ' + c.upp : ''}</p></div>
</button>`).join('');
}
async function agregarProductorCuentaEjido(cuentaId){
const c = estado.cuentasProductores.find(x => x.id === cuentaId);
if (!c) return;
const clave = 'ej_' + Date.now();
// Igual que en modo individual: se trae todo lo que el productor ya tiene
// guardado en su perfil (apellidos, domicilio, localidad, teléfono, GPS y la
// figura de su fierro de herrar) para no tener que volver a preguntarlo.
productoresSesionEjido.push({
clave, tipo:'registrado', cuentaId: c.id, nombre: c.nombre, predio: c.predio, upp: c.upp, curp: c.curp || '',
estadoMx: c.estadoMx || '', municipio: c.municipio || '',
apellidoPaterno: c.apellidoPaterno || '', apellidoMaterno: c.apellidoMaterno || '', nombres: c.nombres || '',
domicilio: c.domicilio || '', localidad: c.localidad || '', telefono: c.telefono || '',
latitud: c.latitud != null ? c.latitud : null, longitud: c.longitud != null ? c.longitud : null,
fierroImagen: c.fierroImagen || null,
animales: null,
});
document.getElementById('ejido-buscador-cuenta').classList.add('hidden');
if (!pcProductorActivoClave) { pcProductorActivoClave = clave; productorSeleccionadoPruebaCampo = productoresSesionEjido.find(x => x.clave === clave) || null; cacheAnimalesProductorPrueba = null; }
renderProductoresEjido();
actualizarSelectorProductorRapidoPC();
mostrarToast(`${c.nombre} agregado — cargando su inventario...`);
if (navigator.onLine && typeof window.firebaseLeerCuenta === 'function'){
try {
const datosCuenta = await window.firebaseLeerCuenta(cuentaId);
const prod = productoresSesionEjido.find(p => p.clave === clave);
if (prod && datosCuenta){
const inventarioRemoto = Array.isArray(datosCuenta.hato) ? datosCuenta.hato : (Array.isArray(datosCuenta.animales) ? datosCuenta.animales : []);
prod.animales = inventarioRemoto;
estado.inventariosOfflineProductores[cuentaId] = { animales: inventarioRemoto, fecha: new Date().toISOString() };
if (pcProductorActivoClave === clave) { cacheAnimalesProductorPrueba = inventarioRemoto; renderFilasAnimalesPruebaCampo(); }
guardarEstadoLocal();
}
} catch(e){ console.warn('No se pudo traer el inventario', e); }
} else {
// Sin señal: se usa la última copia guardada de este productor, si existe.
const prod = productoresSesionEjido.find(p => p.clave === clave);
const respaldo = estado.inventariosOfflineProductores[cuentaId];
if (prod && respaldo){
prod.animales = respaldo.animales;
if (pcProductorActivoClave === clave) { cacheAnimalesProductorPrueba = respaldo.animales; renderFilasAnimalesPruebaCampo(); }
const fechaTexto = new Date(respaldo.fecha).toLocaleDateString('es-MX', { day:'numeric', month:'short' });
mostrarToast(`Sin señal — usando el inventario guardado del ${fechaTexto} (puede no estar al día)`);
} else {
mostrarToast('Sin señal y sin copia guardada de este productor — agrega los animales manualmente');
}
}
}
function agregarProductorManualEjido(){
const apellidoPaterno = valor('ejido-manual-apellidopaterno').trim();
const apellidoMaterno = valor('ejido-manual-apellidomaterno').trim();
const nombres = valor('ejido-manual-nombres').trim();
const nombre = [nombres, apellidoPaterno, apellidoMaterno].filter(Boolean).join(' ');
if (!nombre){ mostrarToast('Escribe al menos el nombre del productor'); return; }
productoresSesionEjido.push({
clave: 'ej_' + Date.now(), tipo:'manual', cuentaId: null,
nombre, apellidoPaterno, apellidoMaterno, nombres,
domicilio: valor('ejido-manual-domicilio').trim() || 'CONOCIDO',
estadoMx: valor('ejido-manual-estado'), municipio: leerMunicipioSeleccionado('ejido-manual'),
localidad: valor('ejido-manual-localidad').trim(), telefono: valor('ejido-manual-telefono').trim(),
poblacion: valor('ejido-manual-poblacion').trim(), colonia: valor('ejido-manual-colonia').trim(),
correoElectronico: valor('ejido-manual-correo').trim(),
curp: valor('ejido-manual-curp').trim().toUpperCase(),
rfc: valor('ejido-manual-rfc').trim().toUpperCase(),
predio: valor('ejido-manual-predio').trim(), upp: valor('ejido-manual-upp').trim(),
animales: [],
});
document.getElementById('ejido-alta-manual').classList.add('hidden');
renderProductoresEjido();
mostrarToast(`${nombre} agregado a la sesión (sin app)`);
}
function eliminarProductorEjido(clave){
productoresSesionEjido = productoresSesionEjido.filter(p => p.clave !== clave);
filasAnimalesPruebaCampo = filasAnimalesPruebaCampo.filter(f => f.productorClave !== clave);
renderProductoresEjido();
renderFilasAnimalesPruebaCampo();
}
function renderProductoresEjido(){
const cont = document.getElementById('lista-productores-ejido');
if (!cont) return;
if (productoresSesionEjido.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-2" style="color:var(--sage);">Aún no agregas productores a esta sesión.</p>`;
return;
}
cont.innerHTML = productoresSesionEjido.map(p => `
<div class="flex items-center gap-2 bg-white rounded-xl p-2" style="border:2px solid var(--line);">
${avatarHtml(p.nombre, null, 32)}
<div class="flex-1 min-w-0">
<p class="text-sm font-bold truncate">${p.nombre} ${p.tipo === 'manual' ? '<span class="text-xs" style="color:var(--slate);">(sin app)</span>' : ''}</p>
<p class="text-xs" style="color:var(--sage);">${p.upp ? 'UPP ' + p.upp : 'sin UPP'} ${p.tipo === 'registrado' ? (p.animales === null ? '· cargando inventario...' : '· ' + p.animales.length + ' animal(es)') : ''}</p>
</div>
<button onclick="eliminarProductorEjido('${p.clave}')" style="color:var(--red);"><i class="fa-solid fa-trash"></i></button>
</div>`).join('');
guardarBorradorPruebaCampoActivo();
}
// ================= BÚSQUEDA RÁPIDA DE ARETE (por terminación) =================
function buscarPorTerminacionArete(){
const cont = document.getElementById('ba-resultado');
if (!cont) return;
const termino = valor('ba-terminacion').trim();
if (!termino){ cont.innerHTML = ''; return; }
const buscado = termino.toLowerCase();

if (modoPruebaCampo === 'ejido'){
if (productoresSesionEjido.length === 0){
cont.innerHTML = `<p class="text-xs mt-2" style="color:var(--sage);"><i class="fa-solid fa-circle-question mr-1"></i>Agrega al menos un productor a la sesión primero.</p>`;
return;
}
let coincidencias = [];
productoresSesionEjido.forEach(p => {
(p.animales || []).forEach(a => {
if ((a.arete || '').toLowerCase().endsWith(buscado)) coincidencias.push({ animal: a, productor: p });
});
});
if (coincidencias.length === 1){
const { animal: a, productor: p } = coincidencias[0];
cont.innerHTML = `
<div class="bg-white rounded-2xl p-3 mt-2" style="border:2px solid var(--green);">
<p class="text-sm font-bold">${a.arete} ${a.nombre ? '— ' + a.nombre : ''}</p>
<p class="text-xs" style="color:var(--sage);">${a.raza || 'sin raza'} · ${a.sexo === 'macho' ? 'Macho' : 'Hembra'} · Productor: <b>${p.nombre}</b></p>
<button onclick="confirmarBusquedaAreteEjido('${p.clave}','${(a.arete||'').replace(/'/g,"\\'")}')" class="w-full text-xs font-bold px-3 py-2 rounded-full mt-2" style="background:var(--green); color:#fff;"><i class="fa-solid fa-check"></i> Confirmar y agregar</button>
</div>`;
} else if (coincidencias.length > 1){
cont.innerHTML = `<p class="text-xs mt-2 font-bold" style="color:var(--red);"><i class="fa-solid fa-triangle-exclamation mr-1"></i>Hay ${coincidencias.length} animales con esa misma terminación (entre los productores de esta sesión) — anota el número completo del arete.</p>`;
} else {
cont.innerHTML = `
<div class="bg-white rounded-2xl p-3 mt-2" style="border:2px solid var(--yellow);">
<p class="text-xs font-bold" style="color:var(--sage);"><i class="fa-solid fa-circle-info mr-1"></i>No se encontró en ningún productor de la sesión. Agrégalo manualmente:</p>
<div class="space-y-2 mt-2">
<div><label class="campo-label">Arete completo</label><input class="campo-mayusculas" id="ba-manual-arete" oninput="forzarMayusculas(this)" placeholder="Arete completo" style="font-size:.85rem;" type="text" value="${termino}"/></div>
<div><label class="campo-label">Productor</label><select id="ba-manual-productor" style="font-size:.85rem;">
${productoresSesionEjido.map(p => `<option value="${p.clave}">${p.nombre}${p.upp ? ' — UPP ' + p.upp : ''}</option>`).join('')}
</select></div>
<div class="grid grid-cols-2 gap-2">
<div><label class="campo-label">Especie</label><select id="ba-manual-especie" style="font-size:.85rem;">
<option value="Bovino">Bovino</option><option value="Caprino">Caprino</option><option value="Ovino">Ovino</option><option value="Porcino">Porcino</option>
</select></div>
<div><label class="campo-label">Edad (meses)</label><input id="ba-manual-edad" placeholder="Edad (meses)" style="font-size:.85rem;" type="text"/></div>
</div>
<div><label class="campo-label">Sexo</label>
<div class="btn-sexo-grupo">
<button class="btn-sexo activo" id="ba-manual-sexo-btn-h" onclick="elegirSexoManual('h')" type="button">H — Hembra</button>
<button class="btn-sexo" id="ba-manual-sexo-btn-m" onclick="elegirSexoManual('m')" type="button">M — Macho</button>
</div>
<input id="ba-manual-sexo" type="hidden" value="H"/>
</div>
<div><label class="campo-label">Raza</label><input class="campo-mayusculas" id="ba-manual-raza" oninput="forzarMayusculas(this)" placeholder="Raza" style="font-size:.85rem;" type="text"/></div>
</div>
<button onclick="agregarAnimalManualDesdeBusqueda()" class="w-full text-xs font-bold px-3 py-2 rounded-full mt-2" style="background:var(--pine); color:#fff;"><i class="fa-solid fa-plus"></i> Agregar animal manualmente</button>
</div>`;
}
return;
}

if (!cacheAnimalesProductorPrueba){
cont.innerHTML = `<p class="text-xs mt-2" style="color:var(--sage);"><i class="fa-solid fa-circle-question mr-1"></i>Aún no se ha cargado el inventario del productor.</p>`;
return;
}
const coincidencias = cacheAnimalesProductorPrueba.filter(a => (a.arete || '').toLowerCase().endsWith(buscado));
if (coincidencias.length === 1){
const a = coincidencias[0];
cont.innerHTML = `
<div class="bg-white rounded-2xl p-3 mt-2" style="border:2px solid var(--green);">
<p class="text-sm font-bold">${a.arete} ${a.nombre ? '— ' + a.nombre : ''}</p>
<p class="text-xs" style="color:var(--sage);">${a.raza || 'sin raza'} · ${a.sexo === 'macho' ? 'Macho' : 'Hembra'} · Estatus: ${a.estatus || 'activo'}</p>
<button onclick="confirmarBusquedaArete('${a.arete.replace(/'/g,"\\'")}')" class="w-full text-xs font-bold px-3 py-2 rounded-full mt-2" style="background:var(--green); color:#fff;"><i class="fa-solid fa-check"></i> Confirmar y agregar</button>
</div>`;
} else if (coincidencias.length > 1){
cont.innerHTML = `<p class="text-xs mt-2 font-bold" style="color:var(--red);"><i class="fa-solid fa-triangle-exclamation mr-1"></i>Hay ${coincidencias.length} animales con esa misma terminación — anota el número completo del arete.</p>`;
} else {
cont.innerHTML = `
<div class="bg-white rounded-2xl p-3 mt-2" style="border:2px solid var(--yellow);">
<p class="text-xs font-bold" style="color:var(--sage);"><i class="fa-solid fa-circle-info mr-1"></i>Animal no encontrado en el inventario del productor. Si está presente en físico, agrégalo manualmente:</p>
<div class="space-y-2 mt-2">
<div><label class="campo-label">Arete completo</label><input class="campo-mayusculas" id="ba-manual-arete" oninput="forzarMayusculas(this)" placeholder="Arete completo" style="font-size:.85rem;" type="text" value="${termino}"/></div>
<div class="grid grid-cols-2 gap-2">
<div><label class="campo-label">Especie</label><select id="ba-manual-especie" style="font-size:.85rem;">
<option value="Bovino">Bovino</option><option value="Caprino">Caprino</option><option value="Ovino">Ovino</option><option value="Porcino">Porcino</option>
</select></div>
<div><label class="campo-label">Edad (meses)</label><input id="ba-manual-edad" placeholder="Edad (meses)" style="font-size:.85rem;" type="text"/></div>
</div>
<div><label class="campo-label">Sexo</label>
<div class="btn-sexo-grupo">
<button class="btn-sexo activo" id="ba-manual-sexo-btn-h" onclick="elegirSexoManual('h')" type="button">H — Hembra</button>
<button class="btn-sexo" id="ba-manual-sexo-btn-m" onclick="elegirSexoManual('m')" type="button">M — Macho</button>
</div>
<input id="ba-manual-sexo" type="hidden" value="H"/>
</div>
<div><label class="campo-label">Raza</label><input class="campo-mayusculas" id="ba-manual-raza" oninput="forzarMayusculas(this)" placeholder="Raza" style="font-size:.85rem;" type="text"/></div>
</div>
<button onclick="agregarAnimalManualDesdeBusqueda()" class="w-full text-xs font-bold px-3 py-2 rounded-full mt-2" style="background:var(--pine); color:#fff;"><i class="fa-solid fa-plus"></i> Agregar animal manualmente</button>
</div>`;
}
}
function elegirSexoManual(sexo){
const esH = sexo === 'h' || sexo === 'H';
establecerValor('ba-manual-sexo', esH ? 'H' : 'M');
const btnH = document.getElementById('ba-manual-sexo-btn-h');
const btnM = document.getElementById('ba-manual-sexo-btn-m');
if (btnH) btnH.classList.toggle('activo', esH);
if (btnM) btnM.classList.toggle('activo', !esH);
if (btnM) btnM.classList.toggle('es-macho', !esH);
}
function confirmarBusquedaArete(arete){
const animal = buscarAnimalPorArete(arete);
if (!animal) return;
let edadMeses = '';
if (animal.fecha){
try { edadMeses = String(Math.max(0, Math.floor(diasEntreISO(hoyISO(), animal.fecha) / 30))); } catch(e){}
}
const nuevoId = 'fila_' + Date.now() + Math.random().toString(36).slice(2,6);
filasAnimalesPruebaCampo.push({
id: nuevoId,
arete: animal.arete, especie:'Bovino', edad: edadMeses, sexo: sexoAHM(animal.sexo), raza: animal.raza || '', fierro:'',
resultado: tabPruebasCampoActual === 'prueba' ? 'N' : null,
});
marcarAnimalNuevoParaEdicion(nuevoId);
renderFilasAnimalesPruebaCampo();
establecerValor('ba-terminacion', '');
document.getElementById('ba-resultado').innerHTML = '';
mostrarToast(`Arete ${animal.arete} agregado`);
}
function confirmarBusquedaAreteEjido(productorClave, arete){
const p = productoresSesionEjido.find(x => x.clave === productorClave);
if (!p) return;
const animal = (p.animales || []).find(a => (a.arete || '') === arete);
if (!animal) return;
let edadMeses = '';
if (animal.fecha){
try { edadMeses = String(Math.max(0, Math.floor(diasEntreISO(hoyISO(), animal.fecha) / 30))); } catch(e){}
}
const nuevoId = 'fila_' + Date.now() + Math.random().toString(36).slice(2,6);
filasAnimalesPruebaCampo.push({
id: nuevoId,
productorClave,
arete: animal.arete, especie:'Bovino', edad: edadMeses, sexo: sexoAHM(animal.sexo), raza: animal.raza || '', fierro:'',
resultado: tabPruebasCampoActual === 'prueba' ? 'N' : null,
});
marcarAnimalNuevoParaEdicion(nuevoId);
renderFilasAnimalesPruebaCampo();
establecerValor('ba-terminacion', '');
document.getElementById('ba-resultado').innerHTML = '';
mostrarToast(`Arete ${animal.arete} agregado — ${p.nombre}`);
}
function agregarAnimalManualDesdeBusqueda(){
const arete = valor('ba-manual-arete').trim();
if (!arete){ mostrarToast('Escribe el número de arete'); return; }
const fila = {
id: 'fila_' + Date.now() + Math.random().toString(36).slice(2,6),
arete, especie: valor('ba-manual-especie'), edad: valor('ba-manual-edad').trim(), sexo: valor('ba-manual-sexo'), raza: valor('ba-manual-raza').trim(), fierro:'',
resultado: tabPruebasCampoActual === 'prueba' ? 'N' : null,
};
if (modoPruebaCampo === 'ejido'){
const sel = document.getElementById('ba-manual-productor');
if (!sel || !sel.value){ mostrarToast('Selecciona a qué productor pertenece'); return; }
fila.productorClave = sel.value;
}
filasAnimalesPruebaCampo.push(fila);
marcarAnimalNuevoParaEdicion(fila.id);
renderFilasAnimalesPruebaCampo();
establecerValor('ba-terminacion', '');
document.getElementById('ba-resultado').innerHTML = '';
mostrarToast(`Arete ${arete} agregado manualmente`);
}
function abrirSelectorInventarioProductor(){
if (!productorSeleccionadoPruebaCampo){ mostrarToast('Primero selecciona al productor'); return; }
if (!cacheAnimalesProductorPrueba){ mostrarToast('Aún no se ha cargado el inventario de este productor — inténtalo en unos segundos.'); return; }
seleccionInventarioProductor = new Set();
establecerValor('si-buscar', '');
renderSelectorInventarioProductor();
const modal = document.getElementById('modal-selector-inventario');
modal.classList.remove('hidden'); modal.style.display = 'flex';
}
function animalesVigentesProductor(){
return (cacheAnimalesProductorPrueba || []).filter(a => a.estatus !== 'vendido' && a.estatus !== 'finado');
}
function renderSelectorInventarioProductor(){
const cont = document.getElementById('lista-selector-inventario');
if (!cont) return;
const q = (valor('si-buscar') || '').trim().toLowerCase();
let animales = animalesVigentesProductor();
if (q) animales = animales.filter(a => (a.arete || '').toLowerCase().includes(q) || (a.nombre || '').toLowerCase().includes(q));
if (animales.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-3" style="color:var(--sage);">No hay animales vigentes que coincidan.</p>`;
return;
}
cont.innerHTML = animales.map((a, i) => {
const clave = a.id || a.arete || ('idx' + i);
const marcado = seleccionInventarioProductor.has(clave);
return `
<label class="flex items-center gap-3 bg-white rounded-xl p-2" style="border:2px solid ${marcado ? 'var(--teal)' : 'var(--line)'};">
<input onchange="toggleSeleccionInventario('${clave}', this.checked)" type="checkbox" ${marcado ? 'checked' : ''}/>
<div class="flex-1 min-w-0">
<p class="text-sm font-bold">${a.arete || 'Sin arete'} ${a.nombre ? '— ' + a.nombre : ''}</p>
<p class="text-xs" style="color:var(--sage);">${a.raza || 'sin raza'} · ${a.sexo === 'macho' ? 'Macho' : 'Hembra'} · Estatus: ${a.estatus || 'activo'}</p>
</div>
</label>`;
}).join('');
}
function toggleSeleccionInventario(clave, marcado){
if (marcado) seleccionInventarioProductor.add(clave);
else seleccionInventarioProductor.delete(clave);
}
function agregarSeleccionadosDeInventario(){
if (seleccionInventarioProductor.size === 0){ mostrarToast('No marcaste ningún animal'); return; }
const animales = animalesVigentesProductor();
let agregados = 0;
animales.forEach((a, i) => {
const clave = a.id || a.arete || ('idx' + i);
if (!seleccionInventarioProductor.has(clave)) return;
let edadMeses = '';
if (a.fecha){
try { edadMeses = String(Math.max(0, Math.floor(diasEntreISO(hoyISO(), a.fecha) / 30))); } catch(e){ edadMeses = ''; }
}
filasAnimalesPruebaCampo.push({
id: 'fila_' + Date.now() + Math.random().toString(36).slice(2,6),
arete: a.arete || '', especie:'Bovino', edad: edadMeses, sexo: sexoAHM(a.sexo), raza: a.raza || '', fierro:'',
resultado: tabPruebasCampoActual === 'prueba' ? 'N' : null,
});
agregados++;
});
renderFilasAnimalesPruebaCampo();
document.getElementById('modal-selector-inventario').classList.add('hidden');
mostrarToast(`${agregados} animal(es) agregado(s) desde el inventario`);
}
function verificarAreteFila(id, arete){
actualizarFilaAnimalPC(id, 'arete', arete);
const badge = document.getElementById('badge-verificacion-' + id);
if (!badge) return;
if (!arete || !arete.trim()){ badge.innerHTML = ''; return; }
if (!cacheAnimalesProductorPrueba){
badge.innerHTML = `<span class="text-xs" style="color:var(--sage);"><i class="fa-solid fa-circle-question mr-1"></i>Sin datos del productor para verificar</span>`;
return;
}
const animal = buscarAnimalPorArete(arete);
if (animal){
badge.innerHTML = `<span class="text-xs font-bold" style="color:var(--green);"><i class="fa-solid fa-circle-check mr-1"></i>Encontrado: ${animal.raza || 'sin raza'}, ${animal.sexo === 'macho' ? 'macho' : 'hembra'}${animal.nombre ? ' — ' + animal.nombre : ''}</span>`;
const f = filasAnimalesPruebaCampo.find(x => x.id === id);
if (f){
if (!f.raza && animal.raza) f.raza = animal.raza;
if (animal.sexo) f.sexo = sexoAHM(animal.sexo);
if (!f.edad && animal.fecha){
try { f.edad = String(Math.max(0, Math.floor(diasEntreISO(hoyISO(), animal.fecha) / 30))); } catch(e){}
}
const card = document.getElementById('tarjeta-animal-' + id);
if (card){
const inputRaza = card.querySelector('input[placeholder="Raza"]');
const inputEdad = card.querySelector('input[placeholder="Edad (meses)"]');
if (inputRaza && !inputRaza.value){ inputRaza.value = f.raza; marcarCampoLleno(inputRaza, true); }
if (inputEdad && !inputEdad.value){ inputEdad.value = f.edad; marcarCampoLleno(inputEdad, true); }
const btnesSexo = card.querySelectorAll('.btn-sexo-grupo button');
const btnElegir = f.sexo === 'M' ? btnesSexo[1] : btnesSexo[0];
if (btnElegir) elegirSexoFila(id, f.sexo, btnElegir);
}
actualizarTarjetaAnimalUI(id);
}
} else {
badge.innerHTML = `<span class="text-xs font-bold" style="color:var(--red);"><i class="fa-solid fa-triangle-exclamation mr-1"></i>No coincide con ningún animal registrado — verifica en físico</span>`;
}
}
// ================= VINCULAR ARETE NUEVO A UNA SOLICITUD DE ARETES PENDIENTE =================
// Cuando el veterinario coloca un arete físico a un animal que el productor había
// reportado "sin arete" en su Solicitud de aretes, este botón permite tomar el
// número recién capturado y asignarlo a uno de esos pendientes — así la solicitud
// del productor queda resuelta sin que tenga que hacerlo él por su cuenta.
let filaPendienteAreteNuevo = null;
function productorIdDeFilaPruebaCampo(f){
if (modoPruebaCampo === 'ejido'){
const p = productoresSesionEjido.find(x => x.clave === f.productorClave);
return p ? p.cuentaId : null;
}
return productorSeleccionadoPruebaCampo ? productorSeleccionadoPruebaCampo.id : null;
}
function abrirSelectorAreteNuevo(idFila){
const f = filasAnimalesPruebaCampo.find(x => x.id === idFila);
if (!f) return;
if (!f.arete || !f.arete.trim()){ mostrarToast('Primero escribe el número del arete nuevo'); return; }
const productorId = productorIdDeFilaPruebaCampo(f);
if (!productorId){ mostrarToast('Este productor no tiene cuenta en la app — no hay solicitud de aretes que buscar'); return; }
const pendientes = [];
(estado.solicitudesAretes || []).forEach(s => {
if (s.productorId !== productorId) return;
(s.animales || []).forEach((a, i) => { if (!a.arete) pendientes.push({ solicitud: s, animal: a, indice: i }); });
});
if (pendientes.length === 0){ mostrarToast('Este productor no tiene solicitudes de aretes pendientes'); return; }
filaPendienteAreteNuevo = idFila;
const ETIQUETAS_SEXO = { H:'Hembra', M:'Macho' };
const cont = document.getElementById('lista-selector-arete-nuevo-pc');
if (cont){
cont.innerHTML = pendientes.map(p => `
<button onclick="asignarAreteNuevoASolicitud('${p.solicitud.id}',${p.indice})" class="w-full text-left bg-white rounded-xl p-3" style="border:2px solid var(--line);" type="button">
<p class="text-sm font-bold">${ETIQUETAS_SEXO[p.animal.sexo] || p.animal.sexo}${p.animal.edad ? ', ' + p.animal.edad + ' meses' : ''}</p>
<p class="text-xs" style="color:var(--sage);">${p.animal.madre ? 'Madre: ' + p.animal.madre + ' ' : ''}${p.animal.padre ? '· Padre: ' + p.animal.padre : ''}${!p.animal.madre && !p.animal.padre ? 'Solicitado el ' + p.solicitud.fecha : ''}</p>
</button>`).join('');
}
const m = document.getElementById('modal-selector-arete-nuevo-pc');
if (m){ m.classList.remove('hidden'); m.style.display = 'flex'; }
}
function cerrarSelectorAreteNuevo(){
const m = document.getElementById('modal-selector-arete-nuevo-pc');
if (m){ m.classList.add('hidden'); m.style.removeProperty('display'); }
filaPendienteAreteNuevo = null;
}
function asignarAreteNuevoASolicitud(solicitudId, indice){
const f = filasAnimalesPruebaCampo.find(x => x.id === filaPendienteAreteNuevo);
const s = (estado.solicitudesAretes || []).find(x => x.id === solicitudId);
if (!f || !s || !s.animales[indice]){ cerrarSelectorAreteNuevo(); return; }
const item = s.animales[indice];
item.arete = f.arete;
item.fechaAsignado = hoyISO();
if (s.animales.every(a => a.arete)) {
  s.estatus = 'atendida';
  const origenAretes = estado.flujoOrigenPorId?.[s.id];
  if (origenAretes && typeof window.firebaseActualizarFlujo === 'function') window.firebaseActualizarFlujo(origenAretes, s.id, {estatus:'atendida'});
}
if (item.sexo) f.sexo = item.sexo;
if (item.edad && !f.edad) f.edad = item.edad;
guardarEstadoLocal();
const card = document.getElementById('tarjeta-animal-' + f.id);
if (card){
const inputEdad = card.querySelector('input[placeholder="Edad (meses)"]');
if (inputEdad && !inputEdad.value){ inputEdad.value = f.edad; marcarCampoLleno(inputEdad, true); }
const btnesSexo = card.querySelectorAll('.btn-sexo-grupo button');
const btnElegir = f.sexo === 'M' ? btnesSexo[1] : btnesSexo[0];
if (btnElegir) elegirSexoFila(f.id, f.sexo, btnElegir);
}
actualizarTarjetaAnimalUI(f.id);
cerrarSelectorAreteNuevo();
mostrarToast(`Arete ${f.arete} vinculado — la solicitud del productor queda actualizada`);
}
function agregarFilaAnimalPruebaCampo(){
const nuevoId = 'fila_' + Date.now() + Math.random().toString(36).slice(2,6);
filasAnimalesPruebaCampo.push({ id: nuevoId, arete:'', especie:'Bovino', edad:'', sexo:'H', raza:'', fierro:'', resultado:'N' });
marcarAnimalNuevoParaEdicion(nuevoId);
renderFilasAnimalesPruebaCampo();
}
function eliminarFilaAnimalPruebaCampo(id){
filasAnimalesPruebaCampo = filasAnimalesPruebaCampo.filter(f => f.id !== id);
animalesExpandidosPC.delete(id);
animalesEditandoPC.delete(id);
renderFilasAnimalesPruebaCampo();
}
// Al agregar uno o más animales nuevos, colapsa los anteriores (ya los revisó al
// registrarlos) y deja el/los recién agregados abiertos en edición para completarlos.
function marcarAnimalNuevoParaEdicion(...ids){
animalesExpandidosPC = new Set(ids);
animalesEditandoPC = new Set(ids);
}
function toggleVerAnimalPC(id){
if (animalesExpandidosPC.has(id)){
animalesExpandidosPC.delete(id);
animalesEditandoPC.delete(id);
} else {
animalesExpandidosPC.add(id);
}
renderFilasAnimalesPruebaCampo();
}
function activarEdicionAnimalPC(id){
animalesExpandidosPC.add(id);
animalesEditandoPC.add(id);
renderFilasAnimalesPruebaCampo();
}
function terminarEdicionAnimalPC(id){
animalesEditandoPC.delete(id);
renderFilasAnimalesPruebaCampo();
}
function actualizarResumenPruebaCampo(){
const total = document.getElementById('resumen-pc-total');
const negativos = document.getElementById('resumen-pc-negativos');
const reactores = document.getElementById('resumen-pc-reactores');
if (!total) return;
total.textContent = filasAnimalesPruebaCampo.length;
negativos.textContent = filasAnimalesPruebaCampo.filter(f => f.resultado === 'N').length;
reactores.textContent = filasAnimalesPruebaCampo.filter(f => f.resultado === 'R').length;
}
function camposRequeridosAnimal(){
return tabPruebasCampoActual === 'prueba' ? ['arete','edad','sexo','raza','resultado'] : ['arete','edad','sexo','raza'];
}
function camposFaltantesAnimal(f){
return camposRequeridosAnimal().filter(c => !f[c] || !String(f[c]).trim());
}
// Actualiza solo el borde de la tarjeta y el aviso "Completo / Falta X dato(s)" de
// un animal específico sin re-renderizar toda la lista — así no se pierde el foco
// ni la posición del cursor mientras la persona sigue escribiendo en otro campo.
function actualizarTarjetaAnimalUI(id){
const f = filasAnimalesPruebaCampo.find(x => x.id === id);
if (!f) return;
const card = document.getElementById('tarjeta-animal-' + id);
const estadoEl = document.getElementById('estado-animal-' + id);
const faltan = camposFaltantesAnimal(f);
const completa = faltan.length === 0;
if (card) card.style.borderColor = completa ? 'var(--green)' : 'var(--line)';
if (estadoEl){
estadoEl.style.color = completa ? 'var(--green)' : 'var(--sage)';
estadoEl.innerHTML = completa
? '<i class="fa-solid fa-circle-check"></i> Completo'
: `<i class="fa-solid fa-triangle-exclamation" style="color:var(--yellow-d);"></i> Falta${faltan.length > 1 ? 'n' : ''} ${faltan.length} dato${faltan.length > 1 ? 's' : ''}`;
}
}
function elegirSexoFila(id, sexo, btnEl){
actualizarFilaAnimalPC(id, 'sexo', sexo);
const grupo = btnEl.closest('.btn-sexo-grupo');
if (grupo){
grupo.querySelectorAll('.btn-sexo').forEach(b => b.classList.remove('activo', 'es-macho'));
btnEl.classList.add('activo');
if (sexo === 'M') btnEl.classList.add('es-macho');
}
actualizarTarjetaAnimalUI(id);
}
function renderFilasAnimalesPruebaCampo(){
const cont = document.getElementById('lista-animales-prueba-campo');
if (!cont) return;
const ETIQUETAS = { arete:'Arete', edad:'Edad', sexo:'Sexo', raza:'Raza', resultado:'Resultado' };
const razaOpciones = ['LN','BM','Holstein','Jersey','Brahman','Angus','Charolais','Simmental','Hereford','Pardo Suizo','Cebú','Criollo','Gyr','Sardo Negro','Limousin','Beefmaster','Brangus','Indubrasil'];
const escape = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const productorDeFila = f => modoPruebaCampo === 'ejido' ? productoresSesionEjido.find(p => p.clave === f.productorClave) : productorSeleccionadoPruebaCampo;
const edadInv = a => {
if (a && a.fecha){ try { return String(calcularEdadMesesDesdeFechaNacimiento(a.fecha) ?? Math.max(0, Math.floor(diasEntreISO(hoyISO(), a.fecha)/30))); } catch(e){} }
if (a && a.edadMeses != null) return String(a.edadMeses);
return '';
};
const datosFuente = f => {
const p = productorDeFila(f);
const lista = p && Array.isArray(p.animales) ? p.animales : (modoPruebaCampo === 'individual' && Array.isArray(cacheAnimalesProductorPrueba) ? cacheAnimalesProductorPrueba : []);
return lista.find(a => normalizarAretePC(a.arete) === normalizarAretePC(f.arete)) || null;
};
const faltantes = f => camposFaltantesAnimal(f);
const renderEditor = f => {
const a = datosFuente(f);
const fuente = a ? 'Inventario cotejado' : 'Captura manual';
const raza = f.raza || '';
const conflictos = Array.isArray(f.conflictosDatos) ? f.conflictosDatos : [];
return `<div class="pc-animal-editor" id="editor-animal-${f.id}">
<div class="text-xs mb-2 font-bold" style="color:${a ? 'var(--green)' : 'var(--sage)'};"><i class="fa-solid ${a ? 'fa-link' : 'fa-pen'}"></i> ${fuente}</div>
<div class="grid grid-cols-2 gap-2">
<div><label class="campo-label">Arete</label><input id="arete-input-${f.id}" inputmode="numeric" value="${escape(f.arete)}" oninput="actualizarFilaAnimalPC('${f.id}','arete',this.value); actualizarTarjetaAnimalUI('${f.id}')"/></div>
<div><label class="campo-label">Edad (meses)</label><input id="edad-input-${f.id}" inputmode="numeric" maxlength="3" value="${escape(f.edad)}" oninput="actualizarFilaAnimalPC('${f.id}','edad',this.value); actualizarTarjetaAnimalUI('${f.id}')"/></div>
<div><label class="campo-label">Raza</label><input id="raza-input-${f.id}" list="pc-lista-razas" value="${escape(raza)}" placeholder="Raza" oninput="actualizarFilaAnimalPC('${f.id}','raza',this.value); actualizarTarjetaAnimalUI('${f.id}')"/></div>
<div><label class="campo-label">Especie</label><select onchange="actualizarFilaAnimalPC('${f.id}','especie',this.value); actualizarTarjetaAnimalUI('${f.id}')"><option value="Bovino" ${f.especie==='Bovino'?'selected':''}>Bovino</option><option value="Caprino" ${f.especie==='Caprino'?'selected':''}>Caprino</option><option value="Ovino" ${f.especie==='Ovino'?'selected':''}>Ovino</option><option value="Porcino" ${f.especie==='Porcino'?'selected':''}>Porcino</option></select></div>
</div>
<div class="mt-2"><label class="campo-label">Sexo</label><div class="btn-sexo-grupo"><button class="btn-sexo ${f.sexo==='H'?'activo':''}" onclick="elegirSexoFila('${f.id}','H',this)" type="button">H — Hembra</button><button class="btn-sexo ${f.sexo==='M'?'activo es-macho':''}" onclick="elegirSexoFila('${f.id}','M',this)" type="button">M — Macho</button></div></div>
${tabPruebasCampoActual==='prueba' ? `<div class="mt-2"><label class="campo-label">Resultado</label><select onchange="actualizarFilaAnimalPC('${f.id}','resultado',this.value); actualizarResumenPruebaCampo(); actualizarTarjetaAnimalUI('${f.id}')"><option value="">Selecciona...</option><option value="N" ${f.resultado==='N'?'selected':''}>N — Negativo</option><option value="S" ${f.resultado==='S'?'selected':''}>S — Sospechoso</option><option value="R" ${f.resultado==='R'?'selected':''}>R — Reactor</option><option value="E" ${f.resultado==='E'?'selected':''}>E — Exento</option></select></div>` : ''}
${conflictos.length ? `<div class="pc-conflict-list">${conflictos.map((c,i)=>`<div class="w-full rounded-xl p-2 text-xs" style="background:#FEF2F2;border:1px solid var(--red);color:var(--ink);"><b><i class="fa-solid fa-triangle-exclamation" style="color:var(--red);"></i> ${escape(c.campo)}</b>: inventario = <b>${escape(c.inventario)}</b>; dictado = <b>${escape(c.dictado)}</b><div class="flex gap-2 mt-2"><button type="button" class="pc-outline-button" onclick="resolverConflictoAnimalPC('${f.id}',${i},'inventario')">Mantener inventario</button><button type="button" class="pc-primary-small" onclick="resolverConflictoAnimalPC('${f.id}',${i},'dictado')">Usar dictado</button></div></div>`).join('')}</div>` : ''}
<div class="grid grid-cols-2 gap-2 mt-3"><button type="button" class="pc-outline-button" onclick="terminarEdicionAnimalPC('${f.id}')"><i class="fa-solid fa-check"></i> Listo</button><button type="button" class="pc-outline-button" onclick="eliminarFilaAnimalPruebaCampo('${f.id}')" style="color:var(--red);"><i class="fa-solid fa-trash"></i> Quitar</button></div>
</div>`;
};
const row = f => {
const p = productorDeFila(f);
const miss = faltantes(f);
const conflictos = Array.isArray(f.conflictosDatos) ? f.conflictosDatos : [];
const open = animalesExpandidosPC.has(f.id);
const fuente = f.origenInventario ? '✓ Inventario' : 'Manual';
const resumen = [f.sexo==='M'?'Macho':(f.sexo==='H'?'Hembra':'sexo pendiente'), f.raza || 'raza pendiente', f.edad ? f.edad+' meses' : 'edad pendiente'].join(' · ');
const estadoClase = conflictos.length ? 'warn' : (miss.length ? '' : 'ok');
return `<div class="pc-animal-row ${estadoClase}" id="tarjeta-animal-${f.id}">
<div class="pc-animal-main">
<div class="min-w-0" onclick="toggleVerAnimalPC('${f.id}')" style="cursor:pointer"><div class="pc-animal-id">${escape(f.arete || 'Sin arete')}</div><div class="pc-animal-sub">${escape(resumen)}${p && modoPruebaCampo==='ejido' ? ' · '+escape(p.nombre) : ''}</div><div class="text-xs mt-1" style="color:${conflictos.length?'var(--red)':(miss.length?'var(--yellow-d)':'var(--green)')};font-weight:800"><i class="fa-solid ${conflictos.length?'fa-triangle-exclamation':(miss.length?'fa-circle-question':'fa-circle-check')}"></i> ${conflictos.length ? conflictos.length+' dato(s) por verificar' : (miss.length ? 'Faltan: '+miss.map(x=>ETIQUETAS[x]).join(', ') : 'Completo')} · ${fuente}</div></div>
<button type="button" class="pc-outline-button" onclick="toggleVerAnimalPC('${f.id}')"><i class="fa-solid ${open?'fa-chevron-up':'fa-pen'}"></i> ${open?'Cerrar':'Abrir'}</button>
</div>
${miss.length ? `<div class="pc-missing-list">${miss.map(c=>`<button type="button" class="pc-missing-btn" onclick="activarCampoFaltantePC('${f.id}','${c}')"><i class="fa-solid fa-plus"></i> ${ETIQUETAS[c]}</button>`).join('')}</div>` : ''}
${conflictos.length ? `<div class="pc-conflict-list">${conflictos.map(c=>`<button type="button" class="pc-conflict-btn" onclick="activarEdicionAnimalPC('${f.id}')"><i class="fa-solid fa-triangle-exclamation"></i> ${escape(c.campo)}: ${escape(c.inventario)} ≠ ${escape(c.dictado)}</button>`).join('')}</div>` : ''}
${open ? renderEditor(f) : ''}</div>`;
};
if (!filasAnimalesPruebaCampo.length){ cont.innerHTML = '<div class="rounded-2xl p-5 text-center bg-white" style="border:1px dashed var(--line);color:var(--sage);"><i class="fa-solid fa-cow text-2xl"></i><p class="text-sm font-bold mt-2">Aún no hay animales.</p><p class="text-xs">Escribe o dicta un arete arriba.</p></div>'; actualizarResumenPruebaCampo(); return; }
cont.innerHTML = (modoPruebaCampo==='ejido' ? productoresSesionEjido.flatMap(p => filasAnimalesPruebaCampo.filter(f=>f.productorClave===p.clave).map(row)).join('') : filasAnimalesPruebaCampo.map(row).join(''));
actualizarResumenPruebaCampo();
actualizarIndicadorConflictosPC();
guardarBorradorPruebaCampoActivo();
}
function normalizarAretePC(v){ return String(v||'').replace(/[^0-9a-z]/gi,'').toLowerCase().replace(/^mx/,'').replace(/^0+(?=\d{6,})/,''); }
function obtenerInventarioPC(productor){
if (!productor) return [];
if (Array.isArray(productor.animales)) return productor.animales;
if (Array.isArray(productor.hato)) return productor.hato;
return [];
}
function calcularEdadPC(animal){
if (!animal) return '';
if (animal.fechaNacimiento) { const e=calcularEdadMesesDesdeFechaNacimiento(animal.fechaNacimiento); if(e!=null) return String(e); }
if (animal.fecha) { const e=calcularEdadMesesDesdeFechaNacimiento(animal.fecha); if(e!=null) return String(e); }
if (animal.edadMeses != null) return String(animal.edadMeses);
return '';
}
function actualizarResumenProductorRapidoPC(){
const el=document.getElementById('pc-productor-activo-resumen'); if(!el) return;
const p=productorSeleccionadoPruebaCampo;
if(!p){el.innerHTML='<span class="text-sm" style="color:var(--sage);">Selecciona un productor</span>';return;}
el.innerHTML=`<p class="text-base font-bold truncate">${String(p.nombre||'').replace(/[<>]/g,'')}</p><p class="text-xs" style="color:var(--sage);">${p.upp?'UPP '+p.upp:'Sin UPP'}${p.predio?' · '+p.predio:''}</p>`;
}
function actualizarSelectorProductorRapidoPC(){
const sel=document.getElementById('pc-selector-productor-rapido'); if(!sel) return;
const arr=productoresSesionEjido||[]; sel.innerHTML='<option value="">Selecciona productor para capturar</option>'+arr.map(p=>`<option value="${p.clave}">${String(p.nombre||'').replace(/[<>]/g,'')}${p.upp?' — UPP '+p.upp:''}</option>`).join('');
if (typeof pcProductorActivoClave!=='undefined' && pcProductorActivoClave) sel.value=pcProductorActivoClave;
const activo=document.getElementById('pc-productor-activo-ejido'); const p=(productoresSesionEjido||[]).find(x=>x.clave===pcProductorActivoClave); if(activo) activo.innerHTML=p?`<i class="fa-solid fa-location-dot"></i> Trabajando con: <b>${String(p.nombre||'').replace(/[<>]/g,'')}</b>${p.upp?' · UPP '+p.upp:''}`:'';
}
let pcProductorActivoClave = null;
async function seleccionarProductorRapidoPC(clave){
if(!clave) return;
const p=(productoresSesionEjido||[]).find(x=>x.clave===clave); if(!p) return;
pcProductorActivoClave=clave;
productorSeleccionadoPruebaCampo=p;
cacheAnimalesProductorPrueba=Array.isArray(p.animales)?p.animales:null;
establecerValor('pc-buscar-arete-campo','');
actualizarSelectorProductorRapidoPC();
renderFilasAnimalesPruebaCampo();
setTimeout(()=>document.getElementById('pc-buscar-arete-campo')?.focus(),40);
}
function activarCampoFaltantePC(id,campo){
animalesExpandidosPC.add(id);animalesEditandoPC.add(id);renderFilasAnimalesPruebaCampo();
setTimeout(()=>{const el=document.getElementById(campo==='arete'?'arete-input-'+id:campo==='edad'?'edad-input-'+id:campo==='raza'?'raza-input-'+id:null);if(el){el.focus();el.select&&el.select();}},30);
}
function resolverConflictoAnimalPC(id,index,accion){
const f=filasAnimalesPruebaCampo.find(x=>x.id===id); if(!f||!Array.isArray(f.conflictosDatos)||!f.conflictosDatos[index]) return;
const c=f.conflictosDatos[index];
if(accion==='dictado'){ f[c.campoKey]=c.dictado; }
else { f[c.campoKey]=c.inventario; }
f.conflictosDatos.splice(index,1);
if(!f.conflictosDatos.length) delete f.conflictosDatos;
renderFilasAnimalesPruebaCampo();
}
function actualizarIndicadorConflictosPC(){
const el=document.getElementById('pc-indicador-conflictos');if(!el)return;
const n=filasAnimalesPruebaCampo.reduce((s,f)=>s+(Array.isArray(f.conflictosDatos)?f.conflictosDatos.length:0),0);
el.classList.toggle('hidden',!n);el.innerHTML=n?`<i class="fa-solid fa-triangle-exclamation"></i> ${n} por verificar`:' ';
}
function buscarAnimalEnSesionPruebaCampoVoz(arete){
const objetivo=normalizarAretePC(arete);if(!objetivo)return null;
const fila=filasAnimalesPruebaCampo.find(f=>{const x=normalizarAretePC(f.arete);return x&& (x===objetivo||x.endsWith(objetivo)||objetivo.endsWith(x));});
if(fila)return {fuente:'prueba',fila,animal:null,productor:productorDeFilaPC(fila)};
if(modoPruebaCampo==='ejido'){
for(const p of productoresSesionEjido){const a=obtenerInventarioPC(p).find(x=>{const id=normalizarAretePC(x.arete);return id&&(id===objetivo||id.endsWith(objetivo)||objetivo.endsWith(id));});if(a)return {fuente:'inventario',fila:null,animal:a,productor:p};}
return null;
}
const a=buscarAnimalPorArete(arete);return a?{fuente:'inventario',fila:null,animal:a,productor:productorSeleccionadoPruebaCampo}:null;
}
function productorDeFilaPC(f){ return modoPruebaCampo==='ejido' ? (productoresSesionEjido||[]).find(p=>p.clave===f.productorClave) : productorSeleccionadoPruebaCampo; }
function buscarAnimalCampoRapido(){
const cont=document.getElementById('pc-resultados-busqueda-campo');if(!cont)return;
const q=valor('pc-buscar-arete-campo').trim();if(!q){cont.innerHTML='';return;}
let fuentes=[];
if(modoPruebaCampo==='ejido'){
(productoresSesionEjido||[]).forEach(p=>obtenerInventarioPC(p).forEach(a=>{if(normalizarAretePC(a.arete).includes(normalizarAretePC(q)))fuentes.push({animal:a,productor:p});}));
}else if(cacheAnimalesProductorPrueba){cacheAnimalesProductorPrueba.forEach(a=>{if(normalizarAretePC(a.arete).includes(normalizarAretePC(q)))fuentes.push({animal:a,productor:productorSeleccionadoPruebaCampo});});}
const seen=new Set();fuentes=fuentes.filter(x=>{const k=(x.productor?.clave||x.productor?.id||'')+'|'+normalizarAretePC(x.animal.arete);if(seen.has(k))return false;seen.add(k);return true;}).slice(0,8);
const exactas=fuentes.filter(x=>normalizarAretePC(x.animal.arete)===normalizarAretePC(q));
if(exactas.length===1 && normalizarAretePC(q).length>=8){ agregarAnimalDesdeFuentePC(exactas[0].animal,exactas[0].productor); return; }
if(fuentes.length){cont.innerHTML=fuentes.map((x,i)=>`<button type="button" class="w-full text-left bg-white rounded-xl p-2" style="border:1px solid var(--line);" onclick="seleccionarResultadoBusquedaPC(${i})"><b>${String(x.animal.arete||'').replace(/[<>]/g,'')}</b><span class="text-xs" style="color:var(--sage);"> · ${String(x.animal.raza||'raza pendiente')} · ${x.animal.sexo==='Macho'?'Macho':'Hembra'}${modoPruebaCampo==='ejido'?' · '+String(x.productor.nombre||''):''}</span></button>`).join('');window._pcResultadosBusqueda=fuentes;}
else cont.innerHTML='<div class="rounded-xl p-2 text-xs" style="background:#FFFBEB;border:1px solid var(--yellow);">No está en el inventario local. Si el animal sí está presente, puedes agregarlo manualmente y elegir productor.</div><button type="button" class="w-full pc-primary-small mt-1" onclick="abrirAnimalNoEncontradoPC()"><i class="fa-solid fa-user-plus"></i> Agregar animal no encontrado</button>';
}
function seleccionarResultadoBusquedaPC(i){const x=(window._pcResultadosBusqueda||[])[i];if(!x)return;agregarAnimalDesdeFuentePC(x.animal,x.productor);}
function agregarAnimalDesdeFuentePC(animal,productor,dictado){
if (modoPruebaCampo==='ejido' && productor) { pcProductorActivoClave=productor.clave; productorSeleccionadoPruebaCampo=productor; cacheAnimalesProductorPrueba=obtenerInventarioPC(productor); actualizarSelectorProductorRapidoPC(); }
const idArete=animal.arete||'';const ya=filasAnimalesPruebaCampo.find(f=>normalizarAretePC(f.arete)===normalizarAretePC(idArete)&&(modoPruebaCampo!=='ejido'||f.productorClave===productor?.clave));
if(ya){if(dictado)aplicarDictadoConCotejoPC(ya,dictado,animal);animalesExpandidosPC.add(ya.id);animalesEditandoPC.add(ya.id);renderFilasAnimalesPruebaCampo();return ya;}
const f={id:'fila_'+Date.now()+Math.random().toString(36).slice(2,6),productorClave:modoPruebaCampo==='ejido'?(productor?.clave||null):null,arete:idArete,especie:animal.especie||'Bovino',edad:calcularEdadPC(animal),sexo:animal.sexo?sexoAHM(animal.sexo):'',raza:animal.raza||'',fierro:'',resultado:tabPruebasCampoActual==='prueba'?'N':null,origenInventario:true,fechaNacimiento:animal.fechaNacimiento||animal.fecha||null};
filasAnimalesPruebaCampo.push(f);if(dictado)aplicarDictadoConCotejoPC(f,dictado,animal);marcarAnimalNuevoParaEdicion(f.id);renderFilasAnimalesPruebaCampo();
establecerValor('pc-buscar-arete-campo','');document.getElementById('pc-resultados-busqueda-campo').innerHTML='';mostrarToast(`Arete ${idArete} encontrado${productor?.nombre?' · '+productor.nombre:''}`);return f;
}
function aplicarDictadoConCotejoPC(f,datos,animal){
const conflictos=[];const norm=s=>String(s||'').trim().toLowerCase();
const sexoInv=animal?.sexo?sexoAHM(animal.sexo):null; if(datos.sexo&&sexoInv&&datos.sexo!==sexoAHM(animal.sexo))conflictos.push({campo:'Sexo',campoKey:'sexo',inventario:sexoInv==='M'?'Macho':'Hembra',dictado:datos.sexo==='M'?'Macho':'Hembra'});
const razaInv=animal?.raza||'';if(datos.raza&&razaInv&&norm(datos.raza)!==norm(razaInv))conflictos.push({campo:'Raza',campoKey:'raza',inventario:razaInv,dictado:datos.raza});
const edadInv=calcularEdadPC(animal);if(datos.edad&&edadInv&&String(datos.edad)!==String(edadInv))conflictos.push({campo:'Edad',campoKey:'edad',inventario:edadInv+' meses',dictado:datos.edad+' meses'});
f.conflictosDatos=conflictos;
if(!animal?.raza&&datos.raza)f.raza=String(datos.raza).toUpperCase();
if(!animal?.sexo&&datos.sexo)f.sexo=datos.sexo==='macho'?'M':'H';
if(!animal?.fecha&&!edadInv&&datos.edad)f.edad=datos.edad;
}
function abrirAnimalNoEncontradoPC(datosVoz){
const m=document.getElementById('modal-animal-no-encontrado-pc');if(!m)return;
window._pcAnimalNoEncontradoDatos=datosVoz||null;
const arete=datosVoz?.arete||valor('pc-buscar-arete-campo')||'';establecerValor('pc-no-encontrado-arete',arete);establecerValor('pc-no-encontrado-edad',datosVoz?.edad||'');establecerValor('pc-no-encontrado-raza',datosVoz?.raza||'');establecerValor('pc-no-encontrado-especie','Bovino');establecerValor('pc-no-encontrado-sexo',datosVoz?.sexo==='macho'?'M':'H');elegirSexoNoEncontradoPC(datosVoz?.sexo==='macho'?'M':'H');
const sel=document.getElementById('pc-no-encontrado-productor');const arr=modoPruebaCampo==='ejido'?productoresSesionEjido:(productorSeleccionadoPruebaCampo?[productorSeleccionadoPruebaCampo]:[]);sel.innerHTML=arr.map(p=>`<option value="${p.clave||p.id}">${String(p.nombre||'').replace(/[<>]/g,'')}${p.upp?' — UPP '+p.upp:''}</option>`).join('');if(productorSeleccionadoPruebaCampo)sel.value=productorSeleccionadoPruebaCampo.clave||productorSeleccionadoPruebaCampo.id;
document.getElementById('pc-no-encontrado-resumen').innerHTML=`<b>Arete ${arete||'sin número'}</b><div class="text-xs mt-1" style="color:var(--sage);">No fue encontrado en la base local de inventario. Puedes agregarlo si lo verificaste físicamente.</div>`;m.classList.remove('hidden');m.style.display='flex';
}
function cerrarAnimalNoEncontradoPC(){const m=document.getElementById('modal-animal-no-encontrado-pc');if(m){m.classList.add('hidden');m.style.removeProperty('display');}}
function elegirSexoNoEncontradoPC(s){establecerValor('pc-no-encontrado-sexo',s);document.getElementById('pc-no-encontrado-h')?.classList.toggle('activo',s==='H');document.getElementById('pc-no-encontrado-m')?.classList.toggle('activo',s==='M');document.getElementById('pc-no-encontrado-m')?.classList.toggle('es-macho',s==='M');}
function confirmarAgregarAnimalNoEncontradoPC(){
const arete=valor('pc-no-encontrado-arete').trim();if(!arete){mostrarToast('Escribe el arete');return;}
const clave=valor('pc-no-encontrado-productor');let productor=null;if(modoPruebaCampo==='ejido')productor=productoresSesionEjido.find(p=>p.clave===clave);else productor=productorSeleccionadoPruebaCampo;if(!productor){mostrarToast('Selecciona el productor');return;}
const f={id:'fila_'+Date.now()+Math.random().toString(36).slice(2,6),productorClave:modoPruebaCampo==='ejido'?productor.clave:null,arete,especie:valor('pc-no-encontrado-especie')||'Bovino',edad:valor('pc-no-encontrado-edad'),sexo:valor('pc-no-encontrado-sexo')||'H',raza:valor('pc-no-encontrado-raza'),fierro:'',resultado:tabPruebasCampoActual==='prueba'?'N':null,origenInventario:false,animalNuevoConfirmado:true};
filasAnimalesPruebaCampo.push(f);marcarAnimalNuevoParaEdicion(f.id);cerrarAnimalNoEncontradoPC();establecerValor('pc-buscar-arete-campo','');document.getElementById('pc-resultados-busqueda-campo').innerHTML='';renderFilasAnimalesPruebaCampo();mostrarToast(`Animal ${arete} agregado a ${productor.nombre}`);
}

function actualizarFilaAnimalPC(id, campo, valorNuevo){
const f = filasAnimalesPruebaCampo.find(x => x.id === id);
if (f) f[campo] = valorNuevo;
guardarBorradorPruebaCampoActivo();
}
// Revisa todos los animales cargados y arma la lista de qué le falta a cada uno
// (usa los mismos campos requeridos que ya se marcan en rojo en cada tarjeta).
function listaAnimalesConDatosFaltantes(filas){
return filas.map((f, i) => ({ f, i, faltan: camposFaltantesAnimal(f) })).filter(x => x.faltan.length > 0);
}
const ETIQUETAS_CAMPO_ANIMAL = { arete:'Arete', edad:'Edad', sexo:'Sexo', raza:'Raza', resultado:'Resultado' };
let guardarPruebaCampoPendiente = null;
function mostrarAvisoDatosFaltantesPruebaCampo(faltantes, onGuardarDeTodasFormas){
guardarPruebaCampoPendiente = onGuardarDeTodasFormas;
const cont = document.getElementById('lista-aviso-datos-faltantes-pc');
if (cont){
cont.innerHTML = faltantes.map(x => `
<div class="rounded-xl p-2 text-xs" style="background:#FFFBEB; border:2px solid var(--yellow);">
<b>${x.f.arete ? x.f.arete : 'Animal #' + (x.i + 1) + ' (sin arete)'}</b> — falta: ${x.faltan.map(c => ETIQUETAS_CAMPO_ANIMAL[c] || c).join(', ')}
</div>`).join('');
}
const m = document.getElementById('modal-aviso-datos-faltantes-pc');
if (m){ m.classList.remove('hidden'); m.style.display = 'flex'; }
}
function cerrarAvisoDatosFaltantesPruebaCampo(){
const m = document.getElementById('modal-aviso-datos-faltantes-pc');
if (m){ m.classList.add('hidden'); m.style.removeProperty('display'); }
guardarPruebaCampoPendiente = null;
}
function confirmarGuardarPruebaCampoConFaltantes(){
const fn = guardarPruebaCampoPendiente;
const m = document.getElementById('modal-aviso-datos-faltantes-pc');
if (m){ m.classList.add('hidden'); m.style.removeProperty('display'); }
guardarPruebaCampoPendiente = null;
if (fn) fn();
}
function guardarPruebaCampo(){
if (modoPruebaCampo === 'ejido') return guardarPruebaCampoEjido();
if (!productorSeleccionadoPruebaCampo){ mostrarToast('Selecciona el productor'); return; }
if (filasAnimalesPruebaCampo.length === 0){ mostrarToast('Agrega al menos un animal'); return; }
const conflictos = filasAnimalesPruebaCampo.reduce((n,f)=>n+(Array.isArray(f.conflictosDatos)?f.conflictosDatos.length:0),0);
if (conflictos > 0){ filasAnimalesPruebaCampo.forEach(f=>{ if(Array.isArray(f.conflictosDatos)&&f.conflictosDatos.length){ animalesExpandidosPC.add(f.id); animalesEditandoPC.add(f.id); }}); renderFilasAnimalesPruebaCampo(); mostrarToast('Hay datos que no coinciden con el inventario. Revísalos antes de guardar.'); return; }
const faltantes = listaAnimalesConDatosFaltantes(filasAnimalesPruebaCampo);
if (faltantes.length > 0){ mostrarAvisoDatosFaltantesPruebaCampo(faltantes, guardarPruebaCampoEjecutar); return; }
guardarPruebaCampoEjecutar();
}
function guardarPruebaCampoEjecutar(){
const c = productorSeleccionadoPruebaCampo;
// Lo que el veterinario haya capturado aquí (para un productor nuevo o para
// completar datos que le faltaban) se guarda también en la cuenta del
// productor, no solo en esta prueba — así la próxima vez ya no aparece
// vacío y, si era un productor nuevo, queda dado de alta de verdad.
if (c){
const mapaCampos = {
apellidoPaterno:'pc-of-apellidopaterno', apellidoMaterno:'pc-of-apellidomaterno', nombres:'pc-of-nombres',
curp:'pc-of-curp', rfc:'pc-of-rfc', upp:'pc-of-clave-upp', predio:'pc-of-predio',
municipio:'pc-of-municipio', estadoMx:'pc-of-estado', localidad:'pc-of-localidad',
latitud:'pc-of-latitud', longitud:'pc-of-longitud',
domicilio:'pc-of-domicilio', codigoPostal:'pc-of-cp', telefono:'pc-of-telefono',
};
Object.entries(mapaCampos).forEach(([campoCuenta, idCampo]) => {
const v = valor(idCampo);
if (v) c[campoCuenta] = v;
});
if (!c.nombre && (c.apellidoPaterno || c.nombres)) c.nombre = [c.nombres, c.apellidoPaterno, c.apellidoMaterno].filter(Boolean).join(' ');
guardarEstadoLocal();
}
const vet = veterinarioActivo();
const tipoPrueba = tabPruebasCampoActual === 'prueba' ? valor('pc-tipo-prueba') : 'Areteo';
const datos = {
categoria: tabPruebasCampoActual,
tipoPrueba,
motivo: valor('pc-motivo'), tipoIdentificacion: valor('pc-tipo-identificacion'), finalidad: valor('pc-finalidad'),
dosis: valor('pc-dosis'), lote: valor('pc-lote'),
fechaInyeccion: valor('pc-fecha-inyeccion'), horaInyeccion: valor('pc-hora-inyeccion'),
fechaLectura: valor('pc-fecha-lectura'), horaLectura: valor('pc-hora-lectura'),
fechaCaducidad: valor('pc-fecha-caducidad'), fechaMuestra: valor('pc-fecha-muestra'),
veterinarioNombre: vet ? vet.nombre : '', mvzClave: vet ? (vet.cedula || '') : '',
apellidoPaterno: valor('pc-of-apellidopaterno'), apellidoMaterno: valor('pc-of-apellidomaterno'), nombres: valor('pc-of-nombres'),
domicilio: valor('pc-of-domicilio'), localidad: valor('pc-of-localidad'), cp: valor('pc-of-cp'),
estadoMx: valor('pc-of-estado'), municipio: valor('pc-of-municipio'), telefonoProductor: valor('pc-of-telefono'),
latitud: valor('pc-of-latitud'), longitud: valor('pc-of-longitud'), claveUpp: valor('pc-of-clave-upp'),
folioTB: valor('pc-of-folio-tb'), ccNo: valor('pc-of-cc-no'), dictamenTB: valor('pc-of-dictamen-tb'), tipoAplicacion: valor('pc-of-tipo-aplicacion'),
productorId: c.id, productorNombre: c.nombre, predio: c.predio, upp: c.upp, curp: c.curp || '',
animales: filasAnimalesPruebaCampo.map(f => ({ arete:f.arete, especie:f.especie, edad:f.edad, sexo:f.sexo, raza:f.raza, fierro:f.fierro, fierroImagenUrl:f.fierroImagenUrl || null, resultado: tabPruebasCampoActual === 'prueba' ? f.resultado : null })),
};
if (editandoPruebaCampoId){
const idx = estado.pruebasCampoVet.findIndex(x => x.id === editandoPruebaCampoId);
if (idx > -1){
if (editandoEsLectura) datos.leida = true;
estado.pruebasCampoVet[idx] = { ...estado.pruebasCampoVet[idx], ...datos };
}
} else {
estado.pruebasCampoVet.push({ id: 'pc_' + Date.now(), compartida: false, estatusProductor: null, fecha: hoyISO(), leida: false, ...datos });
}
guardarEstadoLocal();
// Lo capturado en campo también actualiza el inventario del productor. Si no hay señal,
// queda en una cola local y se sincroniza al recuperar conexión.
if (!editandoEsLectura){ filasAnimalesPruebaCampo.forEach(f => { const pid = productorIdDeFilaPruebaCampo(f); if(pid) programarSyncAnimalProductorPC(pid, f); }); }
mostrarToast(editandoEsLectura ? 'Lectura registrada' : 'Registro guardado');
if (editandoEsLectura){
const reactores = filasAnimalesPruebaCampo.filter(f => f.resultado === 'R');
if (reactores.length > 0){
setTimeout(() => mostrarToast(`⚠️ ${reactores.length} animal(es) marcado(s) como Reactor — genera el Reporte de reactores para enviarlo al CEFPP`), 1200);
if (datos.tipoPrueba === 'TB'){
const pruebaGuardada = estado.pruebasCampoVet.find(x => x.id === (editandoPruebaCampoId || ''));
generarAvisoReactoresTB(pruebaGuardada || { ...datos, id: editandoPruebaCampoId }, reactores);
}
const informePrueba = { ...(estado.pruebasCampoVet.find(x => x.id === (editandoPruebaCampoId || '')) || datos), leida:true };
enviarFlujoConReintento('comite_dgo', informePrueba.id || ('inf_' + Date.now()), 'informe_prueba', informePrueba, {enviadoPor:'veterinario', estatus:'pendiente', origenBandeja:'vet_' + (estado.veterinarioActivoId || '')});
}
}
editandoPruebaCampoId = null;
editandoEsLectura = false;
limpiarBorradorPruebaCampoActivo();
volverAtrasAdmin('pruebascampo');
}
const CLAVE_COLA_SYNC_HATO_PC = 'iranch_pc_sync_hato_pendiente';
let timerSyncHatoPC = null;
function leerColaSyncHatoPC(){ try { return JSON.parse(localStorage.getItem(CLAVE_COLA_SYNC_HATO_PC)||'[]') || []; } catch(e){ return []; } }
function guardarColaSyncHatoPC(q){ try { localStorage.setItem(CLAVE_COLA_SYNC_HATO_PC, JSON.stringify(q.slice(-40))); } catch(e){} }
async function sincronizarAnimalesConProductorPC(cuentaId, animales){
if(!cuentaId||!Array.isArray(animales)||!animales.length)return false;
if(!navigator.onLine || typeof window.firebaseLeerCuenta!=='function' || typeof window.firebaseGuardarCuenta!=='function')return false;
try{
const remoto=await window.firebaseLeerCuenta(cuentaId);if(!remoto)return false;
const hato=Array.isArray(remoto.hato)?remoto.hato.slice():(Array.isArray(remoto.animales)?remoto.animales.slice():[]);
for(const animal of animales){
if(!animal?.arete)continue;
const guardado={...animal};delete guardado.id;delete guardado.productorClave;delete guardado.conflictosDatos;delete guardado.origenInventario;delete guardado.animalNuevoConfirmado;delete guardado.fechaNacimiento;
const i=hato.findIndex(a=>normalizarAretePC(a.arete)===normalizarAretePC(animal.arete));
if(i>=0)hato[i]={...hato[i],...guardado};else hato.push({...guardado,estatus:guardado.estatus||'Activo'});
}
remoto.hato=hato;if(remoto.animales)delete remoto.animales;
return await window.firebaseGuardarCuenta(cuentaId,remoto);
}catch(e){console.warn('No se pudo sincronizar animales con la cuenta del productor',e);return false;}
}
async function sincronizarColaHatoPC(){
let q=leerColaSyncHatoPC();if(!q.length||!navigator.onLine)return;
const restantes=[];
for(const item of q){const ok=await sincronizarAnimalesConProductorPC(item.cuentaId,item.animales||[]);if(!ok)restantes.push(item);}
guardarColaSyncHatoPC(restantes);
if(!restantes.length&&q.length)mostrarToast('Inventario del productor actualizado');
}
function programarSyncAnimalProductorPC(cuentaId, animal){
if(!cuentaId||!animal)return;
const q=leerColaSyncHatoPC();let item=q.find(x=>x.cuentaId===cuentaId);
if(!item){item={cuentaId,animales:[]};q.push(item);}
const i=item.animales.findIndex(a=>normalizarAretePC(a.arete)===normalizarAretePC(animal.arete));
if(i>=0)item.animales[i]={...item.animales[i],...animal};else item.animales.push({...animal});
guardarColaSyncHatoPC(q);
clearTimeout(timerSyncHatoPC);timerSyncHatoPC=setTimeout(()=>sincronizarColaHatoPC(),350);
}
window.addEventListener('online',()=>setTimeout(sincronizarColaHatoPC,600));

function guardarPruebaCampoEjido(){
if (productoresSesionEjido.length === 0){ mostrarToast('Agrega al menos un productor a la sesión'); return; }
if (filasAnimalesPruebaCampo.length === 0){ mostrarToast('Agrega al menos un animal'); return; }
const conflictos = filasAnimalesPruebaCampo.reduce((n,f)=>n+(Array.isArray(f.conflictosDatos)?f.conflictosDatos.length:0),0);
if (conflictos > 0){ filasAnimalesPruebaCampo.forEach(f=>{ if(Array.isArray(f.conflictosDatos)&&f.conflictosDatos.length){ animalesExpandidosPC.add(f.id); animalesEditandoPC.add(f.id); }}); renderFilasAnimalesPruebaCampo(); mostrarToast('Hay datos que no coinciden con el inventario. Revísalos antes de guardar.'); return; }
const faltantes = listaAnimalesConDatosFaltantes(filasAnimalesPruebaCampo);
if (faltantes.length > 0){ mostrarAvisoDatosFaltantesPruebaCampo(faltantes, guardarPruebaCampoEjidoEjecutar); return; }
guardarPruebaCampoEjidoEjecutar();
}
function guardarPruebaCampoEjidoEjecutar(){
const vet = veterinarioActivo();
const tipoPrueba = tabPruebasCampoActual === 'prueba' ? valor('pc-tipo-prueba') : 'Areteo';
const camposComunes = {
categoria: tabPruebasCampoActual, tipoPrueba,
motivo: valor('pc-motivo'), tipoIdentificacion: valor('pc-tipo-identificacion'), finalidad: valor('pc-finalidad'),
dosis: valor('pc-dosis'), lote: valor('pc-lote'),
fechaInyeccion: valor('pc-fecha-inyeccion'), horaInyeccion: valor('pc-hora-inyeccion'),
fechaLectura: valor('pc-fecha-lectura'), horaLectura: valor('pc-hora-lectura'),
fechaCaducidad: valor('pc-fecha-caducidad'), fechaMuestra: valor('pc-fecha-muestra'),
veterinarioNombre: vet ? vet.nombre : '', mvzClave: vet ? (vet.cedula || '') : '',
latitud: valor('pc-of-latitud'), longitud: valor('pc-of-longitud'), claveUpp: valor('pc-of-clave-upp'), cp: valor('pc-of-cp'),
folioTB: valor('pc-of-folio-tb'), ccNo: valor('pc-of-cc-no'), dictamenTB: valor('pc-of-dictamen-tb'), tipoAplicacion: valor('pc-of-tipo-aplicacion'),
};
let creadas = 0;
productoresSesionEjido.forEach(p => {
const filas = filasAnimalesPruebaCampo.filter(f => f.productorClave === p.clave);
if (filas.length === 0) return;
estado.pruebasCampoVet.push({
id: 'pc_' + Date.now() + '_' + Math.random().toString(36).slice(2,6),
...camposComunes,
productorId: p.cuentaId, productorNombre: p.nombre, predio: p.predio || '', upp: p.upp || '', curp: p.curp || '',
apellidoPaterno: p.apellidoPaterno || '', apellidoMaterno: p.apellidoMaterno || '', nombres: p.nombres || '',
domicilio: p.domicilio || '', estadoMx: p.estadoMx || '', municipio: p.municipio || '', localidad: p.localidad || '', telefonoProductor: p.telefono || '',
// Si este productor trae su propia UPP/GPS guardados (se agregó por "Buscar
// cuenta"), se usan los suyos en vez del campo compartido de la sesión.
latitud: (p.latitud != null && p.latitud !== '') ? String(p.latitud) : camposComunes.latitud,
longitud: (p.longitud != null && p.longitud !== '') ? String(p.longitud) : camposComunes.longitud,
claveUpp: p.upp || camposComunes.claveUpp,
esProductorManual: p.tipo === 'manual',
animales: filas.map(f => ({ arete:f.arete, especie:f.especie, edad:f.edad, sexo:f.sexo, raza:f.raza, fierro:f.fierro, fierroImagenUrl:f.fierroImagenUrl || null, resultado: tabPruebasCampoActual === 'prueba' ? f.resultado : null })),
compartida: false, estatusProductor: null, fecha: hoyISO(), leida: false,
});
creadas++;
if (p.cuentaId) filas.forEach(f => programarSyncAnimalProductorPC(p.cuentaId, f));
});
guardarEstadoLocal();
mostrarToast(`${creadas} hoja(s) de campo guardadas (una por productor)`);
limpiarBorradorPruebaCampoActivo();
volverAtrasAdmin('pruebascampo');
}
function sexoAHM(sexo){
return sexo === 'macho' || sexo === 'M' ? 'M' : 'H';
}

// [iRANCH MODULAR] tb cargado bajo demanda.
// ================= CAPTURISTA (oficina) =================
function renderPruebasCapturista(soloTB){
const cont = document.getElementById(soloTB ? 'lista-pruebas-capturista-tb' : 'lista-pruebas-capturista');
if (!cont) return;
const prefijo = soloTB ? 'capttb' : 'capt';
const filtroEstatus = valor(prefijo + '-filtro-estatus') || 'pendientes';
const q = (valor(prefijo + '-buscar') || '').trim().toLowerCase();
let items = estado.pruebasCampoVet.filter(p => p.categoria === 'areteo' || p.leida);
if (soloTB) items = items.filter(p => p.tipoPrueba === 'TB');
if (filtroEstatus === 'pendientes') items = items.filter(p => !p.capturada);
else if (filtroEstatus === 'capturadas') items = items.filter(p => p.capturada);
else if (filtroEstatus === 'impresas') items = items.filter(p => p.impresa);
if (q) items = items.filter(p => (p.productorNombre || '').toLowerCase().includes(q) || (p.upp || '').toLowerCase().includes(q));
items = items.sort((a,b) => (b.fecha||'').localeCompare(a.fecha||''));
if (items.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-keyboard"></i><p>No hay pruebas para mostrar con este filtro.</p></div>`;
return;
}
const ETIQUETAS_RESULTADO = { N:'Negativo', S:'Sospechoso', R:'Reactor', E:'Exento' };
cont.innerHTML = items.map(p => `
<div class="item-registro" style="border-left:6px solid ${p.capturada ? 'var(--green)' : 'var(--teal)'};">
<p class="font-bold">${p.tipoPrueba} — ${p.productorNombre}</p>
<p class="text-sm" style="color:var(--sage);">${p.predio || ''} ${p.upp ? '· UPP ' + p.upp : ''} · ${p.fecha} · Vet: ${p.veterinarioNombre || '—'}</p>
<div class="mt-2 space-y-1">
${p.animales.map((a, i) => `<p class="text-xs" style="color:var(--ink);">${i+1}. ${a.arete || 'sin arete'} — ${a.especie}, ${a.sexo === 'H' ? 'hembra' : 'macho'}, ${a.raza || 'sin raza'}${a.resultado ? ' — ' + (ETIQUETAS_RESULTADO[a.resultado] || a.resultado) : ''}</p>`).join('')}
</div>
${p.capturada ? `<span class="text-xs px-2 py-0.5 rounded-full inline-block mt-2" style="background:var(--green); color:#fff;">Ya capturada</span>` : ''}
${p.impresa ? `<span class="text-xs px-2 py-0.5 rounded-full inline-block mt-2 ml-1" style="background:var(--slate); color:#fff;">Impresa el ${p.fechaImpresion}</span>` : ''}
<div class="flex flex-wrap gap-2 mt-3">
<button onclick="copiarDatosPruebaCapturista('${p.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--parchment); color:var(--pine); border:2px solid var(--line);"><i class="fa-solid fa-copy"></i> Copiar datos</button>
<button onclick="exportarPruebaCampo('${p.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--parchment); color:var(--pine); border:2px solid var(--line);"><i class="fa-solid fa-file-export"></i> Exportar / imprimir</button>
<button onclick="abrirVistaPreviaDictamen('${p.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--slate); color:#fff;"><i class="fa-solid fa-print"></i> Imprimir nueva hoja de campo</button>
${p.tipoPrueba === 'TB' ? `<button onclick="abrirVistaPreviaDictamenTB('${p.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--purple); color:#fff;"><i class="fa-solid fa-file-medical"></i> Imprimir dictamen de TB</button>` : ''}
${p.tipoPrueba === 'Brucelosis' ? `<button onclick="abrirVistaPreviaDictamenBR('${p.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--orange); color:#fff;"><i class="fa-solid fa-file-medical"></i> Imprimir dictamen de BR</button>` : ''}
${!p.capturada ? `<button onclick="marcarPruebaCapturada('${p.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--green); color:#fff;"><i class="fa-solid fa-check"></i> Marcar como capturada</button>` : ''}
${!p.impresa ? `<button onclick="marcarPruebaImpresa('${p.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--slate); color:#fff;"><i class="fa-solid fa-print"></i> Marcar como impresa</button>` : ''}
</div>
</div>`).join('');
}
function copiarDatosPruebaCapturista(id){
const p = estado.pruebasCampoVet.find(x => x.id === id);
if (!p) return;
const ETIQUETAS_RESULTADO = { N:'Negativo', S:'Sospechoso', R:'Reactor', E:'Exento' };
const lineas = [
`${p.tipoPrueba} — ${p.productorNombre}`,
`Predio: ${p.predio || ''}  UPP: ${p.upp || ''}  CURP: ${p.curp || ''}`,
`Fecha: ${p.fecha}  Veterinario: ${p.veterinarioNombre || ''}`,
'',
...p.animales.map((a, i) => `${i+1}. ${a.arete || 'sin arete'} | ${a.especie} | ${a.edad} meses | ${a.sexo === 'H' ? 'H' : 'M'} | ${a.raza || ''}${a.resultado ? ' | ' + (ETIQUETAS_RESULTADO[a.resultado] || a.resultado) : ''}`),
];
const texto = lineas.join('\n');
if (navigator.clipboard && navigator.clipboard.writeText){
navigator.clipboard.writeText(texto).then(() => mostrarToast('Datos copiados — pégalos donde los necesites')).catch(() => mostrarToast(texto));
} else {
mostrarToast(texto);
}
}
function marcarPruebaCapturada(id){
const p = estado.pruebasCampoVet.find(x => x.id === id);
if (!p) return;
p.capturada = true;
guardarEstadoLocal();
renderPruebasCapturista(false); renderPruebasCapturista(true);
mostrarToast('Marcada como capturada');
}
// ================= PRUEBAS REALIZADAS (buscador + exportar/compartir) =================
function renderPruebasRealizadas(){
const cont = document.getElementById('lista-pruebas-realizadas');
if (!cont) return;
const q = (valor('pr-buscar') || '').trim().toLowerCase();
let items = estado.pruebasCampoVet.filter(p => p.categoria === 'areteo' || p.leida);
if (q) items = items.filter(p => (p.productorNombre || '').toLowerCase().includes(q) || (p.upp || '').toLowerCase().includes(q));
items = items.sort((a,b) => (b.fecha||'').localeCompare(a.fecha||''));
if (items.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-magnifying-glass"></i><p>${q ? 'Sin resultados para "' + q + '"' : 'Aún no hay pruebas realizadas.'}</p></div>`;
return;
}
cont.innerHTML = items.map(p => {
const clave = 'pr_' + p.id;
EXPORT_REGISTRY[clave] = () => construirConfigExportPrueba(p);
return `
<div class="item-registro" style="border-left:6px solid ${p.categoria === 'prueba' ? 'var(--purple)' : 'var(--orange)'};">
<p class="font-bold">${p.tipoPrueba} — ${p.productorNombre}</p>
<p class="text-sm" style="color:var(--sage);">${p.predio || ''} ${p.upp ? '· UPP ' + p.upp : ''} · ${p.fecha}</p>
<p class="text-sm" style="color:var(--sage);">${p.animales.length} animal(es) · Vet: ${p.veterinarioNombre || '—'}</p>
<div class="flex flex-wrap gap-2 mt-3">
<button onclick="abrirMenuExportarPrueba('${p.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--teal); color:#fff;"><i class="fa-solid fa-file-arrow-down"></i> Excel / Compartir</button>
</div>
</div>`;
}).join('');
}
function construirConfigExportPrueba(p){
const ETIQUETAS_RESULTADO = { N:'Negativo', S:'Sospechoso', R:'Reactor', E:'Exento' };
const encabezados = p.categoria === 'prueba'
? ['Productor','Predio','UPP','CURP','Identificación','Especie','Edad','Sexo','Raza','Fierro','Resultado']
: ['Productor','Predio','UPP','CURP','Identificación','Especie','Edad','Sexo','Raza','Fierro'];
const filas = p.animales.map(a => p.categoria === 'prueba'
? [p.productorNombre, p.predio, p.upp, p.curp || '', a.arete, a.especie, a.edad, a.sexo, a.raza, a.fierro || '', ETIQUETAS_RESULTADO[a.resultado] || a.resultado]
: [p.productorNombre, p.predio, p.upp, p.curp || '', a.arete, a.especie, a.edad, a.sexo, a.raza, a.fierro || '']);
return { titulo: `${p.tipoPrueba} - ${p.productorNombre} - ${p.fecha}`, encabezados, filas };
}
function abrirMenuExportarPrueba(pruebaId){
const p = estado.pruebasCampoVet.find(x => x.id === pruebaId);
if (!p) return;
hiloAbiertoCuentaId = p.productorId;
abrirMenuExportar('pr_' + pruebaId);
}
// ================= SOLICITUDES CEFP (capturista / Almita) — requieren aprobación del admin =================
function renderSolicitudesCEFP(){
const cont = document.getElementById('lista-solicitudes-cefp');
if (!cont) return;
const items = (estado.solicitudesCEFP || []).slice().sort((a,b) => (b.fecha||'').localeCompare(a.fecha||''));
if (items.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-user-clock"></i><p>No hay solicitudes de cuenta CEFPP.</p></div>`;
return;
}
const ETIQUETAS_PUESTO = { capturista:'Capturista', almita:'Emisora de solicitudes', capturista_tb:'Capturista TB' };
const ETIQUETAS_ESTATUS = { pendiente:'Pendiente de autorizar', aprobada:'Aprobada', rechazada:'Rechazada' };
const COLORES = { pendiente:'var(--yellow)', aprobada:'var(--green)', rechazada:'var(--red)' };
cont.innerHTML = items.map(s => `
<div class="item-registro" style="border-left:6px solid var(--teal);">
<p class="font-bold">${s.nombre} — ${ETIQUETAS_PUESTO[s.puesto] || s.puesto}</p>
<p class="text-sm" style="color:var(--sage);">${s.centroTrabajo || ''} · CURP: ${s.curp || ''}</p>
<p class="text-sm" style="color:var(--sage);">Tel: ${s.telefono || ''} · Usuario solicitado: ${s.usuario} · ${s.fecha}</p>
<span class="text-xs px-2 py-0.5 rounded-full inline-block mt-1" style="background:${COLORES[s.estatus]}; color:#fff;">${ETIQUETAS_ESTATUS[s.estatus]}</span>
${s.estatus === 'pendiente' ? `
<div class="flex gap-2 mt-3">
<button onclick="aprobarSolicitudCEFP('${s.id}')" class="text-xs font-bold px-3 py-2 rounded-full flex-1" style="background:var(--green); color:#fff;"><i class="fa-solid fa-check"></i> Autorizar cuenta</button>
<button onclick="rechazarSolicitudCEFP('${s.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--parchment); color:var(--red); border:2px solid var(--line);"><i class="fa-solid fa-xmark"></i></button>
</div>` : ''}
</div>`).join('');
}
function aprobarSolicitudCEFP(id){
const s = (estado.solicitudesCEFP || []).find(x => x.id === id);
if (!s) return;
if (existeUsuarioDuplicado(s.usuario)){ mostrarToast('Ese usuario ya existe, no se puede autorizar'); return; }
const ETIQUETAS_PUESTO_USR = { almita:'Emisora de solicitudes', capturista_tb:'Capturista TB', capturista:'Capturista' };
estado.usuarios.push({ nombre: s.nombre + ' (' + (ETIQUETAS_PUESTO_USR[s.puesto] || 'Capturista') + ')', usuario: s.usuario, clave: s.clave, rol: s.puesto });
s.estatus = 'aprobada';
guardarEstadoLocal();
renderSolicitudesCEFP(); renderGridAdminHome(); renderListaUsuarios();
mostrarToast(`Cuenta autorizada para ${s.nombre}`);
}
function rechazarSolicitudCEFP(id){
const s = (estado.solicitudesCEFP || []).find(x => x.id === id);
if (!s) return;
s.estatus = 'rechazada';
guardarEstadoLocal();
renderSolicitudesCEFP();
mostrarToast('Solicitud rechazada');
}
// ================= ALMITA (departamento de TB) =================
function enviarAAlmita(pruebaId){
const p = estado.pruebasCampoVet.find(x => x.id === pruebaId);
if (!p) return;
estado.enviosAlmita.push({
id: 'alm_' + Date.now(), pruebaId: p.id,
tipoPrueba: p.tipoPrueba, productorNombre: p.productorNombre, predio: p.predio, upp: p.upp, curp: p.curp || '',
veterinarioNombre: p.veterinarioNombre, fecha: p.fecha,
animales: p.animales, reactores: contarReactores(p),
fechaEnvio: hoyISO(), revisado: false,
});
p.enviadaAlmita = true;
guardarEstadoLocal();
renderListaPruebasCampo();
mostrarToast('Enviado al centro de solicitudes del CEFPP');
}
function renderEnviosAlmita(){
const cont = document.getElementById('lista-envios-almita');
if (!cont) return;
const filtro = valor('almita-filtro-estatus') || 'recibidos';
const q = (valor('almita-buscar') || '').trim().toLowerCase();
let items = estado.enviosAlmita || [];
if (filtro === 'recibidos') items = items.filter(e => !e.revisado);
else if (filtro === 'revisados') items = items.filter(e => e.revisado);
if (q) items = items.filter(e => (e.productorNombre || '').toLowerCase().includes(q) || (e.upp || '').toLowerCase().includes(q));
items = items.sort((a,b) => (b.fechaEnvio||'').localeCompare(a.fechaEnvio||''));
if (items.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-envelope-open-text"></i><p>No hay envíos para mostrar con este filtro.</p></div>`;
return;
}
cont.innerHTML = items.map(e => `
<div class="item-registro" style="border-left:6px solid ${e.reactores > 0 ? 'var(--red)' : 'var(--teal)'};">
<p class="font-bold">${e.tipoPrueba} — ${e.productorNombre}</p>
<p class="text-sm" style="color:var(--sage);">${e.predio || ''} ${e.upp ? '· UPP ' + e.upp : ''} · Aplicada: ${e.fecha} · Enviada: ${e.fechaEnvio}</p>
<p class="text-sm" style="color:var(--sage);">Veterinario: ${e.veterinarioNombre || '—'} · ${e.animales.length} animal(es)</p>
${e.reactores > 0 ? `<span class="text-xs px-2 py-0.5 rounded-full inline-block mt-1" style="background:var(--red); color:#fff;">${e.reactores} reactor(es)</span>` : ''}
${e.revisado ? `<span class="text-xs px-2 py-0.5 rounded-full inline-block mt-1 ml-1" style="background:var(--green); color:#fff;">Revisado</span>` : ''}
<div class="flex flex-wrap gap-2 mt-3">
<button onclick="abrirVistaPreviaDictamen('${e.pruebaId}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--slate); color:#fff;"><i class="fa-solid fa-print"></i> Imprimir nueva hoja de campo</button>
${e.tipoPrueba === 'TB' ? `<button onclick="abrirVistaPreviaDictamenTB('${e.pruebaId}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--purple); color:#fff;"><i class="fa-solid fa-file-medical"></i> Imprimir dictamen de TB</button>` : ''}
${e.tipoPrueba === 'Brucelosis' ? `<button onclick="abrirVistaPreviaDictamenBR('${e.pruebaId}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--orange); color:#fff;"><i class="fa-solid fa-file-medical"></i> Imprimir dictamen de BR</button>` : ''}
${!e.revisado ? `<button onclick="marcarEnvioAlmitaRevisado('${e.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--green); color:#fff;"><i class="fa-solid fa-check"></i> Marcar como revisado</button>` : ''}
</div>
</div>`).join('');
}
function marcarEnvioAlmitaRevisado(id){
const e = (estado.enviosAlmita || []).find(x => x.id === id);
if (!e) return;
e.revisado = true;
guardarEstadoLocal();
renderEnviosAlmita();
mostrarToast('Marcado como revisado');
}
// ================= SOLICITUDES CEFPP → VETERINARIO (dadas de alta por la emisora de solicitudes) =================
let vetSeleccionadoSolicitudCEFPP = null;
function abrirNuevaSolicitudCEFPP(){
vetSeleccionadoSolicitudCEFPP = null;
if (!Array.isArray(estado.solicitudesCEFPPVet)) estado.solicitudesCEFPPVet = [];
const numero = 'SOL-' + String(estado.solicitudesCEFPPVet.length + 1).padStart(5, '0');
establecerValor('sc-numero-solicitud', numero);
establecerValor('sc-folio-interno', '');
establecerValor('sc-buscar-vet', '');
document.getElementById('resultado-buscar-vet-sc').innerHTML = '';
document.getElementById('vet-seleccionado-sc').classList.add('hidden');
establecerValor('sc-num-productores', '1');
establecerValor('sc-folio-inicial', '');
establecerValor('sc-folios-manual', '');
document.getElementById('sc-folios-manual').classList.add('hidden');
establecerValor('sc-upp-unica', '');
establecerValor('sc-upps-manual', '');
document.getElementById('sc-upps-manual').classList.add('hidden');
establecerValor('sc-motivo', '');
actualizarCamposSolicitudCEFPP();
irAdmin('nueva-solicitud-cefpp');
}
function actualizarCamposSolicitudCEFPP(){
const n = parseInt(valor('sc-num-productores'), 10) || 1;
document.getElementById('sc-upp-unica').classList.toggle('hidden', n > 1);
document.getElementById('sc-upps-manual').classList.toggle('hidden', n <= 1);
document.getElementById('sc-btn-editar-upps').textContent = n > 1 ? 'Usar campo único' : 'Editar manualmente';
document.getElementById('sc-folio-inicial').classList.toggle('hidden', document.getElementById('sc-folios-manual').classList.contains('hidden') === false);
actualizarPreviewFolios();
}
function toggleEdicionManualFolios(){
const manual = document.getElementById('sc-folios-manual');
const inicial = document.getElementById('sc-folio-inicial');
const editando = manual.classList.contains('hidden');
manual.classList.toggle('hidden', !editando);
inicial.classList.toggle('hidden', editando);
document.getElementById('sc-btn-editar-folios').textContent = editando ? 'Usar folio consecutivo' : 'Editar manualmente';
actualizarPreviewFolios();
}
function toggleEdicionManualUpps(){
const manual = document.getElementById('sc-upps-manual');
const unica = document.getElementById('sc-upp-unica');
const editando = manual.classList.contains('hidden');
manual.classList.toggle('hidden', !editando);
unica.classList.toggle('hidden', editando || (parseInt(valor('sc-num-productores'),10)||1) <= 1);
document.getElementById('sc-btn-editar-upps').textContent = editando ? 'Usar campo único' : 'Editar manualmente';
}
function actualizarPreviewFolios(){
const n = parseInt(valor('sc-num-productores'), 10) || 1;
const preview = document.getElementById('sc-folios-preview');
if (n <= 1 || !document.getElementById('sc-folios-manual').classList.contains('hidden')){
preview.textContent = '';
return;
}
const folioInicial = valor('sc-folio-inicial').trim();
if (!folioInicial || !/^\d+$/.test(folioInicial)){
preview.textContent = n > 1 ? 'Escribe el primer folio (solo números) para generar el resto en automático.' : '';
return;
}
const base = parseInt(folioInicial, 10);
const lista = Array.from({ length: n }, (_, i) => base + i);
preview.textContent = `Folios generados: ${lista.join(', ')}`;
}
document.addEventListener('input', e => { if (e.target && (e.target.id === 'sc-folio-inicial')) actualizarPreviewFolios(); });
function buscarVetParaSolicitudCEFPP(){
const q = valor('sc-buscar-vet').trim().toLowerCase();
const cont = document.getElementById('resultado-buscar-vet-sc');
if (!q){ cont.innerHTML = ''; return; }
const resultados = estado.veterinarios.filter(v => (v.nombre || '').toLowerCase().includes(q)).slice(0, 8);
if (resultados.length === 0){ cont.innerHTML = `<p class="text-xs text-center py-2" style="color:var(--sage);">Sin coincidencias.</p>`; return; }
cont.innerHTML = resultados.map(v => `
<button onclick="seleccionarVetParaSolicitudCEFPP('${v.id}')" class="w-full text-left bg-white rounded-xl p-2 flex items-center gap-2" style="border:2px solid var(--line);">
${avatarHtml(v.nombre, null, 34)}
<div class="flex-1 min-w-0"><p class="text-sm font-bold truncate">${v.nombre}</p></div>
</button>`).join('');
}
function seleccionarVetParaSolicitudCEFPP(vetId){
const v = estado.veterinarios.find(x => x.id === vetId);
if (!v) return;
vetSeleccionadoSolicitudCEFPP = v;
document.getElementById('resultado-buscar-vet-sc').innerHTML = '';
establecerValor('sc-buscar-vet', '');
const cont = document.getElementById('vet-seleccionado-sc');
cont.classList.remove('hidden');
cont.innerHTML = `<div class="flex items-center gap-2">${avatarHtml(v.nombre, null, 36)}<div class="flex-1"><p class="text-sm font-bold">${v.nombre}</p></div><button onclick="vetSeleccionadoSolicitudCEFPP=null; document.getElementById('vet-seleccionado-sc').classList.add('hidden');" style="color:var(--red);"><i class="fa-solid fa-xmark"></i></button></div>`;
}
function guardarSolicitudCEFPP(){
if (!vetSeleccionadoSolicitudCEFPP){ mostrarToast('Selecciona el veterinario'); return; }
const folioInterno = valor('sc-folio-interno').trim();
const numProductores = parseInt(valor('sc-num-productores'), 10) || 1;
const motivo = valor('sc-motivo').trim();
if (!marcarCamposFaltantes([{ id:'sc-folio-interno', etiqueta:'Folio interno' }, { id:'sc-motivo', etiqueta:'Motivo' }])) return;
let folios = [];
if (!document.getElementById('sc-folios-manual').classList.contains('hidden')){
folios = valor('sc-folios-manual').split(',').map(f => f.trim()).filter(Boolean);
} else {
const base = parseInt(valor('sc-folio-inicial'), 10);
if (!base){ mostrarToast('Escribe el folio inicial de hoja de campo'); return; }
folios = Array.from({ length: numProductores }, (_, i) => String(base + i));
}
let upps = [];
if (numProductores <= 1 && document.getElementById('sc-upps-manual').classList.contains('hidden')){
upps = [valor('sc-upp-unica').trim()];
} else {
upps = valor('sc-upps-manual').split(',').map(u => u.trim()).filter(Boolean);
}
if (!Array.isArray(estado.solicitudesCEFPPVet)) estado.solicitudesCEFPPVet = [];
estado.solicitudesCEFPPVet.push({
id: 'sccv_' + Date.now(),
numeroSolicitud: valor('sc-numero-solicitud'),
folioInterno, numProductores, folios, upps, motivo,
veterinarioId: vetSeleccionadoSolicitudCEFPP.id, veterinarioNombre: vetSeleccionadoSolicitudCEFPP.nombre,
fecha: hoyISO(), estatus: 'pendiente',
});
guardarEstadoLocal();
mostrarToast(`Solicitud enviada a ${vetSeleccionadoSolicitudCEFPP.nombre}`);
volverAtrasAdmin('almita');
}
function renderSolicitudesCEFPPGeneradas(){
const cont = document.getElementById('lista-solicitudes-cefpp-generadas');
if (!cont) return;
const items = (estado.solicitudesCEFPPVet || []).slice().sort((a,b) => (b.fecha||'').localeCompare(a.fecha||''));
if (items.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-file-circle-plus"></i><p>Aún no has dado de alta ninguna solicitud.</p></div>`;
return;
}
const COLORES = { pendiente:'var(--yellow)', atendida:'var(--green)' };
cont.innerHTML = items.map(s => `
<div class="item-registro" style="border-left:6px solid var(--teal);">
<p class="font-bold">${s.numeroSolicitud} — ${s.veterinarioNombre}</p>
<p class="text-sm" style="color:var(--sage);">Folio interno: ${s.folioInterno} · ${s.numProductores} productor(es) · ${s.fecha}</p>
<p class="text-sm" style="color:var(--sage);">Folios de campo: ${s.folios.join(', ')}</p>
<p class="text-sm" style="color:var(--sage);">UPP(s): ${s.upps.join(', ')}</p>
<span class="text-xs px-2 py-0.5 rounded-full inline-block mt-1" style="background:${COLORES[s.estatus]}; color:#fff;">${s.estatus === 'pendiente' ? 'Pendiente de atender' : 'Atendida por el veterinario'}</span>
</div>`).join('');
}
function renderSolicitudesCEFPPVet(){
const cont = document.getElementById('lista-solicitudes-cefpp-vet');
if (!cont) return;
const vet = veterinarioActivo();
const items = (estado.solicitudesCEFPPVet || []).filter(s => s.veterinarioId === (vet ? vet.id : null)).sort((a,b) => (b.fecha||'').localeCompare(a.fecha||''));
if (items.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-building-shield"></i><p>No tienes solicitudes autorizadas por el CEFPP.</p></div>`;
return;
}
cont.innerHTML = items.map(s => `
<div class="item-registro" style="border-left:6px solid var(--teal);">
<p class="font-bold">${s.numeroSolicitud} — Folio interno ${s.folioInterno}</p>
<p class="text-sm" style="color:var(--sage);">${s.numProductores} productor(es) · Folios: ${s.folios.join(', ')}</p>
<p class="text-sm" style="color:var(--sage);">UPP(s): ${s.upps.join(', ')}</p>
<p class="text-sm" style="color:var(--sage);">Motivo: ${s.motivo}</p>
<span class="text-xs px-2 py-0.5 rounded-full inline-block mt-1" style="background:${s.estatus === 'pendiente' ? 'var(--yellow)' : 'var(--green)'}; color:#fff;">${s.estatus === 'pendiente' ? 'Pendiente de atender' : 'Atendida'}</span>
${s.estatus === 'pendiente' ? `<button onclick="usarSolicitudCEFPPEnPrueba('${s.id}')" class="w-full text-xs font-bold px-3 py-2 rounded-full mt-2" style="background:var(--purple); color:#fff;"><i class="fa-solid fa-vial-circle-check"></i> Usar en nueva prueba</button>` : ''}
</div>`).join('');
}
function usarSolicitudCEFPPEnPrueba(id){
const s = (estado.solicitudesCEFPPVet || []).find(x => x.id === id);
if (!s) return;
abrirNuevaPruebaCampo('prueba');
establecerValor('pc-motivo', s.motivo);
if (s.numProductores === 1 && s.upps[0]){
const c = estado.cuentasProductores.find(x => (x.upp || '').toLowerCase() === s.upps[0].toLowerCase());
if (c) seleccionarProductorParaPrueba(c.id);
else mostrarToast(`No se encontró ninguna cuenta con la UPP ${s.upps[0]} — selecciona el productor manualmente.`);
} else {
mostrarToast(`Esta solicitud incluye ${s.numProductores} productores (UPPs: ${s.upps.join(', ')}) — selecciona cada uno y crea una prueba por productor.`);
}
s.estatus = 'atendida';
guardarEstadoLocal();
}
function marcarPruebaImpresa(id){
const p = estado.pruebasCampoVet.find(x => x.id === id);
if (!p) return;
p.impresa = true;
p.fechaImpresion = hoyISO();
if (!Array.isArray(estado.historialImpresiones)) estado.historialImpresiones = [];
estado.historialImpresiones.push({ id:'imp_' + Date.now(), pruebaId: p.id, productorNombre: p.productorNombre, tipoPrueba: p.tipoPrueba, fecha: hoyISO() });
guardarEstadoLocal();
renderPruebasCapturista(false); renderPruebasCapturista(true);
mostrarToast('Marcada como impresa');
}
function compartirPruebaCampo(id){
const p = estado.pruebasCampoVet.find(x => x.id === id);
if (!p) return;
p.compartida = true;
p.estatusProductor = 'pendiente';
guardarEstadoLocal();
enviarFlujoConReintento('prod_' + p.productorId, p.id, 'prueba_compartida', p, {enviadoPor:'veterinario', estatus:'pendiente', origenBandeja:'vet_' + (estado.veterinarioActivoId || '')});
renderListaPruebasCampo();
mostrarToast(`Compartido con ${p.productorNombre}`);
}
function eliminarPruebaCampo(id){
estado.pruebasCampoVet = estado.pruebasCampoVet.filter(p => p.id !== id);
guardarEstadoLocal();
renderListaPruebasCampo();
}
function exportarPruebaCampo(id){
const p = estado.pruebasCampoVet.find(x => x.id === id);
if (!p) return;
const ETIQUETAS_RESULTADO = { N:'Negativo', S:'Sospechoso', R:'Reactor', E:'Exento' };
const encabezados = p.categoria === 'prueba'
? ['Productor','Predio','UPP','CURP','Motivo','Identificación','Especie','Edad','Sexo','Raza','Fierro','Resultado']
: ['Productor','Predio','UPP','CURP','Identificación','Especie','Edad','Sexo','Raza','Fierro'];
const filas = p.animales.map(a => p.categoria === 'prueba'
? [p.productorNombre, p.predio, p.upp, p.curp || '', p.motivo || '', a.arete, a.especie, a.edad, a.sexo, a.raza, a.fierro || '', ETIQUETAS_RESULTADO[a.resultado] || a.resultado]
: [p.productorNombre, p.predio, p.upp, p.curp || '', a.arete, a.especie, a.edad, a.sexo, a.raza, a.fierro || '']);
generarCSVConPie(`${p.tipoPrueba} - ${p.productorNombre} - ${p.fecha}`, encabezados, filas);
}
function renderPruebasCampoCompartidas(){
const cont = document.getElementById('lista-pruebas-campo-productor');
if (!cont) return;
const items = estado.pruebasCampoVet.filter(p => p.productorId === estado.cuentaActivaId && p.compartida).sort((a,b) => (b.fecha||'').localeCompare(a.fecha||''));
const badge = document.getElementById('badge-pruebas-campo-productor');
const pendientes = items.filter(p => p.estatusProductor === 'pendiente').length;
if (badge){ badge.textContent = pendientes; badge.classList.toggle('hidden', pendientes === 0); }
if (items.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-vial-circle-check"></i><p>Tu veterinario aún no te ha compartido pruebas o areteos.</p></div>`;
return;
}
const ETIQUETAS_ESTATUS = { pendiente:'Pendiente de tu respuesta', aceptada:'Guardado en tu cuenta', rechazada:'Descartado' };
const COLORES_ESTATUS = { pendiente:'var(--yellow)', aceptada:'var(--green)', rechazada:'var(--red)' };
cont.innerHTML = items.map(p => `
<div class="item-registro" style="border-left:6px solid ${p.categoria === 'prueba' ? 'var(--purple)' : 'var(--orange)'};">
<p class="font-bold">${p.tipoPrueba} — compartido por ${p.veterinarioNombre || 'tu veterinario'}</p>
<p class="text-sm" style="color:var(--sage);">${p.fecha} · ${p.animales.length} animal(es)</p>
<span class="text-xs px-2 py-0.5 rounded-full inline-block mt-1" style="background:${COLORES_ESTATUS[p.estatusProductor]}; color:#fff;">${ETIQUETAS_ESTATUS[p.estatusProductor]}</span>
${p.estatusProductor === 'pendiente' ? `
<div class="flex gap-2 mt-3">
<button onclick="aceptarPruebaCampoCompartida('${p.id}')" class="text-xs font-bold px-3 py-2 rounded-full flex-1" style="background:var(--green); color:#fff;"><i class="fa-solid fa-check"></i> Guardar en mi cuenta</button>
<button onclick="rechazarPruebaCampoCompartida('${p.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--parchment); color:var(--red); border:2px solid var(--line);"><i class="fa-solid fa-xmark"></i></button>
</div>` : ''}
</div>`).join('');
}
function aceptarPruebaCampoCompartida(id){
const p = estado.pruebasCampoVet.find(x => x.id === id);
if (!p || p.productorId !== estado.cuentaActivaId) return;
if (p.categoria === 'prueba'){
const ETIQUETAS_RESULTADO = { N:'Negativo', S:'Sospechoso', R:'Reactor', E:'Exento' };
p.animales.forEach(a => {
estado.salud.push({
tipo: 'diagnostico',
producto: `Prueba de ${p.tipoPrueba}`,
fecha: p.fecha, proxima: '', notas: `Resultado: ${ETIQUETAS_RESULTADO[a.resultado] || a.resultado} — compartido por ${p.veterinarioNombre || 'veterinario'} (arete ${a.arete}, ${a.edad}, ${a.sexo === 'H' ? 'hembra' : 'macho'}, ${a.raza})`,
recuperado: true, estadoCEFPP: null, retiroLecheHasta: null, cuartoMastitis: null, cmt: null,
animal: a.arete,
});
});
}
p.estatusProductor = 'aceptada';
const origenAceptacion = estado.flujoOrigenPorId?.[p.id];
if (origenAceptacion && typeof window.firebaseActualizarFlujo === 'function') window.firebaseActualizarFlujo(origenAceptacion, p.id, {estatus:'aceptada', estatusProductor:'aceptada'});
guardarEstadoLocal();
renderPruebasCampoCompartidas();
mostrarToast('Guardado en tu cuenta');
}
function rechazarPruebaCampoCompartida(id){
const p = estado.pruebasCampoVet.find(x => x.id === id);
if (!p || p.productorId !== estado.cuentaActivaId) return;
p.estatusProductor = 'rechazada';
const origenRechazo = estado.flujoOrigenPorId?.[p.id];
if (origenRechazo && typeof window.firebaseActualizarFlujo === 'function') window.firebaseActualizarFlujo(origenRechazo, p.id, {estatus:'rechazada', estatusProductor:'rechazada'});
guardarEstadoLocal();
renderPruebasCampoCompartidas();
}
// ================= SOLICITUD DE ARETES (PRODUCTOR -> VETERINARIO) =================
let filasSolicitudAretes = [];
let vetSeleccionadoSolicitudAretes = null;
function renderSolicitudAretesProductor(){
filasSolicitudAretes = [];
vetSeleccionadoSolicitudAretes = null;
establecerValor('sa-buscar-vet', '');
document.getElementById('resultado-buscar-vet-sa').innerHTML = '';
document.getElementById('vet-seleccionado-sa').classList.add('hidden');
renderFilasSolicitudAretes();
renderMisSolicitudesAretes();
}
function buscarVetParaSolicitudAretes(){
const q = valor('sa-buscar-vet').trim().toLowerCase();
const cont = document.getElementById('resultado-buscar-vet-sa');
if (!q){ cont.innerHTML = ''; return; }
const resultados = estado.veterinarios.filter(v => (v.nombre || '').toLowerCase().includes(q)).slice(0, 8);
if (resultados.length === 0){ cont.innerHTML = `<p class="text-xs text-center py-2" style="color:var(--sage);">Sin coincidencias.</p>`; return; }
cont.innerHTML = resultados.map(v => `
<button onclick="seleccionarVetParaSolicitudAretes('${v.id}')" class="w-full text-left bg-white rounded-xl p-2 flex items-center gap-2" style="border:2px solid var(--line);">
${avatarHtml(v.nombre, null, 34)}
<div class="flex-1 min-w-0"><p class="text-sm font-bold truncate">${v.nombre}</p>${v.cedula ? `<p class="text-xs" style="color:var(--sage);">Cédula ${v.cedula}</p>` : ''}</div>
</button>`).join('');
}
function seleccionarVetParaSolicitudAretes(vetId){
const v = estado.veterinarios.find(x => x.id === vetId);
if (!v) return;
vetSeleccionadoSolicitudAretes = v;
document.getElementById('resultado-buscar-vet-sa').innerHTML = '';
establecerValor('sa-buscar-vet', '');
const cont = document.getElementById('vet-seleccionado-sa');
cont.classList.remove('hidden');
cont.innerHTML = `<div class="flex items-center gap-2">${avatarHtml(v.nombre, null, 36)}<div class="flex-1"><p class="text-sm font-bold">${v.nombre}</p>${v.cedula ? `<p class="text-xs" style="color:var(--sage);">Cédula ${v.cedula}</p>` : ''}</div><button onclick="vetSeleccionadoSolicitudAretes=null; document.getElementById('vet-seleccionado-sa').classList.add('hidden');" style="color:var(--red);"><i class="fa-solid fa-xmark"></i></button></div>`;
}
function agregarFilaSolicitudAretes(){
filasSolicitudAretes.push({ id: 'fsa_' + Date.now() + Math.random().toString(36).slice(2,6), sexo:'H', edad:'', madre:'', padre:'' });
renderFilasSolicitudAretes();
}
function cargarAnimalesSinAreteAutomatico(){
const sinArete = estado.animales.filter(a => !a.arete && a.estatus !== 'vendido' && a.estatus !== 'finado');
if (sinArete.length === 0){ mostrarToast('No hay animales sin arete en tu inventario'); return; }
const idsExistentes = new Set(filasSolicitudAretes.map(f => f._origenAnimalId).filter(Boolean));
let agregados = 0;
sinArete.forEach(a => {
if (a.id && idsExistentes.has(a.id)) return;
let edadMeses = '';
if (a.fecha){
try { edadMeses = Math.max(0, Math.floor(diasEntreISO(hoyISO(), a.fecha) / 30)); } catch(e){ edadMeses = ''; }
}
filasSolicitudAretes.push({
id: 'fsa_' + Date.now() + Math.random().toString(36).slice(2,6),
_origenAnimalId: a.id || null,
sexo: sexoAHM(a.sexo),
edad: edadMeses !== '' ? String(edadMeses) : '',
madre: a.madre || '',
padre: a.padre || '',
});
agregados++;
});
renderFilasSolicitudAretes();
mostrarToast(`${agregados} animal(es) sin arete cargados desde tu inventario`);
}
function eliminarFilaSolicitudAretes(id){
filasSolicitudAretes = filasSolicitudAretes.filter(f => f.id !== id);
renderFilasSolicitudAretes();
}
function actualizarFilaSolicitudAretes(id, campo, valorNuevo){
const f = filasSolicitudAretes.find(x => x.id === id);
if (f) f[campo] = valorNuevo;
}
function renderFilasSolicitudAretes(){
const cont = document.getElementById('lista-filas-solicitud-aretes');
if (!cont) return;
if (filasSolicitudAretes.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-2" style="color:var(--sage);">Aún no agregas animales. Toca "Agregar".</p>`;
return;
}
const opcionesPadres = estado.animales.map(a => `<option value="${(a.arete || a.nombre || '').replace(/"/g,'&quot;')}">${a.arete || a.nombre} ${a.nombre && a.arete ? '— ' + a.nombre : ''}</option>`).join('');
cont.innerHTML = filasSolicitudAretes.map(f => `
<div class="bg-white rounded-2xl p-3" style="border:2px solid var(--line);">
<div class="flex items-center justify-between mb-2">
<span class="text-xs font-bold" style="color:var(--sage);">Animal sin arete</span>
<button onclick="eliminarFilaSolicitudAretes('${f.id}')" style="color:var(--red);"><i class="fa-solid fa-trash"></i></button>
</div>
<div class="grid grid-cols-2 gap-2">
<select onchange="actualizarFilaSolicitudAretes('${f.id}','sexo',this.value)" style="font-size:.85rem;">
<option ${f.sexo==='H'?'selected':''} value="H">Hembra</option>
<option ${f.sexo==='M'?'selected':''} value="M">Macho</option>
</select>
<input onchange="actualizarFilaSolicitudAretes('${f.id}','edad',this.value)" placeholder="Edad (meses)" style="font-size:.85rem;" type="text" value="${f.edad}"/>
<select onchange="actualizarFilaSolicitudAretes('${f.id}','madre',this.value)" style="font-size:.85rem;">
<option value="">Madre (opcional)</option>
${opcionesPadres}
</select>
<select onchange="actualizarFilaSolicitudAretes('${f.id}','padre',this.value)" style="font-size:.85rem;">
<option value="">Padre (opcional)</option>
${opcionesPadres}
</select>
</div>
</div>`).join('');
}
function enviarSolicitudAretes(){
if (!vetSeleccionadoSolicitudAretes){ mostrarToast('Selecciona a tu veterinario'); return; }
if (filasSolicitudAretes.length === 0){ mostrarToast('Agrega al menos un animal'); return; }
const solicitudAretes = {
id: 'sa_' + Date.now(),
veterinarioId: vetSeleccionadoSolicitudAretes.id,
veterinarioNombre: vetSeleccionadoSolicitudAretes.nombre,
productorId: estado.cuentaActivaId,
productorNombre: estado.productor.nombre,
predio: estado.productor.predio,
upp: estado.productor.upp,
fecha: hoyISO(),
animales: filasSolicitudAretes.map(f => ({ sexo:f.sexo, edad:f.edad, madre:f.madre, padre:f.padre })),
estatus: 'pendiente',
};
estado.solicitudesAretes.push(solicitudAretes);
guardarEstadoLocal();
enviarFlujoConReintento('vet_' + vetSeleccionadoSolicitudAretes.id, solicitudAretes.id, 'solicitud_aretes', solicitudAretes, {enviadoPor:'productor', estatus:'pendiente', origenBandeja:'prod_' + (estado.cuentaActivaId || '')});
mostrarToast(`Solicitud enviada a ${vetSeleccionadoSolicitudAretes.nombre}`);
renderSolicitudAretesProductor();
}
function renderMisSolicitudesAretes(){
const cont = document.getElementById('lista-mis-solicitudes-aretes');
if (!cont) return;
const mias = estado.solicitudesAretes.filter(s => s.productorId === estado.cuentaActivaId).sort((a,b) => (b.fecha||'').localeCompare(a.fecha||''));
if (mias.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-tags"></i><p>Aún no has enviado solicitudes de aretes.</p></div>`;
return;
}
const COLORES = { pendiente:'var(--yellow)', atendida:'var(--green)' };
const ETIQUETAS = { pendiente:'Pendiente', atendida:'Atendida' };
cont.innerHTML = mias.map(s => `
<div class="item-registro" style="border-left:6px solid var(--teal);">
<p class="font-bold">${s.animales.length} arete(s) — enviado a ${s.veterinarioNombre}</p>
<p class="text-sm" style="color:var(--sage);">${s.fecha}</p>
<span class="text-xs px-2 py-0.5 rounded-full inline-block mt-1" style="background:${COLORES[s.estatus]}; color:#fff;">${ETIQUETAS[s.estatus]}</span>
</div>`).join('');
}
// ================= SOLICITAR PRUEBA AL VETERINARIO (comparte inventario) =================
let vetSeleccionadoSolicitudPrueba = null;
function abrirSolicitarPruebaVet(){
vetSeleccionadoSolicitudPrueba = null;
establecerValor('sp-buscar-vet', '');
document.getElementById('resultado-buscar-vet-sp').innerHTML = '';
document.getElementById('vet-seleccionado-sp').classList.add('hidden');
const vigentes = estado.animales.filter(a => a.estatus !== 'vendido' && a.estatus !== 'finado');
const conArete = vigentes.filter(a => a.arete).length;
const sinArete = vigentes.length - conArete;
document.getElementById('sp-conteo-animales').textContent = `${vigentes.length} animal(es) vigente(s): ${conArete} con arete, ${sinArete} sin arete.`;
const modal = document.getElementById('modal-solicitar-prueba');
modal.classList.remove('hidden'); modal.style.display = 'flex';
}
function buscarVetParaSolicitudPrueba(){
const q = valor('sp-buscar-vet').trim().toLowerCase();
const cont = document.getElementById('resultado-buscar-vet-sp');
if (!q){ cont.innerHTML = ''; return; }
const resultados = estado.veterinarios.filter(v => (v.nombre || '').toLowerCase().includes(q)).slice(0, 8);
if (resultados.length === 0){ cont.innerHTML = `<p class="text-xs text-center py-2" style="color:var(--sage);">Sin coincidencias.</p>`; return; }
cont.innerHTML = resultados.map(v => `
<button onclick="seleccionarVetParaSolicitudPrueba('${v.id}')" class="w-full text-left bg-white rounded-xl p-2 flex items-center gap-2" style="border:2px solid var(--line);">
${avatarHtml(v.nombre, null, 34)}
<div class="flex-1 min-w-0"><p class="text-sm font-bold truncate">${v.nombre}</p></div>
</button>`).join('');
}
function seleccionarVetParaSolicitudPrueba(vetId){
const v = estado.veterinarios.find(x => x.id === vetId);
if (!v) return;
vetSeleccionadoSolicitudPrueba = v;
document.getElementById('resultado-buscar-vet-sp').innerHTML = '';
establecerValor('sp-buscar-vet', '');
const cont = document.getElementById('vet-seleccionado-sp');
cont.classList.remove('hidden');
cont.innerHTML = `<div class="flex items-center gap-2">${avatarHtml(v.nombre, null, 36)}<div class="flex-1"><p class="text-sm font-bold">${v.nombre}</p></div><button onclick="vetSeleccionadoSolicitudPrueba=null; document.getElementById('vet-seleccionado-sp').classList.add('hidden');" style="color:var(--red);"><i class="fa-solid fa-xmark"></i></button></div>`;
}
function enviarSolicitudPrueba(){
if (!vetSeleccionadoSolicitudPrueba){ mostrarToast('Selecciona a tu veterinario'); return; }
const vigentes = estado.animales.filter(a => a.estatus !== 'vendido' && a.estatus !== 'finado');
if (!estado.solicitudesPrueba) estado.solicitudesPrueba = [];
const solicitudPrueba = {
id: 'spr_' + Date.now(),
veterinarioId: vetSeleccionadoSolicitudPrueba.id,
veterinarioNombre: vetSeleccionadoSolicitudPrueba.nombre,
productorId: estado.cuentaActivaId,
productorNombre: estado.productor.nombre,
predio: estado.productor.predio, upp: estado.productor.upp, curp: estado.productor.curp || '',
fecha: hoyISO(),
animales: vigentes.map(a => ({ arete: a.arete || '', nombre: a.nombre || '', sexo: a.sexo, raza: a.raza, fechaNacimiento: a.fecha, estatus: a.estatus })),
estatus: 'pendiente',
};
estado.solicitudesPrueba.push(solicitudPrueba);
guardarEstadoLocal();
enviarFlujoConReintento('vet_' + vetSeleccionadoSolicitudPrueba.id, solicitudPrueba.id, 'solicitud_prueba', solicitudPrueba, {enviadoPor:'productor', estatus:'pendiente', origenBandeja:'prod_' + (estado.cuentaActivaId || '')});
document.getElementById('modal-solicitar-prueba').classList.add('hidden');
mostrarToast(`Solicitud de prueba enviada a ${vetSeleccionadoSolicitudPrueba.nombre}`);
}
function renderSolicitudesPruebaVet(){
const cont = document.getElementById('lista-solicitudes-prueba-vet');
if (!cont) return;
const vet = veterinarioActivo();
const items = (estado.solicitudesPrueba || []).filter(s => s.veterinarioId === (vet ? vet.id : null)).sort((a,b) => (b.fecha||'').localeCompare(a.fecha||''));
if (items.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-vial-circle-check"></i><p>No tienes solicitudes de prueba pendientes.</p></div>`;
return;
}
cont.innerHTML = items.map(s => {
const conArete = s.animales.filter(a => a.arete).length;
return `
<div class="item-registro" style="border-left:6px solid var(--teal);">
<p class="font-bold">${s.productorNombre}</p>
<p class="text-sm" style="color:var(--sage);">${s.predio || ''} ${s.upp ? '· UPP ' + s.upp : ''} · ${s.fecha}</p>
<p class="text-sm" style="color:var(--sage);">${s.animales.length} animal(es): ${conArete} con arete, ${s.animales.length - conArete} sin arete</p>
<span class="text-xs px-2 py-0.5 rounded-full inline-block mt-1" style="background:${s.estatus === 'pendiente' ? 'var(--yellow)' : 'var(--green)'}; color:#fff;">${s.estatus === 'pendiente' ? 'Pendiente' : 'Usada en prueba'}</span>
${s.estatus === 'pendiente' ? `<button onclick="usarSolicitudPruebaEnNuevaPrueba('${s.id}')" class="w-full text-xs font-bold px-3 py-2 rounded-full mt-2" style="background:var(--purple); color:#fff;"><i class="fa-solid fa-vial-circle-check"></i> Usar en nueva prueba</button>` : ''}
</div>`;
}).join('');
}
function usarSolicitudPruebaEnNuevaPrueba(id){
if (!requiereVeterinarioActivo()) return;
const vet = veterinarioActivo();
const s = (estado.solicitudesPrueba || []).find(x => x.id === id && x.veterinarioId === (vet ? vet.id : null));
if (!s) return;
abrirNuevaPruebaCampo('prueba');
const c = estado.cuentasProductores.find(x => x.id === s.productorId);
if (c) seleccionarProductorParaPrueba(c.id);
filasAnimalesPruebaCampo = s.animales.map(a => ({ id: 'fila_' + Date.now() + Math.random().toString(36).slice(2,6), arete: a.arete || '', especie:'Bovino', edad: a.fechaNacimiento || '', sexo: sexoAHM(a.sexo), raza: a.raza || '', fierro:'', resultado:'N' }));
renderFilasAnimalesPruebaCampo();
s.estatus = 'usada';
const origenSolicitudPrueba = estado.flujoOrigenPorId?.[s.id];
if (origenSolicitudPrueba && typeof window.firebaseActualizarFlujo === 'function') window.firebaseActualizarFlujo(origenSolicitudPrueba, s.id, {estatus:'usada'});
guardarEstadoLocal();
mostrarToast(`${filasAnimalesPruebaCampo.length} animal(es) cargados desde la solicitud`);
}
function renderSolicitudesAretesVet(){
if (!requiereVeterinarioActivo()) return;
const cont = document.getElementById('lista-solicitudes-aretes-vet');
if (!cont) return;
const vet = veterinarioActivo();
const items = estado.solicitudesAretes.filter(s => s.veterinarioId === (vet ? vet.id : null)).sort((a,b) => (b.fecha||'').localeCompare(a.fecha||''));
if (items.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-tags"></i><p>No tienes solicitudes de aretes pendientes.</p></div>`;
return;
}
const ETIQUETAS_SEXO = { H:'Hembra', M:'Macho' };
cont.innerHTML = items.map(s => `
<div class="item-registro" style="border-left:6px solid var(--teal);">
<p class="font-bold">${s.productorNombre}</p>
<p class="text-sm" style="color:var(--sage);">${s.predio || ''} ${s.upp ? '· UPP ' + s.upp : ''} · ${s.fecha}</p>
<div class="mt-2 space-y-1">
${s.animales.map((a, i) => `<p class="text-xs" style="color:var(--ink);">${i+1}. ${ETIQUETAS_SEXO[a.sexo]}, ${a.edad || '—'} meses${a.madre ? ', madre: ' + a.madre : ''}${a.padre ? ', padre: ' + a.padre : ''}</p>`).join('')}
</div>
<span class="text-xs px-2 py-0.5 rounded-full inline-block mt-2" style="background:${s.estatus === 'pendiente' ? 'var(--yellow)' : 'var(--green)'}; color:#fff;">${s.estatus === 'pendiente' ? 'Pendiente' : 'Atendida'}</span>
${s.estatus === 'pendiente' ? `<button onclick="marcarSolicitudAretesAtendida('${s.id}')" class="w-full text-xs font-bold px-3 py-2 rounded-full mt-2" style="background:var(--green); color:#fff;"><i class="fa-solid fa-check"></i> Marcar como atendida</button>` : ''}
</div>`).join('');
}
function marcarSolicitudAretesAtendida(id){
if (!requiereVeterinarioActivo()) return;
const vet = veterinarioActivo();
const s = estado.solicitudesAretes.find(x => x.id === id && x.veterinarioId === (vet ? vet.id : null));
if (!s) return;
s.estatus = 'atendida';
const origenSolicitudAretes = estado.flujoOrigenPorId?.[s.id];
if (origenSolicitudAretes && typeof window.firebaseActualizarFlujo === 'function') window.firebaseActualizarFlujo(origenSolicitudAretes, s.id, {estatus:'atendida'});
guardarEstadoLocal();
renderSolicitudesAretesVet();
mostrarToast('Marcada como atendida');
}
function abrirPerfilVeterinario(){
if (!requiereVeterinarioActivo()) return;
const vet = veterinarioActivo();
if (!vet) return;
establecerValor('vetperfil-especialidad', vet.especialidad || '');
establecerValor('vetperfil-descripcion', vet.descripcion || '');
const foto = document.getElementById('vetperfil-foto-preview');
if (foto) foto.src = vet.foto || '';
const zonasCont = document.getElementById('vetperfil-zonas');
if (zonasCont){
zonasCont.innerHTML = estado.zonasAtencionDisponibles.map(z => {
const activa = (vet.zonaAtencion || []).includes(z);
return `<button type="button" class="subtab${activa ? ' active' : ''}" data-zona="${z}" onclick="toggleZonaVeterinario('${z}')" style="font-size:.78rem; padding:.5rem .8rem;">${z}</button>`;
}).join('');
}
const m = document.getElementById('modal-perfil-vet');
m.classList.remove('hidden'); m.style.display = 'flex';
}
function toggleZonaVeterinario(zona){
if (!requiereVeterinarioActivo()) return;
const vet = veterinarioActivo();
if (!vet) return;
if (!vet.zonaAtencion) vet.zonaAtencion = [];
const i = vet.zonaAtencion.indexOf(zona);
if (i === -1) vet.zonaAtencion.push(zona); else vet.zonaAtencion.splice(i, 1);
guardarEstadoLocal();
abrirPerfilVeterinario();
}
function cerrarPerfilVeterinario(){
const m = document.getElementById('modal-perfil-vet');
m.classList.add('hidden'); m.style.removeProperty('display');
}
function subirFotoVeterinario(archivo){
if (!requiereVeterinarioActivo()) return;
if (!archivo) return;
const vet = veterinarioActivo();
if (!vet) return;
const lector = new FileReader();
lector.onload = e => {
const img = new Image();
img.onload = () => {
const anchoObjetivo = 240;
const escala = Math.min(1, anchoObjetivo / img.width);
const canvas = document.createElement('canvas');
canvas.width = img.width * escala;
canvas.height = img.height * escala;
canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
vet.foto = canvas.toDataURL('image/webp', 0.8);
const foto = document.getElementById('vetperfil-foto-preview');
if (foto) foto.src = vet.foto;
guardarEstadoLocal();
};
img.src = e.target.result;
};
lector.readAsDataURL(archivo);
}
function guardarPerfilVeterinario(){
if (!requiereVeterinarioActivo()) return;
const vet = veterinarioActivo();
if (!vet) return;
vet.especialidad = valor('vetperfil-especialidad').trim();
vet.descripcion = valor('vetperfil-descripcion').trim();
guardarEstadoLocal();
cerrarPerfilVeterinario();
mostrarToast('Perfil actualizado');
}
function normalizarTelefono(t){
return (t || '').replace(/\D/g, '').slice(-10);
}
function buscarUsuarioPorTelefono(tel10){
if (!tel10 || tel10.length < 10) return null;
const cuenta = estado.cuentasProductores.find(c => normalizarTelefono(c.telefono) === tel10);
if (cuenta) return { tipo: cuenta.tipo === 'punto' ? 'punto' : 'productor', nombre: cuenta.nombre, ref: cuenta };
const vet = estado.veterinarios.find(v => normalizarTelefono(v.telefono) === tel10);
if (vet) return { tipo: 'veterinario', nombre: vet.nombre + ' (MVZ)', ref: vet };
return null;
}
function urlInvitacionApp(){
return 'https://coruscating-narwhal-634382.netlify.app/';
}
function renderResultadosContactos(contenedorId, resultados){
const cont = document.getElementById(contenedorId);
if (!cont) return;
cont.classList.remove('hidden');
if (!resultados.length){
cont.innerHTML = `<p class="text-sm text-center py-2" style="color:var(--sage);">${tr('contactos__sin_coincidencias')}</p>`;
return;
}
// Cada contacto que sí coincide con un productor registrado se agrega a la
// lista de "verificados" — es justo lo que hace que luego aparezca en la
// bandeja de mensajes, en vez de tener que ver a todo el directorio.
let seAgregoAlguno = false;
resultados.forEach(r => {
if (r.match && r.match.tipo === 'productor' && r.match.ref && r.match.ref.id){
if (!Array.isArray(estado.contactosVerificadosChat)) estado.contactosVerificadosChat = [];
if (!estado.contactosVerificadosChat.includes(r.match.ref.id)){
estado.contactosVerificadosChat.push(r.match.ref.id);
seAgregoAlguno = true;
}
}
});
if (seAgregoAlguno){ guardarEstadoLocal(); if (typeof renderListaConversacionesAdmin === 'function') renderListaConversacionesAdmin(); }
cont.innerHTML = resultados.map(r => {
if (r.match){
const puedeAbrirChat = r.match.tipo === 'productor' && r.match.ref && estado.rolActual === 'admin';
const accion = puedeAbrirChat ? `onclick="abrirHiloMensajes('${r.match.ref.id}')" style="cursor:pointer;"` : '';
return `<div class="bg-white rounded-2xl p-3 flex items-center gap-3" ${accion} style="border:2px solid var(--line);">
${avatarHtml(r.nombreContacto, null, 42)}
<div class="flex-1 min-w-0"><p class="font-bold text-sm truncate">${r.nombreContacto}</p><p class="text-xs" style="color:var(--sage);">${tr('contactos__ya_usa_la_app')} · ${r.match.nombre}</p></div>
<span class="text-xs font-bold flex-shrink-0" style="color:var(--green);"><i class="fa-solid fa-circle-check"></i></span>
</div>`;
}
const mensaje = encodeURIComponent(`¡Hola ${r.nombreContacto}! Te invito a usar MiRanch: ${urlInvitacionApp()}`);
const numero = r.tel.length === 10 ? '52' + r.tel : r.tel;
return `<div class="bg-white rounded-2xl p-3 flex items-center gap-3" style="border:2px solid var(--line);">
${avatarHtml(r.nombreContacto, null, 42)}
<div class="flex-1 min-w-0"><p class="font-bold text-sm truncate">${r.nombreContacto}</p><p class="text-xs" style="color:var(--sage);">${r.tel}</p></div>
<a href="https://wa.me/${numero}?text=${mensaje}" target="_blank" rel="noopener" class="btn-primario-plano flex-shrink-0" style="background:#25D366; white-space:nowrap; padding:.5rem .8rem; font-size:.78rem;"><i class="fa-brands fa-whatsapp"></i> ${tr('contactos__invitar_por_whatsapp')}</a>
</div>`;
}).join('');
}
async function buscarContactosConApp(){
const contenedorId = estado.rolActual === 'productor' ? 'panel-resultado-contactos-productor' : 'panel-resultado-contactos';
if ('contacts' in navigator && 'ContactsManager' in window){
try {
const props = ['name', 'tel'];
const opts = { multiple: true };
const contactos = await navigator.contacts.select(props, opts);
const resultados = contactos.map(c => {
const tel = normalizarTelefono((c.tel && c.tel[0]) || '');
const nombreContacto = (c.name && c.name[0]) || tel;
const match = buscarUsuarioPorTelefono(tel);
return { nombreContacto, tel, match };
}).filter(r => r.tel);
renderResultadosContactos(contenedorId, resultados);
return;
} catch (e) {
mostrarToast(tr('contactos__no_disponible_en_este_dispositivo'));
}
}
const numero = prompt(tr('contactos__numero_manual'));
if (!numero) return;
const tel = normalizarTelefono(numero);
const match = buscarUsuarioPorTelefono(tel);
renderResultadosContactos(contenedorId, [{ nombreContacto: numero, tel, match }]);
}
function agregarPredio(){
const nombre = valor('predio-nombre').trim();
if (!nombre){ mostrarToast(tr('predios_multiples__escribe_el_nombre_del_predio')); return; }
estado.predios.push({ id:'p' + Date.now(), nombre, upp: valor('predio-upp'), municipio: valor('predio-municipio') });
limpiarCampos(['predio-nombre','predio-upp','predio-municipio']);
renderListaPredios();
mostrarToast(tr('predios_multiples__predio_agregado'));
}
function eliminarPredio(id){
const i = estado.predios.findIndex(x => x.id === id);
if (i === -1) return;
const borrado = estado.predios.splice(i, 1)[0];
renderListaPredios();
mostrarToast(tr('predios_multiples__predio_eliminado'), () => { estado.predios.splice(i, 0, borrado); renderListaPredios(); mostrarToast(tr('predios_multiples__predio_restaurado')); });
}
function renderListaPredios(){
const cont = document.getElementById('lista-predios');
if (!cont) return;
if (estado.predios.length === 0){
cont.innerHTML = `<p class="text-xs text-center py-2" style="color:var(--sage);">${tr('predios_multiples__aun_no_agregas_predios_adicionales')}</p>`;
return;
}
cont.innerHTML = estado.predios.map(p => `
<div class="flex items-center justify-between py-2" style="border-top:2px solid var(--line);">
<div><p class="font-medium text-sm">${p.nombre}</p><p class="text-xs" style="color:var(--sage);">${p.upp || tr('transferencia_autonoma_aretes__sin_upp')} · ${p.municipio || '—'}</p></div>
<button onclick="eliminarPredio('${p.id}')" class="text-sm px-2 py-1" style="color:var(--red);"><i class="fa-solid fa-trash"></i></button>
</div>`).join('');
}
function cambiarPredioActivo(id){
const p = estado.predios.find(x => x.id === id);
if (!p) return;
estado.productor.predio = p.nombre;
estado.productor.upp = p.upp;
estado.productor.municipio = p.municipio;
renderTarjetaDatosGenerales();
mostrarToast(`Viendo: ${p.nombre}`);
}
async function activarPush(){
if (!('Notification' in window)){ mostrarToast(tr('notificaciones_push_reales__este_navegador_no_soporta_notifica')); return; }
const permiso = await Notification.requestPermission();
estado.pushActivado = permiso === 'granted';
document.getElementById('texto-btn-push').textContent = estado.pushActivado ? tr('notificaciones_push_reales__notificaciones_activadas') : tr('notificaciones_push_reales__permiso_no_concedido');
if (estado.pushActivado){
mostrarToast(tr('notificaciones_push_reales__notificaciones_push_activadas'));
dispararPushPendientes();
} else {
mostrarToast(tr('notificaciones_push_reales__no_se_concedio_permiso_de'));
}
}
let pushYaEnviados = new Set();
function dispararPushPendientes(){
if (!estado.pushActivado || Notification.permission !== 'granted') return;
calcularNotificaciones().filter(n => n.categoria === 'hoy' || n.categoria === 'vencido').forEach(n => {
const clave = n.titulo + '|' + n.detalle;
if (pushYaEnviados.has(clave)) return;
pushYaEnviados.add(clave);
if (navigator.serviceWorker?.controller){
  navigator.serviceWorker.controller.postMessage({ type:'IRANCH_LOCAL_NOTIFICATION', title:tr('notificaciones_push_reales__mi_ranchapp') + ' ' + n.titulo, body:n.detalle, url:'./index.html' });
} else {
  new Notification(tr('notificaciones_push_reales__mi_ranchapp') + ' ' + n.titulo, { body: n.detalle });
}
});
}
function renderListaCefpp(){
const cont = document.getElementById('lista-cefpp');
if (!cont) return;
const casos = estado.salud.map((r,i) => ({ ...r, i })).filter(r => r.estadoCEFPP);
if (casos.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-shield-virus"></i><p>${tr('reportes_cefpp__no_hay_casos_urgentes_reportados')}</p></div>`;
return;
}
const ETIQUETAS = { muerte_subita: tr('reportes_cefpp__muerte_subita'), sospecha_exotica: tr('reportes_cefpp__sospecha_de_enfermedad_exotica') };
cont.innerHTML = casos.map(r => `
<div class="item-registro" style="border-left:6px solid var(--red);">
<p class="text-xs font-bold" style="color:var(--red);">${ETIQUETAS[r.tipo] || r.tipo} · ${r.estadoCEFPP === 'enviado' ? 'ENVIADO A CEFPP' : 'PENDIENTE DE ENVIAR'}</p>
<p class="font-bold text-lg mt-1">${r.animal || 'Animal'}</p>
<p class="text-sm mt-1" style="color:var(--sage);">${r.producto || r.notas || 'Sin detalle'} · ${r.fecha || 'sin fecha'}</p>
<div class="flex gap-2 mt-3">
<button onclick="toggleEnviadoCefpp(${r.i})" class="text-xs font-bold px-3 py-2 rounded-full flex-1" style="background:${r.estadoCEFPP === 'enviado' ? 'var(--parchment)' : 'var(--red)'}; color:${r.estadoCEFPP === 'enviado' ? 'var(--pine)' : '#fff'}; border:2px solid var(--line);">
<i class="fa-solid ${r.estadoCEFPP === 'enviado' ? 'fa-rotate-left' : 'fa-paper-plane'}"></i> ${r.estadoCEFPP === 'enviado' ? 'Marcar pendiente' : 'Marcar enviado a CEFPP'}
</button>
</div>
</div>`).join('');
}
function toggleEnviadoCefpp(i){
const r = estado.salud[i];
if (!r) return;
r.estadoCEFPP = r.estadoCEFPP === 'enviado' ? 'pendiente' : 'enviado';
renderListaCefpp();
mostrarToast(r.estadoCEFPP === 'enviado' ? tr('reportes_cefpp__caso_marcado_como_enviado_a') : tr('reportes_cefpp__caso_marcado_como_pendiente'));
}
function exportarCefppCSV(){
const casos = estado.salud.filter(r => r.estadoCEFPP);
if (casos.length === 0){ mostrarToast(tr('reportes_cefpp__no_hay_casos_para_exportar')); return; }
const p = estado.productor;
const encabezados = [tr('csv_extra__predio'),'UPP',tr('editar_datos_productor__municipio'),tr('csv_extra__animal'),tr('reportes_cefpp__tipo_de_caso'),tr('gastos_rendimiento_animal__fecha'),tr('csv_extra__detalle'),tr('reportes_cefpp__estatus_de_envio_a_cefpp')];
const filas = casos.map(r => [p.predio, p.upp, p.municipio, r.animal, r.tipo, r.fecha, r.producto || r.notas, r.estadoCEFPP]);
const csv = [encabezados, ...filas].map(f => f.map(v => `"${(v||'').toString().replace(/"/g,'""')}"`).join(',')).join('\n');
const blob = new Blob(['\ufeff' + csv], { type:'text/csv;charset=utf-8;' });
const url = URL.createObjectURL(blob);
const a = document.createElement('a');
a.href = url; a.download = 'informe-cefpp.csv';
a.click();
URL.revokeObjectURL(url);
mostrarToast(tr('reportes_cefpp__informe_descargado'));
}

// [iRANCH MODULAR] chat cargado bajo demanda.

// [iRANCH MODULAR] admin-reports cargado bajo demanda.
// ================= FIGURA DEL FIERRO DE HERRAR (foto + recorte manual) =================
// No es viable detectar automáticamente "solo la figura" dentro de la foto de una
// credencial (eso requeriría un modelo de visión por computadora que esta app no
// tiene) — en vez de eso, el productor toma la foto y dibuja con el dedo/mouse un
// recuadro sobre la figura; se recorta esa parte y se guarda como imagen, lista
// para usarse automáticamente donde se pida "fierro" en las pruebas de campo.
// Compresión SIN preprocesar (sin escala de grises) — para todo lo que la
// persona necesita VER y recortar a simple vista (como la figura del fierro),
// que debe seguir a color; el preprocesamiento a blanco y negro con más
// contraste (comprimirParaOCR) es solo para lo que va a LEER el OCR, nunca
// para lo que la persona tiene que mirar y recortar con el dedo.
async function comprimirParaRecorte(archivo, maxAncho){
try { return await comprimirArchivoImagen(archivo, maxAncho || 1800, 0.88); }
catch(e){ console.warn('No se pudo comprimir la imagen para recorte, se intenta con el archivo original', e); return archivoADataUrl(archivo); }
}
const RECORTE_FIERRO_ESTADO = {};
// OpenCV.js es pesada (varios MB) y se carga en segundo plano desde el CDN —
// esto espera a que esté lista, sin bloquear el resto de la app mientras
// tanto. Si no llega a cargar (sin internet, CDN caído), simplemente no se
// ofrece la sugerencia automática y el recorte a mano sigue funcionando igual
// que siempre — nunca se queda la pantalla esperando para siempre.
// OpenCV.js es pesada (varios MB) — antes se cargaba SIEMPRE de fondo apenas
// se abría la app, para todos los roles, aunque casi nadie use la sugerencia
// automática del recorte de fierro. Ahora solo se manda a pedir la primera
// vez que alguien de verdad abre esa pantalla. Si no llega a cargar (sin
// internet, CDN caído), simplemente no se ofrece la sugerencia automática y
// el recorte a mano sigue funcionando igual que siempre.
let opencvListoPromise = null;
function esperarOpenCV(){
if (opencvListoPromise) return opencvListoPromise;
opencvListoPromise = new Promise((resolve) => {
if (!window.cv){
const script = document.createElement('script');
script.src = 'https://docs.opencv.org/4.x/opencv.js';
script.async = true;
script.onerror = () => resolve(false);
document.head.appendChild(script);
}
const checar = () => {
if (window.cv && cv.Mat){ resolve(true); return; }
if (window.cv && typeof cv === 'object'){ cv['onRuntimeInitialized'] = () => resolve(true); return; }
setTimeout(checar, 300);
};
checar();
setTimeout(() => resolve(false), 8000);
});
return opencvListoPromise;
}
// Detección automática del recuadro del fierro de herrar: busca en la foto la
// figura cuadrada/rectangular más grande con proporciones parecidas a una
// casilla de fierro (ni una línea delgada, ni la credencial completa), y
// dibuja un recuadro sugerido — la persona lo puede ajustar arrastrando antes
// de confirmar, igual que si lo hubiera dibujado ella desde el principio.
async function sugerirRecorteFierroAutomatico(prefijo){
const est = RECORTE_FIERRO_ESTADO[prefijo];
if (!est) return;
const listo = await esperarOpenCV();
if (!listo || est.arrastrando || (est.rect && est.rect.w > 8)) return; // no pisar un recorte que la persona ya empezó a dibujar a mano
try {
const canvas = document.getElementById(prefijo + '-fierro-canvas');
let src = cv.imread(canvas);
let gray = new cv.Mat(), thresh = new cv.Mat(), contours = new cv.MatVector(), hierarchy = new cv.Mat();
cv.cvtColor(src, gray, cv.COLOR_RGBA2GRAY, 0);
cv.threshold(gray, thresh, 120, 255, cv.THRESH_BINARY_INV);
cv.findContours(thresh, contours, hierarchy, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE);
let maxArea = 0, bestRect = null;
for (let i = 0; i < contours.size(); ++i){
const r = cv.boundingRect(contours.get(i));
const area = r.width * r.height;
const aspecto = r.width / (r.height || 1);
if (area > 2000 && area < (src.rows * src.cols * 0.3) && aspecto >= 0.6 && aspecto <= 1.6 && area > maxArea){
maxArea = area; bestRect = r;
}
}
if (bestRect && !est.arrastrando){
est.rect = { x: bestRect.x, y: bestRect.y, w: bestRect.width, h: bestRect.height };
redibujarCanvasFierro(prefijo);
mostrarToast('Encontré un posible recuadro del fierro — ajústalo si hace falta y confirma');
}
src.delete(); gray.delete(); thresh.delete(); contours.delete(); hierarchy.delete();
} catch(e){ console.warn('No se pudo sugerir el recorte automático del fierro, se deja el recorte manual', e); }
}
let camaraFierroStream = null;
let camaraFierroPrefijoDestino = null;
// Cámara con recuadro guía para el fierro de herrar — igual que el recuadro
// que ya existía para centrar el código de barras del arete, pero cuadrado y
// para centrar la figura del fierro. Al capturar, la foto entra al mismo
// flujo de recorte y sugerencia automática que ya existía para fotos subidas
// de archivo, así que no se duplica esa lógica.
async function abrirCamaraFierroConGuia(prefijo){
camaraFierroPrefijoDestino = prefijo;
const modal = document.getElementById('modal-scanner-fierro');
const video = document.getElementById('video-scanner-fierro');
modal.classList.remove('hidden');
try {
camaraFierroStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
video.srcObject = camaraFierroStream;
} catch (err){
mostrarToast('No se pudo acceder a la cámara — revisa los permisos, o usa el botón de subir foto');
cerrarCamaraFierro();
}
}
function capturarFotoFierroConGuia(){
const video = document.getElementById('video-scanner-fierro');
if (!video.videoWidth){ mostrarToast('La cámara todavía no está lista — espera un momento'); return; }
const canvasCaptura = document.createElement('canvas');
canvasCaptura.width = video.videoWidth;
canvasCaptura.height = video.videoHeight;
canvasCaptura.getContext('2d').drawImage(video, 0, 0);
const dataUrl = canvasCaptura.toDataURL('image/jpeg', 0.9);
const prefijo = camaraFierroPrefijoDestino;
cerrarCamaraFierro();
const img = new Image();
img.onload = () => {
const canvas = document.getElementById(prefijo + '-fierro-canvas');
const wrap = document.getElementById(prefijo + '-fierro-lienzo-wrap');
const anchoMax = Math.min((wrap && wrap.clientWidth) || 340, 480);
const escala = anchoMax / img.width;
canvas.width = anchoMax;
canvas.height = img.height * escala;
canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
RECORTE_FIERRO_ESTADO[prefijo] = { imgOriginal: img, escala, rect: null, arrastrando: false, inicioX: 0, inicioY: 0 };
document.getElementById(prefijo + '-fierro-recorte-cont').classList.remove('hidden');
activarArrastreRecorteFierro(prefijo);
sugerirRecorteFierroAutomatico(prefijo);
};
img.onerror = () => mostrarToast('No se pudo procesar la foto capturada — inténtalo de nuevo');
img.src = dataUrl;
}
function cerrarCamaraFierro(){
if (camaraFierroStream){ camaraFierroStream.getTracks().forEach(t => t.stop()); camaraFierroStream = null; }
document.getElementById('modal-scanner-fierro').classList.add('hidden');
}
function cargarFotoParaRecorteFierro(inputEl, prefijo){
const archivo = inputEl.files && inputEl.files[0];
if (!archivo) return;
inputEl.value = '';
// Misma corrección que en "Alta rápida por escaneo": se comprime la foto antes
// de cargarla al recorte, en vez de decodificar la original a resolución
// completa — evita que el navegador se quede sin memoria y recargue la página
// de golpe en celulares con poca RAM. A COLOR (no la versión para OCR).
comprimirParaRecorte(archivo, 1800).then(dataUrlComprimido => {
const img = new Image();
img.onload = () => {
const canvas = document.getElementById(prefijo + '-fierro-canvas');
const wrap = document.getElementById(prefijo + '-fierro-lienzo-wrap');
const anchoMax = Math.min(wrap.clientWidth || 340, 480);
const escala = anchoMax / img.width;
canvas.width = anchoMax;
canvas.height = img.height * escala;
const ctx = canvas.getContext('2d');
ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
RECORTE_FIERRO_ESTADO[prefijo] = { imgOriginal: img, escala, rect: null, arrastrando: false, inicioX: 0, inicioY: 0 };
document.getElementById(prefijo + '-fierro-recorte-cont').classList.remove('hidden');
activarArrastreRecorteFierro(prefijo);
sugerirRecorteFierroAutomatico(prefijo);
};
img.onerror = () => mostrarToast('No se pudo abrir la foto para recortar — vuelve a tomarla');
img.src = dataUrlComprimido;
}).catch(() => mostrarToast('No se pudo abrir la foto para recortar — vuelve a tomarla'));
}
function posicionEnCanvasFierro(canvas, evt){
const rect = canvas.getBoundingClientRect();
const punto = evt.touches ? evt.touches[0] : evt;
return { x: (punto.clientX - rect.left) * (canvas.width / rect.width), y: (punto.clientY - rect.top) * (canvas.height / rect.height) };
}
function redibujarCanvasFierro(prefijo){
const est = RECORTE_FIERRO_ESTADO[prefijo];
if (!est) return;
const canvas = document.getElementById(prefijo + '-fierro-canvas');
const ctx = canvas.getContext('2d');
ctx.clearRect(0, 0, canvas.width, canvas.height);
ctx.drawImage(est.imgOriginal, 0, 0, canvas.width, canvas.height);
if (est.rect){
ctx.strokeStyle = '#E11D48';
ctx.lineWidth = 2;
ctx.setLineDash([6,4]);
ctx.strokeRect(est.rect.x, est.rect.y, est.rect.w, est.rect.h);
ctx.setLineDash([]);
ctx.fillStyle = 'rgba(225,29,72,0.12)';
ctx.fillRect(est.rect.x, est.rect.y, est.rect.w, est.rect.h);
}
}
function activarArrastreRecorteFierro(prefijo){
const canvas = document.getElementById(prefijo + '-fierro-canvas');
const est = RECORTE_FIERRO_ESTADO[prefijo];
const iniciar = evt => {
evt.preventDefault();
const p = posicionEnCanvasFierro(canvas, evt);
est.arrastrando = true;
est.inicioX = p.x; est.inicioY = p.y;
est.rect = { x: p.x, y: p.y, w: 0, h: 0 };
};
const mover = evt => {
if (!est.arrastrando) return;
evt.preventDefault();
const p = posicionEnCanvasFierro(canvas, evt);
est.rect = { x: Math.min(est.inicioX, p.x), y: Math.min(est.inicioY, p.y), w: Math.abs(p.x - est.inicioX), h: Math.abs(p.y - est.inicioY) };
redibujarCanvasFierro(prefijo);
};
const soltar = () => { est.arrastrando = false; };
canvas.onmousedown = iniciar; canvas.onmousemove = mover; canvas.onmouseup = soltar; canvas.onmouseleave = soltar;
canvas.ontouchstart = iniciar; canvas.ontouchmove = mover; canvas.ontouchend = soltar;
}
function cancelarRecorteFierro(prefijo){
const cont = document.getElementById(prefijo + '-fierro-recorte-cont');
if (cont) cont.classList.add('hidden');
delete RECORTE_FIERRO_ESTADO[prefijo];
}
function confirmarRecorteFierro(prefijo){
const est = RECORTE_FIERRO_ESTADO[prefijo];
if (!est || !est.rect || est.rect.w < 8 || est.rect.h < 8){ mostrarToast('Dibuja un recuadro sobre la figura antes de recortar'); return; }
const escalaOriginal = 1 / est.escala;
const sx = est.rect.x * escalaOriginal, sy = est.rect.y * escalaOriginal;
const sw = est.rect.w * escalaOriginal, sh = est.rect.h * escalaOriginal;
const salida = document.createElement('canvas');
salida.width = 300; salida.height = Math.max(1, Math.round(300 * (sh / sw)));
salida.getContext('2d').drawImage(est.imgOriginal, sx, sy, sw, sh, 0, 0, salida.width, salida.height);
const dataUrl = salida.toDataURL('image/png');
if (prefijo === 'ed'){
estado.productor.fierroImagen = dataUrl;
if (estado.cuentaActivaId){
const cuenta = estado.cuentasProductores.find(c => c.id === estado.cuentaActivaId);
if (cuenta) cuenta.fierroImagen = dataUrl;
}
guardarEstadoLocal();
renderVistaFierroGuardado('ed');
}
if (prefijo === 'esc'){
fierroImagenEscaneoTemp = dataUrl;
renderVistaFierroGuardado('esc');
if (typeof guardarBorradorEscaneoDoc === 'function') guardarBorradorEscaneoDoc();
}
cancelarRecorteFierro(prefijo);
mostrarToast('Figura del fierro guardada — se usará automáticamente en las pruebas de campo');
}
let fierroImagenEscaneoTemp = null;
function renderVistaFierroGuardado(prefijo){
const cont = document.getElementById(prefijo + '-fierro-vista-guardada');
if (!cont) return;
const img = prefijo === 'ed' ? estado.productor.fierroImagen : (prefijo === 'esc' ? fierroImagenEscaneoTemp : null);
if (!img){ cont.innerHTML = ''; return; }
cont.innerHTML = `<div class="flex items-center gap-3 bg-white rounded-xl p-2" style="border:2px solid var(--green);">
<img loading="lazy" decoding="async" src="${img}" style="width:56px; height:56px; object-fit:contain; border-radius:8px; background:#fff; border:1px solid var(--line);"/>
<div class="flex-1"><p class="text-xs font-bold" style="color:var(--green);"><i class="fa-solid fa-circle-check mr-1"></i>Figura guardada</p><p class="text-xs" style="color:var(--sage);">Se usará automáticamente en el campo "Fierro" de tus pruebas.</p></div>
<button onclick="quitarFierroGuardado('${prefijo}')" style="color:var(--red);"><i class="fa-solid fa-trash"></i></button>
</div>`;
}
function quitarFierroGuardado(prefijo){
if (prefijo === 'ed'){
estado.productor.fierroImagen = null;
if (estado.cuentaActivaId){
const cuenta = estado.cuentasProductores.find(c => c.id === estado.cuentaActivaId);
if (cuenta) cuenta.fierroImagen = null;
}
guardarEstadoLocal();
renderVistaFierroGuardado('ed');
}
mostrarToast('Figura de fierro eliminada');
}

// [iRANCH MODULAR] ocr cargado bajo demanda.
// ================= CARGADOR BAJO DEMANDA: VOZ =================
// El motor de voz es pesado y no se descarga al abrir MiRanch. Se carga solo
// cuando alguna función de voz se necesita. Los stubs conservan los nombres
// globales que ya usa la interfaz/onclick, por lo que no rompemos el código
// existente durante la migración modular.
let moduloVozIRanchPromise = null;
function cargarModuloVozIRanch(){
if (moduloVozIRanchPromise) return moduloVozIRanchPromise;
moduloVozIRanchPromise = new Promise((resolve, reject) => {
const existente = document.querySelector('script[data-iranch-modulo="voz"]');
if (existente){
existente.addEventListener('load', () => resolve(true), { once:true });
existente.addEventListener('error', () => reject(new Error('No se pudo cargar el módulo de voz')), { once:true });
return;
}
const script = document.createElement('script');
script.src = './iranch-modular/modules/voice.js';
script.dataset.iranchModulo = 'voz';
script.async = true;
script.onload = () => resolve(true);
script.onerror = () => { moduloVozIRanchPromise = null; reject(new Error('No se pudo cargar el módulo de voz')); };
document.head.appendChild(script);
});
return moduloVozIRanchPromise;
}
function activarModoPlautdietschVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['activarModoPlautdietschVoz'] === 'function' && window['activarModoPlautdietschVoz'] !== activarModoPlautdietschVoz) window['activarModoPlautdietschVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function tonoInicioEscucha(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['tonoInicioEscucha'] === 'function' && window['tonoInicioEscucha'] !== tonoInicioEscucha) window['tonoInicioEscucha'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function decirEnVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['decirEnVoz'] === 'function' && window['decirEnVoz'] !== decirEnVoz) window['decirEnVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function estadoVisualVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['estadoVisualVoz'] === 'function' && window['estadoVisualVoz'] !== estadoVisualVoz) window['estadoVisualVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function mostrarEtiqueta(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['mostrarEtiqueta'] === 'function' && window['mostrarEtiqueta'] !== mostrarEtiqueta) window['mostrarEtiqueta'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function actualizarBotonVozSegunConexion(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['actualizarBotonVozSegunConexion'] === 'function' && window['actualizarBotonVozSegunConexion'] !== actualizarBotonVozSegunConexion) window['actualizarBotonVozSegunConexion'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function iniciarEscuchaContinua(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['iniciarEscuchaContinua'] === 'function' && window['iniciarEscuchaContinua'] !== iniciarEscuchaContinua) window['iniciarEscuchaContinua'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function detenerEscuchaContinua(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['detenerEscuchaContinua'] === 'function' && window['detenerEscuchaContinua'] !== detenerEscuchaContinua) window['detenerEscuchaContinua'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function traducirDesdePlautdietsch(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['traducirDesdePlautdietsch'] === 'function' && window['traducirDesdePlautdietsch'] !== traducirDesdePlautdietsch) window['traducirDesdePlautdietsch'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function convertirNumerosEspanolADigitos(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['convertirNumerosEspanolADigitos'] === 'function' && window['convertirNumerosEspanolADigitos'] !== convertirNumerosEspanolADigitos) window['convertirNumerosEspanolADigitos'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function buscarPersonaFuzzy(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['buscarPersonaFuzzy'] === 'function' && window['buscarPersonaFuzzy'] !== buscarPersonaFuzzy) window['buscarPersonaFuzzy'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function buscarProductorEnFrase(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['buscarProductorEnFrase'] === 'function' && window['buscarProductorEnFrase'] !== buscarProductorEnFrase) window['buscarProductorEnFrase'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function interpretarComandoComplejoPruebaCampo(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['interpretarComandoComplejoPruebaCampo'] === 'function' && window['interpretarComandoComplejoPruebaCampo'] !== interpretarComandoComplejoPruebaCampo) window['interpretarComandoComplejoPruebaCampo'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function buscarTrabajadorEnFrase(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['buscarTrabajadorEnFrase'] === 'function' && window['buscarTrabajadorEnFrase'] !== buscarTrabajadorEnFrase) window['buscarTrabajadorEnFrase'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function interpretarComandoTareaTrabajador(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['interpretarComandoTareaTrabajador'] === 'function' && window['interpretarComandoTareaTrabajador'] !== interpretarComandoTareaTrabajador) window['interpretarComandoTareaTrabajador'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function ejecutarComandoTareaTrabajador(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['ejecutarComandoTareaTrabajador'] === 'function' && window['ejecutarComandoTareaTrabajador'] !== ejecutarComandoTareaTrabajador) window['ejecutarComandoTareaTrabajador'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function ejecutarComandoPruebaCampoComplejo(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['ejecutarComandoPruebaCampoComplejo'] === 'function' && window['ejecutarComandoPruebaCampoComplejo'] !== ejecutarComandoPruebaCampoComplejo) window['ejecutarComandoPruebaCampoComplejo'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function interpretarFechaRelativaVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['interpretarFechaRelativaVoz'] === 'function' && window['interpretarFechaRelativaVoz'] !== interpretarFechaRelativaVoz) window['interpretarFechaRelativaVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function extraerAltaAnimalCompleta(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['extraerAltaAnimalCompleta'] === 'function' && window['extraerAltaAnimalCompleta'] !== extraerAltaAnimalCompleta) window['extraerAltaAnimalCompleta'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function interpretarComandoAltaAnimal(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['interpretarComandoAltaAnimal'] === 'function' && window['interpretarComandoAltaAnimal'] !== interpretarComandoAltaAnimal) window['interpretarComandoAltaAnimal'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function ejecutarComandoAltaAnimalPorVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['ejecutarComandoAltaAnimalPorVoz'] === 'function' && window['ejecutarComandoAltaAnimalPorVoz'] !== ejecutarComandoAltaAnimalPorVoz) window['ejecutarComandoAltaAnimalPorVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function interpretarComandoBajaAnimal(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['interpretarComandoBajaAnimal'] === 'function' && window['interpretarComandoBajaAnimal'] !== interpretarComandoBajaAnimal) window['interpretarComandoBajaAnimal'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function ejecutarComandoBajaAnimalPorVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['ejecutarComandoBajaAnimalPorVoz'] === 'function' && window['ejecutarComandoBajaAnimalPorVoz'] !== ejecutarComandoBajaAnimalPorVoz) window['ejecutarComandoBajaAnimalPorVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function interpretarComandoBuscarArete(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['interpretarComandoBuscarArete'] === 'function' && window['interpretarComandoBuscarArete'] !== interpretarComandoBuscarArete) window['interpretarComandoBuscarArete'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function ejecutarComandoBuscarArete(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['ejecutarComandoBuscarArete'] === 'function' && window['ejecutarComandoBuscarArete'] !== ejecutarComandoBuscarArete) window['ejecutarComandoBuscarArete'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function interpretarComandoGasto(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['interpretarComandoGasto'] === 'function' && window['interpretarComandoGasto'] !== interpretarComandoGasto) window['interpretarComandoGasto'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function extraerFiltroFechaReporte(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['extraerFiltroFechaReporte'] === 'function' && window['extraerFiltroFechaReporte'] !== extraerFiltroFechaReporte) window['extraerFiltroFechaReporte'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function interpretarComandoReporte(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['interpretarComandoReporte'] === 'function' && window['interpretarComandoReporte'] !== interpretarComandoReporte) window['interpretarComandoReporte'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function ejecutarComandoReporte(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['ejecutarComandoReporte'] === 'function' && window['ejecutarComandoReporte'] !== ejecutarComandoReporte) window['ejecutarComandoReporte'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function unirDigitosSueltosDeArete(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['unirDigitosSueltosDeArete'] === 'function' && window['unirDigitosSueltosDeArete'] !== unirDigitosSueltosDeArete) window['unirDigitosSueltosDeArete'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function interpretarComandoNavegacion(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['interpretarComandoNavegacion'] === 'function' && window['interpretarComandoNavegacion'] !== interpretarComandoNavegacion) window['interpretarComandoNavegacion'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function extraerValorTrasPalabraClave(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['extraerValorTrasPalabraClave'] === 'function' && window['extraerValorTrasPalabraClave'] !== extraerValorTrasPalabraClave) window['extraerValorTrasPalabraClave'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function interpretarComandoDictadoAnimalEnPantalla(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['interpretarComandoDictadoAnimalEnPantalla'] === 'function' && window['interpretarComandoDictadoAnimalEnPantalla'] !== interpretarComandoDictadoAnimalEnPantalla) window['interpretarComandoDictadoAnimalEnPantalla'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function ejecutarComandoDictadoAnimalEnPantalla(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['ejecutarComandoDictadoAnimalEnPantalla'] === 'function' && window['ejecutarComandoDictadoAnimalEnPantalla'] !== ejecutarComandoDictadoAnimalEnPantalla) window['ejecutarComandoDictadoAnimalEnPantalla'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function ejecutarDictadoEnPruebaCampo(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['ejecutarDictadoEnPruebaCampo'] === 'function' && window['ejecutarDictadoEnPruebaCampo'] !== ejecutarDictadoEnPruebaCampo) window['ejecutarDictadoEnPruebaCampo'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function ejecutarDictadoEnModuloA(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['ejecutarDictadoEnModuloA'] === 'function' && window['ejecutarDictadoEnModuloA'] !== ejecutarDictadoEnModuloA) window['ejecutarDictadoEnModuloA'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function guardarContextoVozUltimoAnimal(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['guardarContextoVozUltimoAnimal'] === 'function' && window['guardarContextoVozUltimoAnimal'] !== guardarContextoVozUltimoAnimal) window['guardarContextoVozUltimoAnimal'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function obtenerUltimoAnimalContextoVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['obtenerUltimoAnimalContextoVoz'] === 'function' && window['obtenerUltimoAnimalContextoVoz'] !== obtenerUltimoAnimalContextoVoz) window['obtenerUltimoAnimalContextoVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function resolverReferenciasContextoVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['resolverReferenciasContextoVoz'] === 'function' && window['resolverReferenciasContextoVoz'] !== resolverReferenciasContextoVoz) window['resolverReferenciasContextoVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function interpretarComandoVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['interpretarComandoVoz'] === 'function' && window['interpretarComandoVoz'] !== interpretarComandoVoz) window['interpretarComandoVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function hayFormularioActivoParaVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['hayFormularioActivoParaVoz'] === 'function' && window['hayFormularioActivoParaVoz'] !== hayFormularioActivoParaVoz) window['hayFormularioActivoParaVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function dispararEventosCampo(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['dispararEventosCampo'] === 'function' && window['dispararEventosCampo'] !== dispararEventosCampo) window['dispararEventosCampo'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function construirGramaticaVozRancho(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['construirGramaticaVozRancho'] === 'function' && window['construirGramaticaVozRancho'] !== construirGramaticaVozRancho) window['construirGramaticaVozRancho'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function calcularLevenshteinVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['calcularLevenshteinVoz'] === 'function' && window['calcularLevenshteinVoz'] !== calcularLevenshteinVoz) window['calcularLevenshteinVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function autocorregirPalabraVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['autocorregirPalabraVoz'] === 'function' && window['autocorregirPalabraVoz'] !== autocorregirPalabraVoz) window['autocorregirPalabraVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function limpiarYCorregirDictado(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['limpiarYCorregirDictado'] === 'function' && window['limpiarYCorregirDictado'] !== limpiarYCorregirDictado) window['limpiarYCorregirDictado'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function preguntarDatoFaltante(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['preguntarDatoFaltante'] === 'function' && window['preguntarDatoFaltante'] !== preguntarDatoFaltante) window['preguntarDatoFaltante'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function completarConRespuestaDeVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['completarConRespuestaDeVoz'] === 'function' && window['completarConRespuestaDeVoz'] !== completarConRespuestaDeVoz) window['completarConRespuestaDeVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function clasificarIntencionVerboMasivo(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['clasificarIntencionVerboMasivo'] === 'function' && window['clasificarIntencionVerboMasivo'] !== clasificarIntencionVerboMasivo) window['clasificarIntencionVerboMasivo'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function procesarVozMasiva(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['procesarVozMasiva'] === 'function' && window['procesarVozMasiva'] !== procesarVozMasiva) window['procesarVozMasiva'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function procesarComandoVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['procesarComandoVoz'] === 'function' && window['procesarComandoVoz'] !== procesarComandoVoz) window['procesarComandoVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function resumenComandoVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['resumenComandoVoz'] === 'function' && window['resumenComandoVoz'] !== resumenComandoVoz) window['resumenComandoVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function pedirConfirmacionComandoVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['pedirConfirmacionComandoVoz'] === 'function' && window['pedirConfirmacionComandoVoz'] !== pedirConfirmacionComandoVoz) window['pedirConfirmacionComandoVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function intentarCorregirCampoPendiente(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['intentarCorregirCampoPendiente'] === 'function' && window['intentarCorregirCampoPendiente'] !== intentarCorregirCampoPendiente) window['intentarCorregirCampoPendiente'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function responderConfirmacionVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['responderConfirmacionVoz'] === 'function' && window['responderConfirmacionVoz'] !== responderConfirmacionVoz) window['responderConfirmacionVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function registrarBitacoraVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['registrarBitacoraVoz'] === 'function' && window['registrarBitacoraVoz'] !== registrarBitacoraVoz) window['registrarBitacoraVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function limpiarBitacoraVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['limpiarBitacoraVoz'] === 'function' && window['limpiarBitacoraVoz'] !== limpiarBitacoraVoz) window['limpiarBitacoraVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function renderBitacoraVoz(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['renderBitacoraVoz'] === 'function' && window['renderBitacoraVoz'] !== renderBitacoraVoz) window['renderBitacoraVoz'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function guardarComandoVozEnSegundoPlano(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['guardarComandoVozEnSegundoPlano'] === 'function' && window['guardarComandoVozEnSegundoPlano'] !== guardarComandoVozEnSegundoPlano) window['guardarComandoVozEnSegundoPlano'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }
function animalEncontrado(...args){ cargarModuloVozIRanch().then(()=>{ if (typeof window['animalEncontrado'] === 'function' && window['animalEncontrado'] !== animalEncontrado) window['animalEncontrado'](...args); }).catch(e=>console.warn('MiRanch: módulo de voz no disponible',e)); }

function buscarGlobal(){
const q = valor('buscador-global').trim().toLowerCase();
const cont = document.getElementById('resultados-buscador');
if (!q){ cont.classList.add('hidden'); cont.innerHTML = ''; return; }
const resultados = [];
estado.animales.forEach(a => {
if ((a.nombre||'').toLowerCase().includes(q) || (a.arete||'').toLowerCase().includes(q))
resultados.push({ icono:'fa-cow', color:'var(--blue)', texto:`${a.nombre || a.arete} · animal`, ir:"irA('hato')" });
});
estado.potreros.forEach(p => {
if ((p.nombre||'').toLowerCase().includes(q))
resultados.push({ icono:'fa-map-location-dot', color:'var(--teal)', texto:`${p.nombre} · potrero`, ir:"irModulo('E')" });
});
estado.boletines.forEach(b => {
if ((b.titulo||'').toLowerCase().includes(q))
resultados.push({ icono:'fa-bullhorn', color:'var(--pink)', texto:`${b.titulo} · boletín`, ir:"irA('boletines')" });
});
if (resultados.length === 0){
cont.innerHTML = `<p class="text-sm text-center py-3" style="color:var(--sage);">${tr('buscador_global__sin_resultados')}</p>`;
} else {
cont.innerHTML = resultados.slice(0, 8).map(r => `
<button onclick="${r.ir}; document.getElementById('resultados-buscador').classList.add('hidden');" class="w-full flex items-center gap-3 p-2 rounded-xl text-left" style="background:var(--parchment);">
<span class="w-9 h-9 rounded-lg flex items-center justify-center" style="background:${r.color}; color:#fff;"><i class="fa-solid ${r.icono}"></i></span>
<span class="font-medium text-sm">${r.texto}</span>
</button>`).join('');
}
cont.classList.remove('hidden');
}
function diasHasta(fecha){
const hoy = new Date();
hoy.setHours(0,0,0,0);
const f = new Date(fecha);
f.setHours(0,0,0,0);
return Math.ceil((f - hoy) / 86400000);
}
let calMes = new Date().getMonth();
let calAnio = new Date().getFullYear();
const NOMBRES_MESES = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
function cambiarMesCalendario(delta){
calMes += delta;
if (calMes < 0){ calMes = 11; calAnio--; }
if (calMes > 11){ calMes = 0; calAnio++; }
renderCalendario();
}
function eventosDelMes(){
const eventos = {}; 
const agregar = (fecha, color, texto) => {
if (!fecha) return;
if (!eventos[fecha]) eventos[fecha] = [];
eventos[fecha].push({ color, texto });
};
estado.salud.forEach(r => { if (r.proxima) agregar(r.proxima, 'var(--purple)', `${r.animal || 'Animal'} — ${r.tipo}`); });
estado.reproduccion.forEach(r => { if (r.diagnostico === 'confirmada' && r.parto) agregar(r.parto, 'var(--pink)', `Parto: ${r.vaca || 'Vaca'}`); });
if (estado.productor.vencimientoFierro) agregar(estado.productor.vencimientoFierro, 'var(--blue)', tr('calendario_visual__vencimiento_credencial_de_fierro'));
return eventos;
}
function renderCalendario(){
document.getElementById('calendario-titulo').textContent = `${NOMBRES_MESES[calMes]} ${calAnio}`;
const eventos = eventosDelMes();
const primerDia = new Date(calAnio, calMes, 1).getDay();
const diasEnMes = new Date(calAnio, calMes + 1, 0).getDate();
const hoyStr = new Date().toISOString().slice(0,10);
let celdas = '';
for (let i = 0; i < primerDia; i++) celdas += `<div></div>`;
for (let d = 1; d <= diasEnMes; d++){
const fechaStr = `${calAnio}-${String(calMes+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
const evs = eventos[fechaStr] || [];
const esHoy = fechaStr === hoyStr;
celdas += `
<button onclick="mostrarEventosDia('${fechaStr}')" class="rounded-xl flex flex-col items-center justify-center gap-1 py-2" style="background:${esHoy ? 'var(--pine)' : '#fff'}; color:${esHoy ? '#fff' : 'var(--ink)'}; border:2px solid var(--line); min-height:52px;">
<span class="text-sm font-bold">${d}</span>
<span class="flex gap-0.5">${evs.slice(0,3).map(e => `<span class="inline-block w-1.5 h-1.5 rounded-full" style="background:${e.color};"></span>`).join('')}</span>
</button>`;
}
document.getElementById('calendario-grid').innerHTML = celdas;
mostrarEventosDia(hoyStr);
}
function mostrarEventosDia(fechaStr){
const eventos = eventosDelMes()[fechaStr] || [];
const cont = document.getElementById('calendario-eventos-dia');
const [a,m,d] = fechaStr.split('-');
cont.innerHTML = `<p class="font-display font-bold pt-2">${d}/${m}/${a}</p>` + (
eventos.length === 0
? `<p class="text-sm" style="color:var(--sage);">${tr('calendario_visual__sin_eventos_este_dia')}</p>`
: eventos.map(e => `<div class="item-registro" style="border-left:6px solid ${e.color};"><p class="text-sm font-semibold">${e.texto}</p></div>`).join('')
);
}
function exportarNotificacionesCSV(){
const notas = calcularNotificaciones();
if (notas.length === 0){ mostrarToast(tr('calendario_visual__no_hay_vencimientos_proximos_para')); return; }
const ETIQUETAS_CATEGORIA = { vencido: tr('csv_extra8__vencido'), hoy: tr('csv_extra4__hoy'), proximo: tr('calendario_visual__proximo'), tramite: tr('calendario_visual__tramite') };
const encabezados = [tr('calendario_visual__categoria'),tr('calendario_visual__titulo'),tr('csv_extra__detalle'),tr('calendario_visual__dias_restantes')];
const filas = notas.map(n => [ETIQUETAS_CATEGORIA[n.categoria] || n.categoria, n.titulo, n.detalle, n.dias]);
const csv = [encabezados, ...filas].map(f => f.map(v => `"${(v??'').toString().replace(/"/g,'""')}"`).join(',')).join('\n');
const blob = new Blob(['\ufeff' + csv], { type:'text/csv;charset=utf-8;' });
const url = URL.createObjectURL(blob);
const a = document.createElement('a');
a.href = url; a.download = 'proximos-vencimientos.csv';
a.click();
URL.revokeObjectURL(url);
mostrarToast(tr('calendario_visual__tabla_exportada'));
}
function diasDesde(fecha){ return -diasHasta(fecha); }
function calcularAlertasMotor(){
const alertas = [];
estado.reproduccion.forEach(r => {
if (r.diagnostico !== 'confirmada' || !r.parto || r.partoReal) return;
const dias = diasHasta(r.parto);
if (dias >= 0 && dias <= 30){
alertas.push({
nivel: dias <= 7 ? 'rojo' : 'naranja',
icono: 'fa-baby-carriage',
titulo: `Parto próximo: ${r.vaca || 'Vaca'}`,
detalle: `Estimado para el ${r.parto} (en ${dias} día${dias === 1 ? '' : 's'}) — prepara el secado y el corral de maternidad.`,
});
}
});
const ultimoPartoPorVaca = {};
estado.reproduccion.forEach(r => {
if (!r.vaca || !r.partoReal) return;
if (!ultimoPartoPorVaca[r.vaca] || new Date(r.partoReal) > new Date(ultimoPartoPorVaca[r.vaca])){
ultimoPartoPorVaca[r.vaca] = r.partoReal;
}
});
Object.entries(ultimoPartoPorVaca).forEach(([vaca, fechaParto]) => {
const huboServicioDespues = estado.reproduccion.some(r => r.vaca === vaca && r.fecha && new Date(r.fecha) > new Date(fechaParto));
if (huboServicioDespues) return;
const dias = diasDesde(fechaParto);
if (dias > 90){
alertas.push({
nivel: dias > 150 ? 'rojo' : 'naranja',
icono: 'fa-triangle-exclamation',
titulo: `Días abiertos: ${vaca}`,
detalle: `${dias} días desde su último parto sin un nuevo servicio — se recomienda revisión veterinaria.`,
});
}
});
estado.becerros.forEach(b => {
if (!b.fecha || b.fechaDestete) return;
const edadDias = diasDesde(b.fecha);
if (edadDias >= 210 && edadDias <= 244){
alertas.push({
nivel: edadDias >= 230 ? 'rojo' : 'naranja',
icono: 'fa-cow',
titulo: `Listo para destete: ${b.animal || 'Becerro/a'}`,
detalle: `${Math.floor(edadDias / 30)} meses de edad — sepáralo, cambia su etapa y actualiza su dieta.`,
});
}
});
estado.bodega.forEach(i => {
if (i.cantidad <= i.stockMinimo){
alertas.push({
nivel: i.cantidad === 0 ? 'rojo' : 'naranja',
icono: 'fa-warehouse',
titulo: `Stock bajo: ${i.producto}`,
detalle: `Quedan ${i.cantidad} ${i.unidad} — considera comprar o resurtir pronto.`,
});
}
});
alertas.sort((a, b) => (a.nivel === 'rojo' ? 0 : 1) - (b.nivel === 'rojo' ? 0 : 1));
return alertas;
}
function renderAlertasMotor(){
const cont = document.getElementById('motor-alertas-home');
if (!cont) return;
const alertas = calcularAlertasMotor();
if (alertas.length === 0){ cont.innerHTML = ''; return; }
const COLORES = { rojo: 'var(--red)', naranja: 'var(--orange)' };
cont.innerHTML = alertas.map(a => `
<div class="rounded-2xl p-3 flex items-center gap-3" style="background:${COLORES[a.nivel]}; color:#fff;">
<span class="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style="background:rgba(255,255,255,0.25);"><i class="fa-solid ${a.icono}"></i></span>
<div><p class="font-bold text-sm">${a.titulo}</p><p class="text-xs" style="opacity:.9;">${a.detalle}</p></div>
</div>`).join('');
}
setInterval(() => {
const home = document.getElementById('screen-home');
if (home && home.classList.contains('active')) renderAlertasMotor();
}, 60000);
function calcularNotificaciones(){
const notas = [];
estado.salud.forEach(r => {
if (!r.proxima || r.recuperado) return;
const dias = diasHasta(r.proxima);
const esObligatoria = r.tipo === 'vacuna_brucelosis_obligatoria' || r.tipo === 'vacuna_tuberculosis_obligatoria';
notas.push({
icono: esObligatoria ? 'fa-shield-heart' : 'fa-syringe', color: dias < 0 ? 'var(--red)' : (dias === 0 ? 'var(--yellow)' : (esObligatoria ? 'var(--red)' : 'var(--purple)')),
titulo: (esObligatoria ? tr('motor_alertas_automaticas__obligatoria') + ' ' : '') + (dias < 0 ? tr('render_estatus_hato__dosis_vencida') : (dias === 0 ? tr('motor_alertas_automaticas__tratamiento_de_hoy') : tr('motor_alertas_automaticas__proxima_dosis_programada'))),
detalle: `${r.animal || 'Animal'} — ${r.tipo} (${r.proxima})`,
dias, categoria: dias < 0 ? 'vencido' : (dias === 0 ? 'hoy' : 'proximo'),
});
});
if (estado.tipoGanado === 'leche'){
estado.salud.forEach(r => {
if (!r.retiroLecheHasta) return;
const dias = diasHasta(r.retiroLecheHasta);
if (dias < 0) return;
notas.push({
icono:'fa-ban', color:'var(--red)',
titulo: dias === 0 ? tr('motor_alertas_automaticas__leche_apta_desde_hoy') : tr('motor_alertas_automaticas__leche_no_apta_para_el'),
detalle: `${r.animal || 'Animal'} — no incluir en el tanque hasta ${r.retiroLecheHasta}`,
dias, categoria: dias === 0 ? 'hoy' : 'proximo',
});
});
}
estado.reproduccion.forEach(r => {
if (r.diagnostico !== 'confirmada' || !r.parto) return;
const dias = diasHasta(r.parto);
if (dias <= 30) {
notas.push({
icono:'fa-heart', color: dias < 0 ? 'var(--red)' : (dias === 0 ? 'var(--yellow)' : 'var(--pink)'),
titulo: dias < 0 ? tr('motor_alertas_automaticas__parto_atrasado') : (dias === 0 ? tr('motor_alertas_automaticas__parto_esperado_hoy') : tr('motor_alertas_automaticas__parto_proximo')),
detalle: `${r.vaca || 'Vaca'} — estimado ${r.parto}`,
dias, categoria: dias < 0 ? 'vencido' : (dias === 0 ? 'hoy' : 'proximo'),
});
}
});
if (estado.tipoGanado === 'leche'){
estado.reproduccion.forEach(r => {
if (!r.secado || r.partoReal) return;
const dias = diasHasta(r.secado);
if (dias > 15) return;
notas.push({
icono:'fa-droplet-slash', color: dias < 0 ? 'var(--red)' : (dias === 0 ? 'var(--yellow)' : 'var(--teal)'),
titulo: dias < 0 ? tr('motor_alertas_automaticas__secado_atrasado') : (dias === 0 ? tr('motor_alertas_automaticas__secar_hoy') : tr('motor_alertas_automaticas__secado_proximo')),
detalle: `${r.vaca || 'Vaca'} — programado ${r.secado}`,
dias, categoria: dias < 0 ? 'vencido' : (dias === 0 ? 'hoy' : 'proximo'),
});
});
estado.reproduccion.forEach(r => {
if (!r.finPeriodoSeco) return;
const dias = diasHasta(r.finPeriodoSeco);
if (dias > 5 || dias < -30) return;
notas.push({
icono:'fa-cow', color: dias < 0 ? 'var(--red)' : (dias === 0 ? 'var(--yellow)' : 'var(--teal)'),
titulo: dias < 0 ? tr('motor_alertas_automaticas__periodo_seco_vencido_atenta_al') : (dias === 0 ? tr('motor_alertas_automaticas__termina_el_periodo_seco_hoy') : tr('motor_alertas_automaticas__periodo_seco_por_terminar')),
detalle: `${r.vaca || 'Vaca'} — prepárate para el parto (${r.finPeriodoSeco})`,
dias, categoria: dias < 0 ? 'vencido' : (dias === 0 ? 'hoy' : 'proximo'),
});
});
}
const masRecienteSinDiag = {};
estado.reproduccion.forEach((r, i) => {
if (!r.vaca || !r.fecha || r.diagnostico !== 'sin_diagnostico') return;
const actual = masRecienteSinDiag[r.vaca];
if (actual === undefined || new Date(r.fecha) > new Date(estado.reproduccion[actual].fecha)) {
masRecienteSinDiag[r.vaca] = i;
}
});
Object.values(masRecienteSinDiag).forEach(i => {
const r = estado.reproduccion[i];
if (!r.fechaProximoCelo || r.celoDescartado) return;
const dias = diasHasta(r.fechaProximoCelo);
if (dias >= 0 && dias <= 5){
notas.push({
icono:'fa-heart-pulse', color:'var(--pink)',
titulo: dias === 0 ? tr('motor_alertas_automaticas__vigilar_celo_hoy') : tr('motor_alertas_automaticas__vigilar_posible_celo_proximo'),
detalle: `${r.vaca || 'Vaca'} — podría volver a estar en celo alrededor del ${r.fechaProximoCelo}`,
dias, categoria: dias === 0 ? 'hoy' : 'proximo',
});
} else if (dias < 0 && dias >= -5){
notas.push({
icono:'fa-circle-question', color:'var(--purple)',
titulo:tr('motor_alertas_automaticas__no_volvio_a_estar_en'),
detalle: `${r.vaca || 'Vaca'} — ya pasó la fecha esperada, es probable que esté cargada`,
dias: -1, categoria:'hoy', accionMarcarCargada: i,
});
}
});
if (estado.tipoGanado === 'leche'){
estado.becerros.forEach(b => {
if (b.litrosCalostro > 0) return; 
const dias = diasHasta(b.fecha);
if (dias < -1) return; 
notas.push({
icono:'fa-triangle-exclamation', color:'var(--red)',
titulo:tr('motor_alertas_automaticas__calostro_pendiente_de_registrar'),
detalle: `${b.animal || 'Becerro'} — nacido ${b.fecha}, registra si ya tomó calostro (ventana crítica: primeras 6 horas)`,
dias: -1, categoria:'hoy',
});
});
const consumoDiario = consumoDiarioPromedio();
if (consumoDiario > 0){
estado.inventarioAlimento.forEach(i => {
const diasRestantes = Math.floor(i.kg / consumoDiario);
if (diasRestantes <= 7){
notas.push({
icono:'fa-boxes-stacked', color: diasRestantes <= 2 ? 'var(--red)' : 'var(--yellow)',
titulo:tr('motor_alertas_automaticas__inventario_de_alimento_bajo'),
detalle: `${i.producto} — quedan ${i.kg} kg, alcanza para ${diasRestantes} día(s) al ritmo actual`,
dias: diasRestantes, categoria: diasRestantes <= 0 ? 'vencido' : (diasRestantes === 0 ? 'hoy' : 'proximo'),
});
}
});
}
}
const mesActual = new Date().getMonth() + 1;
estado.planSanitario.filter(pl => pl.mes === mesActual).forEach(pl => {
notas.push({
icono:'fa-calendar-check', color:'var(--purple)',
titulo:tr('motor_alertas_automaticas__campana_sanitaria_de_este_mes'),
detalle: `${pl.nombre}${pl.notas ? ' — ' + pl.notas : ''}`,
dias: 0, categoria:'hoy',
});
});
const p = estado.productor;
if (p.vencimientoFierro) {
const dias = diasHasta(p.vencimientoFierro);
if (dias <= 60) {
notas.push({
icono:'fa-file-signature', color: dias < 0 ? 'var(--red)' : 'var(--blue)',
titulo: dias < 0 ? tr('motor_alertas_automaticas__tramite_vencido') : tr('motor_alertas_automaticas__tramite_proximo'),
detalle: `Vencimiento credencial de fierro de herrar (${p.vencimientoFierro})`,
dias, categoria: dias < 0 ? 'vencido' : 'tramite',
});
}
}
const hoyMs = Date.now();
estado.animales.filter(a => a.estatus !== 'vendido' && a.estatus !== 'finado').forEach(a => {
const clave = a.arete || a.nombre;
if (!clave) return;
const fechas = [
...estado.salud.filter(r => r.animal === clave).map(r => r.fecha),
...estado.pesajes.filter(r => r.animal === clave).map(r => r.fecha),
...estado.produccionLeche.filter(r => r.animal === clave).map(r => r.fecha),
...estado.reproduccion.filter(r => r.vaca === clave).map(r => r.fecha),
].filter(Boolean).map(f => new Date(f).getTime()).filter(t => !isNaN(t));
const masReciente = fechas.length ? Math.max(...fechas) : null;
const diasSinMovimiento = masReciente ? Math.floor((hoyMs - masReciente) / 86400000) : null;
if (diasSinMovimiento !== null && diasSinMovimiento >= 90){
notas.push({
icono:'fa-magnifying-glass', color:'var(--slate)',
titulo:tr('motor_alertas_automaticas__sin_revision_reciente'),
detalle: `${a.nombre || clave} — sin ningún registro en ${diasSinMovimiento} días`,
dias: 9999, categoria:'proximo',
});
}
});
notas.sort((a, b) => a.dias - b.dias);
return notas;
}
function actualizarBadgeNotificaciones(){
const notas = calcularNotificaciones();
const badge = document.getElementById('badge-notificaciones');
if (!badge) return;
badge.classList.toggle('hidden', notas.length === 0);
badge.textContent = notas.length;
}
function renderAnimalesEnfermos(){
const cont = document.getElementById('lista-animales-enfermos');
if (!cont) return;
const enfermos = estado.salud
.map((r, i) => ({ ...r, i }))
.filter(r => (r.tipo === 'enfermedad' || r.tipo === 'muerte_subita' || r.tipo === 'sospecha_exotica') && !r.recuperado);
if (enfermos.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-clipboard-check"></i><p>${tr('motor_alertas_automaticas__no_hay_animales_enfermos_reportado')}</p></div>`;
return;
}
const ETIQUETAS_TIPO = { enfermedad: tr('csv_extra4__enfermo'), muerte_subita: tr('motor_alertas_automaticas__urgente_muerte_subita'), sospecha_exotica: tr('motor_alertas_automaticas__urgente_sospecha_exotica') };
cont.innerHTML = enfermos.map(r => { const urgente = r.tipo !== 'enfermedad'; return `
<div class="item-registro" style="border-left:6px solid var(--red);">
<div class="flex items-center justify-between gap-3">
<div class="flex items-center gap-3">
<span class="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style="background:var(--red); color:#fff;"><i class="fa-solid fa-triangle-exclamation"></i></span>
<div>
<p class="font-bold">${r.animal || 'Animal'} ${urgente ? `<span class="text-xs px-2 py-0.5 rounded-full ml-1" style="background:var(--red); color:#fff;">${ETIQUETAS_TIPO[r.tipo]}</span>` : ''}</p>
<p class="text-sm" style="color:var(--sage);">${r.producto || r.notas || 'Enfermo'} · ${r.fecha || 'sin fecha'}</p>
</div>
</div>
<button onclick="marcarRecuperado(${r.i})" class="text-xs font-bold px-3 py-2 rounded-full transition-transform active:scale-95 hover:-translate-y-0.5" style="background:var(--green); color:#fff;">
<i class="fa-solid fa-check"></i> ${tr('motor_alertas_automaticas__recuperado')}
</button>
</div>
</div>`; }).join('');
}
function marcarRecuperado(i){
if (!estado.salud[i]) return;
estado.salud[i].recuperado = true;
renderAnimalesEnfermos();
actualizarBadgeNotificaciones();
mostrarToast(`${estado.salud[i].animal || tr('csv_extra__animal')} marcado como recuperado`);
}
function renderNotificaciones(){
const cont = document.getElementById('lista-notificaciones');
const notas = calcularNotificaciones();
if (notas.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-bell-slash"></i><p>${tr('motor_alertas_automaticas__no_tienes_notificaciones_por_ahora')}</p></div>`;
return;
}
const ETIQUETAS_CATEGORIA = { vencido: tr('csv_extra4__vencidos'), hoy: tr('csv_extra4__hoy'), proximo: tr('motor_alertas_automaticas__proximos'), tramite: tr('motor_alertas_automaticas__proximos_tramites') };
let html = '';
let categoriaAnterior = null;
notas.forEach(n => {
if (n.categoria !== categoriaAnterior) {
html += `<p class="text-xs font-bold uppercase tracking-wide pt-2" style="color:var(--sage);">${ETIQUETAS_CATEGORIA[n.categoria] || ''}</p>`;
categoriaAnterior = n.categoria;
}
html += `
<div class="item-registro" style="border-left:6px solid ${n.color};">
<div class="flex items-center gap-3">
<span class="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style="background:${n.color}; color:#fff;"><i class="fa-solid ${n.icono}"></i></span>
<div>
<p class="font-bold">${n.titulo}</p>
<p class="text-sm" style="color:var(--sage);">${n.detalle}</p>
</div>
</div>
${n.accionMarcarCargada !== undefined ? `
<div class="flex gap-2 mt-3">
<button onclick="marcarAnimalCargado(${n.accionMarcarCargada})" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--purple); color:#fff;"><i class="fa-solid fa-check"></i> Marcar como cargada</button>
<button onclick="descartarAlertaCelo(${n.accionMarcarCargada})" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--parchment); color:var(--pine); border:2px solid var(--line);">Aún no, seguir vigilando</button>
</div>` : ''}
${!estado.modoTrabajador && trabajadoresDelAmbito().length > 0 ? `
<div class="flex items-center gap-2 mt-3">
<select onchange="if(this.value){ enviarNotificacionATrabajador(this.value, ${JSON.stringify(n.titulo)}, ${JSON.stringify(n.detalle)}); this.value=''; }" class="text-xs flex-1">
<option value="">${tr('trabajadores__enviar_a')}</option>
${trabajadoresDelAmbito().map(t => `<option value="${t.id}">${t.nombre}</option>`).join('')}
</select>
</div>` : ''}
</div>`;
});
cont.innerHTML = html;
}
function enviarNotificacionATrabajador(trabajadorId, titulo, detalle){
const trabajador = estado.trabajadores.find(t => t.id === trabajadorId);
if (!trabajador) return;
estado.tareas.unshift({ id:'k' + Date.now(), texto: `${titulo} — ${detalle}`, asignadoA: trabajadorId, fecha: hoyISO(), hecha:false });
mostrarToast(`${tr('trabajadores__tarea_enviada_a')} ${trabajador.nombre}`);
}
function toggleFab(){
const menu = document.getElementById('fab-menu');
const sheet = document.getElementById('fab-sheet');
const abrir = menu.classList.contains('hidden');
if (abrir){
menu.innerHTML = Object.entries(MODULOS)
.map(([letra, m]) => `
<button onclick="toggleFab(); irModulo('${letra}');" class="w-full flex items-center gap-3 p-3 rounded-2xl text-left font-bold transition-transform active:scale-95 hover:-translate-y-0.5" style="background:var(--parchment);">
<span class="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${m.bg}" style="color:#fff;"><i class="fa-solid ${m.icono}"></i></span>
<span class="text-sm">${nombreModulo(letra)}</span>
</button>`).join('');
}
menu.classList.toggle('hidden', !abrir);
sheet.classList.toggle('hidden', !abrir);
}
function exportarModuloCSV(letra){
const mapa = {
B: { datos: estado.salud, encabezados: [tr('csv_extra__animal'),tr('gastos_rendimiento_animal__tipo'),tr('csv_extra2__producto'),tr('gastos_rendimiento_animal__fecha'),tr('gastos_rendimiento_animal__proxima'),tr('csv_extra__notas')], campos: ['animal','tipo','producto','fecha','proxima','notas'] },
C: { datos: estado.reproduccion, encabezados: [tr('csv_extra2__vaca'),tr('csv_extra3__servicio'),tr('gastos_rendimiento_animal__fecha'),tr('exportar_csv__toro_pajuela'),tr('exportar_csv__diagnostico'),tr('render_estatus_hato__parto_estimado')], campos: ['vaca','servicio','fecha','toro','diagnostico','parto'] },
D: { datos: estado.pesajes, encabezados: [tr('csv_extra__animal'),tr('gastos_rendimiento_animal__fecha'),tr('gastos_rendimiento_animal__peso_kg'),tr('csv_extra2__lote'),tr('exportar_csv__condicion_corporal')], campos: ['animal','fecha','peso','lote','condicionCorporal'] },
E: { datos: estado.potreros, encabezados: [tr('editar_datos_productor__nombre'),tr('exportar_csv__hectareas'),tr('exportar_csv__capacidad_animal')], campos: ['nombre','hectareas','capacidad'] },
F: { datos: estado.costos, encabezados: [tr('gastos_rendimiento_animal__tipo'),tr('calendario_visual__categoria'),tr('csv_extra2__monto'),tr('gastos_rendimiento_animal__fecha'),tr('exportar_csv__imputar_a'),tr('exportar_csv__descripcion')], campos: ['tipo','categoria','monto','fecha','imputar','descripcion'] },
G: { datos: estado.produccionLeche, encabezados: [tr('csv_extra__animal'),tr('gastos_rendimiento_animal__fecha'),tr('exportar_csv__ordeno'),tr('exportar_csv__litros_am'),tr('exportar_csv__litros_pm'),tr('exportar_csv__total_litros'),tr('exportar_csv__grasa'),tr('exportar_csv__proteina'),tr('exportar_csv__celulas_somaticas'),tr('csv_extra__notas')], campos: ['animal','fecha','ordenador','litrosAM','litrosPM','total','grasa','proteina','celulas','notas'] },
H: { datos: estado.tanqueLeche, encabezados: [tr('gastos_rendimiento_animal__fecha'),tr('exportar_csv__litros_acopiados'),tr('csv_extra2__temperatura'),tr('csv_extra2__recolectado'),tr('csv_extra2__comprador'),tr('exportar_csv__precio_litro'),tr('csv_extra2__bonos'),tr('csv_extra2__descuentos'),tr('csv_extra__notas')], campos: ['fecha','litrosAcopiados','temperatura','recolectado','comprador','precioLitro','bonos','descuentos','notas'] },
I: { datos: estado.alimentacionLeche, encabezados: [tr('csv_extra__animal'),tr('gastos_rendimiento_animal__fecha'),tr('csv_extra2__etapa'),tr('exportar_csv__racion'),tr('exportar_csv__kg_concentrado_dia'),tr('csv_extra__notas')], campos: ['animal','fecha','etapa','racion','kgConcentrado','notas'] },
J: { datos: estado.becerros, encabezados: [tr('csv_extra2__becerro'),tr('exportar_csv__fecha_nacimiento'),tr('exportar_csv__peso_al_nacer'),tr('exportar_csv__litros_calostro'),tr('exportar_csv__horas_calostro'),tr('csv_extra2__alojamiento'),tr('exportar_csv__alimentacion'),tr('exportar_csv__fecha_destete'),tr('exportar_csv__peso_destete'),tr('csv_extra__notas')], campos: ['animal','fecha','pesoNacer','litrosCalostro','horasCalostro','alojamiento','alimentacion','fechaDestete','pesoDestete','notas'] },
};
const cfg = mapa[letra];
if (!cfg || cfg.datos.length === 0){ mostrarToast(tr('exportacion_pie_pagina__no_hay_registros_para_exportar')); return; }
const filas = cfg.datos.map(r => cfg.campos.map(c => r[c]));
const csv = [cfg.encabezados, ...filas].map(f => f.map(v => `"${(v ?? '').toString().replace(/"/g,'""')}"`).join(',')).join('\n');
const blob = new Blob(['\ufeff' + csv], { type:'text/csv;charset=utf-8;' });
const url = URL.createObjectURL(blob);
const a = document.createElement('a');
a.href = url; a.download = `${MODULOS[letra].nombre.toLowerCase().replace(/[^a-z0-9]+/g,'-')}.csv`;
a.click();
URL.revokeObjectURL(url);
mostrarToast(tr('exportar_csv__registros_exportados'));
}
function exportarHatoCSV(){
if (estado.animales.length === 0){ mostrarToast(tr('exportar_csv__no_hay_animales_para_exportar')); return; }
const encabezados = [tr('gastos_rendimiento_animal__arete_siniiga'),tr('exportar_csv__arete_campana'),tr('editar_datos_productor__nombre'),tr('gastos_rendimiento_animal__raza'),tr('gastos_rendimiento_animal__sexo'),tr('exportar_csv__fecha_nacimiento'),tr('gastos_rendimiento_animal__estatus'),tr('csv_extra__potrero'),tr('gastos_rendimiento_animal__madre'),tr('gastos_rendimiento_animal__padre')];
const filas = estado.animales.map(a => [a.arete,a.chip,a.nombre,a.raza,a.sexo,a.fecha,a.estatus,a.potrero,a.madre,a.padre]);
const csv = [encabezados, ...filas].map(f => f.map(v => `"${(v||'').toString().replace(/"/g,'""')}"`).join(',')).join('\n');
const blob = new Blob(['\ufeff' + csv], { type:'text/csv;charset=utf-8;' });
const url = URL.createObjectURL(blob);
const a = document.createElement('a');
a.href = url; a.download = 'inventario-hato.csv';
a.click();
URL.revokeObjectURL(url);
mostrarToast(tr('exportar_csv__inventario_exportado'));
}
EXPORT_REGISTRY.hato = () => ({
titulo: tr('registro_exportaciones_csv__inventario_de_hato'),
encabezados: [tr('gastos_rendimiento_animal__arete_siniiga'),tr('exportar_csv__arete_campana'),tr('editar_datos_productor__nombre'),tr('gastos_rendimiento_animal__raza'),tr('gastos_rendimiento_animal__sexo'),tr('exportar_csv__fecha_nacimiento'),tr('gastos_rendimiento_animal__estatus'),tr('csv_extra__potrero'),tr('gastos_rendimiento_animal__madre'),tr('gastos_rendimiento_animal__padre')],
filas: estado.animales.map(a => [a.arete,a.chip,a.nombre,a.raza,a.sexo,a.fecha,a.estatus,a.potrero,a.madre,a.padre]),
});
EXPORT_REGISTRY.notificaciones = () => ({
titulo: tr('registro_exportaciones_csv__proximos_vencimientos'),
encabezados: [tr('calendario_visual__categoria'),tr('calendario_visual__titulo'),tr('csv_extra__detalle'),tr('calendario_visual__dias_restantes')],
filas: (() => {
const ETIQUETAS_CATEGORIA = { vencido: tr('csv_extra8__vencido'), hoy: tr('csv_extra4__hoy'), proximo: tr('calendario_visual__proximo'), tramite: tr('calendario_visual__tramite') };
return calcularNotificaciones().map(n => [ETIQUETAS_CATEGORIA[n.categoria] || n.categoria, n.titulo, n.detalle, n.dias]);
})(),
});
EXPORT_REGISTRY.reporteSanitarioAnual = () => {
const anioActual = new Date().getFullYear();
return {
titulo: `Reporte sanitario ${anioActual}`,
encabezados: [tr('csv_extra__animal'),tr('gastos_rendimiento_animal__tipo'),tr('gastos_rendimiento_animal__producto_diagnostico'),tr('gastos_rendimiento_animal__fecha'),tr('gastos_rendimiento_animal__proxima'),tr('csv_extra__notas')],
filas: estado.salud.filter(r => r.fecha && new Date(r.fecha).getFullYear() === anioActual)
.map(r => [r.animal, r.tipo, r.producto, r.fecha, r.proxima, r.notas]),
};
};
EXPORT_REGISTRY.cefpp = () => {
const p = estado.productor;
return {
titulo: tr('registro_exportaciones_csv__informe_cefpp'),
encabezados: [tr('csv_extra__predio'),'UPP',tr('editar_datos_productor__municipio'),tr('csv_extra__animal'),tr('reportes_cefpp__tipo_de_caso'),tr('gastos_rendimiento_animal__fecha'),tr('csv_extra__detalle'),tr('reportes_cefpp__estatus_de_envio_a_cefpp')],
filas: estado.salud.filter(r => r.estadoCEFPP).map(r => [p.predio, p.upp, p.municipio, r.animal, r.tipo, r.fecha, r.producto || r.notas, r.estadoCEFPP]),
};
};
EXPORT_REGISTRY.modulo = () => {
const letra = letraActual;
const mapa = {
B: { datos: estado.salud, encabezados: [tr('csv_extra__animal'),tr('gastos_rendimiento_animal__tipo'),tr('csv_extra2__producto'),tr('gastos_rendimiento_animal__fecha'),tr('gastos_rendimiento_animal__proxima'),tr('csv_extra__notas')], campos: ['animal','tipo','producto','fecha','proxima','notas'] },
C: { datos: estado.reproduccion, encabezados: [tr('csv_extra2__vaca'),tr('csv_extra3__servicio'),tr('gastos_rendimiento_animal__fecha'),tr('exportar_csv__toro_pajuela'),tr('exportar_csv__diagnostico'),tr('render_estatus_hato__parto_estimado')], campos: ['vaca','servicio','fecha','toro','diagnostico','parto'] },
D: { datos: estado.pesajes, encabezados: [tr('csv_extra__animal'),tr('gastos_rendimiento_animal__fecha'),tr('gastos_rendimiento_animal__peso_kg'),tr('csv_extra2__lote'),tr('exportar_csv__condicion_corporal')], campos: ['animal','fecha','peso','lote','condicionCorporal'] },
E: { datos: estado.potreros, encabezados: [tr('editar_datos_productor__nombre'),tr('exportar_csv__hectareas'),tr('exportar_csv__capacidad_animal')], campos: ['nombre','hectareas','capacidad'] },
F: { datos: estado.costos, encabezados: [tr('gastos_rendimiento_animal__tipo'),tr('calendario_visual__categoria'),tr('csv_extra2__monto'),tr('gastos_rendimiento_animal__fecha'),tr('exportar_csv__imputar_a'),tr('exportar_csv__descripcion')], campos: ['tipo','categoria','monto','fecha','imputar','descripcion'] },
G: { datos: estado.produccionLeche, encabezados: [tr('csv_extra__animal'),tr('gastos_rendimiento_animal__fecha'),tr('exportar_csv__ordeno'),tr('exportar_csv__litros_am'),tr('exportar_csv__litros_pm'),tr('exportar_csv__total_litros'),tr('exportar_csv__grasa'),tr('exportar_csv__proteina'),tr('exportar_csv__celulas_somaticas'),tr('csv_extra__notas')], campos: ['animal','fecha','ordenador','litrosAM','litrosPM','total','grasa','proteina','celulas','notas'] },
H: { datos: estado.tanqueLeche, encabezados: [tr('gastos_rendimiento_animal__fecha'),tr('exportar_csv__litros_acopiados'),tr('csv_extra2__temperatura'),tr('csv_extra2__recolectado'),tr('csv_extra2__comprador'),tr('exportar_csv__precio_litro'),tr('csv_extra2__bonos'),tr('csv_extra2__descuentos'),tr('csv_extra__notas')], campos: ['fecha','litrosAcopiados','temperatura','recolectado','comprador','precioLitro','bonos','descuentos','notas'] },
I: { datos: estado.alimentacionLeche, encabezados: [tr('csv_extra__animal'),tr('gastos_rendimiento_animal__fecha'),tr('csv_extra2__etapa'),tr('exportar_csv__racion'),tr('exportar_csv__kg_concentrado_dia'),tr('csv_extra__notas')], campos: ['animal','fecha','etapa','racion','kgConcentrado','notas'] },
J: { datos: estado.becerros, encabezados: [tr('csv_extra2__becerro'),tr('exportar_csv__fecha_nacimiento'),tr('exportar_csv__peso_al_nacer'),tr('exportar_csv__litros_calostro'),tr('exportar_csv__horas_calostro'),tr('csv_extra2__alojamiento'),tr('exportar_csv__alimentacion'),tr('exportar_csv__fecha_destete'),tr('exportar_csv__peso_destete'),tr('csv_extra__notas')], campos: ['animal','fecha','pesoNacer','litrosCalostro','horasCalostro','alojamiento','alimentacion','fechaDestete','pesoDestete','notas'] },
};
const cfg = mapa[letra];
if (!cfg) return { titulo: nombreModulo(letra), encabezados: [], filas: [] };
return {
titulo: nombreModulo(letra),
encabezados: cfg.encabezados,
filas: cfg.datos.map(r => cfg.campos.map(c => r[c])),
};
};
function actualizarBannerConexion(){
const banner = document.getElementById('banner-offline');
if (banner) banner.classList.toggle('hidden', navigator.onLine);
}
window.addEventListener('online', actualizarBannerConexion);
window.addEventListener('offline', actualizarBannerConexion);
// Se aplica aquí (al final del script, cuando ya existen todas las constantes
// como MODULOS, BANNERS_TILE, charts, etc.) para reflejar el idioma guardado
// desde la primera pantalla, sin el error de "acceso antes de inicialización".
try { aplicarIdioma(); } catch(e){ console.warn('No se pudo aplicar el idioma inicial', e); }
try { aplicarLogoPersonalizado(); } catch(e){ console.warn('No se pudo aplicar el logo personalizado', e); }
// ================= CAPTURA DE DOCUMENTOS: DEBE SER SÍNCRONA =================
// IMPORTANTE: input.click() debe ocurrir dentro del mismo gesto del usuario.
// Si se deja como stub lazy que primero espera a cargar el módulo OCR, Android/iOS
// puede considerar que se perdió la activación del botón y NO abrir la cámara.
function abrirCapturaDocumento(inputId){
  const input = document.getElementById(inputId);
  if (!input) { mostrarToast('No se encontró el campo de captura. Abre nuevamente esta pantalla.'); return; }
  try { input.value = ''; } catch(e){}
  input.dataset.iranchEsperandoCaptura = '1';
  try { input.click(); }
  catch(e){ mostrarToast('No se pudo abrir la cámara. Usa "Elegir foto" para seleccionar una imagen del dispositivo.'); }
}
function abrirGaleriaDocumento(inputId){
  const input=document.getElementById(inputId);
  if(!input){ mostrarToast('No se encontró el campo de fotografía.'); return; }
  const teniaCapture=input.getAttribute('capture');
  try {
    input.value=''; input.removeAttribute('capture'); input.dataset.iranchGaleria='1'; input.click();
    if(teniaCapture!=null) setTimeout(()=>{ try{ input.setAttribute('capture',teniaCapture); }catch(e){} },0);
  } catch(e){ if(teniaCapture!=null) input.setAttribute('capture',teniaCapture); mostrarToast('No se pudo abrir la galería de fotos.'); }
}
// ================= CARGADOR BAJO DEMANDA: OCR =================
const IRANCH_OCR_FUNCIONES = ['evaluarNitidezImagenOCR', 'cargarTesseractSiNecesario', 'precargarTesseractEnSegundoPlano', 'encolarLecturaOCR', 'extraerTextoDeImagen', 'mostrarModalAjustarEsquinas', 'actualizarGeometriaAjusteEsquinas', 'dibujarEsquinasAjuste', 'inicializarArrastreEsquinas', 'cancelarAjusteEsquinas', 'confirmarAjusteEsquinas', 'ordenarEsquinasCuadrilatero', 'distanciaPuntos', 'resolverSistemaLineal8x8', 'calcularHomografia', 'aplicarHomografia', 'muestrearPixelBilineal', 'recortarYEnderezarImagen', 'reemplazarArchivoDeInput', 'previsualizarEscaneo', 'ajustarYLeerEscaneo', 'guardarBorradorEscaneoDoc', 'limpiarBorradorEscaneoDoc', 'restaurarBorradorEscaneoDoc', 'cambiarPasoEscaneo', 'abrirEscaneoDocumentos', 'extraerCURP', 'extraerUPPPorPatron', 'normalizarParaBuscarEtiqueta', 'extraerTrasEtiqueta', 'extraerDatosCredencial', 'iniciarRecorteDesdeEscaneo', 'extraerDatosConstanciaUPP', 'convertirAreteMX', 'extraerIdentificadoresSINIIGADirigidos', 'parsearFilasSINIIGA', 'extraerTablaSINIIGA', 'agregarFilaSINIIGAManual', 'actualizarFilaSINIIGA', 'eliminarFilaSINIIGA', 'renderFilasSINIIGA', 'fechaAISOSiPosible', 'actualizarResumenImportarEscaneo', 'confirmarImportacionEscaneo', 'abrirEdicionProductor', 'validarLongitudCampo', 'guardarEdicionProductor', 'quitarPrefijoLetra', 'renderTogglesModulos', 'renderTogglesPermisosTrabajador', 'toggleModuloTrabajador', 'renderListaIconosBotones', 'actualizarIconoBoton', 'renderListaOrdenMas', 'moverOrdenMas', 'renderListaOrdenGraficas', 'moverOrdenGraficas', 'toggleGraficaVisible', 'agregarPlanSanitario', 'eliminarPlanSanitario', 'renderListaPlanSanitario', 'exportarReporteSanitarioAnual', 'generarCodigoTrabajador', 'trabajadoresDelAmbito', 'agregarTrabajador', 'eliminarTrabajador', 'renderListaTrabajadores', 'agregarTarea', 'eliminarTarea', 'nombreTrabajador', 'renderListaTareasAdmin', 'renderTogglesCampos', 'toggleModulo', 'toggleCampo', 'renderCamposPersonalizadosAdmin', 'agregarCampoPersonalizado', 'eliminarCampoPersonalizado', 'renderCamposPersonalizadosFormulario', 'leerCamposPersonalizadosFormulario', 'renderTogglesVentanasExtra', 'agregarVentana', 'toggleVentanaExtra', 'eliminarVentana', 'abrirVentanaExtra', 'renderNotasVentana', 'agregarNotaVentana', 'eliminarNotaVentana', 'agregarBanner', 'toggleBanner', 'eliminarBanner', 'renderListaBanners', 'bannerVigente', 'renderBannerHome', 'cerrarBanner', 'agregarBoletin', 'renderBoletinesAdmin', 'eliminarBoletin', 'mostrarToast', 'ejecutarDeshacer', 'mostrarBannerNotificacion'];
function cargarOCRIRanch(){ return typeof window.cargarModuloIRanch === 'function' ? window.cargarModuloIRanch('ocr') : Promise.reject(new Error('Cargador de módulos no disponible')); }
IRANCH_OCR_FUNCIONES.forEach(nombre => {
  if (typeof window[nombre] === 'function') return;
  window[nombre] = function(){ const args=arguments; return cargarOCRIRanch().then(() => window[nombre].apply(window,args)); };
});
window.cargarOCRIRanch=cargarOCRIRanch;
