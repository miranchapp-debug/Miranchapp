(function(){
// MiRanch — módulo extraído automáticamente. Se ejecuta como script clásico para conservar compatibilidad con funciones globales.
// ================= DICTAMEN OFICIAL SENASICA — VISTA PREVIA / IMPRESIÓN =================
// Reproduce el FORMATO-CC-TB-BR-2024 (portada + hoja(s) complementaria(s)) a partir
// de una prueba de campo ya guardada, y lo abre en una ventana nueva lista para
// imprimir o "Guardar como PDF" desde el diálogo de impresión del navegador.
// La portada siempre tiene 10 renglones (como el papel oficial); si hay más
// animales, se reparten en hojas complementarias de 30 renglones cada una.
// Ambos números son ajustables aquí si el formato real que usa el comité varía.
const DICTAMEN_FILAS_PORTADA = 10;
const DICTAMEN_FILAS_COMPLEMENTARIA = 30;
function fechaDMA(iso){
if (!iso) return '';
const [y,m,d] = iso.split('-');
if (!y || !m || !d) return iso;
return `${d}/${m}/${y}`;
}
function estilosDictamenSenasica(){
// Variables CSS de control: ajusta aquí los márgenes y espaciados para alinear
// la impresión con el papel oficial si tu impresora/copia varía un poco.
return `<style>
:root{
--dictamen-margen-superior: 8mm;
--dictamen-margen-inferior: 8mm;
--dictamen-margen-izquierdo: 8mm;
--dictamen-margen-derecho: 8mm;
--dictamen-espaciado-seccion: 2.2mm;
--dictamen-fuente-base: 7.3pt;
--dictamen-fuente-titulo: 11pt;
--dictamen-color-borde: #000;
--dictamen-alto-fila-tabla: 5mm;
}
*{ box-sizing:border-box; }
body{ margin:0; font-family: Arial, Helvetica, sans-serif; font-size:var(--dictamen-fuente-base); color:#000; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
.hoja-senasica{
width:215.9mm; min-height:279.4mm;
padding: var(--dictamen-margen-superior) var(--dictamen-margen-derecho) var(--dictamen-margen-inferior) var(--dictamen-margen-izquierdo);
page-break-after: always;
position:relative;
}
.hoja-senasica:last-child{ page-break-after:auto; }
@media print{ @page{ size: letter portrait; margin:0; } }
.encabezado-senasica{ display:flex; align-items:center; gap:3mm; border-bottom:2px solid var(--dictamen-color-borde); padding-bottom:2mm; margin-bottom:var(--dictamen-espaciado-seccion); }
.encabezado-senasica .titulo-central{ text-align:center; flex:1; }
.encabezado-senasica .titulo-central h1{ font-size:9pt; margin:0; letter-spacing:.2px; }
.encabezado-senasica .titulo-central h2{ font-size:8pt; margin:1mm 0 0; font-weight:normal; }
.encabezado-senasica .titulo-central .fuerte{ font-weight:bold; }
.encabezado-senasica .logo-senasica{ font-weight:bold; font-size:var(--dictamen-fuente-titulo); border:2px solid var(--dictamen-color-borde); padding:2mm 3mm; text-align:center; flex-shrink:0; }
.caja-folios{ border:1.3px solid var(--dictamen-color-borde); font-size:6.6pt; width:58mm; float:right; margin-bottom:2mm; }
.caja-folios div{ border-bottom:1px solid var(--dictamen-color-borde); padding:.8mm 2mm; display:flex; justify-content:space-between; gap:3mm; }
.caja-folios div:last-child{ border-bottom:none; }
.seccion-dictamen{ border:1.3px solid var(--dictamen-color-borde); margin-bottom:var(--dictamen-espaciado-seccion); clear:both; }
.seccion-dictamen > .titulo-seccion{ font-weight:bold; font-size:7.5pt; background:#e5e5e5; padding:.8mm 2mm; border-bottom:1px solid var(--dictamen-color-borde); }
.fila-campos{ display:flex; }
.fila-campos + .fila-campos{ border-top:1px solid var(--dictamen-color-borde); }
.campo-dictamen{ flex:1; border-right:1px solid var(--dictamen-color-borde); padding:.8mm 2mm; min-height:8mm; }
.campo-dictamen:last-child{ border-right:none; }
.campo-dictamen .etiqueta{ font-size:5.8pt; text-transform:uppercase; color:#333; display:block; }
.campo-dictamen .valor{ font-size:8pt; font-weight:bold; margin-top:.6mm; min-height:3mm; }
.tabla-resumen{ width:100%; border-collapse:collapse; font-size:7pt; }
.tabla-resumen td, .tabla-resumen th{ border:1px solid var(--dictamen-color-borde); padding:.8mm 1.5mm; text-align:center; }
.caja-texto{ padding:1mm 2mm; font-size:6.8pt; line-height:1.7; }
.tabla-resultados{ width:100%; border-collapse:collapse; font-size:6.6pt; margin-top:1mm; }
.tabla-resultados th, .tabla-resultados td{ border:1px solid var(--dictamen-color-borde); padding:.6mm 1mm; text-align:center; height:var(--dictamen-alto-fila-tabla); }
.tabla-resultados th{ background:#e5e5e5; font-size:6.2pt; }
.tabla-resultados .col-i{ width:5mm; }
.tabla-resultados .col-arete{ width:28mm; font-weight:bold; text-align:left; padding-left:1.5mm; }
.tabla-resultados .col-resultado{ font-weight:bold; }
.pie-firma{ display:flex; justify-content:space-around; margin-top:6mm; padding-top:2mm; font-size:6.8pt; }
.pie-firma .bloque-firma{ flex:1; text-align:center; max-width:75mm; }
.pie-firma .linea-firma{ border-top:1px solid #000; margin:9mm 4mm 1mm; }
.nota-pie{ font-size:5.8pt; color:#333; margin-top:2.5mm; line-height:1.5; }
.controles-vista-previa{ position:sticky; top:0; background:#3C6B4F; color:#fff; padding:3mm; display:flex; gap:3mm; justify-content:center; z-index:99; }
.controles-vista-previa button{ font-family:inherit; font-size:9pt; font-weight:bold; padding:2mm 5mm; border-radius:999px; border:none; cursor:pointer; }
@media print{ .controles-vista-previa{ display:none; } }
</style>`;
}
function filaResultadoDictamenHTML(a, indice){
if (!a) return `<tr><td class="col-i">&nbsp;</td><td class="col-arete"></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>`;
const ETIQUETAS_ESPECIE = { Bovino:'B', Caprino:'C', Ovino:'O', Porcino:'P' };
return `<tr>
<td class="col-i">${indice}</td>
<td class="col-arete">${a.arete || ''}</td>
<td>${ETIQUETAS_ESPECIE[a.especie] || (a.especie || '').slice(0,1)}</td>
<td>${a.edad || ''}</td>
<td>${a.raza || ''}</td>
<td>${a.sexo === 'M' ? 'M' : 'H'}</td>
<td>${a.fierro || ''}</td>
<td></td>
<td></td>
<td class="col-resultado">${a.resultado || ''}</td>
<td></td>
<td></td>
</tr>`;
}
function tablaResultadosDictamenHTML(filas, totalRenglones, indiceInicial){
let cuerpo = '';
for (let i = 0; i < totalRenglones; i++){
const animal = filas[i];
cuerpo += filaResultadoDictamenHTML(animal, animal ? indiceInicial + i : '');
}
return `<table class="tabla-resultados">
<thead>
<tr>
<th rowspan="2" class="col-i">I</th>
<th rowspan="2" class="col-arete">IDENTIFICACIÓN OFICIAL / SINIIGA</th>
<th rowspan="2">ESPECIE</th>
<th rowspan="2">EDAD<br>(meses)</th>
<th rowspan="2">RAZA</th>
<th rowspan="2">SEXO</th>
<th rowspan="2">FIERRO</th>
<th colspan="2">PRUEBA DE TUBERCULINA</th>
<th rowspan="2">RESULT.<br>N S R E</th>
<th colspan="2">BRUCELOSIS</th>
</tr>
<tr>
<th style="font-size:5.6pt;">Palpación<br>antes</th>
<th style="font-size:5.6pt;">72±6h</th>
<th style="font-size:5.6pt;">TUBO</th>
<th style="font-size:5.6pt;">TARJETA<br>NPE</th>
</tr>
</thead>
<tbody>${cuerpo}</tbody>
</table>`;
}
function pieFirmaDictamenHTML(p){
return `
<div class="pie-firma">
<div class="bloque-firma">
<div class="linea-firma"></div>
MVZ RESPONSABLE AUTORIZADO<br>
<b>${p.veterinarioNombre || ''}</b>${p.mvzClave ? '<br>Cédula/Clave: ' + p.mvzClave : ''}
</div>
<div class="bloque-firma">
<div class="linea-firma"></div>
NOMBRE Y FIRMA DEL MVZ OFICIAL
</div>
</div>
<p class="nota-pie"><b>NOTA IMPORTANTE:</b> Este documento original no tiene validez para la movilización y deberá ser conservado en archivo por parte del MVZ responsable autorizado por 24 meses, a partir de la fecha de lectura de la prueba. — Generado desde MiRanch el ${new Date().toLocaleDateString('es-MX')}.</p>`;
}
function paginaPortadaDictamenHTML(p, filasPortada, resumen, esUltimaPagina){
const esBrucelosis = p.tipoPrueba === 'Brucelosis';
return `
<div class="hoja-senasica">
<div class="encabezado-senasica">
<div class="logo-senasica">🇲🇽<br>SADER</div>
<div class="titulo-central">
<h1>SERVICIO NACIONAL DE SANIDAD, INOCUIDAD Y CALIDAD AGROALIMENTARIA</h1>
<h2>DIRECCIÓN GENERAL DE SALUD ANIMAL</h2>
<h2 class="fuerte">CAMPAÑA NACIONAL CONTRA LA TUBERCULOSIS BOVINA Y BRUCELOSIS EN LOS ANIMALES</h2>
<h2>CONTROL DE CAMPO DE LA PRUEBA DE TUBERCULINA Y DEL MUESTREO DE BRUCELOSIS</h2>
</div>
<div class="logo-senasica">SENASICA</div>
</div>
<div class="caja-folios">
<div><span>${p.tipoAplicacion === 'cervical' ? '☑' : '☐'} CERVICAL SIMPLE</span><span>${p.tipoAplicacion !== 'cervical' ? '☑' : '☐'} PLIEGUE CAUDAL</span></div>
<div><span>DICTAMEN DE PRUEBA DE TUBERCULINA</span><b>${p.dictamenTB || ''}</b></div>
<div><span>FOLIO TB</span><b>${p.folioTB || ''}</b></div>
<div><span>CC No.</span><b>${p.ccNo || ''}</b></div>
</div>
<div style="clear:both;"></div>
<div class="seccion-dictamen">
<div class="titulo-seccion">I. PROPIETARIO</div>
<div class="fila-campos">
<div class="campo-dictamen"><span class="etiqueta">Apellido paterno</span><span class="valor">${p.apellidoPaterno || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Apellido materno</span><span class="valor">${p.apellidoMaterno || ''}</span></div>
<div class="campo-dictamen" style="flex:2;"><span class="etiqueta">Nombre(s)</span><span class="valor">${p.nombres || p.productorNombre || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Teléfono</span><span class="valor">${p.telefonoProductor || ''}</span></div>
</div>
<div class="fila-campos">
<div class="campo-dictamen" style="flex:2;"><span class="etiqueta">Domicilio</span><span class="valor">${p.domicilio || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Localidad / Población</span><span class="valor">${p.localidad || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Código postal</span><span class="valor">${p.cp || ''}</span></div>
</div>
<div class="fila-campos">
<div class="campo-dictamen"><span class="etiqueta">Estado</span><span class="valor">${p.estadoMx || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Municipio</span><span class="valor">${p.municipio || ''}</span></div>
</div>
</div>
<div class="seccion-dictamen">
<div class="titulo-seccion">II. UNIDAD DE PRODUCCIÓN</div>
<div class="fila-campos">
<div class="campo-dictamen" style="flex:2;"><span class="etiqueta">Nombre de la unidad de producción / predio</span><span class="valor">${p.predio || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Latitud</span><span class="valor">${p.latitud || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Longitud</span><span class="valor">${p.longitud || ''}</span></div>
</div>
<div class="fila-campos">
<div class="campo-dictamen" style="flex:2;"><span class="etiqueta">Domicilio</span><span class="valor">${p.domicilio || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Código postal</span><span class="valor">${p.cp || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Clave UPP / PSG</span><span class="valor">${p.claveUpp || p.upp || ''}</span></div>
</div>
</div>
<div class="seccion-dictamen">
<div class="titulo-seccion">III. DE LA PRUEBA — ${p.municipio || ''}${p.municipio && p.estadoMx ? ', ' : ''}${p.estadoMx || ''}</div>
<div class="fila-campos">
<div class="campo-dictamen"><span class="etiqueta">Motivo de prueba</span><span class="valor">${p.motivo || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Fin zootécnico</span><span class="valor">${p.finalidad || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Tipo de identificación</span><span class="valor">${p.tipoIdentificacion || ''}</span></div>
</div>
</div>
<div style="display:flex; gap:2mm; margin-bottom:var(--dictamen-espaciado-seccion); clear:both;">
<div class="seccion-dictamen" style="flex:1; margin-bottom:0;">
<div class="titulo-seccion">RESUMEN</div>
<table class="tabla-resumen">
<tr><td></td><td>TB</td><td>BR</td></tr>
<tr><td>Negativos</td><td>${!esBrucelosis ? resumen.negativos : ''}</td><td>${esBrucelosis ? resumen.negativos : ''}</td></tr>
<tr><td>Reactores</td><td>${!esBrucelosis ? resumen.reactores : ''}</td><td>${esBrucelosis ? resumen.reactores : ''}</td></tr>
<tr><td>Total probados</td><td colspan="2">${resumen.totalProbados}</td></tr>
<tr><td>Total del hato</td><td colspan="2"></td></tr>
</table>
</div>
<div class="seccion-dictamen" style="flex:1; margin-bottom:0;">
<div class="titulo-seccion">TUBERCULINA</div>
<div class="caja-texto">
Dosis: <b>${p.dosis || ''}</b><br>
Lote No.: <b>${p.lote || ''}</b><br>
Fecha caducidad: <b>${fechaDMA(p.fechaCaducidad)}</b><br>
Fecha inyección: <b>${fechaDMA(p.fechaInyeccion)}</b> ${p.horaInyeccion || ''} hrs<br>
Fecha lectura: <b>${fechaDMA(p.fechaLectura)}</b> ${p.horaLectura || ''} hrs
</div>
</div>
<div class="seccion-dictamen" style="flex:1; margin-bottom:0;">
<div class="titulo-seccion">BRUCELOSIS</div>
<div class="caja-texto">
Fecha de toma de muestra:<br><b>${fechaDMA(p.fechaMuestra) || '—'}</b><br><br>
Fecha de resultado de laboratorio:<br><b>____________</b>
</div>
</div>
</div>
<div class="seccion-dictamen">
<div class="titulo-seccion">IV. RESULTADOS</div>
${tablaResultadosDictamenHTML(filasPortada, DICTAMEN_FILAS_PORTADA, 1)}
</div>
${esUltimaPagina ? pieFirmaDictamenHTML(p) : ''}
</div>`;
}
function paginaComplementariaDictamenHTML(p, filasBloque, indiceInicial, esUltimaPagina){
return `
<div class="hoja-senasica">
<div class="encabezado-senasica" style="border-bottom:1px solid #000;">
<div class="titulo-central">
<h1 style="font-size:8.5pt;">SENASICA — HOJA COMPLEMENTARIA — CONTINUACIÓN DE RESULTADOS</h1>
<h2>${p.productorNombre || ''} · Folio TB ${p.folioTB || '—'} · CC No. ${p.ccNo || '—'}</h2>
</div>
</div>
<div class="seccion-dictamen">
<div class="titulo-seccion">IV. RESULTADOS (continuación)</div>
${tablaResultadosDictamenHTML(filasBloque, DICTAMEN_FILAS_COMPLEMENTARIA, indiceInicial)}
</div>
<p class="nota-pie">Al MVZ encargado de la prueba se le recuerda que al pasar estos datos al dictamen de prueba de tuberculina, los números de identificación de los animales deberán colocarlos en orden progresivo del número menor al mayor. Asimismo, la edad de cada uno se anotará en meses.</p>
${esUltimaPagina ? pieFirmaDictamenHTML(p) : ''}
</div>`;
}
function generarPaginasDictamenHTML(p){
const animales = p.animales || [];
const negativos = animales.filter(a => a.resultado === 'N').length;
const reactores = animales.filter(a => a.resultado === 'R').length;
const resumen = { totalProbados: animales.length, negativos, reactores };
const filasPortada = animales.slice(0, DICTAMEN_FILAS_PORTADA);
const resto = animales.slice(DICTAMEN_FILAS_PORTADA);
const paginas = [];
paginas.push(paginaPortadaDictamenHTML(p, filasPortada, resumen, resto.length === 0));
for (let i = 0; i < resto.length; i += DICTAMEN_FILAS_COMPLEMENTARIA){
const bloque = resto.slice(i, i + DICTAMEN_FILAS_COMPLEMENTARIA);
const esUltima = (i + DICTAMEN_FILAS_COMPLEMENTARIA) >= resto.length;
paginas.push(paginaComplementariaDictamenHTML(p, bloque, DICTAMEN_FILAS_PORTADA + i + 1, esUltima));
}
return paginas.join('');
}
function abrirVistaPreviaDictamen(id){
const p = estado.pruebasCampoVet.find(x => x.id === id);
if (!p) return;
const ventana = window.open('', '_blank');
if (!ventana){ mostrarToast('Tu navegador bloqueó la ventana emergente — permite pop-ups para imprimir el dictamen'); return; }
ventana.document.write(`<html><head><title>Dictamen SENASICA — ${(p.productorNombre || '').replace(/</g,'')}</title>${estilosDictamenSenasica()}</head><body>
<div class="controles-vista-previa">
<button onclick="window.print()"><i class="fa-solid fa-print"></i> Imprimir / Guardar como PDF</button>
<button onclick="window.close()" style="background:#8a3b3b;">Cerrar</button>
</div>
${generarPaginasDictamenHTML(p)}
</body></html>`);
ventana.document.close();
ventana.focus();
}
// ================= DICTAMEN OFICIAL DE TB Y DE BR (formatos separados, para el comité) =================
// A diferencia de la hoja de campo (que usa el veterinario mientras trabaja), estos
// son los formatos que recibe el comité: FORMATO-TB-DICT-2025 / FORMATO-BR-DICT-2025
// y sus hojas complementarias FORMATO-TB-HC-DICT-2025 / FORMATO-BR-HC-DICT-2025.
// Portada con 20 animales (2 columnas de 10), complementarias con 50 (2 columnas de
// 25). Solo se llenan los campos que cada formato realmente pide — sin folios de
// dictamen/consecutivos ni conteos de vientres/toros que no aparecen en el papel.
function estilosDictamenOficial(){
return `<style>
.tabla-resultados-doble{ display:flex; gap:2mm; margin-top:1mm; }
.tabla-resultados-mini{ flex:1; border-collapse:collapse; width:50%; font-size:6.1pt; }
.tabla-resultados-mini th, .tabla-resultados-mini td{ border:1px solid var(--dictamen-color-borde); padding:.5mm .8mm; text-align:center; height:4.6mm; }
.tabla-resultados-mini th{ background:#e5e5e5; font-size:5.6pt; }
.tabla-resultados-mini .col-no{ width:5mm; }
.tabla-resultados-mini .col-tally{ width:4mm; }
.tabla-resultados-mini .col-id{ width:21mm; font-weight:bold; text-align:left; padding-left:1mm; }
.hoja-oficial .caja-folios{ width:50mm; }
</style>`;
}
function celdaValorAnimalOficial(a, campo){
if (campo === 'identificacion') return a.arete || '';
if (campo === 'especie'){ const M = { Bovino:'B', Caprino:'C', Ovino:'O', Porcino:'P' }; return M[a.especie] || (a.especie || '').slice(0,1); }
if (campo === 'edad') return a.edad || '';
if (campo === 'raza') return a.raza || '';
if (campo === 'sexo') return a.sexo === 'M' ? 'M' : 'H';
if (campo === 'fierro') return a.fierro || '';
if (campo === 'resultado'){ if (!a.resultado) return ''; return a.resultado === 'R' ? 'P' : a.resultado; }
return '';
}
function miniTablaResultadosOficialHTML(filas, totalFilas, indiceInicial, tipo){
const encabezados = tipo === 'TB'
? [['No.','col-no'],['1','col-tally'],['IDENTIFICACIÓN OFICIAL/ SINIIGA','col-id'],['EDAD<br>(meses)',''],['RAZA',''],['SEXO',''],['FIERRO',''],['N/S/P/E','']]
: [['No.','col-no'],['1','col-tally'],['IDENTIFICACIÓN OFICIAL/ SINIIGA','col-id'],['ESPECIE',''],['EDAD<br>(meses)',''],['RAZA',''],['SEXO',''],['N/P/E','']];
const campos = tipo === 'TB' ? ['identificacion','edad','raza','sexo','fierro','resultado'] : ['identificacion','especie','edad','raza','sexo','resultado'];
let cuerpo = '';
for (let i = 0; i < totalFilas; i++){
const a = filas[i];
const num = a ? indiceInicial + i : '';
cuerpo += `<tr><td class="col-no">${num}</td><td class="col-tally"></td>` + campos.map(c => `<td class="${c === 'identificacion' ? 'col-id' : ''}">${a ? celdaValorAnimalOficial(a, c) : ''}</td>`).join('') + `</tr>`;
}
return `<table class="tabla-resultados-mini"><thead><tr>${encabezados.map(c => `<th class="${c[1]}">${c[0]}</th>`).join('')}</tr></thead><tbody>${cuerpo}</tbody></table>`;
}
function tablaResultadosDobleHTML(filasPagina, totalRenglones, indiceInicial, tipo){
const mitad = totalRenglones / 2;
const izq = filasPagina.slice(0, mitad);
const der = filasPagina.slice(mitad, totalRenglones);
return `<div class="tabla-resultados-doble">${miniTablaResultadosOficialHTML(izq, mitad, indiceInicial, tipo)}${miniTablaResultadosOficialHTML(der, mitad, indiceInicial + mitad, tipo)}</div>`;
}
function pieFirmaDictamenOficialHTML(p, esBR){
const nota = esBR
? 'LOS QUE SUSCRIBEN MÉDICOS VETERINARIOS ZOOTECNISTAS, CONSTATAN HABER REALIZADO LA(S) PRUEBA(S) PARA EL DIAGNÓSTICO DE BRUCELOSIS Y HABER OBTENIDO LOS RESULTADOS SEÑALADOS EN ESTE DOCUMENTO'
: 'LOS QUE SUSCRIBEN MÉDICOS VETERINARIOS ZOOTECNISTAS, CONSTATAN HABER REALIZADO LA(S) PRUEBA(S) PARA EL DIAGNÓSTICO DE TUBERCULOSIS Y HABER OBTENIDO LOS RESULTADOS SEÑALADOS EN ESTE DOCUMENTO';
return `
${esBR ? `<div class="pie-firma" style="margin-top:5mm;">
<div class="bloque-firma"><div class="linea-firma"></div>NOMBRE DEL JEFE DEL LABORATORIO</div>
<div class="bloque-firma"><div class="linea-firma"></div>FIRMA DEL JEFE DEL LABORATORIO</div>
</div>` : ''}
<div class="pie-firma">
<div class="bloque-firma"><div class="linea-firma"></div>NOMBRE DEL MVZ RESPONSABLE AUTORIZADO<br><b>${p.veterinarioNombre || ''}</b>${p.mvzClave ? '<br>Clave: ' + p.mvzClave : ''}</div>
<div class="bloque-firma"><div class="linea-firma"></div>NOMBRE DEL MVZ OFICIAL</div>
<div class="bloque-firma"><div class="linea-firma"></div>NOMBRE DEL PROPIETARIO</div>
</div>
<p class="nota-pie">${nota}<br>ESTE DOCUMENTO PERDERÁ VALIDEZ OFICIAL SI PRESENTA TACHADURAS O ENMENDADURAS.</p>`;
}
function paginaPortadaDictamenTBHTML(p, filasPortada, resumen, totalPaginas){
return `<div class="hoja-senasica hoja-oficial">
<div class="encabezado-senasica">
<div class="logo-senasica">🇲🇽<br>SADER</div>
<div class="titulo-central">
<h1>SERVICIO NACIONAL DE SANIDAD, INOCUIDAD Y CALIDAD AGROALIMENTARIA</h1>
<h2>DIRECCIÓN GENERAL DE SALUD ANIMAL</h2>
<h2 class="fuerte">CAMPAÑA NACIONAL CONTRA LA TUBERCULOSIS BOVINA</h2>
<h2 class="fuerte">DICTAMEN DE LA PRUEBA DE TUBERCULINA</h2>
</div>
<div class="logo-senasica">SENASICA</div>
</div>
<div class="caja-folios">
<div><span>FOLIO</span><b>TB ${p.folioTB || ''}</b></div>
<div><span>PÁGINA N°.</span><b>1 DE ${totalPaginas}</b></div>
</div>
<div style="clear:both;"></div>
<div class="seccion-dictamen">
<div class="titulo-seccion">I. PROPIETARIO</div>
<div class="fila-campos">
<div class="campo-dictamen"><span class="etiqueta">Apellido paterno</span><span class="valor">${p.apellidoPaterno || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Apellido materno</span><span class="valor">${p.apellidoMaterno || ''}</span></div>
<div class="campo-dictamen" style="flex:2;"><span class="etiqueta">Nombre(s)</span><span class="valor">${p.nombres || p.productorNombre || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Teléfono</span><span class="valor">${p.telefonoProductor || ''}</span></div>
</div>
<div class="fila-campos">
<div class="campo-dictamen" style="flex:2;"><span class="etiqueta">Domicilio</span><span class="valor">${p.domicilio || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Municipio</span><span class="valor">${p.municipio || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Localidad/Población</span><span class="valor">${p.localidad || ''}</span></div>
</div>
<div class="fila-campos">
<div class="campo-dictamen"><span class="etiqueta">Estado</span><span class="valor">${p.estadoMx || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Correo electrónico</span><span class="valor">&nbsp;</span></div>
</div>
</div>
<div class="seccion-dictamen">
<div class="titulo-seccion">II. UNIDAD DE PRODUCCIÓN</div>
<div class="fila-campos">
<div class="campo-dictamen" style="flex:2;"><span class="etiqueta">Nombre de la unidad de producción o predio</span><span class="valor">${p.predio || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Latitud</span><span class="valor">${p.latitud || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Longitud</span><span class="valor">${p.longitud || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Clave UPP o PSG</span><span class="valor">${p.claveUpp || p.upp || ''}</span></div>
</div>
<div class="fila-campos">
<div class="campo-dictamen"><span class="etiqueta">Domicilio</span><span class="valor">${p.domicilio || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Municipio</span><span class="valor">${p.municipio || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Localidad/Población</span><span class="valor">${p.localidad || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Estado</span><span class="valor">${p.estadoMx || ''}</span></div>
</div>
</div>
<div class="seccion-dictamen">
<div class="titulo-seccion">III. DE LA PRUEBA</div>
<div class="fila-campos">
<div class="campo-dictamen"><span class="etiqueta">Fecha prueba anterior</span><span class="valor">&nbsp;</span></div>
<div class="campo-dictamen"><span class="etiqueta">Dictamen TB anterior No.</span><span class="valor">&nbsp;</span></div>
<div class="campo-dictamen"><span class="etiqueta">Tipo de prueba realizada</span><span class="valor">${p.tipoIdentificacion || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Total de hato a constatar / No. animales</span><span class="valor">${resumen.totalProbados}</span></div>
</div>
<div class="fila-campos">
<div class="campo-dictamen"><span class="etiqueta">Motivo de la presente prueba</span><span class="valor">${p.motivo || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Función zootécnica</span><span class="valor">${p.finalidad || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Inyección — fecha / hora</span><span class="valor">${fechaDMA(p.fechaInyeccion)} ${p.horaInyeccion || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Lectura — fecha / hora</span><span class="valor">${fechaDMA(p.fechaLectura)} ${p.horaLectura || ''}</span></div>
</div>
<div class="fila-campos">
<div class="campo-dictamen"><span class="etiqueta">Negativos</span><span class="valor">${resumen.negativos}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Sospechosos</span><span class="valor">${resumen.sospechosos}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Positivos</span><span class="valor">${resumen.positivos}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Total</span><span class="valor">${resumen.totalProbados}</span></div>
</div>
</div>
<div class="seccion-dictamen">
<div class="titulo-seccion">IV. RESULTADOS</div>
${tablaResultadosDobleHTML(filasPortada, 20, 1, 'TB')}
</div>
${totalPaginas === 1 ? pieFirmaDictamenOficialHTML(p, false) : ''}
</div>`;
}
function paginaComplementariaDictamenTBHTML(p, filasBloque, indiceInicial, numPagina, totalPaginas, esUltima){
return `<div class="hoja-senasica hoja-oficial">
<div class="encabezado-senasica" style="border-bottom:1px solid #000;">
<div class="titulo-central">
<h1>SERVICIO NACIONAL DE SANIDAD, INOCUIDAD Y CALIDAD AGROALIMENTARIA</h1>
<h2 class="fuerte">CAMPAÑA NACIONAL CONTRA LA TUBERCULOSIS BOVINA</h2>
</div>
</div>
<div class="caja-folios">
<div><span>HOJA COMPLEMENTARIA</span></div>
<div><span>FOLIO TB</span><b>${p.folioTB || ''}</b></div>
<div><span>PÁGINA N°.</span><b>${numPagina} DE ${totalPaginas}</b></div>
</div>
<div style="clear:both;"></div>
<div class="seccion-dictamen">
<div class="titulo-seccion">IV. RESULTADOS</div>
${tablaResultadosDobleHTML(filasBloque, 50, indiceInicial, 'TB')}
</div>
<p class="nota-pie">Hoja complementaria válida solo con la presentación del dictamen que señala el folio original.</p>
${esUltima ? pieFirmaDictamenOficialHTML(p, false) : ''}
</div>`;
}
function paginaPortadaDictamenBRHTML(p, filasPortada, resumen, totalPaginas){
return `<div class="hoja-senasica hoja-oficial">
<div class="encabezado-senasica">
<div class="logo-senasica">🇲🇽<br>SADER</div>
<div class="titulo-central">
<h1>SERVICIO NACIONAL DE SANIDAD, INOCUIDAD Y CALIDAD AGROALIMENTARIA</h1>
<h2>DIRECCIÓN GENERAL DE SALUD ANIMAL</h2>
<h2 class="fuerte">CAMPAÑA NACIONAL CONTRA LA BRUCELOSIS EN LOS ANIMALES</h2>
<h2 class="fuerte">DICTAMEN DE LA PRUEBA DE BRUCELOSIS</h2>
</div>
<div class="logo-senasica">SENASICA</div>
</div>
<div class="caja-folios">
<div><span>FOLIO</span><b>BR ${p.folioTB || ''}</b></div>
<div><span>PÁGINA N°.</span><b>1 DE ${totalPaginas}</b></div>
</div>
<div style="clear:both;"></div>
<div class="seccion-dictamen">
<div class="titulo-seccion">I. PROPIETARIO</div>
<div class="fila-campos">
<div class="campo-dictamen"><span class="etiqueta">Apellido paterno</span><span class="valor">${p.apellidoPaterno || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Apellido materno</span><span class="valor">${p.apellidoMaterno || ''}</span></div>
<div class="campo-dictamen" style="flex:2;"><span class="etiqueta">Nombre(s)</span><span class="valor">${p.nombres || p.productorNombre || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Teléfono</span><span class="valor">${p.telefonoProductor || ''}</span></div>
</div>
<div class="fila-campos">
<div class="campo-dictamen" style="flex:2;"><span class="etiqueta">Domicilio</span><span class="valor">${p.domicilio || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Municipio</span><span class="valor">${p.municipio || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Localidad/Población</span><span class="valor">${p.localidad || ''}</span></div>
</div>
<div class="fila-campos">
<div class="campo-dictamen"><span class="etiqueta">Estado</span><span class="valor">${p.estadoMx || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Correo electrónico</span><span class="valor">&nbsp;</span></div>
</div>
</div>
<div class="seccion-dictamen">
<div class="titulo-seccion">II. UNIDAD DE PRODUCCIÓN</div>
<div class="fila-campos">
<div class="campo-dictamen" style="flex:2;"><span class="etiqueta">Nombre de la unidad de producción o predio</span><span class="valor">${p.predio || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Latitud</span><span class="valor">${p.latitud || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Longitud</span><span class="valor">${p.longitud || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Clave UPP o PSG</span><span class="valor">${p.claveUpp || p.upp || ''}</span></div>
</div>
<div class="fila-campos">
<div class="campo-dictamen"><span class="etiqueta">Domicilio</span><span class="valor">${p.domicilio || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Municipio</span><span class="valor">${p.municipio || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Localidad/Población</span><span class="valor">${p.localidad || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Estado</span><span class="valor">${p.estadoMx || ''}</span></div>
</div>
</div>
<div class="seccion-dictamen">
<div class="titulo-seccion">III. DE LA PRUEBA</div>
<div class="fila-campos">
<div class="campo-dictamen"><span class="etiqueta">Fecha de prueba anterior</span><span class="valor">&nbsp;</span></div>
<div class="campo-dictamen"><span class="etiqueta">Fecha del muestreo</span><span class="valor">${fechaDMA(p.fechaMuestra)}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Fecha de prueba próxima</span><span class="valor">&nbsp;</span></div>
</div>
<div class="fila-campos">
<div class="campo-dictamen"><span class="etiqueta">Motivo de la presente prueba</span><span class="valor">${p.motivo || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Función zootécnica</span><span class="valor">${p.finalidad || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Total del hato</span><span class="valor">&nbsp;</span></div>
</div>
<div class="fila-campos">
<div class="campo-dictamen"><span class="etiqueta">Negativos</span><span class="valor">${resumen.negativos}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Positivos</span><span class="valor">${resumen.positivos}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Total</span><span class="valor">${resumen.totalProbados}</span></div>
</div>
</div>
<div class="seccion-dictamen">
<div class="titulo-seccion">IV. RESULTADOS</div>
${tablaResultadosDobleHTML(filasPortada, 20, 1, 'BR')}
</div>
${totalPaginas === 1 ? pieFirmaDictamenOficialHTML(p, true) : ''}
</div>`;
}
function paginaComplementariaDictamenBRHTML(p, filasBloque, indiceInicial, numPagina, totalPaginas, esUltima){
return `<div class="hoja-senasica hoja-oficial">
<div class="encabezado-senasica" style="border-bottom:1px solid #000;">
<div class="titulo-central">
<h1>SERVICIO NACIONAL DE SANIDAD, INOCUIDAD Y CALIDAD AGROALIMENTARIA</h1>
<h2 class="fuerte">CAMPAÑA NACIONAL CONTRA LA BRUCELOSIS EN LOS ANIMALES</h2>
</div>
</div>
<div class="caja-folios">
<div><span>HOJA COMPLEMENTARIA</span></div>
<div><span>FOLIO BR</span><b>${p.folioTB || ''}</b></div>
<div><span>PÁGINA N°.</span><b>${numPagina} DE ${totalPaginas}</b></div>
</div>
<div style="clear:both;"></div>
<div class="seccion-dictamen">
<div class="titulo-seccion">IV. RESULTADOS</div>
${tablaResultadosDobleHTML(filasBloque, 50, indiceInicial, 'BR')}
</div>
<p class="nota-pie">Hoja complementaria válida solo con la presentación del dictamen que señala el folio original.</p>
${esUltima ? pieFirmaDictamenOficialHTML(p, true) : ''}
</div>`;
}
function generarPaginasDictamenOficialHTML(p, tipo){
const animales = p.animales || [];
const negativos = animales.filter(a => a.resultado === 'N').length;
const sospechosos = animales.filter(a => a.resultado === 'S').length;
const positivos = animales.filter(a => a.resultado === 'R').length;
const resumen = { totalProbados: animales.length, negativos, sospechosos, positivos };
const filasPortada = animales.slice(0, 20);
const resto = animales.slice(20);
const totalPaginas = 1 + Math.ceil(resto.length / 50);
const paginas = [tipo === 'TB' ? paginaPortadaDictamenTBHTML(p, filasPortada, resumen, totalPaginas) : paginaPortadaDictamenBRHTML(p, filasPortada, resumen, totalPaginas)];
let numPagina = 2;
for (let i = 0; i < resto.length; i += 50){
const bloque = resto.slice(i, i + 50);
const esUltima = (i + 50) >= resto.length;
paginas.push(tipo === 'TB'
? paginaComplementariaDictamenTBHTML(p, bloque, 20 + i + 1, numPagina, totalPaginas, esUltima)
: paginaComplementariaDictamenBRHTML(p, bloque, 20 + i + 1, numPagina, totalPaginas, esUltima));
numPagina++;
}
return paginas.join('');
}
function abrirVistaPreviaDictamenTB(id){
const p = estado.pruebasCampoVet.find(x => x.id === id);
if (!p) return;
const ventana = window.open('', '_blank');
if (!ventana){ mostrarToast('Tu navegador bloqueó la ventana emergente — permite pop-ups para imprimir'); return; }
ventana.document.write(`<html><head><title>Dictamen TB — ${(p.productorNombre || '').replace(/</g,'')}</title>${estilosDictamenSenasica()}${estilosDictamenOficial()}</head><body>
<div class="controles-vista-previa"><button onclick="window.print()"><i class="fa-solid fa-print"></i> Imprimir / Guardar como PDF</button><button onclick="window.close()" style="background:#8a3b3b;">Cerrar</button></div>
${generarPaginasDictamenOficialHTML(p, 'TB')}
</body></html>`);
ventana.document.close();
ventana.focus();
}
function abrirVistaPreviaDictamenBR(id){
const p = estado.pruebasCampoVet.find(x => x.id === id);
if (!p) return;
const ventana = window.open('', '_blank');
if (!ventana){ mostrarToast('Tu navegador bloqueó la ventana emergente — permite pop-ups para imprimir'); return; }
ventana.document.write(`<html><head><title>Dictamen BR — ${(p.productorNombre || '').replace(/</g,'')}</title>${estilosDictamenSenasica()}${estilosDictamenOficial()}</head><body>
<div class="controles-vista-previa"><button onclick="window.print()"><i class="fa-solid fa-print"></i> Imprimir / Guardar como PDF</button><button onclick="window.close()" style="background:#8a3b3b;">Cerrar</button></div>
${generarPaginasDictamenOficialHTML(p, 'BR')}
</body></html>`);
ventana.document.close();
ventana.focus();
}
// ================= MÓDULO TB — AVISOS DE REACTORES, MÉDICOS DE CAMPO Y PRUEBA CERVICAL COMPARATIVA =================
// Cuando una lectura de una prueba TB arroja al menos 1 animal Reactor, se genera
// automáticamente un aviso en la "Ventana general de TB" para que el comité asigne
// un médico de campo autorizado que haga la Prueba Cervical Comparativa (PCC) de
// confirmación — sin backend propio (Cloud Functions/reglas por UID) esto se simula
// con el mismo patrón de roles ya usado en el resto de la app (usuario/clave +
// bandera de modo), igual que capturista/emisora de solicitudes.
function generarAvisoReactoresTB(prueba, reactoresFilas){
if (!prueba) return;
if ((estado.avisosReactoresTB || []).some(a => a.pruebaId === prueba.id)) return;
estado.avisosReactoresTB.push({
id: 'avtb_' + Date.now(),
pruebaId: prueba.id,
productorId: prueba.productorId || '',
productorNombre: prueba.productorNombre || '',
predio: prueba.predio || '', upp: prueba.upp || '', curp: prueba.curp || '',
apellidoPaterno: prueba.apellidoPaterno || '', apellidoMaterno: prueba.apellidoMaterno || '', nombres: prueba.nombres || '',
domicilio: prueba.domicilio || '', localidad: prueba.localidad || '', estadoMx: prueba.estadoMx || '', municipio: prueba.municipio || '',
totalHato: (prueba.animales || []).length,
aretesReactores: reactoresFilas.map(f => ({ arete: f.arete, especie: f.especie, edad: f.edad, raza: f.raza, sexo: f.sexo, fierro: f.fierro })),
fecha: hoyISO(),
estatus: 'pendiente',
medicoAsignadoId: null, medicoAsignadoNombre: null, fechaAsignacion: null,
animalesPCC: null, fechaFinalizado: null, folioTB: prueba.folioTB || '',
});
const avisoNuevo = estado.avisosReactoresTB.find(a => a.pruebaId === prueba.id);
if (avisoNuevo && typeof enviarFlujoConReintento === 'function') {
  enviarFlujoConReintento('comite_dgo', avisoNuevo.id, 'aviso_reactor', avisoNuevo, {enviadoPor:'veterinario', estatus:'pendiente', origenBandeja:'vet_' + (estado.veterinarioActivoId || '')});
}
guardarEstadoLocal();
}
function cambiarTabVentanaTB(tab){
['avisos','medicos','informes'].forEach(t=>{
  const btn=document.getElementById('tab-tb-'+t), bloque=document.getElementById('bloque-tb-'+t);
  if(btn){ btn.style.background = tab === t ? 'var(--pine)' : ''; btn.style.color = tab === t ? '#fff' : ''; }
  if(bloque) bloque.classList.toggle('hidden', tab !== t);
});
if(tab === 'informes') renderInformesRecibidosComiteTB();
}
function renderInformesRecibidosComiteTB(){
  const cont=document.getElementById('lista-informes-recibidos-tb');
  if(!cont) return;
  const items=(estado.reportesRecibidosComiteTB || []).slice().sort((a,b)=>(b.fechaFinalizado||b.fecha||'').localeCompare(a.fechaFinalizado||a.fecha||''));
  const badge=document.getElementById('badge-tb-informes');
  if(badge) badge.textContent=String(items.length);
  if(!items.length){ cont.innerHTML='<div class="vacio"><i class="fa-solid fa-file-circle-check"></i><p>Aún no se han recibido informes de pruebas.</p></div>'; return; }
  cont.innerHTML=items.map(r=>{
    const animales=Array.isArray(r.animalesPCC)?r.animalesPCC:(Array.isArray(r.animales)?r.animales:[]);
    const reactores=animales.filter(a=>a.resultado==='R').length;
    return `<div class="item-registro" style="border-left:6px solid var(--purple);">
      <p class="font-bold">${r.productorNombre || 'Productor sin nombre'}</p>
      <p class="text-sm" style="color:var(--sage);">${r.upp ? 'UPP '+r.upp+' · ' : ''}${r.predio || ''}</p>
      <p class="text-sm" style="color:var(--sage);">${animales.length} animal(es) en el informe${reactores ? ` · ${reactores} reactor(es)` : ''}</p>
      <p class="text-xs mt-1" style="color:var(--sage);">${r.medicoAsignadoNombre ? 'Médico: '+r.medicoAsignadoNombre+' · ' : ''}${r.fechaFinalizado || r.fecha || ''}</p>
      ${(r.folioTB || r.folioHojaCampo || r.consecutivo) ? `<p class="text-xs mt-1" style="color:var(--sage);">${r.folioTB ? 'Folio: '+r.folioTB+' ' : ''}${r.folioHojaCampo ? '· Hoja: '+r.folioHojaCampo+' ' : ''}${r.consecutivo ? '· Consecutivo: '+r.consecutivo : ''}</p>` : ''}
      <span class="text-xs px-2 py-0.5 rounded-full inline-block mt-2" style="background:${reactores ? 'var(--red)' : 'var(--green)'}; color:#fff;">${reactores ? 'Requiere seguimiento' : 'Resultado sin reactores'}</span>
      <button onclick="abrirVistaPreviaDictamenPCC('${r.id}')" class="w-full text-xs font-bold px-3 py-2 rounded-full mt-2" style="background:var(--pine); color:#fff;"><i class="fa-solid fa-print"></i> Ver / imprimir hoja PCC</button>
    </div>`;
  }).join('');
}
function cambiarTabComiteCEFPP(tab){
document.getElementById('tab-cefpp-general').style.background = tab === 'general' ? 'var(--pine)' : '';
document.getElementById('tab-cefpp-general').style.color = tab === 'general' ? '#fff' : '';
document.getElementById('tab-cefpp-tb').style.background = tab === 'tb' ? 'var(--pine)' : '';
document.getElementById('tab-cefpp-tb').style.color = tab === 'tb' ? '#fff' : '';
document.getElementById('bloque-cefpp-general').classList.toggle('hidden', tab !== 'general');
document.getElementById('bloque-cefpp-tb').classList.toggle('hidden', tab !== 'tb');
}
function actualizarBadgesComiteCEFPP(){
const pendSolicitudes = (estado.solicitudesCEFP || []).filter(s => s.estatus === 'pendiente').length;
const pendTB = (estado.avisosReactoresTB || []).filter(a => a.estatus === 'pendiente').length;
const badgeSol = document.getElementById('badge-cefpp-solicitudes');
const badgeTB = document.getElementById('badge-cefpp-tb');
if (badgeSol){ badgeSol.textContent = pendSolicitudes; badgeSol.classList.toggle('hidden', pendSolicitudes === 0); }
if (badgeTB){ badgeTB.textContent = pendTB; badgeTB.classList.toggle('hidden', pendTB === 0); }
}
function renderAvisosReactoresTB(){
const cont = document.getElementById('lista-avisos-reactores-tb');
if (!cont) return;
const filtro = valor('tb-avisos-filtro') || 'pendientes';
const q = (valor('tb-avisos-buscar') || '').trim().toLowerCase();
let items = estado.avisosReactoresTB || [];
if (filtro === 'pendientes') items = items.filter(a => a.estatus === 'pendiente');
else if (filtro === 'proceso') items = items.filter(a => a.estatus === 'asignado' || a.estatus === 'en_proceso');
else if (filtro === 'finalizados') items = items.filter(a => a.estatus === 'finalizado');
if (q) items = items.filter(a => (a.productorNombre || '').toLowerCase().includes(q) || (a.upp || '').toLowerCase().includes(q));
items = items.sort((a,b) => (b.fecha || '').localeCompare(a.fecha || ''));
if (items.length === 0){ cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-triangle-exclamation"></i><p>No hay avisos con este filtro.</p></div>`; return; }
const ETIQUETAS = { pendiente:'Pendiente de asignar', asignado:'Asignado', en_proceso:'En proceso', finalizado:'Finalizado' };
const COLORES = { pendiente:'var(--red)', asignado:'var(--yellow)', en_proceso:'var(--blue)', finalizado:'var(--green)' };
cont.innerHTML = items.map(a => `
<div class="item-registro" style="border-left:6px solid ${COLORES[a.estatus]};">
<p class="font-bold">${a.productorNombre}</p>
<p class="text-sm" style="color:var(--sage);">${a.predio || ''} ${a.upp ? '· UPP ' + a.upp : ''} · ${a.fecha}</p>
<p class="text-sm" style="color:var(--sage);">${a.aretesReactores.length} reactor(es) de ${a.totalHato} probados</p>
<span class="text-xs px-2 py-0.5 rounded-full inline-block mt-1" style="background:${COLORES[a.estatus]}; color:#fff;">${ETIQUETAS[a.estatus]}</span>
${a.medicoAsignadoNombre ? `<p class="text-xs mt-1" style="color:var(--sage);"><i class="fa-solid fa-user-doctor mr-1"></i>${a.medicoAsignadoNombre}</p>` : ''}
${(a.folioTB || a.folioHojaCampo || a.consecutivo) ? `<p class="text-xs mt-1" style="color:var(--sage);">${a.folioTB ? 'Folio: ' + a.folioTB + ' ' : ''}${a.folioHojaCampo ? '· Hoja de campo: ' + a.folioHojaCampo + ' ' : ''}${a.consecutivo ? '· Consecutivo: ' + a.consecutivo : ''}</p>` : ''}
<div class="flex flex-wrap gap-2 mt-3">
${a.estatus === 'pendiente' ? `<button onclick="abrirModalAsignarMedicoTB('${a.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--red); color:#fff;"><i class="fa-solid fa-user-doctor"></i> Asignar médico</button>` : ''}
${(a.estatus === 'asignado' || a.estatus === 'en_proceso') ? `<button onclick="abrirModalAsignarMedicoTB('${a.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--parchment); color:var(--pine); border:2px solid var(--line);"><i class="fa-solid fa-arrows-rotate"></i> Reasignar</button>` : ''}
${a.estatus === 'finalizado' ? `<button onclick="abrirVistaPreviaDictamenPCC('${a.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--purple); color:#fff;"><i class="fa-solid fa-print"></i> Imprimir dictamen PCC</button>` : ''}
${a.fechaFinCuarentena && !a.reProbado ? (hoyISO() < a.fechaFinCuarentena
? `<span class="text-xs px-2 py-0.5 rounded-full inline-flex items-center" style="background:var(--yellow); color:#fff;"><i class="fa-solid fa-clock mr-1"></i>${a.animalesEnCuarentena.length} en cuarentena hasta ${a.fechaFinCuarentena}</span>`
: `<button onclick="iniciarRePruebaCuarentena('${a.id}')" class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--red); color:#fff;"><i class="fa-solid fa-rotate"></i> Cuarentena cumplida — registrar re-prueba</button>`) : ''}
</div>
</div>`).join('');
}
let avisoTBSeleccionadoParaAsignar = null;
function abrirModalAsignarMedicoTB(avisoId){
if ((estado.medicosComiteTB || []).length === 0){ mostrarToast('Registra primero al menos un médico de campo en la pestaña "Médicos del comité"'); return; }
avisoTBSeleccionadoParaAsignar = avisoId;
const aviso = (estado.avisosReactoresTB || []).find(a => a.id === avisoId);
const pestanas = document.getElementById('tb-pestanas-medico');
pestanas.innerHTML = estado.medicosComiteTB.map(m => `<button class="subtab" data-medico-id="${m.id}" onclick="elegirMedicoParaAsignar('${m.id}', this)" type="button">${m.nombre}</button>`).join('');
establecerValor('tb-select-medico', aviso && aviso.medicoAsignadoId ? aviso.medicoAsignadoId : '');
pestanas.querySelectorAll('button').forEach(b => b.classList.toggle('active', b.dataset.medicoId === valor('tb-select-medico')));
establecerValor('tb-asig-folio', (aviso && aviso.folioTB) || '');
establecerValor('tb-asig-folio-hoja-campo', (aviso && aviso.folioHojaCampo) || '');
establecerValor('tb-asig-consecutivo', (aviso && aviso.consecutivo) || '');
const m = document.getElementById('modal-asignar-medico-tb');
m.classList.remove('hidden'); m.style.display = 'flex';
}
function elegirMedicoParaAsignar(medicoId, btnEl){
establecerValor('tb-select-medico', medicoId);
btnEl.parentElement.querySelectorAll('button').forEach(b => b.classList.remove('active'));
btnEl.classList.add('active');
}
function cerrarModalAsignarMedicoTB(){
const m = document.getElementById('modal-asignar-medico-tb');
m.classList.add('hidden'); m.style.removeProperty('display');
avisoTBSeleccionadoParaAsignar = null;
}
function confirmarAsignarMedicoTB(){
const aviso = (estado.avisosReactoresTB || []).find(a => a.id === avisoTBSeleccionadoParaAsignar);
const medicoId = valor('tb-select-medico');
const medico = estado.medicosComiteTB.find(m => m.id === medicoId);
if (!aviso){ cerrarModalAsignarMedicoTB(); return; }
if (!medico){ mostrarToast('Selecciona un médico de campo'); return; }
aviso.medicoAsignadoId = medico.id;
aviso.medicoAsignadoNombre = medico.nombre;
aviso.fechaAsignacion = hoyISO();
aviso.estatus = 'asignado';
// Folio/hoja de campo/consecutivo: siempre se escriben a mano, no se generan solos.
// Se asignan ANTES de construir el flujo para que el médico reciba exactamente
// los datos que el comité acaba de capturar (firebaseEnviarFlujo hace una copia
// profunda antes de esperar a Firebase).
aviso.folioTB = valor('tb-asig-folio').trim();
aviso.folioHojaCampo = valor('tb-asig-folio-hoja-campo').trim();
aviso.consecutivo = valor('tb-asig-consecutivo').trim();
if (typeof enviarFlujoConReintento === 'function') {
  enviarFlujoConReintento('medico_' + medico.id, aviso.id, 'asignacion_pcc', aviso, {enviadoPor:'comite', estatus:'asignado', origenBandeja:'comite_dgo'});
}
guardarEstadoLocal();
cerrarModalAsignarMedicoTB();
renderAvisosReactoresTB();
mostrarToast(`Asignado a ${medico.nombre}`);
}
function agregarMedicoComiteTB(){
const nombre = valor('tbm-nombre').trim();
const cedula = valor('tbm-cedula').trim();
const claveMvz = valor('tbm-clave-mvz').trim();
const vigencia = valor('tbm-vigencia');
const telefono = valor('tbm-telefono').trim();
if (!nombre){ mostrarToast('Escribe el nombre del médico'); return; }
const usuario = generarUsuarioDesdeNombre(nombre);
if (existeUsuarioDuplicado(usuario)){ mostrarToast('Ya existe un usuario con ese nombre — cámbialo ligeramente'); return; }
const clave = generarContrasenaProvisional();
estado.medicosComiteTB.push({ id: 'tbm_' + Date.now(), nombre, cedula, claveMvz, vigencia, telefono, usuario, clave });
estado.usuarios.push({ nombre: nombre + ' (Médico de campo TB)', usuario, clave, rol: 'medico_campo_tb' });
guardarEstadoLocal();
establecerValor('tbm-nombre', ''); establecerValor('tbm-cedula', ''); establecerValor('tbm-clave-mvz', ''); establecerValor('tbm-vigencia', ''); establecerValor('tbm-telefono', '');
renderMedicosComiteTB();
mostrarToast(`Médico registrado — usuario: ${usuario} / contraseña: ${clave}`);
}
function eliminarMedicoComiteTB(id){
estado.medicosComiteTB = estado.medicosComiteTB.filter(m => m.id !== id);
guardarEstadoLocal();
renderMedicosComiteTB();
mostrarToast('Médico eliminado del catálogo');
}
function renderMedicosComiteTB(){
const cont = document.getElementById('lista-medicos-comite-tb');
if (!cont) return;
if ((estado.medicosComiteTB || []).length === 0){ cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-user-doctor"></i><p>Aún no registras médicos de campo.</p></div>`; return; }
cont.innerHTML = estado.medicosComiteTB.map(m => `
<div class="item-registro flex items-center justify-between gap-3">
<div>
<p class="font-bold">${m.nombre}</p>
<p class="text-sm" style="color:var(--sage);">${m.cedula ? 'Cédula: ' + m.cedula + ' · ' : ''}${m.claveMvz ? 'Clave MVZ: ' + m.claveMvz : ''} ${m.telefono ? '· Tel: ' + m.telefono : ''}</p>
${m.vigencia ? `<p class="text-xs" style="color:var(--sage);">Vigencia: ${m.vigencia}</p>` : ''}
<p class="text-xs" style="color:var(--sage);">Usuario: ${m.usuario}</p>
</div>
<button onclick="eliminarMedicoComiteTB('${m.id}')" style="color:var(--red);"><i class="fa-solid fa-trash"></i></button>
</div>`).join('');
}
// ---- Interfaz del médico de campo: solo ve sus propios casos asignados ----
function renderCasosMedicoCampoTB(){
const cont = document.getElementById('lista-casos-medico-campo-tb');
if (!cont) return;
const items = (estado.avisosReactoresTB || []).filter(a => a.medicoAsignadoId === estado.medicoComiteActivoId && a.estatus !== 'finalizado').sort((a,b) => (b.fecha || '').localeCompare(a.fecha || ''));
if (items.length === 0){ cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-notes-medical"></i><p>No tienes casos asignados por el momento.</p></div>`; return; }
cont.innerHTML = items.map(a => `
<div class="item-registro" style="border-left:6px solid var(--red);">
<p class="font-bold">${a.productorNombre}</p>
<p class="text-sm" style="color:var(--sage);">${a.predio || ''} ${a.upp ? '· UPP ' + a.upp : ''}</p>
<p class="text-sm" style="color:var(--sage);">${a.aretesReactores.length} animal(es) reactor(es) a confirmar</p>
<span class="text-xs px-2 py-0.5 rounded-full inline-block mt-1" style="background:var(--red); color:#fff;">Prueba cervical comparativa pendiente</span>
<button onclick="abrirCapturaPCC('${a.id}')" class="w-full text-xs font-bold px-3 py-2 rounded-full mt-3" style="background:var(--red); color:#fff;"><i class="fa-solid fa-syringe"></i> Capturar prueba cervical comparativa</button>
</div>`).join('');
}
// ================= REPORTES TB (gráficas + filtro por tipo de prueba) =================
// Clasifica cada prueba/aviso registrado en una de las categorías que pidió Luis:
// hato, barrido, cervical (PCC), brucelosis, otras — usando el motivo/tipoPrueba
// ya capturado, sin inventar datos nuevos.
function categoriaTB(p){
if (p.tipoPrueba === 'Brucelosis') return 'brucelosis';
if (p.categoria === 'areteo') return 'otras';
if (p.tipoPrueba === 'TB'){
const motivo = (p.motivo || '').toLowerCase();
if (motivo.includes('barrido')) return 'barrido';
return 'hato';
}
return 'otras';
}
const ETIQUETAS_CATEGORIA_TB = { hato:'Pruebas de hato (TB)', barrido:'Pruebas de barrido', cervical:'Cervicales comparativas (PCC)', brucelosis:'Brucelosis', otras:'Otras' };
async function renderReportesTB(){
await cargarChartJsSiNecesario();
const pruebas = estado.pruebasCampoVet || [];
const avisos = estado.avisosReactoresTB || [];
const pccFinalizadas = avisos.filter(a => a.estatus === 'finalizado');
const conteos = { hato:0, barrido:0, cervical: pccFinalizadas.length, brucelosis:0, otras:0 };
let totalAnimales = 0;
pruebas.forEach(p => { conteos[categoriaTB(p)]++; totalAnimales += (p.animales || []).length; });
pccFinalizadas.forEach(a => { totalAnimales += (a.animalesPCC || []).length; });
const totalReactores = avisos.reduce((acc, a) => acc + (a.aretesReactores || []).length, 0);
const tarjetas = document.getElementById('tarjetas-resumen-reportes-tb');
if (tarjetas){
tarjetas.innerHTML = `
<div class="bg-white rounded-2xl p-3 text-center" style="border:2px solid var(--line);"><p class="text-2xl font-display font-bold">${pruebas.length + pccFinalizadas.length}</p><p class="text-xs" style="color:var(--sage);">Pruebas totales</p></div>
<div class="bg-white rounded-2xl p-3 text-center" style="border:2px solid var(--line);"><p class="text-2xl font-display font-bold">${totalAnimales}</p><p class="text-xs" style="color:var(--sage);">Animales probados</p></div>
<div class="bg-white rounded-2xl p-3 text-center" style="border:2px solid var(--red);"><p class="text-2xl font-display font-bold" style="color:var(--red);">${totalReactores}</p><p class="text-xs" style="color:var(--sage);">Reactores</p></div>`;
}
if (typeof Chart !== 'undefined'){
const ctxTipo = document.getElementById('grafica-tb-por-tipo');
if (ctxTipo){
if (window._chartTBTipo) window._chartTBTipo.destroy();
window._chartTBTipo = new Chart(ctxTipo.getContext('2d'), {
type: 'bar',
data: { labels: Object.keys(conteos).map(k => ETIQUETAS_CATEGORIA_TB[k]), datasets: [{ label:'Pruebas', data: Object.values(conteos), backgroundColor:['#EF4444','#F59E0B','#7C3AED','#0D9488','#334155'] }] },
options: { plugins:{ legend:{ display:false } }, scales:{ y:{ beginAtZero:true, ticks:{ precision:0 } } } }
});
}
const ctxReact = document.getElementById('grafica-tb-reactores');
if (ctxReact){
const ETIQUETAS_ESTATUS_AVISO = { pendiente:'Pendientes', asignado:'Asignados', en_proceso:'En proceso', finalizado:'Finalizados' };
const conteoEstatus = { pendiente:0, asignado:0, en_proceso:0, finalizado:0 };
avisos.forEach(a => { if (a.estatus in conteoEstatus) conteoEstatus[a.estatus]++; });
if (window._chartTBReact) window._chartTBReact.destroy();
window._chartTBReact = new Chart(ctxReact.getContext('2d'), {
type: 'doughnut',
data: { labels: Object.keys(conteoEstatus).map(k => ETIQUETAS_ESTATUS_AVISO[k]), datasets: [{ data: Object.values(conteoEstatus), backgroundColor:['#EF4444','#F59E0B','#2563EB','#16A34A'] }] },
options: { plugins:{ legend:{ position:'bottom', labels:{ boxWidth:12, font:{ size:10 } } } } }
});
}
}
const filtro = valor('reptb-filtro-tipo') || 'todas';
const cont = document.getElementById('lista-reportes-tb-filtrado');
if (cont){
let items = pruebas.map(p => ({ tipo: categoriaTB(p), nombre: p.productorNombre, fecha: p.fecha, animales: (p.animales || []).length, vet: p.veterinarioNombre }));
items = items.concat(pccFinalizadas.map(a => ({ tipo:'cervical', nombre: a.productorNombre, fecha: a.fechaFinalizado, animales: (a.animalesPCC || []).length, vet: a.medicoAsignadoNombre })));
if (filtro !== 'todas') items = items.filter(i => i.tipo === filtro);
items = items.sort((a,b) => (b.fecha || '').localeCompare(a.fecha || ''));
if (items.length === 0){ cont.innerHTML = `<p class="text-xs text-center py-2" style="color:var(--sage);">Sin pruebas con este filtro.</p>`; return; }
cont.innerHTML = items.slice(0, 100).map(i => `
<div class="flex items-center justify-between text-xs py-1" style="border-bottom:1px solid var(--line);">
<span>${ETIQUETAS_CATEGORIA_TB[i.tipo]} — ${i.nombre}</span>
<span style="color:var(--sage);">${i.animales} animal(es) · ${i.fecha || ''}</span>
</div>`).join('');
}
}
// ================= GENERAR INFORME GENERAL (todas las pruebas, filtro avanzado) =================
function renderGenerarInformeTB(){
const desde = valor('gentb-fecha-desde');
const hasta = valor('gentb-fecha-hasta');
const tipo = valor('gentb-tipo') || 'todas';
const motivo = (valor('gentb-motivo') || '').trim().toLowerCase();
const vetTxt = (valor('gentb-veterinario') || '').trim().toLowerCase();
const q = (valor('gentb-buscar') || '').trim().toLowerCase();
let items = (estado.pruebasCampoVet || []).slice();
if (desde) items = items.filter(p => (p.fecha || '') >= desde);
if (hasta) items = items.filter(p => (p.fecha || '') <= hasta);
if (tipo !== 'todas') items = items.filter(p => p.tipoPrueba === tipo);
if (motivo) items = items.filter(p => (p.motivo || '').toLowerCase().includes(motivo));
if (vetTxt) items = items.filter(p => (p.veterinarioNombre || '').toLowerCase().includes(vetTxt));
if (q) items = items.filter(p => (p.productorNombre || '').toLowerCase().includes(q) || (p.predio || '').toLowerCase().includes(q) || (p.upp || '').toLowerCase().includes(q));
items = items.sort((a,b) => (b.fecha || '').localeCompare(a.fecha || ''));
const totalAnimales = items.reduce((acc, p) => acc + (p.animales || []).length, 0);
const tarjetas = document.getElementById('tarjetas-resumen-generar-tb');
if (tarjetas){
tarjetas.innerHTML = `
<div class="bg-white rounded-2xl p-3 text-center" style="border:2px solid var(--line);"><p class="text-2xl font-display font-bold">${items.length}</p><p class="text-xs" style="color:var(--sage);">Pruebas encontradas</p></div>
<div class="bg-white rounded-2xl p-3 text-center" style="border:2px solid var(--line);"><p class="text-2xl font-display font-bold">${totalAnimales}</p><p class="text-xs" style="color:var(--sage);">Animales probados</p></div>`;
}
const cont = document.getElementById('lista-generar-informe-tb');
if (!cont) return;
if (items.length === 0){ cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-magnifying-glass"></i><p>Sin resultados con este filtro.</p></div>`; return; }
cont.innerHTML = items.slice(0, 200).map(p => `
<div class="item-registro" style="border-left:6px solid var(--slate);">
<p class="font-bold">${p.tipoPrueba} — ${p.productorNombre}</p>
<p class="text-xs" style="color:var(--sage);">${p.predio || ''} ${p.upp ? '· UPP ' + p.upp : ''} · ${p.fecha} · ${(p.animales || []).length} animal(es)</p>
<p class="text-xs" style="color:var(--sage);">Motivo: ${p.motivo || '—'} · Veterinario: ${p.veterinarioNombre || '—'}</p>
</div>`).join('');
}
// ---- Captura de la Prueba Cervical Comparativa (PCC) ----
let avisoTBEnCaptura = null;
// Modo directo: el médico de TB registra una PCC sin que exista un aviso de
// reactor previo ni una asignación del comité — para cuando ya está en el
// predio o le avisan por teléfono. Se guarda igual en avisosReactoresTB, pero
// sin folio/hoja de campo/consecutivo (eso lo agrega el comité después) y
// marcado con origenDirecto para diferenciarlo del flujo normal.
let pccModoDirecto = false;
function abrirPCCDirecta(){
pccModoDirecto = true;
avisoTBEnCaptura = null;
document.getElementById('titulo-capturapcc').textContent = 'Prueba PCC directa';
document.getElementById('resumen-propietario-pcc-grid').innerHTML = `
<div class="col-span-2"><label class="campo-label">Nombre del productor</label><input class="campo-mayusculas" id="pccd-productor-nombre" oninput="forzarMayusculas(this)" type="text"/></div>
<div><label class="campo-label">Predio</label><input class="campo-mayusculas" id="pccd-predio" oninput="forzarMayusculas(this)" type="text"/></div>
<div><label class="campo-label">UPP</label><input class="campo-mayusculas" id="pccd-upp" maxlength="12" oninput="forzarMayusculas(this); validarLongitudCampo(this,12,'UPP')" type="text"/></div>
<div><label class="campo-label">CURP (opcional)</label><input class="campo-mayusculas" id="pccd-curp" maxlength="18" oninput="forzarMayusculas(this); validarLongitudCampo(this,18,'CURP')" type="text"/></div>
<div><label class="campo-label">Teléfono (opcional)</label><input id="pccd-telefono" maxlength="10" type="tel"/></div>`;
const btnAgregar = document.getElementById('btn-agregar-animal-pcc');
if (btnAgregar) btnAgregar.classList.remove('hidden');
const btnGuardar = document.getElementById('btn-guardar-pcc');
if (btnGuardar) btnGuardar.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Registrar y enviar al comité';
renderFilasPCC([]);
const cab=document.getElementById('pcc-cabecera-productor'); if(cab) cab.textContent='Captura directa — productor por registrar';
inicializarMetadatosPCC(null);
irAdmin('capturapcc');
}
function agregarFilaVaciaPCC(){
const filas = window._filasPCCActuales || [];
filas.push({ arete:'', especie:'Bovino', edad:'', raza:'', sexo:'M', fierro:'', iniA:'', iniB:'', h72A:'', h72B:'', resultado:'', observaciones:'' });
renderFilasPCC(filas);
}
// Resumen de "solo lectura" del productor en la captura de PCC (médico del
// comité) — misma idea que en Nueva prueba del veterinario: si el productor
// ya tiene cuenta y datos dados de alta en la plataforma (lo normal, porque
// el aviso de reactor viene de una prueba de campo ya guardada), se muestran
// directo sin que el médico tenga que volver a escribirlos. La figura del
// fierro se puede tocar para dibujarla/corregirla igual que en Nueva prueba
// — misma herramienta, mismo vectorizador, solo que guarda con el prefijo
// 'pcc' para no pisar la pantalla de Nueva prueba si las dos existieran
// abiertas en la app al mismo tiempo.
function renderResumenPropietarioPCC(a, notaExtra){
const grid = document.getElementById('resumen-propietario-pcc-grid');
if (!grid) return;
const c = a.productorId ? estado.cuentasProductores.find(x => x.id === a.productorId) : null;
if (c){
productorSeleccionadoPruebaCampo = c; // así el lienzo de dibujo del fierro sabe en qué cuenta guardar
const municipioEstado = [c.municipio, c.estadoMx].filter(Boolean).join(', ') || '—';
const tieneGPS = c.latitud != null && c.longitud != null && String(c.latitud).trim();
grid.innerHTML = [
`<div class="resumen-tile"><span class="resumen-tile-etiqueta">Apellido paterno</span><span class="resumen-tile-valor">${c.apellidoPaterno || '—'}</span></div>`,
`<div class="resumen-tile"><span class="resumen-tile-etiqueta">Materno</span><span class="resumen-tile-valor">${c.apellidoMaterno || '—'}</span></div>`,
`<div class="resumen-tile"><span class="resumen-tile-etiqueta">Nombre(s)</span><span class="resumen-tile-valor">${c.nombres || '—'}</span></div>`,
`<div class="resumen-tile"><span class="resumen-tile-etiqueta">CURP</span><span class="resumen-tile-valor">${c.curp || '—'}</span></div>`,
`<div class="resumen-tile"><span class="resumen-tile-etiqueta">UPP</span><span class="resumen-tile-valor">${c.upp || '—'}</span></div>`,
`<div class="resumen-tile"><span class="resumen-tile-etiqueta">Rancho</span><span class="resumen-tile-valor">${c.predio || '—'}</span></div>`,
`<div class="resumen-tile col-span-2"><span class="resumen-tile-etiqueta">Municipio</span><span class="resumen-tile-valor">${municipioEstado}</span></div>`,
tieneGPS
? `<div class="col-span-2 resumen-gps-badge"><i class="fa-solid fa-location-dot" style="color:var(--green);"></i><span class="text-xs font-bold" style="color:var(--ink);">${c.latitud}, ${c.longitud}</span><i class="fa-solid fa-circle-check ml-auto" style="color:var(--green);"></i></div>`
: `<div class="resumen-tile resumen-tile-vacio col-span-2"><span class="resumen-tile-etiqueta"><i class="fa-solid fa-location-dot"></i> GPS — sin datos guardados en la cuenta</span></div>`,
celdaFierroResumenPC(c, 'pcc'),
`<div class="resumen-tile col-span-2"><span class="resumen-tile-etiqueta">Reactores a confirmar</span><span class="resumen-tile-valor">${a.aretesReactores.length} animal(es)</span></div>`,
notaExtra ? `<div class="resumen-tile col-span-2" style="background:rgba(239,68,68,0.1); border:1.5px solid var(--red);"><span class="resumen-tile-valor" style="color:var(--red);"><i class="fa-solid fa-rotate"></i> ${notaExtra}</span></div>` : '',
].join('');
} else {
// Caso registrado directo por el médico, sin cuenta ligada en la app — se
// muestra solo lo que el aviso trae, sin inventar datos que no existen.
grid.innerHTML = `
<div class="resumen-tile col-span-2"><span class="resumen-tile-etiqueta">Productor</span><span class="resumen-tile-valor">${a.productorNombre || '—'}</span></div>
<div class="resumen-tile"><span class="resumen-tile-etiqueta">Rancho</span><span class="resumen-tile-valor">${a.predio || '—'}</span></div>
<div class="resumen-tile"><span class="resumen-tile-etiqueta">UPP</span><span class="resumen-tile-valor">${a.upp || '—'}</span></div>
<div class="resumen-tile col-span-2"><span class="resumen-tile-etiqueta">Reactores a confirmar</span><span class="resumen-tile-valor">${a.aretesReactores.length} animal(es)</span></div>
${notaExtra ? `<div class="resumen-tile col-span-2" style="background:rgba(239,68,68,0.1); border:1.5px solid var(--red);"><span class="resumen-tile-valor" style="color:var(--red);"><i class="fa-solid fa-rotate"></i> ${notaExtra}</span></div>` : ''}`;
}
}
function obtenerAhoraLocalPCC(){
const d=new Date();
const fecha=d.toISOString().slice(0,10);
const hora=d.toTimeString().slice(0,5);
return {fecha,hora};
}
function sumarHorasPCC(fecha,hora,horas){
if(!fecha || !hora) return null;
const d=new Date(`${fecha}T${hora}:00`);
if(isNaN(d.getTime())) return null;
d.setHours(d.getHours()+horas);
return {fecha:d.toISOString().slice(0,10),hora:d.toTimeString().slice(0,5)};
}
function actualizarMetadatosPCC(){
const aviso=avisoTBEnCaptura ? (estado.avisosReactoresTB||[]).find(x=>x.id===avisoTBEnCaptura) : null;
const fecha=valor('pcc-fecha-aplicacion'), hora=valor('pcc-hora-aplicacion');
if(aviso){ aviso.fechaAplicacionPCC=fecha; aviso.horaAplicacionPCC=hora; aviso.fechaLecturaPCC=valor('pcc-fecha-lectura'); aviso.horaLecturaPCC=valor('pcc-hora-lectura'); }
const salida=sumarHorasPCC(fecha,hora,72);
const el=document.getElementById('pcc-ventana-lectura');
if(el){
  if(salida) el.textContent=`Lectura propuesta: ${fechaDMA(salida.fecha)} ${salida.hora}. Ventana permitida: ± 6 h.`;
  else el.textContent='Captura la fecha y hora de aplicación para proponer automáticamente la lectura a las 72 horas.';
}
if(aviso) guardarEstadoLocal();
}
function inicializarMetadatosPCC(a){
let fecha=a?.fechaAplicacionPCC||'', hora=a?.horaAplicacionPCC||'';
if(!fecha){ const n=obtenerAhoraLocalPCC(); fecha=n.fecha; hora=n.hora; }
const propuesta=sumarHorasPCC(fecha,hora,72);
establecerValor('pcc-fecha-aplicacion',fecha); establecerValor('pcc-hora-aplicacion',hora);
establecerValor('pcc-fecha-lectura',a?.fechaLecturaPCC||propuesta?.fecha||''); establecerValor('pcc-hora-lectura',a?.horaLecturaPCC||propuesta?.hora||'');
actualizarMetadatosPCC();
}
function guardarAvancePCC(){
if(!window._filasPCCActuales || window._filasPCCActuales.length===0){ mostrarToast('Agrega al menos un animal'); return; }
let a=pccModoDirecto ? null : (estado.avisosReactoresTB||[]).find(x=>x.id===avisoTBEnCaptura);
if(pccModoDirecto){
  const nombreProductor=valor('pccd-productor-nombre').trim();
  if(!nombreProductor){ mostrarToast('Escribe el nombre del productor'); return; }
  a={id:'avtb_'+Date.now(),pruebaId:null,productorId:'',productorNombre:nombreProductor,predio:valor('pccd-predio').trim(),upp:valor('pccd-upp').trim(),curp:valor('pccd-curp').trim().toUpperCase(),telefonoProductor:valor('pccd-telefono').trim(),totalHato:window._filasPCCActuales.length,aretesReactores:window._filasPCCActuales.map(f=>({arete:f.arete,especie:'Bovino',edad:f.edad,raza:f.raza,sexo:f.sexo,fierro:f.fierro})),fecha:hoyISO(),estatus:'en_proceso',medicoAsignadoId:estado.medicoComiteActivoId,medicoAsignadoNombre:(estado.medicosComiteTB.find(m=>m.id===estado.medicoComiteActivoId)||{}).nombre||'',fechaAsignacion:hoyISO(),animalesPCC:window._filasPCCActuales,fechaFinalizado:null,folioTB:'',folioHojaCampo:'',consecutivo:'',origenDirecto:true};
  estado.avisosReactoresTB.push(a); avisoTBEnCaptura=a.id; pccModoDirecto=false;
}
if(!a){ mostrarToast('No se encontró la captura de PCC'); return; }
a.animalesPCC=window._filasPCCActuales; a.estatus='en_proceso'; actualizarMetadatosPCC(); guardarEstadoLocal();
const el=document.getElementById('estado-pcc-captura'); if(el){el.textContent='Avance guardado';el.style.background='rgba(22,101,52,.12)';el.style.color='var(--green)';}
mostrarToast('Avance de PCC guardado en el dispositivo. Puedes continuar después.');
}
function abrirCapturaPCC(avisoId){
const a = (estado.avisosReactoresTB || []).find(x => x.id === avisoId);
if (!a) return;
pccModoDirecto = false;
document.getElementById('titulo-capturapcc').textContent = 'Prueba cervical comparativa';
const btnAgregar = document.getElementById('btn-agregar-animal-pcc');
if (btnAgregar) btnAgregar.classList.add('hidden');
const btnGuardar = document.getElementById('btn-guardar-pcc');
if (btnGuardar) btnGuardar.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Guardar y reportar al comité';
avisoTBEnCaptura = avisoId;
if (a.estatus === 'asignado'){ a.estatus = 'en_proceso'; guardarEstadoLocal(); }
renderResumenPropietarioPCC(a);
const cab=document.getElementById('pcc-cabecera-productor'); if(cab) cab.textContent=(a.productorNombre||'Productor') + (a.upp ? ' · UPP '+a.upp : '');
inicializarMetadatosPCC(a);
const datosGuardados = a.animalesPCC || [];
const filas = a.aretesReactores.map((ar, i) => datosGuardados[i] || { arete: ar.arete, especie: ar.especie, edad: ar.edad, raza: ar.raza, sexo: ar.sexo, fierro: ar.fierro, iniA:'', iniB:'', h72A:'', h72B:'', resultado:'', observaciones:'' });
renderFilasPCC(filas);
irAdmin('capturapcc');
}
function calcularSugerenciaResultadoPCC(f){
// La normativa vigente exige interpretar el punto de intersección con la gráfica oficial;
// MiRanch no sustituye esa interpretación con umbrales inventados. Aquí solo indica que
// las cuatro mediciones ya permiten calcular las respuestas A y B.
const n = v => { const x = parseFloat(v); return isNaN(x) ? null : x; };
const iniA=n(f.iniA), h72A=n(f.h72A), iniB=n(f.iniB), h72B=n(f.h72B);
if([iniA,h72A,iniB,h72B].some(x=>x===null)) return '';
return 'Listo para interpretar en gráfica oficial';
}
function renderFilasPCC(filas){
window._filasPCCActuales=filas;
const cont=document.getElementById('lista-animales-pcc'); if(!cont) return;
const completos=filas.filter(f=>f.arete && f.iniA && f.iniB && f.h72A && f.h72B && f.resultado).length;
const prog=document.getElementById('pcc-resumen-progreso'); if(prog) prog.textContent=`${completos} de ${filas.length} animales completos`;
cont.innerHTML=filas.map((f,i)=>{
const n=v=>{const x=parseFloat(v);return isNaN(x)?null:x;};
const dA=(n(f.h72A)!==null&&n(f.iniA)!==null)?(n(f.h72A)-n(f.iniA)).toFixed(1):'';
const dB=(n(f.h72B)!==null&&n(f.iniB)!==null)?(n(f.h72B)-n(f.iniB)).toFixed(1):'';
const diferencia=(dA!==''&&dB!=='')?(parseFloat(dB)-parseFloat(dA)).toFixed(1):'';
const listo=!!(f.arete&&f.iniA&&f.iniB&&f.h72A&&f.h72B);
return `<div class="bg-white rounded-2xl p-3" style="border:2px solid ${listo?'var(--line)':'var(--parchment)'};">
<div class="flex items-center justify-between gap-2"><div><p class="text-xs font-bold" style="color:var(--sage);">ANIMAL ${i+1}</p><p class="font-bold text-lg">${f.arete||'Sin arete'}</p></div><button onclick="eliminarFilaPCC(${i})" style="color:var(--red);" type="button"><i class="fa-solid fa-trash"></i></button></div>
<div class="grid grid-cols-3 gap-2 mt-2"><div><label class="campo-label">Sexo</label><select onchange="actualizarCampoPCC(${i},'sexo',this.value)"><option ${f.sexo==='H'?'selected':''} value="H">Hembra</option><option ${f.sexo==='M'?'selected':''} value="M">Macho</option></select></div><div><label class="campo-label">Edad (meses)</label><input inputmode="numeric" oninput="actualizarCampoPCC(${i},'edad',this.value)" placeholder="Meses" type="text" value="${f.edad||''}"/></div><div><label class="campo-label">Raza</label><input class="campo-mayusculas" oninput="forzarMayusculas(this); actualizarCampoPCC(${i},'raza',this.value)" placeholder="Raza" type="text" value="${f.raza||''}"/></div></div>
<div class="mt-3 rounded-xl p-2" style="background:rgba(22,101,52,.06);"><p class="text-xs font-bold mb-1" style="color:var(--pine);">MEDICIONES · milímetros</p><div class="grid grid-cols-2 gap-2"><div><label class="campo-label">A · inicial</label><input inputmode="decimal" oninput="actualizarCampoPCC(${i},'iniA',this.value)" placeholder="mm" type="number" step="0.1" value="${f.iniA||''}"/></div><div><label class="campo-label">B · inicial</label><input inputmode="decimal" oninput="actualizarCampoPCC(${i},'iniB',this.value)" placeholder="mm" type="number" step="0.1" value="${f.iniB||''}"/></div><div><label class="campo-label">A · lectura</label><input inputmode="decimal" oninput="actualizarCampoPCC(${i},'h72A',this.value)" placeholder="mm" type="number" step="0.1" value="${f.h72A||''}"/></div><div><label class="campo-label">B · lectura</label><input inputmode="decimal" oninput="actualizarCampoPCC(${i},'h72B',this.value)" placeholder="mm" type="number" step="0.1" value="${f.h72B||''}"/></div></div></div>
<div class="grid grid-cols-3 gap-2 mt-2 text-center"><div class="rounded-xl p-2" style="background:var(--parchment);"><span class="text-xs" style="color:var(--sage);">Δ A</span><b class="block">${dA||'—'}</b></div><div class="rounded-xl p-2" style="background:var(--parchment);"><span class="text-xs" style="color:var(--sage);">Δ B</span><b class="block">${dB||'—'}</b></div><div class="rounded-xl p-2" style="background:var(--parchment);"><span class="text-xs" style="color:var(--sage);">B − A</span><b class="block">${diferencia||'—'}</b></div></div>
<div class="mt-2"><label class="campo-label">Interpretación oficial</label><select onchange="actualizarCampoPCC(${i},'resultado',this.value)"><option ${!f.resultado?'selected':''} value="">Pendiente</option><option ${f.resultado==='N'?'selected':''} value="N">N — Negativo</option><option ${f.resultado==='S'?'selected':''} value="S">S — Sospechoso</option><option ${f.resultado==='R'?'selected':''} value="R">R — Positivo/Reactor</option></select></div>
<div class="mt-2"><label class="campo-label">Observaciones</label><input class="campo-mayusculas" oninput="forzarMayusculas(this); actualizarCampoPCC(${i},'observaciones',this.value)" placeholder="Opcional" type="text" value="${f.observaciones||''}"/></div>
</div>`;
}).join('');
}
function eliminarFilaPCC(indice){
if (!window._filasPCCActuales) return;
window._filasPCCActuales.splice(indice, 1);
renderFilasPCC(window._filasPCCActuales);
}
function actualizarCampoPCC(indice, campo, val){
if (!window._filasPCCActuales || !window._filasPCCActuales[indice]) return;
window._filasPCCActuales[indice][campo] = val;
if (['iniA','iniB','h72A','h72B'].includes(campo)) renderFilasPCC(window._filasPCCActuales);
}
function guardarPCC(){
if (!window._filasPCCActuales || window._filasPCCActuales.length === 0){ mostrarToast('Agrega al menos un animal'); return; }
let a;
if (pccModoDirecto){
const nombreProductor = valor('pccd-productor-nombre').trim();
if (!nombreProductor){ mostrarToast('Escribe el nombre del productor'); return; }
const sinArete = window._filasPCCActuales.filter(f => !f.arete || !f.arete.trim());
if (sinArete.length > 0){ mostrarToast('Falta el arete/identificador en ' + sinArete.length + ' animal(es)'); return; }
a = {
id: 'avtb_' + Date.now(), pruebaId: null, productorId: '', productorNombre: nombreProductor,
predio: valor('pccd-predio').trim(), upp: valor('pccd-upp').trim(), curp: valor('pccd-curp').trim().toUpperCase(),
telefonoProductor: valor('pccd-telefono').trim(),
totalHato: window._filasPCCActuales.length, aretesReactores: window._filasPCCActuales.map(f => ({ arete:f.arete, especie:'Bovino', edad:f.edad, raza:f.raza, sexo:f.sexo, fierro:f.fierro })),
fecha: hoyISO(), estatus: 'en_proceso',
medicoAsignadoId: estado.medicoComiteActivoId, medicoAsignadoNombre: (estado.medicosComiteTB.find(m => m.id === estado.medicoComiteActivoId) || {}).nombre || '',
fechaAsignacion: hoyISO(), animalesPCC: null, fechaFinalizado: null,
folioTB: '', folioHojaCampo: '', consecutivo: '',
origenDirecto: true,
};
estado.avisosReactoresTB.push(a);
} else {
a = (estado.avisosReactoresTB || []).find(x => x.id === avisoTBEnCaptura);
if (!a) return;
}
const sinMedir = window._filasPCCActuales.filter(f => !f.arete || !f.iniA || !f.iniB || !f.h72A || !f.h72B || !f.resultado);
if (sinMedir.length > 0){ guardarAvancePCC(); mostrarToast(`No se envió al comité: faltan datos en ${sinMedir.length} animal(es). El avance quedó guardado.`); return; }
actualizarMetadatosPCC();
a.animalesPCC = window._filasPCCActuales;
a.estatus = 'finalizado';
a.fechaFinalizado = hoyISO();
// Si algún animal sigue como reactor después de la prueba confirmatoria, no
// se cierra el caso del todo: entra en cuarentena 2 meses (protocolo oficial
// de TB) antes de poder volver a probarlo. Se guarda la lista de esos
// animales y la fecha en que ya se puede reprogramar la re-prueba.
const siguenReactores = a.animalesPCC.filter(f => f.resultado === 'R');
if (siguenReactores.length > 0){
const fechaFin = new Date(fechaHoy());
fechaFin.setDate(fechaFin.getDate() + 60);
a.animalesEnCuarentena = siguenReactores.map(f => ({ arete: f.arete, especie: f.especie, edad: f.edad, raza: f.raza, sexo: f.sexo, fierro: f.fierro }));
a.fechaFinCuarentena = formatearFechaISO(fechaFin);
a.reProbado = false;
} else {
a.animalesEnCuarentena = null; a.fechaFinCuarentena = null;
}
guardarEstadoLocal();
if (typeof enviarFlujoConReintento === 'function') {
  enviarFlujoConReintento('comite_dgo', a.id, 'reporte_pcc', a, {enviadoPor:'medico_campo_tb', estatus:'finalizado', origenBandeja:'medico_' + (estado.medicoComiteActivoId || '')});
}
mostrarToast(siguenReactores.length > 0 ? `Reportado — ${siguenReactores.length} animal(es) sigue(n) como reactor, entra(n) en cuarentena hasta el ${a.fechaFinCuarentena}` : (pccModoDirecto ? 'Prueba PCC directa registrada y enviada al comité' : 'Prueba cervical comparativa reportada al comité'));
avisoTBEnCaptura = null;
window._filasPCCActuales = null;
pccModoDirecto = false;
const btnAgregarReset = document.getElementById('btn-agregar-animal-pcc');
if (btnAgregarReset) btnAgregarReset.classList.add('hidden');
const btnGuardarReset = document.getElementById('btn-guardar-pcc');
if (btnGuardarReset) btnGuardarReset.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Guardar y reportar al comité';
document.getElementById('titulo-capturapcc').textContent = 'Prueba cervical comparativa';
volverAtrasAdmin('medicocampotb');
}
// Reabre la captura de PCC para los animales que siguen en cuarentena, una vez
// que ya pasaron los 2 meses — genera una nueva ronda de mediciones solo para
// esos animales, sin perder el expediente original del caso.
function iniciarRePruebaCuarentena(avisoId){
const a = (estado.avisosReactoresTB || []).find(x => x.id === avisoId);
if (!a || !a.animalesEnCuarentena || a.animalesEnCuarentena.length === 0) return;
if (hoyISO() < a.fechaFinCuarentena){ mostrarToast('Todavía no se cumplen los 2 meses de cuarentena — no se puede volver a probar antes de ' + a.fechaFinCuarentena); return; }
avisoTBEnCaptura = avisoId;
a.estatus = 'en_proceso';
a.reProbado = true;
renderResumenPropietarioPCC(a, `Re-prueba tras cuarentena — ${a.animalesEnCuarentena.length} animal(es)`);
const filas = a.animalesEnCuarentena.map(ar => ({ arete: ar.arete, especie: ar.especie, edad: ar.edad, raza: ar.raza, sexo: ar.sexo, fierro: ar.fierro, iniA:'', iniB:'', h72A:'', h72B:'', resultado:'', observaciones:'' }));
renderFilasPCC(filas);
guardarEstadoLocal();
irAdmin('capturapcc');
}
// ---- Impresión del dictamen de la Prueba Cervical Comparativa (para la capturista) ----
function filaPCCImpresionHTML(f, i){
const n = v => { const x = parseFloat(v); return isNaN(x) ? null : x; };
const diferencia = (n(f.h72B) !== null && n(f.iniB) !== null && n(f.h72A) !== null && n(f.iniA) !== null) ? ((n(f.h72B) - n(f.iniB)) - (n(f.h72A) - n(f.iniA))).toFixed(1) : '';
return `
<tr>
<td rowspan="2" class="col-id">${f.arete || ''}</td>
<td rowspan="2">${f.edad || ''}</td>
<td rowspan="2">${f.raza || ''}</td>
<td rowspan="2">${f.sexo === 'M' ? 'M' : 'H'}</td>
<td rowspan="2">${f.fierro || ''}</td>
<td>A</td><td>${f.iniA || ''}</td><td>${f.h72A || ''}</td><td rowspan="2">${diferencia}</td>
<td rowspan="2">${f.resultado || ''}</td>
<td rowspan="2">${f.observaciones || ''}</td>
</tr>
<tr><td>B</td><td>${f.iniB || ''}</td><td>${f.h72B || ''}</td></tr>`;
}
function generarPaginaPCCHTML(aviso){
const filas = aviso.animalesPCC || [];
return `<div class="hoja-senasica hoja-oficial">
<div class="encabezado-senasica">
<div class="logo-senasica">🇲🇽<br>SADER</div>
<div class="titulo-central">
<h1>SERVICIO NACIONAL DE SANIDAD, INOCUIDAD Y CALIDAD AGROALIMENTARIA</h1>
<h2>DIRECCIÓN GENERAL DE SALUD ANIMAL</h2>
<h2 class="fuerte">CAMPAÑA NACIONAL CONTRA TUBERCULOSIS BOVINA</h2>
<h2 class="fuerte">CONTROL DE CAMPO — PRUEBA CERVICAL COMPARATIVA</h2>
</div>
<div class="logo-senasica">SENASICA</div>
</div>
<div class="caja-folios">
<div><span>FOLIO TB</span><b>${aviso.folioTB || ''}</b></div>
<div><span>FOLIO HOJA DE CAMPO</span><b>${aviso.folioHojaCampo || ''}</b></div>
<div><span>CONSECUTIVO</span><b>${aviso.consecutivo || ''}</b></div>
</div>
<div style="clear:both;"></div>
<div class="seccion-dictamen">
<div class="titulo-seccion">I. PROPIETARIO</div>
<div class="fila-campos">
<div class="campo-dictamen"><span class="etiqueta">Apellido paterno</span><span class="valor">${aviso.apellidoPaterno || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Apellido materno</span><span class="valor">${aviso.apellidoMaterno || ''}</span></div>
<div class="campo-dictamen" style="flex:2;"><span class="etiqueta">Nombre(s)</span><span class="valor">${aviso.nombres || aviso.productorNombre || ''}</span></div>
</div>
<div class="fila-campos">
<div class="campo-dictamen" style="flex:2;"><span class="etiqueta">Domicilio</span><span class="valor">${aviso.domicilio || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Municipio</span><span class="valor">${aviso.municipio || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Localidad/Población</span><span class="valor">${aviso.localidad || ''}</span></div>
</div>
</div>
<div class="seccion-dictamen">
<div class="titulo-seccion">II. UNIDAD DE PRODUCCIÓN</div>
<div class="fila-campos">
<div class="campo-dictamen" style="flex:2;"><span class="etiqueta">Nombre de la unidad de producción o predio</span><span class="valor">${aviso.predio || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Clave UPP</span><span class="valor">${aviso.upp || ''}</span></div>
</div>
</div>
<div class="seccion-dictamen">
<div class="titulo-seccion">III. MÉDICO DE CAMPO ASIGNADO</div>
<div class="fila-campos">
<div class="campo-dictamen"><span class="etiqueta">Nombre</span><span class="valor">${aviso.medicoAsignadoNombre || ''}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Fecha de asignación</span><span class="valor">${fechaDMA(aviso.fechaAsignacion)}</span></div>
<div class="campo-dictamen"><span class="etiqueta">Fecha de reporte</span><span class="valor">${fechaDMA(aviso.fechaFinalizado)}</span></div>
</div>
</div>
<div class="seccion-dictamen">
<div class="titulo-seccion">IV. RESULTADOS — PRUEBA CERVICAL COMPARATIVA</div>
<table class="tabla-resultados">
<thead><tr>
<th rowspan="2">IDENTIFICACIÓN OFICIAL/ SINIIGA</th><th rowspan="2">EDAD<br>(meses)</th><th rowspan="2">RAZA</th><th rowspan="2">SEXO</th><th rowspan="2">FIERRO</th>
<th colspan="3">TUBERCULINA</th><th rowspan="2">DIFEREN­CIA</th><th rowspan="2">RESULT.<br>N/S/R</th><th rowspan="2">OBSERVACIONES</th>
</tr>
<tr><th style="font-size:5.6pt;">Pliegue</th><th style="font-size:5.6pt;">Medida inicial</th><th style="font-size:5.6pt;">Medida 72h</th></tr>
</thead>
<tbody>${filas.map((f,i) => filaPCCImpresionHTML(f,i)).join('')}</tbody>
</table>
</div>
${pieFirmaDictamenOficialHTML({ veterinarioNombre: aviso.medicoAsignadoNombre || '' }, false)}
</div>`;
}
function abrirVistaPreviaDictamenPCC(avisoId){
const aviso = (estado.avisosReactoresTB || []).find(a => a.id === avisoId);
if (!aviso) return;
const ventana = window.open('', '_blank');
if (!ventana){ mostrarToast('Tu navegador bloqueó la ventana emergente — permite pop-ups para imprimir'); return; }
ventana.document.write(`<html><head><title>Dictamen PCC — ${(aviso.productorNombre || '').replace(/</g,'')}</title>${estilosDictamenSenasica()}${estilosDictamenOficial()}</head><body>
<div class="controles-vista-previa"><button onclick="window.print()"><i class="fa-solid fa-print"></i> Imprimir / Guardar como PDF</button><button onclick="window.close()" style="background:#8a3b3b;">Cerrar</button></div>
${generarPaginaPCCHTML(aviso)}
</body></html>`);
ventana.document.close();
ventana.focus();
}
function contarReactores(p){
return (p.animales || []).filter(a => a.resultado === 'R').length;
}
function exportarReporteReactores(id){
const p = estado.pruebasCampoVet.find(x => x.id === id);
if (!p) return;
const reactores = p.animales.filter(a => a.resultado === 'R');
if (reactores.length === 0){ mostrarToast('Esta prueba no tiene animales reactores'); return; }
const encabezadosReales = ['Productor','Predio','UPP','CURP','Veterinario','Fecha de la prueba','Identificación','Especie','Edad','Sexo','Raza','Fierro','Tipo de prueba'];
const filas = reactores.map(a => [p.productorNombre, p.predio, p.upp, p.curp || '', p.veterinarioNombre || '', p.fecha, a.arete, a.especie, a.edad, a.sexo, a.raza, a.fierro || '', p.tipoPrueba]);
generarCSVConPie(`Reporte de reactores - ${p.tipoPrueba} - ${p.productorNombre} - ${p.fecha}`, encabezadosReales, filas);
mostrarToast('Reporte de reactores generado — envíalo junto con la hoja de campo digital');
}


  window['fechaDMA'] = fechaDMA;
  window['estilosDictamenSenasica'] = estilosDictamenSenasica;
  window['filaResultadoDictamenHTML'] = filaResultadoDictamenHTML;
  window['tablaResultadosDictamenHTML'] = tablaResultadosDictamenHTML;
  window['pieFirmaDictamenHTML'] = pieFirmaDictamenHTML;
  window['paginaPortadaDictamenHTML'] = paginaPortadaDictamenHTML;
  window['paginaComplementariaDictamenHTML'] = paginaComplementariaDictamenHTML;
  window['generarPaginasDictamenHTML'] = generarPaginasDictamenHTML;
  window['abrirVistaPreviaDictamen'] = abrirVistaPreviaDictamen;
  window['estilosDictamenOficial'] = estilosDictamenOficial;
  window['celdaValorAnimalOficial'] = celdaValorAnimalOficial;
  window['miniTablaResultadosOficialHTML'] = miniTablaResultadosOficialHTML;
  window['tablaResultadosDobleHTML'] = tablaResultadosDobleHTML;
  window['pieFirmaDictamenOficialHTML'] = pieFirmaDictamenOficialHTML;
  window['paginaPortadaDictamenTBHTML'] = paginaPortadaDictamenTBHTML;
  window['paginaComplementariaDictamenTBHTML'] = paginaComplementariaDictamenTBHTML;
  window['paginaPortadaDictamenBRHTML'] = paginaPortadaDictamenBRHTML;
  window['paginaComplementariaDictamenBRHTML'] = paginaComplementariaDictamenBRHTML;
  window['generarPaginasDictamenOficialHTML'] = generarPaginasDictamenOficialHTML;
  window['abrirVistaPreviaDictamenTB'] = abrirVistaPreviaDictamenTB;
  window['abrirVistaPreviaDictamenBR'] = abrirVistaPreviaDictamenBR;
  window['generarAvisoReactoresTB'] = generarAvisoReactoresTB;
  window['cambiarTabVentanaTB'] = cambiarTabVentanaTB;
  window['cambiarTabComiteCEFPP'] = cambiarTabComiteCEFPP;
  window['actualizarBadgesComiteCEFPP'] = actualizarBadgesComiteCEFPP;
  window['renderAvisosReactoresTB'] = renderAvisosReactoresTB;
  window['abrirModalAsignarMedicoTB'] = abrirModalAsignarMedicoTB;
  window['elegirMedicoParaAsignar'] = elegirMedicoParaAsignar;
  window['cerrarModalAsignarMedicoTB'] = cerrarModalAsignarMedicoTB;
  window['confirmarAsignarMedicoTB'] = confirmarAsignarMedicoTB;
  window['agregarMedicoComiteTB'] = agregarMedicoComiteTB;
  window['eliminarMedicoComiteTB'] = eliminarMedicoComiteTB;
  window['renderMedicosComiteTB'] = renderMedicosComiteTB;
  window['renderInformesRecibidosComiteTB'] = renderInformesRecibidosComiteTB;
  window['renderCasosMedicoCampoTB'] = renderCasosMedicoCampoTB;
  window['categoriaTB'] = categoriaTB;
  window['renderReportesTB'] = renderReportesTB;
  window['renderGenerarInformeTB'] = renderGenerarInformeTB;
  window['abrirPCCDirecta'] = abrirPCCDirecta;
  window['agregarFilaVaciaPCC'] = agregarFilaVaciaPCC;
  window['renderResumenPropietarioPCC'] = renderResumenPropietarioPCC;
  window['abrirCapturaPCC'] = abrirCapturaPCC;
  window['calcularSugerenciaResultadoPCC'] = calcularSugerenciaResultadoPCC;
  window['renderFilasPCC'] = renderFilasPCC;
  window['eliminarFilaPCC'] = eliminarFilaPCC;
  window['actualizarCampoPCC'] = actualizarCampoPCC;
  window['guardarPCC'] = guardarPCC;
  window['guardarAvancePCC'] = guardarAvancePCC;
  window['actualizarMetadatosPCC'] = actualizarMetadatosPCC;
  window['iniciarRePruebaCuarentena'] = iniciarRePruebaCuarentena;
  window['filaPCCImpresionHTML'] = filaPCCImpresionHTML;
  window['generarPaginaPCCHTML'] = generarPaginaPCCHTML;
  window['abrirVistaPreviaDictamenPCC'] = abrirVistaPreviaDictamenPCC;
  window['contarReactores'] = contarReactores;
  window['exportarReporteReactores'] = exportarReporteReactores;
  Object.defineProperty(window, 'avisoTBEnCaptura', { configurable:true, get:()=>avisoTBEnCaptura, set:(valor)=>{ avisoTBEnCaptura=valor; } });
})();
