(function(){
/* MiRanch — módulo de voz cargado bajo demanda. */
// ============================================================
// ===== SISTEMA GLOBAL DE COMANDOS DE VOZ (Web Speech API) =====
// ============================================================
// IMPORTANTE — límites reales de esta tecnología (léase antes de tocar nada):
// 1) NO es offline de verdad: SpeechRecognition en la gran mayoría de
//    navegadores (Chrome incluido) manda el audio a servidores de Google para
//    reconocerlo — funciona sin costo y sin API key propia, pero necesita
//    internet en el momento de dictar.
// 2) Plautdietsch no es un idioma que ningún motor de voz reconozca de forma
//    nativa. Aquí se usa el reconocedor en alemán estándar (de-DE) como base y
//    se traduce por un diccionario fonético — es un mejor-esfuerzo, no una
//    solución exacta: el alemán estándar va a "enderezar" palabras del
//    dialecto a su aproximación más cercana, y el diccionario de abajo
//    necesita que alguien que hable el dialecto lo revise y lo amplíe.
const CONFIG_VOZ = {
idiomaReconocimiento: 'es-MX', // cambiar a 'de-DE' con activarModoPlautdietschVoz()
};
function activarModoPlautdietschVoz(activar){
CONFIG_VOZ.idiomaReconocimiento = activar ? 'de-DE' : 'es-MX';
try { localStorage.setItem('miRanchAppVozIdioma', CONFIG_VOZ.idiomaReconocimiento); } catch(e){}
}
try {
const guardado = localStorage.getItem('miRanchAppVozIdioma');
if (guardado) CONFIG_VOZ.idiomaReconocimiento = guardado;
} catch(e){}

// ---- Tono auditivo corto al empezar a escuchar (Web Audio API) ----
let vozAudioCtx = null;
function tonoInicioEscucha(){
try {
if (!vozAudioCtx) vozAudioCtx = new (window.AudioContext || window.webkitAudioContext)();
const ctx = vozAudioCtx;
if (ctx.state === 'suspended') ctx.resume();
const osc = ctx.createOscillator();
const gain = ctx.createGain();
osc.type = 'sine';
osc.frequency.setValueAtTime(880, ctx.currentTime);
gain.gain.setValueAtTime(0, ctx.currentTime);
gain.gain.linearRampToValueAtTime(0.15, ctx.currentTime + 0.02);
gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.18);
osc.connect(gain); gain.connect(ctx.destination);
osc.start(); osc.stop(ctx.currentTime + 0.2);
} catch(e){}
}

// ---- Texto a voz (confirmación / error / instrucciones) ----
function decirEnVoz(texto){
try {
if (!('speechSynthesis' in window)) return;
const u = new SpeechSynthesisUtterance(texto);
u.lang = CONFIG_VOZ.idiomaReconocimiento === 'de-DE' ? 'de-DE' : 'es-MX';
u.rate = 1;
window.speechSynthesis.cancel();
window.speechSynthesis.speak(u);
} catch(e){}
}

// ---- Estados visuales del botón ----
function estadoVisualVoz(estadoNuevo){
const boton = document.getElementById('fab-comando-voz');
const icono = document.getElementById('fab-voz-icono');
const anillo = document.getElementById('fab-voz-anillo');
const etiqueta = document.getElementById('fab-voz-etiqueta');
if (!boton) return;
boton.classList.remove('voz-escuchando', 'voz-exito', 'voz-error', 'voz-sin-conexion');
anillo.classList.remove('escuchando');
function mostrarEtiqueta(texto, ocultarDespues){
if (!etiqueta) return;
etiqueta.textContent = texto;
etiqueta.style.opacity = '1';
etiqueta.style.transform = 'translateX(0)';
if (ocultarDespues) setTimeout(() => { etiqueta.style.opacity = '0'; etiqueta.style.transform = 'translateX(-6px)'; }, ocultarDespues);
}
if (estadoNuevo === 'escuchando'){
boton.classList.add('voz-escuchando');
anillo.classList.add('escuchando');
icono.className = 'fa-solid fa-microphone-lines';
mostrarEtiqueta('Escuchando…');
} else if (estadoNuevo === 'procesando'){
icono.className = 'fa-solid fa-circle-notch fa-spin';
mostrarEtiqueta('Procesando…');
} else if (estadoNuevo === 'exito'){
boton.classList.add('voz-exito');
icono.className = 'fa-solid fa-check';
mostrarEtiqueta('¡Listo!', 1600);
setTimeout(() => estadoVisualVoz('inactivo'), 1600);
} else if (estadoNuevo === 'error'){
boton.classList.add('voz-error');
icono.className = 'fa-solid fa-triangle-exclamation';
mostrarEtiqueta('No entendí', 1600);
setTimeout(() => estadoVisualVoz('inactivo'), 1600);
} else if (estadoNuevo === 'sinConexion'){
boton.classList.add('voz-sin-conexion');
icono.className = 'fa-solid fa-microphone-slash';
mostrarEtiqueta('Sin señal', 1800);
} else {
icono.className = 'fa-solid fa-microphone';
if (etiqueta){ etiqueta.textContent = 'Toca y habla'; etiqueta.style.opacity = '0'; etiqueta.style.transform = 'translateX(-6px)'; }
// Si sigue sin haber conexión, el botón se queda gris en vez de volver al
// color normal — refleja de un vistazo que la voz no va a responder ahorita.
if (!navigator.onLine) boton.classList.add('voz-sin-conexion');
}
}
// Mantiene el botón de voz gris mientras no haya señal (no solo cuando se
// toca) y lo regresa a la normalidad en cuanto vuelve la conexión — para que
// se note de un vistazo, sin tener que tocarlo primero para enterarse.
function actualizarBotonVozSegunConexion(){
if (reconocimientoVozActivo) return; // no cambiar el aspecto a medio dictado
estadoVisualVoz(navigator.onLine ? 'inactivo' : 'sinConexion');
}
window.addEventListener('online', actualizarBotonVozSegunConexion);
window.addEventListener('offline', actualizarBotonVozSegunConexion);

// ---- Reconocimiento de voz ----
let reconocimientoVozActivo = null;
// ---- Voz por "mantener presionado" ----
// Antes, el botón alternaba: un toque empezaba a escuchar, y el propio
// navegador cortaba solo apenas detectaba CUALQUIER pausa natural al hablar
// — si la persona hacía una pausa breve a medio pensamiento (ej. "arete 2235
// [pausa] dale indicación a un trabajador de que lo revise"), el navegador
// procesaba solo el primer pedazo como si fuera el comando completo,
// guardando algo que nunca se terminó de decir. Ahora el botón graba
// mientras se mantiene presionado (con el dedo o el mouse) y solo procesa
// TODO junto hasta que se suelta — una pausa breve al hablar ya no corta ni
// guarda nada a medias.
let vozAcumuladaContinua = '';
let botonVozPresionado = false;
function iniciarEscuchaContinua(reinicioAutomatico){
// Los comandos de voz (Web Speech API) mandan el audio a servidores de
// Google para reconocerlo — NO funcionan sin conexión. Antes, si la persona
// hablaba sin señal, simplemente no pasaba nada y no se sabía por qué. Ahora
// se avisa de una vez y no se abre el micrófono, para no hacerla perder
// tiempo hablando en balde.
if (!reinicioAutomatico){
if (!navigator.onLine){
mostrarToast('Comandos de voz necesitan señal — usa el formulario normal mientras tanto');
estadoVisualVoz('sinConexion');
return;
}
botonVozPresionado = true;
}
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
if (!SR){ mostrarToast('Este navegador no tiene reconocimiento de voz disponible'); return; }
if (reconocimientoVozActivo) return; // ya se está grabando, no abrir dos veces
if (!reinicioAutomatico) vozAcumuladaContinua = '';
const rec = new SR();
rec.lang = CONFIG_VOZ.idiomaReconocimiento;
// Le pasamos las palabras del rancho de antemano — ayuda a que el propio
// reconocedor las entienda bien desde el inicio, no solo a corregirlas
// después de transcribirlas mal.
const gramaticaRancho = construirGramaticaVozRancho();
if (gramaticaRancho) rec.grammars = gramaticaRancho;
rec.continuous = true; // no se corta solo por una pausa — sigue escuchando hasta que se suelte el botón
rec.interimResults = true; // muestra en pantalla lo que se va escuchando, no solo hasta que se suelte el botón
rec.maxAlternatives = 1;
reconocimientoVozActivo = rec;
rec.onstart = () => { estadoVisualVoz('escuchando'); if (!reinicioAutomatico) tonoInicioEscucha(); };
rec.onresult = evt => {
// Con continuous=true pueden llegar varios resultados mientras se sigue
// presionando el botón (uno por cada pausa breve que el navegador nota) —
// se van juntando en vez de procesar cada pedazo por separado.
let interino = '';
for (let i = evt.resultIndex; i < evt.results.length; i++){
if (evt.results[i].isFinal){
vozAcumuladaContinua += (vozAcumuladaContinua ? ' ' : '') + (evt.results[i][0].transcript || '');
} else {
interino += evt.results[i][0].transcript || '';
}
}
// Muestra en la etiqueta del botón lo que se lleva escuchado hasta ahora
// (definitivo + lo que todavía se está reconociendo), para que la persona
// vea en tiempo real que sí se está captando lo que dice.
const etiqueta = document.getElementById('fab-voz-etiqueta');
if (etiqueta){
const vistaPrevia = (vozAcumuladaContinua + ' ' + interino).trim();
if (vistaPrevia){
etiqueta.textContent = vistaPrevia.length > 40 ? '…' + vistaPrevia.slice(-40) : vistaPrevia;
etiqueta.style.opacity = '1'; etiqueta.style.transform = 'translateX(0)';
}
}
};
rec.onerror = evt => {
if (evt.error === 'no-speech') return; // con "mantener presionado" esto es normal mientras la persona respira/piensa, no es un error real
// "aborted" pasa cuando el propio navegador corta la sesión sola (el
// límite de tiempo típico de Android/Chrome) — no es un error real del
// usuario, así que no se avisa ni se trata como fallo; onend se encarga
// de reiniciar solo si el dedo sigue en el botón.
if (evt.error === 'aborted') return;
estadoVisualVoz('error');
if (evt.error === 'not-allowed' || evt.error === 'permission-denied') mostrarToast('Falta permiso del micrófono — actívalo en los ajustes del navegador');
else mostrarToast('No se pudo usar el micrófono — revisa tu conexión e inténtalo de nuevo');
reconocimientoVozActivo = null;
};
rec.onend = () => {
reconocimientoVozActivo = null;
// El navegador (sobre todo Android/Chrome) suele cortar el reconocimiento
// solo cada pocos segundos, aunque continuous esté en true — es una
// limitación conocida de esta tecnología, no un error. Si el dedo TODAVÍA
// está en el botón cuando esto pasa, se reinicia de inmediato una sesión
// nueva SIN procesar nada todavía — lo que ya se llevaba escuchado se
// conserva y se le sigue agregando, para que la persona nunca note el
// corte ni tenga que volver a empezar.
if (botonVozPresionado){
setTimeout(() => iniciarEscuchaContinua(true), 60);
return;
}
// Esto se dispara tanto si la persona soltó el botón como si el navegador
// cerró solo — en los dos casos se procesa lo que se alcanzó a juntar.
const textoFinal = vozAcumuladaContinua.trim();
vozAcumuladaContinua = '';
if (textoFinal){
estadoVisualVoz('procesando');
procesarComandoVoz(textoFinal);
} else {
estadoVisualVoz('inactivo');
}
};
try { rec.start(); } catch(e){ estadoVisualVoz('error'); reconocimientoVozActivo = null; }
}
function detenerEscuchaContinua(){
botonVozPresionado = false;
if (reconocimientoVozActivo){ try { reconocimientoVozActivo.stop(); } catch(e){} }
}

// ---- Diccionario fonético Plautdietsch → palabras clave internas ----
// Base de arranque, revisada por Luis según su comunidad — el reconocedor
// alemán (de-DE) va a "enderezar" el dialecto a su aproximación más cercana en
// alemán estándar, así que aquí se mapean tanto formas en Plautdietsch como en
// alemán estándar hacia las mismas palabras clave en español que usa el parser.
const DICCIONARIO_PLAUTDIETSCH = {
// acciones
'wajcht': 'peso', 'gewicht': 'peso', 'wieren': 'peso',
'kult': 'vacuna', 'sprute': 'vacuna', 'medizin': 'tratamiento', 'spratse': 'vacuna', 'impfe': 'vacuna',
'schluv': 'potrero', 'weid': 'potrero', 'wees': 'potrero', 'kroal': 'corral',
'foul': 'parto', 'jeborne': 'nacimiento', 'geburt': 'nacimiento',
// crías y ganado
'kalf': 'becerro', 'kjalw': 'becerro', 'kalfkje': 'becerro', 'koo': 'vaca',
// diagnósticos
'tbc': 'tuberculosis',
// sexo de la cría
'faarsch': 'hembra', 'kuh': 'hembra', 'wajefe': 'hembra',
'boll': 'macho', 'oss': 'macho', 'stea': 'macho',
// unidades
'kilo': 'kilos', 'kilogramm': 'kilos',
// dígitos en alemán (para cuando el número se dicta en palabras)
'null':'0','eins':'1','ein':'1','eine':'1','zwei':'2','drei':'3','vier':'4','fünf':'5','funf':'5',
'sechs':'6','sieben':'7','acht':'8','neun':'9','zehn':'10',
'elf':'11','zwölf':'12','zwolf':'12','dreizehn':'13','vierzehn':'14','fünfzehn':'15','funfzehn':'15',
'sechzehn':'16','siebzehn':'17','achtzehn':'18','neunzehn':'19','zwanzig':'20',
'dreißig':'30','dreissig':'30','vierzig':'40','fünfzig':'50','funfzig':'50',
'sechzig':'60','siebzig':'70','achtzig':'80','neunzig':'90','hundert':'100',
};
function traducirDesdePlautdietsch(texto){
let palabras = texto.toLowerCase().split(/\s+/);
palabras = palabras.map(p => DICCIONARIO_PLAUTDIETSCH[p] || p);
return palabras.join(' ');
}

// ---- Números dictados como palabras ("cuatrocientos cincuenta" -> "450") ----
// Google suele transcribir los números que se dictan como dígitos, pero no
// siempre — sobre todo con números compuestos dichos rápido o con acento
// marcado. Este conversor cubre 0-999, que es más que suficiente para arete y
// kilos en un rancho.
const UNIDADES_ES = {'cero':0,'uno':1,'dos':2,'tres':3,'cuatro':4,'cinco':5,'seis':6,'siete':7,'ocho':8,'nueve':9,
'diez':10,'once':11,'doce':12,'trece':13,'catorce':14,'quince':15,
'dieciseis':16,'dieciséis':16,'diecisiete':17,'dieciocho':18,'diecinueve':19,'veinte':20,
'veintiuno':21,'veintiún':21,'veintidos':22,'veintidós':22,'veintitres':23,'veintitrés':23,'veinticuatro':24,'veinticinco':25,
'veintiseis':26,'veintiséis':26,'veintisiete':27,'veintiocho':28,'veintinueve':29};
const DECENAS_ES = {'treinta':30,'cuarenta':40,'cincuenta':50,'sesenta':60,'setenta':70,'ochenta':80,'noventa':90};
const CENTENAS_ES = {'cien':100,'ciento':100,'doscientos':200,'doscientas':200,'trescientos':300,'trescientas':300,
'cuatrocientos':400,'cuatrocientas':400,'quinientos':500,'quinientas':500,'seiscientos':600,'seiscientas':600,
'setecientos':700,'setecientas':700,'ochocientos':800,'ochocientas':800,'novecientos':900,'novecientas':900};
function convertirNumerosEspanolADigitos(texto){
const tokens = texto.split(/\s+/);
const resultado = [];
let i = 0;
while (i < tokens.length){
const limpio = tokens[i].toLowerCase().replace(/[.,]/g, '');
const esCentena = CENTENAS_ES[limpio] !== undefined;
const esDecena = DECENAS_ES[limpio] !== undefined;
const esUnidad = UNIDADES_ES[limpio] !== undefined;
if (!esCentena && !esDecena && !esUnidad){ resultado.push(tokens[i]); i++; continue; }
let valor = 0;
if (esCentena){
valor = CENTENAS_ES[limpio]; i++;
let sig = tokens[i] ? tokens[i].toLowerCase().replace(/[.,]/g, '') : '';
if (DECENAS_ES[sig] !== undefined){
valor += DECENAS_ES[sig]; i++;
sig = tokens[i] ? tokens[i].toLowerCase() : '';
if (sig === 'y'){ i++; sig = tokens[i] ? tokens[i].toLowerCase().replace(/[.,]/g, '') : ''; }
if (UNIDADES_ES[sig] !== undefined){ valor += UNIDADES_ES[sig]; i++; }
} else if (UNIDADES_ES[sig] !== undefined){ valor += UNIDADES_ES[sig]; i++; }
} else if (esDecena){
valor = DECENAS_ES[limpio]; i++;
let sig = tokens[i] ? tokens[i].toLowerCase() : '';
if (sig === 'y'){ i++; sig = tokens[i] ? tokens[i].toLowerCase().replace(/[.,]/g, '') : ''; }
sig = sig.replace(/[.,]/g, '');
if (UNIDADES_ES[sig] !== undefined){ valor += UNIDADES_ES[sig]; i++; }
} else {
valor = UNIDADES_ES[limpio]; i++;
}
resultado.push(String(valor));
}
return resultado.join(' ');
}

// ---- Búsqueda difusa de nombres (productor/trabajador) con Fuse.js ----
// Antes se buscaba coincidencia exacta de palabras del nombre contra la
// frase dictada — fallaba seguido con acentos marcados o si el reconocedor de
// voz transcribía el nombre un poco distinto. Fuse.js compara qué tan
// PARECIDO es cada nombre real (no una coincidencia perfecta), probando
// contra ventanas de 1 a 3 palabras de la frase dictada.
function buscarPersonaFuzzy(texto, lista, obtenerNombre){
if (!lista || lista.length === 0) return null;
// Fuse.js solo hace falta para esta búsqueda por voz — se manda a descargar
// en segundo plano la primera vez que se necesita (sin bloquear esta
// búsqueda: si aún no llegó, se usa el respaldo de coincidencia exacta de
// abajo, y las próximas veces ya la encuentra cargada).
cargarFuseSiNecesario().catch(() => {});
if (typeof Fuse === 'undefined'){
// Respaldo si Fuse.js no cargó (sin conexión la primera vez, etc.):
// coincidencia exacta de palabras, igual que antes.
const textoNorm = texto.toLowerCase();
let mejor = null, posicion = -1;
lista.forEach(p => {
const primerNombre = (obtenerNombre(p) || '').trim().split(/\s+/)[0];
if (!primerNombre || primerNombre.length < 3) return;
const idx = textoNorm.indexOf(primerNombre.toLowerCase());
if (idx !== -1 && (posicion === -1 || idx < posicion)){ mejor = p; posicion = idx; }
});
return mejor ? { persona: mejor, posicion, largo: obtenerNombre(mejor).trim().split(/\s+/)[0].length } : null;
}
const items = lista.map(p => ({ ref: p, nombreNorm: (obtenerNombre(p) || '').toLowerCase() }));
const fuse = new Fuse(items, { keys: ['nombreNorm'], threshold: 0.4, includeScore: true });
const palabras = texto.toLowerCase().split(/\s+/);
let mejor = null;
for (let tam = 1; tam <= 3; tam++){
for (let i = 0; i + tam <= palabras.length; i++){
const ventana = palabras.slice(i, i + tam).join(' ');
if (ventana.length < 3) continue;
const resultados = fuse.search(ventana);
if (resultados.length && (!mejor || resultados[0].score < mejor.score)){
mejor = { item: resultados[0].item.ref, score: resultados[0].score, ventana };
}
}
}
if (!mejor || mejor.score > 0.4) return null;
const posicion = texto.toLowerCase().indexOf(mejor.ventana);
return { persona: mejor.item, posicion: posicion === -1 ? 0 : posicion, largo: mejor.ventana.length };
}

// ---- Parser de reglas (expresiones regulares) ----
const REGLAS_COMANDO_VOZ = [
{
tipo: 'pesaje',
patron: /\d+.*?(?:kilo|kilos|kg)|(?:kilo|kilos|kg).*?\d+/i,
extraer: m => {
const texto = m.input;
const pesoMatch = texto.match(/(\d+(?:[.,]\d+)?)\s*(?:kilo|kilos|kg)/i);
const peso = pesoMatch ? parseFloat(pesoMatch[1].replace(',', '.')) : null;
const numeros = (texto.match(/\d+/g) || []).filter(n => !pesoMatch || n !== pesoMatch[1]);
return { arete: numeros[0] || null, peso };
},
ejemplo: 'Peso arete 402 450 kilos / El toro 205 pesó 480 kilos',
},
{
tipo: 'sanidad',
patron: /\b(?:vacun\w*|trat\w*|desparasit\w*|cur[oó]\w*|cura\w*|inyect\w*|medic[oó]\w*|medica\w*|desinfect\w*|purg[oó]\w*|purga\w*|ba[ñn][oó]\w*|ba[ñn]a\w*|fumig\w*|castr\w*|coje[oó]\w*|cojea\w*|enferm[oó](?![a-záéíóúñ])|enferma\w*|atend\w*|mastitis|abort[oó]\w*|muela)/i,
extraer: m => {
const texto = m.input;
const numeros = texto.match(/\d+/g) || [];
const prodMatch = texto.match(/\bcon\s+([a-zA-Zñáéíóú0-9 ]+)/i);
return { arete: numeros[0] || null, producto: prodMatch ? prodMatch[1].trim() : null };
},
ejemplo: 'Vacuna arete 205 con Ivermectina / La 55 está cojeando',
},
{
tipo: 'potrero',
patron: /^(?!.*\b(?:env[ií]a(le)?|manda(le)?|dile|ind[ií]ca(le)?|av[ií]sa(le)?|comun[ií]ca(le)?|encarg\w*|p[ií]de(le)?|record\w*|recu[eé]rd\w*)\b).*\b(?:mov\w*|pasa\w*|p[aá]sale|cambi\w*|llev\w*|traslad\w*|sac[oó]|saca\w*|met[eió]|mete\w*|encerr\w*|arre[oó]|arrea\w*|jal[oó]|jala\w*|suelt[oa]|suelta\w*|junt[oó]|junta\w*|re[uú]n[eió]|reune\w*|reúne\w*|regres[oó]|regresa\w*|separ\w*|anda en|se fue|est[aá] en|potrero|corral|cuarentena|b[aá]scula|bodega|parideras|embarcadero)\b/is,
extraer: m => {
const texto = m.input;
const numeros = texto.match(/\d+/g) || [];
const destMatch = texto.match(/(?:potrero|corral)\s*([a-zA-Zñáéíóú0-9 ]+)/i);
const destinoFijo = texto.match(/\b(cuarentena|b[aá]scula|bodega|parideras|embarcadero)\b/i);
const destino = destMatch ? destMatch[1].trim() : (destinoFijo ? destinoFijo[1] : (numeros[1] || ''));
return { arete: numeros[0] || null, potrero: destino };
},
ejemplo: 'Pasa la 88 al potrero Norte / La vaca 12 se fue al corral 3',
},
{
tipo: 'parto',
patron: /\b(?:parto|nacimiento)\b|\bnaci[oó](?![a-záéíóúñ])|\bpari[oó](?![a-záéíóúñ])|\balumbr\w*|dio a luz|tuvo (?:un|una|su) (?:cr[ií]a|becerr[oa]|terner[oa])/i,
extraer: m => {
const texto = m.input;
const numeros = texto.match(/\d+/g) || [];
const sexoMatch = texto.match(/\b(macho|hembra)\b/i);
return { areteMadre: numeros[0] || null, sexo: sexoMatch ? sexoMatch[1].toLowerCase() : null };
},
ejemplo: 'Parto arete madre 88 hembra / La 45 parió una hembra',
},
{
tipo: 'leche',
patron: /\b(orde[ñn]\w*|litro|litros)\b/i,
extraer: m => {
const texto = m.input;
const litrosMatch = texto.match(/(\d+(?:[.,]\d+)?)\s*litro/i);
const litros = litrosMatch ? parseFloat(litrosMatch[1].replace(',', '.')) : null;
const numeros = texto.match(/\d+/g) || [];
const arete = numeros.find(n => n !== (litrosMatch ? litrosMatch[1] : null)) || null;
const esTarde = /\btarde\b/i.test(texto);
const esManana = /\bma[ñn]ana\b/i.test(texto);
return { arete, litros, turno: esTarde ? 'PM' : (esManana ? 'AM' : null), fecha: interpretarFechaRelativaVoz(texto) };
},
ejemplo: 'La vaca 12 dio 8 litros en la mañana / Ordeñé 6 litros a la 45',
},
{
tipo: 'servicio',
patron: /\b(?:mont[eaéó]\w*|monta\b|servici[oó]\w*|inseminé\w*|inseminaci[oó]n|cubri[oó]\w*|cubre\b)/i,
extraer: m => {
const texto = m.input;
const numeros = texto.match(/\d+/g) || [];
const tipoServicio = /insemin/i.test(texto) ? 'inseminacion_artificial' : 'monta_directa';
const toroMatch = texto.match(/(?:con|pajilla)\s+(?:el\s+)?(?:toro\s+)?([a-zA-Zñáéíóú0-9 ]+?)(?:\s+el\s|\s*$)/i);
return { arete: numeros[0] || null, toro: toroMatch ? toroMatch[1].trim() : (numeros[1] || null), tipoServicio };
},
ejemplo: 'Monté a la 45 con el toro 12 / Inseminé a la vaca 20 con la pajilla Brahman 405',
},
{
tipo: 'bodega',
patron: /\b(?:us[eéo]\w*|saqu[eéo]\w*|gast[eéo]\w*|consum[ií]\w*).*\b(?:kilo|kilos|kg|litro|litros|bulto|bultos|costal|costales|dosis|piezas?)\b/i,
extraer: m => {
const texto = m.input;
const cantMatch = texto.match(/(\d+(?:[.,]\d+)?)\s*(?:kilo|kilos|kg|litro|litros|bulto|bultos|costal|costales|dosis|piezas?)/i);
const cantidad = cantMatch ? parseFloat(cantMatch[1].replace(',', '.')) : null;
const prodMatch = texto.match(/(?:de|del)\s+([a-zA-Zñáéíóú ]+?)(?:\s+de la bodega|\s*$)/i);
return { cantidad, producto: prodMatch ? prodMatch[1].trim() : null };
},
ejemplo: 'Usé 5 kilos de alimento / Saqué 2 litros de desinfectante de la bodega',
},
];
// ============================================================
// ===== EXTRACTOR DE COMANDOS COMPLEJOS (pruebas de campo) =====
// ============================================================
// Esto NO es una inteligencia artificial que "entiende" cualquier frase — es
// un extractor de entidades por reglas, especializado en el vocabulario del
// módulo de pruebas de campo. Busca en la frase: productor (comparado contra
// tus cuentas de productor reales), UPP, tipo de prueba (TB/Brucelosis) y
// motivo — y si encuentra al menos el productor, prepara la pantalla de
// "Nueva prueba" ya con todo lo que se entendió, lista para que confirmes y
// sigas capturando animales — nunca guarda una prueba completa sola, porque
// eso requiere ir agregando los animales uno por uno de cualquier forma.
const PALABRAS_TIPO_PRUEBA_VOZ = [
{ re: /\bbrucel[oó]sis\b/i, valor: 'Brucelosis' },
{ re: /\btuberculin[ao]|\btuberculosis\b|\bT\.?B\.?\b/i, valor: 'TB' },
];
const PALABRAS_MOTIVO_VOZ = [
{ re: /\bmovilizaci[oó]n\b/i, valor: 'Movilización' },
{ re: /\bcuarentena\b/i, valor: 'Cuarentena definitiva' },
{ re: /\bfin zoot[eé]cnico\b/i, valor: 'Fin zootécnico' },
{ re: /\bdiagn[oó]stico\b/i, valor: 'Diagnóstico' },
];
function buscarProductorEnFrase(texto){
// Compara la frase dictada contra los nombres/predios/UPP reales de tus
// cuentas de productor — así "productor" no es una palabra suelta, sino un
// dato de verdad que ya existe en tu base de datos.
const textoNorm = texto.toLowerCase();
const cuentas = (estado.cuentasProductores || []).filter(c => c.tipo !== 'punto');
const porUpp = cuentas.find(c => c.upp && textoNorm.includes(c.upp.toLowerCase()));
if (porUpp) return porUpp;
const encontrado = buscarPersonaFuzzy(texto, cuentas, c => c.nombre);
return encontrado ? encontrado.persona : null;
}
function interpretarComandoComplejoPruebaCampo(texto){
// Palabras gatillo que indican "quiere iniciar/registrar una prueba" — si no
// aparece ninguna, no es este tipo de comando y se deja pasar a las reglas
// simples de abajo.
if (!/\b(prueba|registra|registrar|inicia|iniciar|nueva prueba)\b/i.test(texto)) return null;
if (!/\b(tuberculin[ao]|tuberculosis|brucel[oó]sis|\bT\.?B\.?\b)\b/i.test(texto)) return null;
const productor = buscarProductorEnFrase(texto);
if (!productor) return null; // sin poder identificar al productor, no se arriesga a adivinar
const tipoPrueba = (PALABRAS_TIPO_PRUEBA_VOZ.find(p => p.re.test(texto)) || {}).valor || 'TB';
const motivo = (PALABRAS_MOTIVO_VOZ.find(p => p.re.test(texto)) || {}).valor || null;
const uppMatch = texto.match(/upp\s*[:\s]?\s*([a-z0-9-]{5,20})/i);
return { tipo: 'prueba_campo_compleja', datos: { productor, tipoPrueba, motivo, uppMencionada: uppMatch ? uppMatch[1] : null }, textoOriginal: texto };
}
// ============================================================
// ===== COMANDO: INDICACIÓN DE VOZ PARA UN TRABAJADOR =====
// ============================================================
// "Envíale a Jorge la indicación de checar los becerros del corral 25" /
// "Dile a Jorge que revise la vaca 102435 recién parida" — el productor dicta
// una indicación con el nombre de un trabajador YA registrado, y se manda
// directo a la lista de tareas de ese trabajador (el mismo sistema de tareas
// que ya existía en la app) — le aparece como cualquier tarea asignada, no es
// un sistema aparte.
function buscarTrabajadorEnFrase(texto){
const lista = typeof trabajadoresDelAmbito === 'function' ? trabajadoresDelAmbito() : (estado.trabajadores || []);
const encontrado = buscarPersonaFuzzy(texto, lista, t => t.nombre);
if (!encontrado) return null;
return { trabajador: encontrado.persona, posicion: encontrado.posicion, largoNombre: encontrado.largo };
}
function interpretarComandoTareaTrabajador(texto){
if (!/\b(env[ií]a(le)?|manda(le)?|dile|ind[ií]ca(le)?|av[ií]sa(le)?|comun[ií]ca(le)?|encarg\w*|p[ií]de(le)?|que se encargue|hazle saber|record\w*|recu[eé]rd\w*)\b/i.test(texto)) return null;
const encontrado = buscarTrabajadorEnFrase(texto);
if (!encontrado) return null; // sin identificar a un trabajador real, no se arriesga a adivinar
let instruccion = texto.slice(encontrado.posicion + encontrado.largoNombre);
instruccion = instruccion.replace(/^[,\s]*(la indicaci[oó]n de|que|de)\s*/i, '').trim();
if (!instruccion || instruccion.length < 4) return null;
instruccion = instruccion.charAt(0).toUpperCase() + instruccion.slice(1);
return { tipo: 'tarea_trabajador', datos: { trabajador: encontrado.trabajador, instruccion }, textoOriginal: texto };
}
function ejecutarComandoTareaTrabajador(datos){
if (estado.modoTrabajador){
mostrarToast('Esta función es solo para el productor, no para el trabajador');
decirEnVoz('Solo el productor puede enviar indicaciones a los trabajadores.');
return;
}
estado.tareas.unshift({ id:'k' + Date.now(), texto: datos.instruccion, asignadoA: datos.trabajador.id, fecha: hoyISO(), hecha:false, origen:'comando_voz' });
guardarEstadoLocal();
if (typeof renderListaTareasAdmin === 'function') renderListaTareasAdmin();
mostrarBannerNotificacion(`Indicación enviada a ${datos.trabajador.nombre}`, 4000, 'fa-microphone');
decirEnVoz(`Listo, se le envió la indicación a ${datos.trabajador.nombre}.`);
}
async function ejecutarComandoPruebaCampoComplejo(datos){
if (!estado.modoVeterinario && !estado.vistaVeterinario){
mostrarToast('Esta función es solo para el veterinario');
decirEnVoz('Esta función solo está disponible con la sesión de veterinario abierta.');
return;
}
irAdmin('pruebascampo');
await new Promise(r => setTimeout(r, 150)); // deja que la pantalla termine de montarse
abrirNuevaPruebaCampo('prueba');
establecerValor('pc-tipo-prueba', datos.tipoPrueba);
if (typeof actualizarCamposSegunTipoPrueba === 'function') actualizarCamposSegunTipoPrueba();
if (datos.motivo) establecerValor('pc-motivo', datos.motivo);
await seleccionarProductorParaPrueba(datos.productor.id);
mostrarBannerNotificacion(`Prueba de ${datos.tipoPrueba} preparada para ${datos.productor.nombre} — revisa y agrega los animales`, 5000, 'fa-microphone');
decirEnVoz(`Prueba de ${datos.tipoPrueba === 'TB' ? 'tuberculina' : 'brucelosis'} preparada para ${datos.productor.nombre}. Agrega los animales para continuar.`);
}
// ============================================================
// ===== COMANDO: ALTA DE ANIMAL NUEVO (ARETE) POR VOZ =====
// ============================================================
// "Dar de alta el arete 245, hembra" / "Registrar arete 310 macho en la
// cuenta de Marcos" — antes esta acción no existía en el motor de voz (solo
// existían pesaje/sanidad/potrero/parto), por eso cualquier frase de alta se
// caía siempre en "no se reconoció el comando".
// Si se menciona el nombre de un productor, SOLO tiene efecto cuando la
// sesión activa es de administrador (es quien puede entrar a la cuenta de
// otro productor, con el mismo mecanismo que ya usa Admin > Cuentas > "Usar
// cuenta de pruebas") — si una cuenta de productor normal dice un nombre por
// error, se ignora y el alta se hace en su propia cuenta, nunca en otra.
// "Dar de alta el arete 245, hembra" — el alta SIEMPRE se hace en la cuenta
// que está abierta en ese momento en el dispositivo, sin excepción. Ningún
// comando de voz cambia de cuenta ni permite modificar datos de otro
// productor — la única forma válida de entrar a una cuenta es con su propio
// usuario y contraseña, de manera formal. Esto aplica igual para admin,
// comité y veterinario: nadie puede usar la voz para saltarse ese control.
// ============================================================
// ===== FECHAS RELATIVAS DICTADAS ("ayer", "antier", "hace 3 días"...) =====
// ============================================================
// Convierte una expresión de tiempo hablada a una fecha real ISO. Regresa
// null si no se detectó ninguna (para que quien llame use hoy por default,
// sin forzar una fecha que nadie dijo).
function interpretarFechaRelativaVoz(texto){
const hoy = hoyISO();
if (/\bhoy\b/i.test(texto)) return hoy;
if (/\bayer\b/i.test(texto)) return sumarDiasISO(hoy, -1);
if (/\b(anti(er)?|anteayer)\b/i.test(texto)) return sumarDiasISO(hoy, -2);
const haceMatch = texto.match(/\bhace\s+(\d+)\s+d[ií]as?\b/i);
if (haceMatch) return sumarDiasISO(hoy, -parseInt(haceMatch[1], 10));
const haceSemanaMatch = texto.match(/\bhace\s+(\d+)\s+semanas?\b/i);
if (haceSemanaMatch) return sumarDiasISO(hoy, -parseInt(haceSemanaMatch[1], 10) * 7);
if (/\bla semana pasada\b/i.test(texto)) return sumarDiasISO(hoy, -7);
const DIAS_SEMANA_VOZ = { domingo:0, lunes:1, martes:2, 'miércoles':3, miercoles:3, jueves:4, viernes:5, 'sábado':6, sabado:6 };
const diaMatch = texto.match(/\bel\s+(lunes|martes|mi[ée]rcoles|jueves|viernes|s[áa]bado|domingo)\b/i);
if (diaMatch){
const diaObjetivo = DIAS_SEMANA_VOZ[diaMatch[1].toLowerCase()];
const diaHoy = new Date(hoy + 'T12:00:00').getDay();
let diferencia = diaHoy - diaObjetivo;
if (diferencia <= 0) diferencia += 7;
return sumarDiasISO(hoy, -diferencia);
}
return null;
}
// ============================================================
// ===== NIVEL 2: EXTRAER VARIOS DATOS DE UNA SOLA FRASE LARGA =====
// (dar de alta un animal completo, hablando desordenado y sin pausas)
// ============================================================
// Con honestidad: esto NO es una inteligencia artificial que "entiende"
// cualquier frase — es un extractor de entidades por reglas y cercanía de
// palabras, especializado en cómo la gente describe un animal nuevo al
// hablar. Cubre el caso real de "apúntame una vaca pinta negra que compré
// ayer, arete 5842, 420 kilos, cargada de 3 meses, del potrero El Sauz" —
// sacando cada dato de su propio pedazo de la frase, sin que el usuario
// tenga que tocar ningún campo.
function extraerAltaAnimalCompleta(textoOriginal){
const texto = textoOriginal;
const numeroMatch = texto.match(/\d+/);
if (!numeroMatch) return null;
const arete = numeroMatch[0];
const confianza = {};
// Sexo y raza — igual que antes.
const sexoMatch = texto.match(/\b(macho|hembra)\b/i);
const sexo = sexoMatch ? sexoMatch[1].toLowerCase() : null;
const razaMatch = texto.match(/\b(holstein|angus|charolais|charoláis|brahman|brahm[aá]n|simmental|hereford|jersey|pardo suizo|suizo|cebú|cebu|criollo|gyr|sardo negro|limousin|beefmaster|brangus|indubrasil)\b/i);
const raza = razaMatch ? razaMatch[1].replace(/\b\w/g, c => c.toUpperCase()) : null;
// Nombre/descripción — si no se reconoce una raza de catálogo, se toma la
// descripción de color/tipo que suele decirse justo después de "vaca",
// "becerro", etc. (ej. "vaca pinta negra") como el nombre del animal, para
// no dejarlo completamente vacío.
let nombre = '';
if (!raza){
const descMatch = texto.match(/\b(?:vaca|becerr[oa]|ternero|ternera|vaquilla|novill[oa]|toro|res)\s+((?:[a-zñáéíóú]+\s*){1,3}?)(?:\s+que\s|\s+arete\s|,|\s+de\s+la\s+upp|$)/i);
if (descMatch && descMatch[1].trim().length > 2) nombre = descMatch[1].trim();
}
confianza.nombre = nombre ? 0.6 : 1; // si no dijo descripción, no es que falló — no hay nada que adivinar
// Peso — número seguido de "kilo(s)"/"kg", ya con los números convertidos a
// dígitos por convertirNumerosEspanolADigitos ANTES de llegar aquí.
const pesoMatch = texto.match(/(\d+(?:[.,]\d+)?)\s*(?:kilos?|kgs?)\b/i);
const peso = pesoMatch ? parseFloat(pesoMatch[1].replace(',', '.')) : null;
confianza.peso = peso ? 0.9 : 1;
// Estado reproductivo + meses de gestación — "cargada de 3 meses" no debe
// confundirse con "3 kilos" ni con el arete; se busca la palabra de estado
// reproductivo Y un número de meses CERCA de ella (ventana de las 6
// palabras siguientes), no en cualquier parte de la frase.
let estadoReproductivo = null, mesesGestacion = null;
const gestaMatch = texto.match(/\b(cargada|preñada|prenada|gestante)\b((?:\s+\S+){0,6})/i);
if (gestaMatch){
estadoReproductivo = 'gestante';
const mesesEnVentana = gestaMatch[2].match(/(\d+)\s*mes(?:es)?/i);
mesesGestacion = mesesEnVentana ? parseInt(mesesEnVentana[1], 10) : null;
confianza.estadoReproductivo = mesesEnVentana ? 0.9 : 0.6; // dijo "cargada" pero no está claro cuántos meses
} else if (/\b(vac[ií]a|abierta)\b/i.test(texto)){
estadoReproductivo = 'vacia';
confianza.estadoReproductivo = 0.85;
} else if (/\ben celo\b/i.test(texto)){
estadoReproductivo = 'en_celo';
confianza.estadoReproductivo = 0.85;
}
// Potrero — lo que sigue a la palabra "potrero", comparado contra los
// potreros que YA existen (por si el reconocedor lo transcribió un poco
// distinto) — si no se parece a ninguno, se toma tal cual como uno NUEVO.
let potrero = null;
const potreroMatch = texto.match(/\bpotrero\s+((?:el\s+|la\s+|los\s+|las\s+)?[a-zA-ZñáéíóúÑÁÉÍÓÚ]+(?:\s+[a-zA-ZñáéíóúÑÁÉÍÓÚ]+){0,2})/i);
if (potreroMatch){
const dicho = potreroMatch[1].trim().replace(/,$/, '');
const existente = (estado.potreros || []).find(p => p.nombre.toLowerCase() === dicho.toLowerCase());
potrero = existente ? existente.nombre : dicho.replace(/\b\w/g, c => c.toUpperCase());
confianza.potrero = existente ? 0.95 : 0.7; // potrero nuevo, no confirmado todavía contra el catálogo
}
// UPP — referencia corta tipo "R-33", o "UPP de [alguien]". Es el dato más
// difícil de la frase de ejemplo real (una UPP prestada/de otra persona) —
// se captura lo que se alcance a identificar, con confianza baja a
// propósito, para que SIEMPRE se le pida confirmar esto en particular. Se
// busca sin distinguir mayúsculas — el reconocedor de voz casi nunca
// escribe en mayúscula una sola letra suelta a media frase.
let uppReferencia = null;
const uppLetraNumero = texto.match(/\b([a-zA-Z])[\s-]?(\d{1,4})\b/);
const uppFrase = texto.match(/\bupp\s+(?:de\s+(?:mi\s+)?)?([a-zA-Zñáéíóú]+)/i);
if (uppLetraNumero) uppReferencia = uppLetraNumero[1].toUpperCase() + '-' + uppLetraNumero[2];
else if (uppFrase) uppReferencia = 'UPP de ' + uppFrase[1];
if (uppReferencia) confianza.upp = 0.5;
// Fecha de compra/llegada — "ayer", "antier", "hace 3 días"...
const fecha = interpretarFechaRelativaVoz(texto);
return {
tipo: 'alta_animal_completa',
datos: { arete, sexo, raza, nombre, peso, estadoReproductivo, mesesGestacion, potrero, uppReferencia, fecha },
confianza,
textoOriginal,
};
}
function interpretarComandoAltaAnimal(texto){
const disparadorAccion = /\b(dar de alta|alta de|registr\w*|agreg\w*|añad\w*|anad\w*|inscrib\w*|captur\w*|dar entrada|nuevo ingreso)\b/i.test(texto);
const disparadorAdquisicion = /\b(lleg\w*|compr\w*)\b.*?\b(animal|arete|becerro|ternero|ternera|vaquilla|novillo|novilla|res)\b|\b(animal|arete|becerro|ternero|ternera|vaquilla|novillo|novilla|res)\b.*?\b(lleg\w*|compr\w*)\b/i.test(texto);
const disparadorNuevo = /\b(animal|arete|becerro|ternero|ternera|vaquilla|novillo|novilla|res)\s+nuevo[a]?\b|\bnuevo[a]?\s+(animal|arete|becerro|ternero|ternera|vaquilla|novillo|novilla|res)\b/i.test(texto);
if (!disparadorAccion && !disparadorAdquisicion && !disparadorNuevo) return null;
const numeroMatch = texto.match(/\d+/);
if (!numeroMatch) return null; // sin un número de arete, no se arriesga a adivinar
const arete = numeroMatch[0];
const sexoMatch = texto.match(/\b(macho|hembra)\b/i);
const sexo = sexoMatch ? sexoMatch[1].toLowerCase() : null;
const razaMatch = texto.match(/\b(holstein|angus|charolais|charoláis|brahman|brahm[aá]n|simmental|hereford|jersey|pardo suizo|suizo|cebú|cebu|criollo|gyr|sardo negro|limousin)\b/i);
const raza = razaMatch ? razaMatch[1].replace(/\b\w/g, c => c.toUpperCase()) : null;
return { tipo: 'alta_animal', datos: { arete, sexo, raza }, textoOriginal: texto };
}
async function ejecutarComandoAltaAnimalPorVoz(datos, textoOriginal){
if (estado.animales.some(a => a.arete === datos.arete)){
mostrarToast('Ya existe un animal registrado con el arete ' + datos.arete);
decirEnVoz('Ya existe un animal con ese arete. No se registró de nuevo.');
return;
}
if (typeof buscarAreteEnOtraUPP === 'function'){
const conflicto = buscarAreteEnOtraUPP(datos.arete);
if (conflicto){
mostrarToast('Ese arete ya está en uso en otra cuenta');
decirEnVoz('Ese arete ya está registrado en otra cuenta. No se dio de alta.');
return;
}
}
estado.animales.push({
arete: datos.arete, chip:'', nombre:'', raza: datos.raza || '', sexo: datos.sexo === 'macho' ? 'Macho' : (datos.sexo === 'hembra' ? 'Hembra' : ''),
fecha: hoyISO(), estatus:'Activo', madre:'', padre:'', potrero:'', motivoBaja:'', foto:null,
proposito:'', engordaDiasObjetivo:null, engordaPesoMeta:null, engordaInicio:null, engordaFinalizado:false, engordaDiasFinal:null,
origen:'comando_voz', textoOriginal,
});
guardarEstadoLocal();
if (typeof renderHato === 'function') renderHato();
if (typeof renderResumenProductor === 'function') renderResumenProductor();
mostrarBannerNotificacion(`Arete ${datos.arete} dado de alta`, 4000, 'fa-microphone');
decirEnVoz(`Listo, se dio de alta el arete ${datos.arete}.`);
}
// "Vendimos el 45" / "Se murió la 12" / "Dale de baja al arete 88" — no
// existía como acción reconocida, se agrega ahora. Solo cambia el estatus
// del animal (vendido/finado) en la cuenta actualmente abierta; nunca
// borra el registro, para conservar el historial.
function interpretarComandoBajaAnimal(texto){
if (!/\b(vend\w*|dar de baja|dio de baja|se muri[oó]|muri[oó])/i.test(texto)) return null;
const numeroMatch = texto.match(/\d+/);
if (!numeroMatch) return null;
const esMuerte = /\bmuri[oó]/i.test(texto);
return { tipo: 'baja_animal', datos: { arete: numeroMatch[0], motivo: esMuerte ? 'Muerte' : 'Venta' }, textoOriginal: texto };
}
function ejecutarComandoBajaAnimalPorVoz(datos){
const animal = estado.animales.find(a => a.arete === datos.arete);
if (!animal){
mostrarToast('No se encontró el arete ' + datos.arete + ' en el hato');
decirEnVoz('No encontré ese arete en el hato. No se dio de baja nada.');
return;
}
animal.estatus = datos.motivo === 'Muerte' ? 'finado' : 'vendido';
animal.motivoBaja = datos.motivo;
guardarEstadoLocal();
if (typeof renderHato === 'function') renderHato();
if (typeof renderResumenProductor === 'function') renderResumenProductor();
mostrarBannerNotificacion(`Arete ${datos.arete} dado de baja (${datos.motivo})`, 4000, 'fa-microphone');
decirEnVoz(`Listo, se dio de baja el arete ${datos.arete}.`);
}
// "Busca el arete 205" / "¿De quién es el arete 90?" — antes no existía como
// acción reconocida, y era justo el error reportado en capturista ("esa
// información no la podía procesar"). Es de solo lectura: si es un
// productor, busca en su propio hato; si es veterinario/capturista/comité,
// busca dentro de las pruebas de campo que YA puede ver normalmente en su
// pantalla — nunca abre ni consulta la cuenta privada de un productor.
function interpretarComandoBuscarArete(texto){
if (!/\b(busca|buscar|encuentra|encontrar|d[oó]nde est[aá]|de qui[eé]n es|informaci[oó]n del|datos del|qu[eé] sabes del)\b/i.test(texto)) return null;
const numeroMatch = texto.match(/\d+/);
if (!numeroMatch) return null;
return { tipo: 'buscar_arete', datos: { arete: numeroMatch[0] }, textoOriginal: texto };
}
function ejecutarComandoBuscarArete(datos){
if (estado.cuentaActivaId){
const animal = estado.animales.find(a => a.arete === datos.arete);
if (!animal){
mostrarBannerNotificacion(`No encontré el arete ${datos.arete} en tu hato`, 4500, 'fa-microphone');
decirEnVoz(`No encontré el arete ${datos.arete} en tu hato.`);
return;
}
const resumen = `Arete ${datos.arete}: ${animal.sexo || 'sin sexo registrado'}, ${animal.raza || 'sin raza registrada'}, estatus ${animal.estatus || 'Activo'}${animal.potrero ? ', en el potrero ' + animal.potrero : ''}`;
mostrarBannerNotificacion(resumen, 6000, 'fa-microphone');
decirEnVoz(resumen);
return;
}
let encontrado = null, pruebaEncontrada = null;
for (const p of (estado.pruebasCampoVet || [])){
const a = (p.animales || []).find(x => x.arete === datos.arete);
if (a){ encontrado = a; pruebaEncontrada = p; break; }
}
if (!encontrado){
mostrarBannerNotificacion(`No encontré el arete ${datos.arete} en ninguna prueba de campo`, 4500, 'fa-microphone');
decirEnVoz(`No encontré el arete ${datos.arete} en ninguna prueba de campo registrada.`);
return;
}
const resumen = `Arete ${datos.arete}: ${encontrado.especie || 'sin especie'}, ${encontrado.sexo === 'H' ? 'hembra' : 'macho'}, de la prueba de ${pruebaEncontrada.productorNombre || 'productor sin nombre'} del ${pruebaEncontrada.fecha || 'sin fecha'}`;
mostrarBannerNotificacion(resumen, 6000, 'fa-microphone');
decirEnVoz(resumen);
}
// "Gasté 500 pesos en alimento" / "500 pesos pagué de medicina" — se revisa
// como función aparte (no como regla simple) porque necesita confirmar DOS
// cosas a la vez (el verbo Y el monto) sin importar cuál se diga primero.
function interpretarComandoGasto(texto){
if (!/\b(gast[eé]\w*|pagu[eé]\w*|pag[oó]\w*|cost[oó]\w*|compr[eé]\w*|ingres[eé]\w*|cobr[eé]\w*|recib[ií]\w*)/i.test(texto)) return null;
const montoMatch = texto.match(/(\d+(?:[.,]\d+)?)\s*(?:pesos|mxn|mx\b)/i) || texto.match(/\$\s*(\d+(?:[.,]\d+)?)/) || texto.match(/(\d+(?:[.,]\d+)?)/);
if (!montoMatch) return null; // sin un monto claro, no se arriesga a adivinar
const monto = parseFloat(montoMatch[1].replace(',', '.'));
const esIngreso = /\b(ingres[eé]\w*|cobr[eé]\w*|recib[ií]\w*)/i.test(texto);
let categoria = 'otro';
if (/\balimento|comida|forraje|concentrado\b/i.test(texto)) categoria = 'alimento';
else if (/\bmedicin\w*|medicamento|veterinari\w*|vacuna\b/i.test(texto)) categoria = 'medicina';
else if (/\bmantenimiento|reparaci[oó]n|arregl\w*\b/i.test(texto)) categoria = 'mantenimiento';
else if (/\bmano de obra|jornal|pago a\b/i.test(texto)) categoria = 'mano_obra';
else if (/\bventa de animal|animal vendido\b/i.test(texto)) categoria = 'venta_animal';
return { tipo: 'gasto', datos: { tipoMovimiento: esIngreso ? 'ingreso' : 'gasto', categoria, monto, descripcion: texto }, textoOriginal: texto };
}
// ============================================================
// ===== EXTRACTOR DE REPORTES POR VOZ (sin IA de pago) =====
// ============================================================
// No es una lista de frases fijas: reconoce 4 "piezas" independientes
// (disparador + entidad + filtro de fecha opcional + filtro de productor
// opcional) y las combina — así cubre muchas más frases reales de las que
// se hubieran escrito a mano, y crece agregando una palabra a un arreglo,
// nunca una regla nueva por frase.
const DISPARADORES_REPORTE = [
'cuántos', 'cuántas', 'cuánto', 'cuanto', 'cuantos', 'cuantas',
'dame un informe', 'dame el informe', 'dame un reporte', 'dame el reporte',
'quiero un informe', 'quiero un reporte', 'quiero saber',
'dime cuántos', 'dime cuántas', 'dime cuantos', 'dime cuantas',
'muéstrame', 'muestrame', 'enséñame', 'ensename',
'necesito saber', 'necesito el número de', 'necesito saber cuántos',
'resumen de', 'dame un resumen', 'un resumen de',
'cuál es el total de', 'cuál es el número de', 'cual es el total de',
'hay reporte de', 'reporte de', 'checa cuántos', 'checa cuántas',
'dame la estadística', 'estadística de', 'estadisticas de',
'existen'
];
const ENTIDADES_REPORTE = [
{ id:'pcc', sinonimos:['pcc','pruebas cervicales','pruebas de tuberculina','tuberculinas','tuberculosis'],
datos:(e)=>(e.pruebasCampoVet||[]).filter(p=>p.tipoPrueba==='TB'), etiquetaHablada:'pruebas de tuberculina (PCC)', soportaFiltroProductor:true },
{ id:'brucelosis', sinonimos:['brucelosis','pruebas de brucelosis'],
datos:(e)=>(e.pruebasCampoVet||[]).filter(p=>p.tipoPrueba==='Brucelosis'), etiquetaHablada:'pruebas de brucelosis', soportaFiltroProductor:true },
{ id:'reactores', sinonimos:['reactores','reactores pendientes','avisos de reactores'],
datos:(e)=>(e.avisosReactoresTB||[]), etiquetaHablada:'avisos de reactores', soportaFiltroProductor:true },
{ id:'becerros', sinonimos:['becerros nacidos','nacimientos','partos','crías nacidas','terneros nacidos','alumbramientos','becerros','terneros'],
datos:(e)=>(e.animales||[]).filter(a=>a.madre), etiquetaHablada:'nacimientos', soportaFiltroProductor:false },
{ id:'pesajes', sinonimos:['pesajes','pesadas','registros de peso','pesos registrados'],
datos:(e)=>(e.pesajes||[]), etiquetaHablada:'pesajes', soportaFiltroProductor:false },
{ id:'vacunas', sinonimos:['vacunas','vacunas aplicadas','registros de sanidad','aplicaciones','tratamientos','curaciones','medicamentos aplicados'],
datos:(e)=>(e.salud||[]), etiquetaHablada:'registros de sanidad', soportaFiltroProductor:false },
{ id:'movimientos', sinonimos:['movimientos','cambios de potrero','traslados','cambios de corral'],
datos:(e)=>(e.movimientosAnimal||[]), etiquetaHablada:'movimientos de potrero', soportaFiltroProductor:false },
{ id:'tareas', sinonimos:['tareas','pendientes','indicaciones'],
datos:(e)=>(e.tareas||[]), etiquetaHablada:'tareas', soportaFiltroProductor:false },
{ id:'animales', sinonimos:['animales','cabezas de ganado','ganado','vacas','reses','vaquillas','novillos','novillas','toros','sementales','hato'],
datos:(e)=>(e.animales||[]), etiquetaHablada:'animales', soportaFiltroProductor:false },
];
const MESES_REPORTE_VOZ = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
function extraerFiltroFechaReporte(texto){
const hoy = new Date();
if (/\bhoy\b/.test(texto)) return { desde: new Date(hoy.getFullYear(),hoy.getMonth(),hoy.getDate()), hasta: hoy, etiqueta:'hoy' };
if (/\besta semana\b/.test(texto)){ const inicio=new Date(hoy); inicio.setDate(hoy.getDate()-hoy.getDay()); return { desde:inicio, hasta:hoy, etiqueta:'esta semana' }; }
if (/\beste mes\b/.test(texto)) return { desde:new Date(hoy.getFullYear(),hoy.getMonth(),1), hasta:hoy, etiqueta:'este mes' };
if (/\beste año\b/.test(texto)) return { desde:new Date(hoy.getFullYear(),0,1), hasta:hoy, etiqueta:'este año' };
for (let i=0;i<MESES_REPORTE_VOZ.length;i++){
if (texto.includes(MESES_REPORTE_VOZ[i])){ const anio=hoy.getFullYear(); return { desde:new Date(anio,i,1), hasta:new Date(anio,i+1,0), etiqueta:MESES_REPORTE_VOZ[i] }; }
}
return null;
}
function interpretarComandoReporte(texto){
const disparadorEncontrado = DISPARADORES_REPORTE.some(d => texto.includes(d));
if (!disparadorEncontrado) return null;
const entidad = ENTIDADES_REPORTE.find(e => e.sinonimos.some(s => texto.includes(s)));
if (!entidad) return null;
const filtroFecha = extraerFiltroFechaReporte(texto);
const filtroProductor = entidad.soportaFiltroProductor ? buscarProductorEnFrase(texto) : null;
return { tipo:'reporte', datos:{ entidad, filtroFecha, filtroProductor }, textoOriginal: texto };
}
function ejecutarComandoReporte(datos){
let lista = datos.entidad.datos(estado);
if (datos.filtroFecha){
lista = lista.filter(item => {
const f = new Date(item.fecha || item.fechaRegistro || item.creado);
return !isNaN(f) && f >= datos.filtroFecha.desde && f <= datos.filtroFecha.hasta;
});
}
if (datos.filtroProductor){
lista = lista.filter(item => item.productorId === datos.filtroProductor.id);
}
const total = lista.length;
let respuesta = `Hay ${total} ${datos.entidad.etiquetaHablada}`;
if (datos.filtroProductor) respuesta += ` de ${datos.filtroProductor.nombre}`;
if (datos.filtroFecha) respuesta += ` en ${datos.filtroFecha.etiqueta}`;
mostrarBannerNotificacion(respuesta, 5000, 'fa-microphone');
decirEnVoz(respuesta);
registrarBitacoraVoz(datos.textoOriginal || '', 'guardado', respuesta);
}
// Cuando alguien lee un arete dígito por dígito ("arete dos dos tres cinco"
// en vez de "arete dos mil doscientos treinta y cinco"), el convertidor de
// números ya deja cada dígito suelto ("arete 2 2 3 5") — esto los junta en
// un solo número ("arete 2235") SOLO cuando son 3 o más dígitos sueltos
// seguidos justo después de "arete"/"número", para no tocar números
// normales de dos cifras ya completos (ej. "20 35" no se toca).
function unirDigitosSueltosDeArete(texto){
// El veterinario suele dictar el arete en bloques: "10 25 34 15 63".
// Para un arete, esos bloques forman UN solo identificador: 1025341563.
// También soportamos dígitos individuales: "1 0 2 5 3 4 1 5 6 3".
// Solo actuamos inmediatamente después de "arete"/"número" y hasta una
// palabra de campo, para no unir por accidente edad, peso u otros números.
return texto.replace(/\b((?:arete|n[uú]mero)\s+)((?:(?:\d{1,3})\s+){1,11}\d{1,3})(?=\s*(?:,|\.|;|$|raza|edad|sexo|hembra|macho|mes(?:es)?|vaca|toro|novilla|novillo|becerro|becerra))/gi,
(m, prefijo, grupos) => prefijo + grupos.replace(/\s+/g, ''));
}
// ============================================================
// ===== NAVEGACIÓN POR VOZ: "abre las gráficas", "ve al hato" =====
// ============================================================
// Es el comando de mayor alcance del motor de voz: en vez de cubrir una sola
// acción, abre CUALQUIER pantalla principal con solo decir su nombre — así se
// multiplica de un jalón cuántas funciones de la app se pueden activar hablando,
// sin tener que tocar la pantalla para llegar ahí. No pide confirmación (a
// diferencia de dar de alta un animal o un gasto) porque no cambia ningún dato,
// solo mueve la vista — el mismo criterio que ya se usa para "buscar_arete" y
// "reporte", que también son de solo lectura.
const DISPARADORES_NAVEGACION = ['abre ', 'abrir ', 'ábreme ', 'abreme ', 've a ', 've al ', 'vete a ', 'vete al ', 'ir a ', 'ir al ', 'llévame a ', 'llevame a ', 'llévame al ', 'llevame al ', 'quiero ver ', 'pásame a ', 'pasame a '];
// Pantallas del lado productor (accesibles con irA). Cada entrada trae varias
// formas comunes de decirlo — la gente no siempre usa el nombre exacto del botón.
const PANTALLAS_VOZ_PRODUCTOR = [
{ id:'home', sinonimos:['inicio', 'la casa', 'el inicio', 'la pantalla principal'] },
{ id:'hato', sinonimos:['hato', 'el hato', 'mi hato', 'mis animales', 'el inventario', 'mi inventario', 'inventario'] },
{ id:'graficas', sinonimos:['gráficas', 'graficas', 'las gráficas', 'las graficas', 'la gráfica', 'la grafica', 'estadísticas', 'estadisticas', 'las estadísticas', 'las estadisticas'] },
{ id:'boletines', sinonimos:['boletines', 'los boletines', 'noticias', 'las noticias', 'avisos', 'los avisos'] },
{ id:'tareas', sinonimos:['tareas', 'las tareas', 'mis tareas', 'pendientes', 'los pendientes'] },
{ id:'datos-productor', sinonimos:['mis datos', 'los datos del productor', 'mi perfil'] },
{ id:'editar-productor', sinonimos:['editar mis datos', 'editar mi perfil', 'actualizar mis datos'] },
{ id:'mensajes', sinonimos:['mensajes', 'los mensajes', 'el chat', 'mi chat'] },
{ id:'escaneo-documentos', sinonimos:['escaneo', 'el escaneo', 'escanear documentos', 'escanear mi credencial'] },
];
// Módulos del productor (se abren con irModulo, no con irA)
const MODULOS_VOZ_PRODUCTOR = [
{ letra:'B', sinonimos:['salud y sanidad', 'la salud', 'sanidad', 'el módulo de salud', 'el modulo de salud'] },
{ letra:'C', sinonimos:['reproducción y maternidad', 'reproduccion y maternidad', 'la reproducción', 'la reproduccion'] },
{ letra:'D', sinonimos:['pesajes y productividad', 'los pesajes', 'el peso de los animales'] },
{ letra:'F', sinonimos:['costos y reportes', 'los costos', 'los gastos', 'las finanzas'] },
{ letra:'G', sinonimos:['producción de leche', 'produccion de leche', 'la ordeña', 'la ordena'] },
{ letra:'H', sinonimos:['tanque de leche', 'el tanque'] },
{ letra:'I', sinonimos:['alimentación', 'alimentacion', 'la comida del ganado'] },
{ letra:'K', sinonimos:['bodega e insumos', 'la bodega', 'los insumos'] },
];
// Pantallas del lado administrador/veterinario/comité (accesibles con irAdmin)
const PANTALLAS_VOZ_ADMIN = [
{ id:'home', sinonimos:['inicio', 'la casa', 'el inicio', 'la pantalla principal'] },
{ id:'usuarios', sinonimos:['usuarios', 'usuarios y contraseñas', 'usuarios y contrasenas', 'los usuarios'] },
{ id:'config', sinonimos:['configuración', 'configuracion', 'los ajustes', 'ajustes'] },
{ id:'boletines', sinonimos:['boletines', 'los boletines', 'noticias'] },
{ id:'cuentas', sinonimos:['cuentas', 'cuentas de productores', 'las cuentas', 'mis productores'] },
{ id:'productor', sinonimos:['datos del productor'] },
{ id:'metricas', sinonimos:['métricas', 'metricas', 'métricas de interacción', 'metricas de interaccion'] },
{ id:'mas', sinonimos:['más funciones', 'mas funciones', 'más opciones', 'mas opciones'] },
{ id:'pruebascampo', sinonimos:['pruebas de campo', 'las pruebas', 'pruebas'] },
{ id:'vetproductores', sinonimos:['personas atendidas', 'mis pacientes', 'mis clientes'] },
{ id:'vetnotas', sinonimos:['notas', 'mis notas'] },
{ id:'ventanageneraltb', sinonimos:['admin tb', 'avisos de reactores', 'los reactores', 'reactores'] },
{ id:'reportestb', sinonimos:['reportes de pruebas tb', 'reportes tb'] },
{ id:'cefpp', sinonimos:['reportes a cefpp', 'cefpp', 'casos urgentes'] },
{ id:'medicocampotb', sinonimos:['pruebas cervicales', 'mis pruebas cervicales', 'mis casos de tb', 'mis casos'] },
{ id:'capturistatb', sinonimos:['pruebas listas para capturar de tb'] },
{ id:'pruebascapturista', sinonimos:['pruebas listas para capturar', 'lo que tengo que capturar'] },
{ id:'almita', sinonimos:['centro de solicitudes cefpp', 'las solicitudes cefpp'] },
{ id:'nueva-prueba-campo', sinonimos:['una nueva prueba', 'nueva prueba de campo', 'registrar una prueba'] },
];
function interpretarComandoNavegacion(texto){
const disparador = DISPARADORES_NAVEGACION.find(d => texto.startsWith(d) || texto.includes(' ' + d) || texto.includes(d));
if (!disparador) return null;
const idx = texto.indexOf(disparador);
const resto = texto.slice(idx + disparador.length).trim();
if (!resto) return null;
const esAdmin = estado.rolActual === 'admin';
if (!esAdmin){
const modulo = MODULOS_VOZ_PRODUCTOR.find(m => m.sinonimos.some(s => resto.includes(s)));
if (modulo) return { tipo:'navegar', datos:{ destino: modulo.letra, funcion:'modulo' }, textoOriginal: texto };
const pantalla = PANTALLAS_VOZ_PRODUCTOR.find(p => p.sinonimos.some(s => resto.includes(s)));
if (pantalla) return { tipo:'navegar', datos:{ destino: pantalla.id, funcion:'productor' }, textoOriginal: texto };
} else {
const pantalla = PANTALLAS_VOZ_ADMIN.find(p => p.sinonimos.some(s => resto.includes(s)));
if (pantalla) return { tipo:'navegar', datos:{ destino: pantalla.id, funcion:'admin' }, textoOriginal: texto };
}
return null;
}
// ============================================================
// ===== COMANDO: DICTADO DE VARIOS CAMPOS DE UN ANIMAL EN PANTALLA =====
// ============================================================
// "Arete 245, raza BR, edad 18 meses" (o el orden que sea, sexo incluido) —
// a diferencia del alta de animal en segundo plano (arriba), este comando
// llena los campos VISIBLES en pantalla — de la captura de animales de una
// prueba de campo (TB/Brucelosis) o del formulario de Registro de ganado
// (módulo A) — para que el médico/productor vea el animal aparecer/actualizarse
// mientras dicta, y revise/corrija antes de guardar, igual que cualquier otro
// formulario llenado por voz.
// Extrae el texto que sigue a una palabra clave (ej. "raza") hasta que aparece
// alguna de las OTRAS palabras clave del mismo comando (ej. "edad", "sexo") o
// se acaba la frase — así "raza BR edad 18 meses" no junta "BR" con "edad".
function extraerValorTrasPalabraClave(texto, palabraClave, otrasClaves){
const patronOtras = otrasClaves.join('|');
const re = new RegExp('\\b' + palabraClave + '\\s*[:\\s]?\\s*([a-z0-9áéíóúñ]+(?:\\s+(?!(?:' + patronOtras + ')\\b)[a-z0-9áéíóúñ]+)*)', 'i');
const m = texto.match(re);
return m ? m[1].trim() : null;
}
function normalizarAreteParaVoz(arete){
let s = String(arete || '').toLowerCase().replace(/[^a-z0-9]/g, '');
if (s.startsWith('mx')) s = s.slice(2);
return s.replace(/^0+(?=\d{6,})/, '');
}
function buscarAnimalParaDictadoPrueba(arete){
const objetivo = normalizarAreteParaVoz(arete);
if (!objetivo) return null;
// La pantalla de prueba conoce todos los productores cargados en la sesión.
// La búsqueda se hace en memoria: no se consulta Firebase por cada animal.
if (typeof window.buscarAnimalEnSesionPruebaCampoVoz === 'function') {
  const encontrado = window.buscarAnimalEnSesionPruebaCampoVoz(arete);
  if (encontrado) return encontrado;
}
const fila = (typeof filasAnimalesPruebaCampo !== 'undefined' ? filasAnimalesPruebaCampo : []).find(f => {
const a = normalizarAreteParaVoz(f.arete); return a && (a === objetivo || a.endsWith(objetivo) || objetivo.endsWith(a));
});
if (fila) return {fuente:'prueba',fila,animal:null,productor:null};
const inventario = (typeof cacheAnimalesProductorPrueba !== 'undefined' && Array.isArray(cacheAnimalesProductorPrueba)) ? cacheAnimalesProductorPrueba : [];
const animal = inventario.find(a => { const x=normalizarAreteParaVoz(a.arete); return x && (x===objetivo || x.endsWith(objetivo) || objetivo.endsWith(x)); });
return animal ? {fuente:'inventario',fila:null,animal,productor:null} : null;
}
function extraerAreteDeDictado(texto){
// Acepta tanto \"arete 1025341563\" como \"arete 10 25 34 15 63\".
const m = texto.match(/\b(?:arete|n[uú]mero)\s+([a-z0-9]+(?:\s+[a-z0-9]+){0,11})/i);
if (!m) return null;
let bruto = m[1].trim();
// Cortar al llegar a un campo posterior.
bruto = bruto.split(/\s+(?=(?:raza|edad|sexo|hembra|macho|mes(?:es)?|vaca|toro|novilla|novillo|becerro|becerra)\b)/i)[0];
bruto = bruto.replace(/[.,;:]+$/, '').trim();
const grupos = bruto.match(/\d{1,3}/g);
if (!grupos || grupos.join('').length < 6) return null;
return grupos.join('');
}
function interpretarComandoDictadoAnimalEnPantalla(texto){
const arete = extraerAreteDeDictado(texto);
if (!arete) return null;
const razaTexto = extraerValorTrasPalabraClave(texto, 'raza', ['arete','edad','sexo']);
const edadMatch = texto.match(/\bedad\s*[:\s]?\s*(\d{1,3})\s*(?:meses|mes)?\b/i) || texto.match(/\b(\d{1,3})\s*(?:meses|mes)\b/i);
const edad = edadMatch ? edadMatch[1] : null;
const sexoTexto = extraerValorTrasPalabraClave(texto, 'sexo', ['arete','raza','edad']);
let sexo = null;
if (sexoTexto){
if (/^h/i.test(sexoTexto)) sexo = 'hembra';
else if (/^m/i.test(sexoTexto)) sexo = 'macho';
} else {
const sexoSuelto = texto.match(/\b(macho|hembra)\b/i);
if (sexoSuelto) sexo = sexoSuelto[1].toLowerCase();
}
if (!razaTexto && !edad && !sexo) return null;
return { tipo:'dictado_animal_pantalla', datos:{ arete, raza:razaTexto, edad, sexo }, textoOriginal:texto };
}
// Modo dedicado de captura de animal por voz para la pantalla de prueba.
// No cambia de cuenta ni crea animales inexistentes: solo activa el mismo
// reconocedor continuo mientras el MVZ mantiene presionado el botón.
function iniciarDictadoAnimalPruebaCampo(){
const cont = document.getElementById('lista-animales-prueba-campo');
if (!cont || !cont.offsetParent){
mostrarToast('Abre primero la prueba de campo');
return;
}
iniciarEscuchaContinua();
}
function detenerDictadoAnimalPruebaCampo(){ detenerEscuchaContinua(); }
function ejecutarComandoDictadoAnimalEnPantalla(datos){
const contPruebaCampo = document.getElementById('lista-animales-prueba-campo');
const pantallaPruebaCampoVisible = !!(contPruebaCampo && contPruebaCampo.offsetParent !== null);
const campoAreteModuloA = document.getElementById('f-arete');
const pantallaModuloAVisible = !!(campoAreteModuloA && campoAreteModuloA.offsetParent !== null);
if (pantallaPruebaCampoVisible){ ejecutarDictadoEnPruebaCampo(datos); return; }
if (pantallaModuloAVisible){ ejecutarDictadoEnModuloA(datos); return; }
estadoVisualVoz('error');
mostrarToast('Abre primero la pantalla de captura de animales (prueba de campo o Registro de ganado) para dictar los datos');
decirEnVoz('Abre primero la pantalla donde quieres capturar el animal.');
}
function ejecutarDictadoEnPruebaCampo(datos){
const encontrado = buscarAnimalParaDictadoPrueba(datos.arete);
let fila = encontrado && encontrado.fila;
let esNueva = false;
if (!fila && encontrado && encontrado.animal && typeof window.agregarAnimalDesdeFuentePC === 'function') {
  fila = window.agregarAnimalDesdeFuentePC(encontrado.animal, encontrado.productor || null, datos);
  esNueva = true;
} else if (fila && encontrado && typeof window.aplicarDictadoConCotejoPC === 'function') {
  const productor = encontrado.productor || (typeof window.productorDeFilaPC === 'function' ? window.productorDeFilaPC(fila) : null);
  const fuente = (typeof window.obtenerInventarioPC === 'function' && productor) ? window.obtenerInventarioPC(productor).find(a => window.normalizarAretePC && window.normalizarAretePC(a.arete) === window.normalizarAretePC(fila.arete)) : null;
  if (fuente) window.aplicarDictadoConCotejoPC(fila, datos, fuente);
  else {
    if (datos.raza) fila.raza = String(datos.raza).toUpperCase();
    if (datos.edad) fila.edad = datos.edad;
    if (datos.sexo) fila.sexo = sexoAHM(datos.sexo);
  }
  if (typeof marcarAnimalNuevoParaEdicion === 'function') marcarAnimalNuevoParaEdicion(fila.id);
  renderFilasAnimalesPruebaCampo();
}
if (!fila){
  // Un arete inexistente no se crea a escondidas. Se conserva TODO lo dictado
  // y se abre la confirmación para que el MVZ decida a qué productor agregarlo.
  estadoVisualVoz('error');
  if (typeof window.abrirAnimalNoEncontradoPC === 'function') window.abrirAnimalNoEncontradoPC(datos);
  mostrarBannerNotificacion(`Arete ${datos.arete}: no encontrado. Revisa y confirma si deseas darlo de alta.`, 6000, 'fa-triangle-exclamation');
  return;
}
if (typeof window.aplicarDictadoConCotejoPC === 'function' && !(encontrado && encontrado.animal)) {
  // Si el animal ya estaba en la lista, el cotejo anterior se encargó de
  // conservar el dato del inventario y marcar cualquier contradicción.
  // Para una fila manual ya existente sí aplicamos directamente lo dictado.
  if (!encontrado || encontrado.fuente !== 'prueba') {
    fila.raza = datos.raza ? String(datos.raza).toUpperCase() : fila.raza;
    fila.edad = datos.edad || fila.edad;
    fila.sexo = datos.sexo ? sexoAHM(datos.sexo) : fila.sexo;
  }
}
if (typeof guardarContextoVozUltimoAnimal === 'function') guardarContextoVozUltimoAnimal(fila.arete);
estadoVisualVoz('exito');
const conflictos = Array.isArray(fila.conflictosDatos) ? fila.conflictosDatos.length : 0;
const resumen = [fila.raza ? 'raza '+fila.raza : null, fila.edad ? fila.edad+' meses' : null, fila.sexo === 'M' ? 'macho' : 'hembra'].filter(Boolean).join(', ');
mostrarBannerNotificacion(`✓ ${fila.arete} ${esNueva ? 'cargado' : 'actualizado'} — ${resumen}${conflictos ? ` · ⚠️ ${conflictos} por verificar` : ''}`, 5000, conflictos ? 'fa-triangle-exclamation' : 'fa-microphone');
decirEnVoz(conflictos ? `Arete ${fila.arete} actualizado. Hay datos que no coinciden con el inventario; revísalos.` : `Arete ${fila.arete} actualizado.`);
}


// ---- Ejecución: llena un formulario activo, o guarda directo si no hay uno ----
function hayFormularioActivoParaVoz(tipo){
const mapaCampos = {
pesaje: { pantalla: 'f-peso', arete: 'f-animal', valor: 'f-peso' },
sanidad: { pantalla: 'f-producto', arete: 'f-animal', valor: 'f-producto' },
potrero: { pantalla: 'f-potrero', arete: null, valor: 'f-potrero' },
};
const cfg = mapaCampos[tipo];
if (!cfg) return null;
const campo = document.getElementById(cfg.pantalla);
// Se considera "activo" si el campo existe Y su pantalla está realmente visible.
if (campo && campo.offsetParent !== null) return cfg;
return null;
}
function dispararEventosCampo(el){
el.dispatchEvent(new Event('input', { bubbles: true }));
el.dispatchEvent(new Event('change', { bubbles: true }));
}
// ============================================================
// ===== CORRECCIÓN FONÉTICA (antes de interpretar el comando) =====
// ============================================================
// Esto NO reemplaza el parser de comandos ya probado — solo limpia el texto
// ANTES de que le llegue, para corregir palabras que el micrófono transcribió
// mal (ej. "bakuna" en vez de "vacuna"). El parser de comandos sigue siendo
// el mismo motor de reglas ya validado con decenas de frases reales.
const MULETILLAS_VOZ = ['eh','este','oye','a ver','por favor','anótame','ponme ahí','fíjate que','favor de','porfa','o sea','pues'];
const MAPEO_CORRECCIONES_VOZ = {
'prenada':'gestante','cargada':'gestante','embarazada':'gestante',
'kilogramos':'kilos','kg':'kilos','libras':'kilos',
};
// Palabras "canónicas" del rancho contra las que se compara cualquier
// palabra rara del dictado, para ver si el micrófono la escuchó mal. Se
// amplió con razas y productos comunes — mientras más completa esta lista,
// más términos del rancho reconoce bien en vez de transcribir algo parecido
// pero incorrecto.
const VOCABULARIO_CORRECCION_VOZ = [
'vacuna','tratamiento','desparasitar','curar','inyectar','medicar','desinfectar','purgar','bañar','fumigar','castrar','cojear','enfermar','atender',
'mover','pasar','cambiar','llevar','trasladar','sacar','meter','encerrar','arrear','jalar','soltar','juntar','reunir','regresar','potrero','corral',
'parto','nacimiento','nació','parió','alumbrar','murió','vendió',
'registrar','agregar','añadir','inscribir','capturar','comprar','llegar',
'envía','manda','dile','indica','avisa','comunica','encarga','pide','recuerda',
'kilos','arete','becerro','becerra','ternero','ternera','vaquilla','novillo','novilla','toro','semental','hato','vaca','res','macho','hembra',
'tuberculosis','brucelosis','vitamina','antibiótico',
'brahman','charolais','angus','simmental','holstein','suizo','cebú','criollo','beefmaster','brangus','limousin','simbrah','pardo','jersey','gyr','indubrasil',
'ivermectina','oxitetraciclina','penicilina','clostridial','triple','rabia','paralítica','garrapaticida','desparasitante','vitaminado','calcio','hierro',
'ordeña','ordeño','leche','litros','calostro','destete','engorda','reemplazo','sementales','pajilla','inseminación','monta','celo','diagnóstico',
'gramo','gramos','mililitro','mililitros','dosis','centímetros','metros','hectáreas','alambre','bebedero','comedero','sombra','cerca',
];
// El navegador soporta darle al reconocedor una lista de frases/palabras que
// se espera escuchar (una "gramática") — esto ayuda a que RECONOZCA MEJOR
// esas palabras desde el principio, no solo a corregirlas después de que ya
// se transcribieron mal. Es una función nativa del navegador, gratis, sin
// necesitar ningún servicio de paga.
function construirGramaticaVozRancho(){
const SGL = window.SpeechGrammarList || window.webkitSpeechGrammarList;
if (!SGL) return null;
const lista = SGL ? new SGL() : null;
if (!lista) return null;
const gramatica = `#JSGF V1.0; grammar rancho; public <termino> = ${VOCABULARIO_CORRECCION_VOZ.join(' | ')} ;`;
lista.addFromString(gramatica, 1);
return lista;
}
function calcularLevenshteinVoz(a, b){
const tmp = [];
for (let i = 0; i <= a.length; i++) tmp[i] = [i];
for (let j = 0; j <= b.length; j++) tmp[0][j] = j;
for (let i = 1; i <= a.length; i++){
for (let j = 1; j <= b.length; j++){
tmp[i][j] = a[i-1] === b[j-1] ? tmp[i-1][j-1] : Math.min(tmp[i-1][j-1]+1, tmp[i][j-1]+1, tmp[i-1][j]+1);
}
}
return tmp[a.length][b.length];
}
function autocorregirPalabraVoz(palabra){
if (/^\d+$/.test(palabra)) return palabra; // nunca tocar números (aretes/pesos)
if (palabra.length < 5) return palabra; // palabras cortas dan falsos positivos fácil (ej. "pesó" no debe tocarse)
if (MAPEO_CORRECCIONES_VOZ[palabra]) return MAPEO_CORRECCIONES_VOZ[palabra];
if (VOCABULARIO_CORRECCION_VOZ.includes(palabra)) return palabra; // ya está bien, no tocar
let mejor = null, mejorDistancia = 3; // distancia máxima permitida: 2
for (const termino of VOCABULARIO_CORRECCION_VOZ){
const distancia = calcularLevenshteinVoz(palabra, termino);
if (distancia < mejorDistancia){ mejorDistancia = distancia; mejor = termino; }
}
return mejorDistancia <= 2 ? mejor : palabra;
}
function limpiarYCorregirDictado(texto){
const palabras = texto.toLowerCase().trim().split(/\s+/);
return palabras
.filter(p => !MULETILLAS_VOZ.includes(p))
.map(p => autocorregirPalabraVoz(p))
.join(' ');
}
// ============================================================
// ===== PREGUNTAR EL DATO QUE FALTA (formulario por voz) =====
// ============================================================
// Si el comando ya se reconoció pero le falta un dato importante (ej. "vacuna
// a la 405" sin decir con qué), en vez de adivinar o guardar algo a medias,
// se pregunta por voz y se espera la SIGUIENTE grabación como respuesta a
// esa pregunta específica — no como un comando nuevo.
let comandoVozEsperandoDato = null; // { tipo, datos, textoOriginal, campo }
function preguntarDatoFaltante(tipo, datos, textoOriginal){
if (tipo === 'sanidad' && !datos.producto){
comandoVozEsperandoDato = { tipo, datos, textoOriginal, campo: 'producto' };
const pregunta = '¿Con qué producto la trataste o vacunaste?';
mostrarBannerNotificacion(pregunta, 6000, 'fa-microphone');
decirEnVoz(pregunta);
estadoVisualVoz('inactivo');
return true;
}
if (tipo === 'gasto' && datos.categoria === 'otro'){
comandoVozEsperandoDato = { tipo, datos, textoOriginal, campo: 'categoria' };
const pregunta = '¿En qué categoría entra? Por ejemplo alimento, medicina, mantenimiento o mano de obra.';
mostrarBannerNotificacion(pregunta, 6000, 'fa-microphone');
decirEnVoz(pregunta);
estadoVisualVoz('inactivo');
return true;
}
return false;
}
function completarConRespuestaDeVoz(textoRespuesta){
const pendiente = comandoVozEsperandoDato;
comandoVozEsperandoDato = null;
if (!pendiente) return false;
const respuesta = textoRespuesta.trim();
if (pendiente.campo === 'producto') pendiente.datos.producto = respuesta || 'sin especificar';
if (pendiente.campo === 'categoria'){
const CATS = { alimento:'alimento', medicina:'medicina', medicamento:'medicina', mantenimiento:'mantenimiento', 'mano de obra':'mano_obra', jornal:'mano_obra' };
const encontrada = Object.keys(CATS).find(k => respuesta.toLowerCase().includes(k));
pendiente.datos.categoria = encontrada ? CATS[encontrada] : 'otro';
}
pedirConfirmacionComandoVoz(pendiente.tipo, pendiente.datos, pendiente.textoOriginal);
return true;
}
// ============================================================
// ===== DICCIONARIO MASIVO DE COMBINACIONES (>10,000) =====
// ============================================================
const MULETILLAS_MASIVAS = ["eh","este","oye","a ver","por favor","anótame","ponme ahí","fíjate que","favor de","quiero","hazme el registro de","checa","revisa","anota","registra","pon","agregame","guárdame","porfa","oye claude"];
const VERBOS_MASIVOS = ["registrar","regístrame","dando de alta","dar de alta","agregar","añadir","ingresar","mover","muéveme","pasar","pásame","transferir","reubicar","vacunar","vacúname","inyectar","aplicar","desparasitar","palpar","inseminar","pesar","pésame","vender","dar de baja","sacar","marcar","curar","bañar","dosificar","sangrar"];
const GANADO_MASIVO = ["becerro","becerra","novillo","novillona","vaca","toro","semental","vaquilla","maza","cría","vaca mocha","vaca parida","horra","seca","lote","cabezas","arete","arete siniiga","primeriza","cargada","vacía","la huérfana","el gordo","la pinta","el despuntado"];
const INFRA_SANIDAD_MASIVO = ["potrero grande","potrero norte","corral 1","corral 2","parideras","lazareto","báscula","embarcadero","corral de manejo","tuberculosis","tb","brucelosis","garrapaticida","baño","gusano barrenador","muestras","cepa 19","rb51","vitaminado","desparasitada"];
// El vocabulario de corrección fonética (Levenshtein) y las entidades de
// reporte se amplían con tu lista de infraestructura/sanidad — ahí es donde
// esas palabras sí cambian el resultado (corrigen mishearings y amplían qué
// puede contar un reporte), en vez de vivir solas dentro de una combinación
// de texto exacto que rara vez se va a decir palabra por palabra igual.
INFRA_SANIDAD_MASIVO.forEach(t => { if (!VOCABULARIO_CORRECCION_VOZ.includes(t)) VOCABULARIO_CORRECCION_VOZ.push(t); });
function clasificarIntencionVerboMasivo(verbo){
const v = verbo.toLowerCase();
if (/registr|alta|agregar|añadir|ingresar/.test(v)) return 'ALTA_INVENTARIO';
if (/mover|muéveme|pasar|pásame|transferir|reubicar|sacar/.test(v)) return 'MOVER_POTRERO';
if (/vacun|inyect|aplicar|desparasit|palpar|insemin|curar|bañar|dosificar|sangrar/.test(v)) return 'SALUD_SANIDAD';
if (/pesar|pésame/.test(v)) return 'PESAJE';
if (/vender|baja|marcar/.test(v)) return 'BAJA_VENTA';
return 'REGISTRO_GENERAL';
}
// Genera el mapeo explícito de combinaciones: 20 muletillas × 30 verbos × 25
// términos de ganado = 15,000 combinaciones (más de las 10,000 pedidas),
// cada una con su intención ya clasificada. Se genera una sola vez al cargar
// la app (toma una fracción de segundo), no hace falta escribir cada
// combinación a mano.
const DICCIONARIO_MASIVO_FRASES = (function(){
const combinaciones = [];
for (const m of MULETILLAS_MASIVAS){
for (const v of VERBOS_MASIVOS){
const intencion = clasificarIntencionVerboMasivo(v);
for (const s of GANADO_MASIVO){
combinaciones.push({ frase: `${m} ${v} ${s}`, intencion });
}
}
}
return combinaciones;
})();
// Mapa auxiliar: de cada intención masiva a su patrón de detección real
// (reutiliza las mismas raíces de verbo ya probadas en el motor de comandos,
// para que la clasificación no viva duplicada ni se desincronice de él).
const MAPA_TIPO_A_INTENCION_MASIVA = {
'alta_animal':'ALTA_INVENTARIO', 'baja_animal':'BAJA_VENTA', 'potrero':'MOVER_POTRERO',
'sanidad':'SALUD_SANIDAD', 'pesaje':'PESAJE', 'parto':'PARTO',
'tarea_trabajador':'INDICACION_TRABAJADOR', 'reporte':'CONSULTA_REPORTE', 'prueba_campo_compleja':'PRUEBA_CAMPO',
};
// Función pedida: toma el dictado del micrófono, lo limpia (muletillas +
// corrección fonética Levenshtein) y devuelve la intención + el dato
// numérico + el texto limpio. Por dentro usa el mismo motor de comandos ya
// probado con decenas de frases reales — así el DICCIONARIO_MASIVO_FRASES
// de arriba clasifica correctamente cualquiera de sus 15,000 combinaciones
// exactas, y la función funciona igual de bien con frases que la gente
// realmente dice (que casi nunca calzan palabra por palabra con una
// combinación fija).
function procesarVozMasiva(textoDictado){
const textoLimpio = limpiarYCorregirDictado(textoDictado);
const interpretado = interpretarComandoVoz(textoLimpio);
let areteODato = null;
if (interpretado && interpretado.datos){
areteODato = interpretado.datos.arete || interpretado.datos.areteMadre || interpretado.datos.peso || null;
}
if (!areteODato){
const numeroSuelto = textoLimpio.match(/\d+/);
if (numeroSuelto) areteODato = numeroSuelto[0];
}
return {
intencion: interpretado ? (MAPA_TIPO_A_INTENCION_MASIVA[interpretado.tipo] || 'REGISTRO_GENERAL') : 'NO_RECONOCIDO',
areteODato,
textoLimpio,
};
}
function procesarComandoVoz(textoOriginal){
if (comandoVozEsperandoDato){
estadoVisualVoz('procesando');
completarConRespuestaDeVoz(textoOriginal);
return;
}
const textoCorregido = limpiarYCorregirDictado(textoOriginal);
const interpretado = interpretarComandoVoz(textoCorregido);
if (interpretado) interpretado.textoOriginal = textoOriginal; // se guarda/muestra lo que realmente se dijo, no la versión corregida
if (!interpretado){
estadoVisualVoz('error');
mostrarToast('No se reconoció el comando — revisa el formato');
decirEnVoz('No entendí ese comando. Por favor intenta de nuevo con el formato correcto.');
registrarBitacoraVoz(textoOriginal, 'no_reconocido', '');
return;
}
const { tipo, datos } = interpretado;
// 0) Navegación por voz — abre la pantalla pedida de inmediato, sin pedir
// confirmación (no cambia ningún dato, solo mueve la vista).
if (tipo === 'navegar'){
estadoVisualVoz('exito');
try {
if (datos.funcion === 'modulo') irModulo(datos.destino);
else if (datos.funcion === 'admin') irAdmin(datos.destino);
else irA(datos.destino);
decirEnVoz('Listo');
} catch(e){
console.error('No se pudo abrir la pantalla por voz:', e);
mostrarToast('No se pudo abrir esa pantalla');
}
registrarBitacoraVoz(textoOriginal, 'navegar', datos.destino);
return;
}
// 0) Comando complejo de prueba de campo (productor + tipo de prueba +
// motivo) — prepara la pantalla en vez de intentar guardar algo directo,
// porque una prueba real necesita ir agregando animales uno por uno.
if (tipo === 'prueba_campo_compleja'){
estadoVisualVoz('exito');
ejecutarComandoPruebaCampoComplejo(datos).catch(e => {
console.error('Error al preparar la prueba por voz:', e);
mostrarToast('No se pudo preparar la prueba — ábrela manualmente');
});
return;
}
// 0.5) Indicación por voz para un trabajador ya registrado — se confirma
// antes de mandarla, para no arriesgarse a que el reconocedor haya entendido
// mal el nombre o la instrucción.
if (tipo === 'tarea_trabajador'){
pedirConfirmacionComandoVoz(tipo, datos, textoOriginal);
return;
}
// 0.7) Reporte / consulta — es de solo lectura (no crea ni cambia nada), así
// que se responde de inmediato sin pedir confirmación, igual que preguntar
// cualquier otro dato.
if (tipo === 'reporte'){
estadoVisualVoz('exito');
ejecutarComandoReporte(datos);
return;
}
// 0.8) Buscar arete — también de solo lectura, responde de inmediato.
if (tipo === 'buscar_arete'){
estadoVisualVoz('exito');
ejecutarComandoBuscarArete(datos);
return;
}
// 0.9) Dictado de varios campos de un animal directo en la pantalla de
// captura (prueba de campo o Registro de ganado) — llena los campos a la
// vista, sin pedir confirmación aparte, porque la persona ya revisa y guarda
// ella misma después de ver el formulario lleno (igual que pesaje/sanidad).
if (tipo === 'dictado_animal_pantalla'){
ejecutarComandoDictadoAnimalEnPantalla(datos).catch(e => {
console.error('Error al llenar el animal por voz:', e);
mostrarToast('No se pudo llenar el formulario — inténtalo a mano');
});
return;
}
// 1) Si hay un formulario de ese tipo abierto en pantalla, se rellena ahí
// (la persona confirma y guarda ella misma, con oportunidad de corregir).
const formularioActivo = hayFormularioActivoParaVoz(tipo);
if (formularioActivo){
if (formularioActivo.arete && datos.arete){
const campoArete = document.getElementById(formularioActivo.arete);
if (campoArete){ campoArete.value = datos.arete; dispararEventosCampo(campoArete); }
}
const campoValor = document.getElementById(formularioActivo.valor);
if (campoValor){
campoValor.value = tipo === 'pesaje' ? datos.peso : (tipo === 'sanidad' ? datos.producto : datos.potrero);
dispararEventosCampo(campoValor);
}
estadoVisualVoz('exito');
mostrarBannerNotificacion('Formulario llenado por voz — revisa y guarda', 3500, 'fa-microphone');
decirEnVoz('Listo, revisa los datos y guarda.');
return;
}
// 2) Si no hay formulario abierto, se pide confirmar ANTES de guardar en
// segundo plano — si el reconocedor de voz entendió mal (ruido, señal,
// acento), esto evita que se guarde un dato equivocado sin que nadie se dé
// cuenta hasta después.
if (preguntarDatoFaltante(tipo, datos, textoOriginal)) return;
pedirConfirmacionComandoVoz(tipo, datos, textoOriginal);
}
// ---- Confirmación antes de guardar (banner + botones + escucha "sí/no") ----
function resumenComandoVoz(tipo, datos){
if (tipo === 'pesaje') return `Peso de ${datos.peso} kilos para el arete ${datos.arete}`;
if (tipo === 'sanidad') return `${datos.producto} para el arete ${datos.arete}`;
if (tipo === 'potrero') return `Mover el arete ${datos.arete} al potrero ${datos.potrero}`;
if (tipo === 'parto') return `Registrar cría ${datos.sexo} de la madre con arete ${datos.areteMadre}`;
if (tipo === 'gasto') return `Registrar ${datos.tipoMovimiento === 'ingreso' ? 'un ingreso' : 'un gasto'} de $${datos.monto} (${datos.categoria})`;
if (tipo === 'leche') return `Registrar ordeña de ${datos.litros} litros del arete ${datos.arete}${datos.turno ? ' (' + datos.turno + ')' : ''}`;
if (tipo === 'servicio') return `Registrar ${datos.tipoServicio === 'inseminacion_artificial' ? 'inseminación' : 'monta'} de la vaca ${datos.arete} con ${datos.toro || 'semental no especificado'}`;
if (tipo === 'alta_animal_completa'){
const partes = [`arete ${datos.arete}`];
if (datos.nombre) partes.push(datos.nombre);
if (datos.raza) partes.push('raza ' + datos.raza);
if (datos.peso) partes.push(datos.peso + ' kilos');
if (datos.estadoReproductivo === 'gestante') partes.push('cargada' + (datos.mesesGestacion ? ' de ' + datos.mesesGestacion + ' meses' : ''));
else if (datos.estadoReproductivo) partes.push(datos.estadoReproductivo.replace('_',' '));
if (datos.potrero) partes.push('potrero ' + datos.potrero);
if (datos.uppReferencia) partes.push(datos.uppReferencia + ' (revisa esto, no estoy seguro)');
if (datos.fecha && datos.fecha !== hoyISO()) partes.push('fecha ' + datos.fecha);
return 'Dar de alta: ' + partes.join(', ');
}
if (tipo === 'bodega') return `Descontar ${datos.cantidad} de ${datos.producto} de la bodega`;
if (tipo === 'alta_animal') return `Dar de alta el arete ${datos.arete}${datos.sexo ? ' (' + datos.sexo + ')' : ''}${datos.raza ? ', raza ' + datos.raza : ''}`;
if (tipo === 'baja_animal') return `Dar de baja el arete ${datos.arete} (${datos.motivo})`;
if (tipo === 'tarea_trabajador') return `Indicación para ${datos.trabajador.nombre}: ${datos.instruccion}`;
return 'este registro';
}
let comandoVozPendiente = null;
let reconocimientoConfirmacionVoz = null;
function pedirConfirmacionComandoVoz(tipo, datos, textoOriginal){
comandoVozPendiente = { tipo, datos, textoOriginal };
const resumen = resumenComandoVoz(tipo, datos);
document.getElementById('texto-confirmar-voz').textContent = resumen;
// Muestra también el texto exacto que captó el micrófono — si hay ruido de
// fondo y no se alcanza a oír bien la confirmación por voz, se puede leer
// aquí qué fue lo que la app entendió que se dijo.
const cajaTextoCrudo = document.getElementById('texto-crudo-confirmar-voz');
if (cajaTextoCrudo) cajaTextoCrudo.textContent = `Se escuchó: "${textoOriginal}"`;
const modal = document.getElementById('modal-confirmar-voz');
modal.classList.remove('hidden'); modal.style.display = 'flex';
estadoVisualVoz('inactivo');
decirEnVoz(`Vas a registrar: ${resumen}. Di sí para confirmar, o no para cancelar.`);
// Escucha automáticamente la respuesta corta, para que no haga falta tocar
// la pantalla si se tienen las manos ocupadas — los botones siguen ahí por
// si el micrófono no capta bien el "sí"/"no".
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SR){
setTimeout(() => {
if (!comandoVozPendiente) return; // ya se respondió por botón mientras tanto
try {
const rec = new SR();
rec.lang = CONFIG_VOZ.idiomaReconocimiento;
rec.continuous = false;
rec.interimResults = false;
reconocimientoConfirmacionVoz = rec;
// Antes de decidir que "no" significa cancelar, se revisa si en realidad es
// una CORRECCIÓN de un campo puntual ("no, el peso es 450, no 420" / "cambia
// el potrero a La Mesa") — en vez de cancelar todo el registro, se corrige
// solo ese dato y se vuelve a pedir confirmación con el dato ya corregido.
const MAPA_CAMPOS_CORRECCION_VOZ = {
peso: ['peso', 'kilos', 'kilo', 'kg'],
potrero: ['potrero', 'corral'],
arete: ['arete', 'número', 'numero'],
litros: ['litros', 'litro'],
producto: ['producto', 'medicamento'],
monto: ['monto', 'precio', 'costo', 'cantidad'],
toro: ['toro', 'pajilla', 'semental'],
mesesGestacion: ['meses', 'gestación', 'gestacion'],
};
function intentarCorregirCampoPendiente(textoDicho){
if (!comandoVozPendiente) return false;
const textoConvertido = convertirNumerosEspanolADigitos(textoDicho.toLowerCase());
let campoDetectado = null;
for (const [campo, palabrasClave] of Object.entries(MAPA_CAMPOS_CORRECCION_VOZ)){
if (palabrasClave.some(p => textoConvertido.includes(p))){ campoDetectado = campo; break; }
}
if (!campoDetectado) return false;
if (!(campoDetectado in comandoVozPendiente.datos)) return false;
// El nuevo valor es el ÚLTIMO número de la frase (para "el peso es 450, no
// 420" — se queda con 450, el valor correcto que se dijo al final,
// no el 420 que se está corrigiendo).
const numeros = textoConvertido.match(/\d+(?:[.,]\d+)?/g);
if (campoDetectado === 'potrero' || campoDetectado === 'producto' || campoDetectado === 'toro'){
// Campos de texto: se toma lo que sigue a la palabra clave ("a"/"es").
const m = textoConvertido.match(/(?:a|es)\s+([a-zñáéíóú ]+)$/i);
if (!m) return false;
comandoVozPendiente.datos[campoDetectado] = m[1].trim().replace(/\b\w/g, c => c.toUpperCase());
} else {
if (!numeros || numeros.length === 0) return false;
// El valor correcto es el que sigue a "es"/"son" (ej. "el peso ES 450, no
// 420") — no simplemente el último número de la frase, porque el número
// que se está RECHAZANDO casi siempre viene después, no antes.
const despuesDeEs = textoConvertido.match(/(?:es|son)\s+(\d+(?:[.,]\d+)?)/i);
const valorCorregido = despuesDeEs ? despuesDeEs[1] : numeros[0];
comandoVozPendiente.datos[campoDetectado] = parseFloat(valorCorregido.replace(',', '.'));
}
// Se vuelve a mostrar la confirmación con el dato ya corregido, en vez de
// guardar directo — sigue habiendo oportunidad de revisar todo antes de
// que se guarde de verdad.
pedirConfirmacionComandoVoz(comandoVozPendiente.tipo, comandoVozPendiente.datos, comandoVozPendiente.textoOriginal + ' → corregido: ' + textoDicho);
return true;
}
rec.onresult = evt => {
const dicho = (evt.results[0][0].transcript || '').toLowerCase();
if (/\b(s[ií]|confirmo|correcto|guardar?)\b/.test(dicho)) { responderConfirmacionVoz(true); return; }
if (intentarCorregirCampoPendiente(dicho)) return;
if (/\b(no|cancela?r?|incorrecto)\b/.test(dicho)) responderConfirmacionVoz(false);
};
rec.onend = () => { reconocimientoConfirmacionVoz = null; };
rec.start();
} catch(e){}
}, 900);
}
}
async function responderConfirmacionVoz(confirmado){
if (reconocimientoConfirmacionVoz){ try { reconocimientoConfirmacionVoz.stop(); } catch(e){} reconocimientoConfirmacionVoz = null; }
const modal = document.getElementById('modal-confirmar-voz');
modal.classList.add('hidden'); modal.style.removeProperty('display');
const pendiente = comandoVozPendiente;
comandoVozPendiente = null;
if (!pendiente) return;
if (!confirmado){
decirEnVoz('Cancelado.');
mostrarToast('Comando de voz cancelado');
registrarBitacoraVoz(pendiente.textoOriginal, 'cancelado', resumenComandoVoz(pendiente.tipo, pendiente.datos));
return;
}
const { tipo, datos, textoOriginal } = pendiente;
try {
if (tipo === 'tarea_trabajador') ejecutarComandoTareaTrabajador(datos);
else if (tipo === 'alta_animal') await ejecutarComandoAltaAnimalPorVoz(datos, textoOriginal);
else if (tipo === 'baja_animal') ejecutarComandoBajaAnimalPorVoz(datos);
else guardarComandoVozEnSegundoPlano(tipo, datos, textoOriginal);
estadoVisualVoz('exito');
if (tipo !== 'tarea_trabajador') decirEnVoz('Registro guardado exitosamente.');
registrarBitacoraVoz(textoOriginal, 'guardado', resumenComandoVoz(tipo, datos));
} catch(e){
console.error('Error al guardar comando de voz:', e);
estadoVisualVoz('error');
mostrarToast('No se pudo guardar el registro por voz — inténtalo desde el formulario');
decirEnVoz('No se pudo guardar el registro. Por favor inténtalo desde el formulario.');
registrarBitacoraVoz(textoOriginal, 'error', e.message || '');
}
}
// ---- Bitácora de comandos de voz (para que la persona pueda auditar ella
// misma qué se dictó y qué pasó, sin depender de que yo revise su celular) ----
function registrarBitacoraVoz(textoOriginal, resultado, detalle){
if (!Array.isArray(estado.bitacoraVoz)) estado.bitacoraVoz = [];
estado.bitacoraVoz.unshift({ texto: textoOriginal, resultado, detalle, fecha: new Date().toISOString() });
if (estado.bitacoraVoz.length > 50) estado.bitacoraVoz.length = 50;
guardarEstadoLocal();
if (typeof renderBitacoraVoz === 'function') renderBitacoraVoz();
}
function limpiarBitacoraVoz(){
estado.bitacoraVoz = [];
guardarEstadoLocal();
renderBitacoraVoz();
}
function renderBitacoraVoz(){
const cont = document.getElementById('lista-bitacora-voz');
if (!cont) return;
const items = estado.bitacoraVoz || [];
if (items.length === 0){ cont.innerHTML = `<p class="text-xs text-center py-4" style="color:var(--sage);">Aún no hay comandos de voz registrados.</p>`; return; }
const ETIQUETAS_RESULTADO_VOZ = {
guardado: { texto: 'Guardado', color: 'var(--green)', icono: 'fa-circle-check' },
cancelado: { texto: 'Cancelado', color: 'var(--sage)', icono: 'fa-circle-xmark' },
error: { texto: 'Error', color: 'var(--red)', icono: 'fa-triangle-exclamation' },
no_reconocido: { texto: 'No se entendió', color: 'var(--orange)', icono: 'fa-circle-question' },
};
cont.innerHTML = items.map(item => {
const et = ETIQUETAS_RESULTADO_VOZ[item.resultado] || ETIQUETAS_RESULTADO_VOZ.error;
const fecha = new Date(item.fecha);
const fechaTexto = isNaN(fecha) ? '' : fecha.toLocaleString('es-MX', { day:'2-digit', month:'2-digit', hour:'2-digit', minute:'2-digit' });
return `
<div class="bg-white rounded-2xl p-3" style="border:2px solid var(--line); border-left:5px solid ${et.color};">
<p class="text-sm font-bold" style="color:var(--ink);">"${item.texto}"</p>
${item.detalle ? `<p class="text-xs mt-1" style="color:var(--sage);">${item.detalle}</p>` : ''}
<div class="flex items-center justify-between mt-2">
<span class="text-xs font-bold" style="color:${et.color};"><i class="fa-solid ${et.icono}"></i> ${et.texto}</span>
<span class="text-xs" style="color:var(--sage);">${fechaTexto}</span>
</div>
</div>`;
}).join('');
}
// Guarda directo en las mismas listas que usa el resto de la app (pesajes,
// salud, animales) — así el registro aparece de inmediato en las pantallas
// normales y se sincroniza igual que cualquier otro dato, sin sistemas
// paralelos. Cada registro se marca con origen:'comando_voz' para poder
// identificarlo después si hace falta revisar los que se crearon por voz.
function guardarComandoVozEnSegundoPlano(tipo, datos, textoOriginal){
// Busca coincidencia exacta primero; si no hay, busca por TERMINACIÓN del
// arete (los últimos dígitos que se hayan dictado) — igual que ya funciona en
// el resto de la app, para no obligar a decir el número completo cada vez.
// Si la terminación coincide con más de un animal, se rechaza en vez de
// adivinar cuál — mejor pedir más dígitos que arriesgarse a elegir mal.
function animalEncontrado(areteDictado){
const buscado = String(areteDictado).trim().toLowerCase();
const exacto = estado.animales.find(a => (a.arete || '').toLowerCase() === buscado);
if (exacto) return exacto;
const porTerminacion = estado.animales.filter(a => (a.arete || '').toLowerCase().endsWith(buscado));
if (porTerminacion.length === 1) return porTerminacion[0];
if (porTerminacion.length > 1) throw new Error(`Hay ${porTerminacion.length} animales que terminan en ${areteDictado} — di el número completo`);
return null;
}
if (tipo === 'pesaje'){
const animal = animalEncontrado(datos.arete);
if (!animal) throw new Error('Arete no encontrado en el hato: ' + datos.arete);
estado.pesajes.push({ animal: animal.arete, fecha: hoyISO(), peso: datos.peso, lote: null, condicionCorporal: null, origen: 'comando_voz', textoOriginal });
guardarContextoVozUltimoAnimal(animal.arete);
} else if (tipo === 'sanidad'){
const animal = animalEncontrado(datos.arete);
if (!animal) throw new Error('Arete no encontrado en el hato: ' + datos.arete);
estado.salud.push({ animal: animal.arete, producto: datos.producto, fecha: hoyISO(), proxima: '', notas: 'Registrado por comando de voz', diasRetiro: null, origen: 'comando_voz', textoOriginal });
guardarContextoVozUltimoAnimal(animal.arete);
} else if (tipo === 'potrero'){
const a = animalEncontrado(datos.arete);
if (!a) throw new Error('Arete no encontrado en el hato: ' + datos.arete);
a.potrero = datos.potrero;
estado.movimientosAnimal.push({ animal: a.arete, tipo: 'potrero', concepto: 'Cambio de potrero por voz a ' + datos.potrero, monto: 0, fecha: hoyISO(), origen: 'comando_voz' });
guardarContextoVozUltimoAnimal(a.arete);
} else if (tipo === 'parto'){
const madre = animalEncontrado(datos.areteMadre);
if (!madre) throw new Error('Arete de la madre no encontrado: ' + datos.areteMadre);
const nuevoArete = 'VOZ-' + Date.now().toString().slice(-8);
estado.animales.push({
arete: nuevoArete, chip:'', nombre:'', raza:'', sexo: datos.sexo === 'macho' ? 'Macho' : 'Hembra',
fecha: hoyISO(), estatus:'Activo', madre: madre.arete, padre:'', potrero:'', motivoBaja:'', foto:null,
proposito:'', engordaDiasObjetivo:null, engordaPesoMeta:null, engordaInicio:null, engordaFinalizado:false, engordaDiasFinal:null,
origen: 'comando_voz', textoOriginal,
});
guardarContextoVozUltimoAnimal(nuevoArete);
} else if (tipo === 'leche'){
if (!datos.arete) throw new Error('No se identificó a qué animal pertenece la ordeña — di el número de arete');
const animalLeche = animalEncontrado(datos.arete);
if (!animalLeche) throw new Error('Arete no encontrado en el hato: ' + datos.arete);
const fechaLeche = datos.fecha || hoyISO();
const am = datos.turno === 'AM' ? (datos.litros || 0) : 0;
const pm = datos.turno === 'PM' ? (datos.litros || 0) : 0;
const total = datos.turno ? (am + pm) : (datos.litros || 0);
estado.produccionLeche.push({ animal: animalLeche.arete, fecha: fechaLeche, ordenador: '', litrosAM: am, litrosPM: pm, total, grasa:'', proteina:'', celulas:'', notas: 'Registrado por comando de voz', origen: 'comando_voz', textoOriginal });
guardarContextoVozUltimoAnimal(animalLeche.arete);
} else if (tipo === 'servicio'){
const vaca = animalEncontrado(datos.arete);
if (!vaca) throw new Error('Arete no encontrado en el hato: ' + datos.arete);
const fecha = hoyISO();
estado.reproduccion.push({
vaca: vaca.arete, servicio: datos.tipoServicio, fecha, toro: datos.toro || '', diagnostico: 'sin_diagnostico',
parto: sumarDias(fecha, 283), secado: null, partoReal: null, cierreLactancia: null, finPeriodoSeco: null,
fechaProximoCelo: sumarDias(fecha, 21), celoDescartado: false, origen: 'comando_voz', textoOriginal,
});
guardarContextoVozUltimoAnimal(vaca.arete);
} else if (tipo === 'alta_animal_completa'){
if (estado.animales.some(a => a.arete === datos.arete)) throw new Error('Ya existe un animal registrado con el arete ' + datos.arete);
if (typeof buscarAreteEnOtraUPP === 'function'){
const conflicto = buscarAreteEnOtraUPP(datos.arete);
if (conflicto) throw new Error('Ese arete ya está en uso en otra cuenta');
}
const fechaAlta = datos.fecha || hoyISO();
// Si mencionó un potrero que no existe todavía en el catálogo, se da de
// alta solo — así la próxima vez que alguien lo diga ya se reconoce contra
// el catálogo real, en vez de quedar como texto suelto sin dueño.
if (datos.potrero && !(estado.potreros || []).some(p => p.nombre.toLowerCase() === datos.potrero.toLowerCase())){
estado.potreros = estado.potreros || [];
estado.potreros.push({ nombre: datos.potrero, capacidad: null, color: '#5C6B55', poligono: null, hectareas: null, centro: null, origen: 'comando_voz' });
}
const nombreCompuesto = [datos.nombre, datos.raza].filter(Boolean).join(' ').trim();
estado.animales.push({
arete: datos.arete, chip:'', nombre: nombreCompuesto, raza: datos.raza || '',
sexo: datos.sexo === 'macho' ? 'Macho' : (datos.sexo === 'hembra' ? 'Hembra' : 'Hembra'),
fecha: fechaAlta, estatus:'Activo', madre:'', padre:'', potrero: datos.potrero || '', motivoBaja:'', foto:null,
proposito:'', engordaDiasObjetivo:null, engordaPesoMeta:null, engordaInicio:null, engordaFinalizado:false, engordaDiasFinal:null,
origen:'comando_voz', textoOriginal,
});
if (datos.peso){
estado.pesajes.push({ animal: datos.arete, fecha: fechaAlta, peso: datos.peso, lote: null, condicionCorporal: null, origen: 'comando_voz', textoOriginal });
}
if (datos.estadoReproductivo === 'gestante'){
// Los meses de gestación dictados se traducen a una fecha probable de
// parto (283 días de gestación total, menos lo que ya lleva avanzado).
const diasGestados = datos.mesesGestacion ? datos.mesesGestacion * 30 : 90;
const fechaServicioEstimada = sumarDiasISO(fechaAlta, -diasGestados);
estado.reproduccion.push({
vaca: datos.arete, servicio: 'monta_directa', fecha: fechaServicioEstimada, toro: '', diagnostico: 'confirmada',
parto: sumarDiasISO(fechaServicioEstimada, 283), secado: null, partoReal: null, cierreLactancia: null, finPeriodoSeco: null,
fechaProximoCelo: null, celoDescartado: false, origen: 'comando_voz', textoOriginal,
notas: 'Gestación estimada por dictado de voz — revisar fecha con el veterinario',
});
}
// Se guarda como "último animal mencionado" para poder referirse a él
// después sin repetir el arete (ej. "y esa misma vaca ponla en el corral 2").
guardarContextoVozUltimoAnimal(datos.arete);
if (datos.uppReferencia){
mostrarToast(`Guardado — pero revisa la UPP: se entendió "${datos.uppReferencia}", confírmala a mano en los datos del animal`);
}
} else if (tipo === 'bodega'){
if (!datos.cantidad || !datos.producto) throw new Error('No se identificó bien la cantidad o el producto — di algo como "usé 5 kilos de alimento"');
// Se busca el insumo por parecido de nombre (igual que se busca un animal
// por terminación de arete) — no hace falta decir el nombre exacto tal
// cual está capturado en la bodega.
const insumo = buscarPersonaFuzzy(datos.producto, estado.bodega, i => i.producto);
if (!insumo) throw new Error('No se encontró "' + datos.producto + '" en tu bodega — revisa el nombre exacto');
descontarInsumoBodega(insumo.persona.id, datos.cantidad);
} else if (tipo === 'gasto'){
if (!datos.monto) throw new Error('No se identificó el monto — di la cantidad seguida de "pesos"');
estado.costos.push({ tipo: datos.tipoMovimiento, categoria: datos.categoria, monto: datos.monto, fecha: hoyISO(), imputar: '', descripcion: datos.descripcion, origen: 'comando_voz', textoOriginal });
}
guardarEstadoLocal();
if (typeof renderHato === 'function') renderHato();
if (typeof renderResumenProductor === 'function') renderResumenProductor();
}

  window['activarModoPlautdietschVoz'] = activarModoPlautdietschVoz;
  window['tonoInicioEscucha'] = tonoInicioEscucha;
  window['decirEnVoz'] = decirEnVoz;
  window['estadoVisualVoz'] = estadoVisualVoz;
  window['mostrarEtiqueta'] = mostrarEtiqueta;
  window['actualizarBotonVozSegunConexion'] = actualizarBotonVozSegunConexion;
  window['iniciarEscuchaContinua'] = iniciarEscuchaContinua;
  window['detenerEscuchaContinua'] = detenerEscuchaContinua;
  window['traducirDesdePlautdietsch'] = traducirDesdePlautdietsch;
  window['convertirNumerosEspanolADigitos'] = convertirNumerosEspanolADigitos;
  window['buscarPersonaFuzzy'] = buscarPersonaFuzzy;
  window['buscarProductorEnFrase'] = buscarProductorEnFrase;
  window['interpretarComandoComplejoPruebaCampo'] = interpretarComandoComplejoPruebaCampo;
  window['buscarTrabajadorEnFrase'] = buscarTrabajadorEnFrase;
  window['interpretarComandoTareaTrabajador'] = interpretarComandoTareaTrabajador;
  window['ejecutarComandoTareaTrabajador'] = ejecutarComandoTareaTrabajador;
  window['ejecutarComandoPruebaCampoComplejo'] = ejecutarComandoPruebaCampoComplejo;
  window['interpretarFechaRelativaVoz'] = interpretarFechaRelativaVoz;
  window['extraerAltaAnimalCompleta'] = extraerAltaAnimalCompleta;
  window['interpretarComandoAltaAnimal'] = interpretarComandoAltaAnimal;
  window['ejecutarComandoAltaAnimalPorVoz'] = ejecutarComandoAltaAnimalPorVoz;
  window['interpretarComandoBajaAnimal'] = interpretarComandoBajaAnimal;
  window['ejecutarComandoBajaAnimalPorVoz'] = ejecutarComandoBajaAnimalPorVoz;
  window['interpretarComandoBuscarArete'] = interpretarComandoBuscarArete;
  window['ejecutarComandoBuscarArete'] = ejecutarComandoBuscarArete;
  window['interpretarComandoGasto'] = interpretarComandoGasto;
  window['extraerFiltroFechaReporte'] = extraerFiltroFechaReporte;
  window['interpretarComandoReporte'] = interpretarComandoReporte;
  window['ejecutarComandoReporte'] = ejecutarComandoReporte;
  window['unirDigitosSueltosDeArete'] = unirDigitosSueltosDeArete;
  window['interpretarComandoNavegacion'] = interpretarComandoNavegacion;
  window['extraerValorTrasPalabraClave'] = extraerValorTrasPalabraClave;
  window['interpretarComandoDictadoAnimalEnPantalla'] = interpretarComandoDictadoAnimalEnPantalla;
  window['ejecutarComandoDictadoAnimalEnPantalla'] = ejecutarComandoDictadoAnimalEnPantalla;
  window['iniciarDictadoAnimalPruebaCampo'] = iniciarDictadoAnimalPruebaCampo;
  window['detenerDictadoAnimalPruebaCampo'] = detenerDictadoAnimalPruebaCampo;
  window['ejecutarDictadoEnPruebaCampo'] = ejecutarDictadoEnPruebaCampo;
  // Los siguientes puentes permiten al módulo de voz usar exactamente la misma búsqueda/cotejo que la UI.
  window['buscarAnimalParaDictadoPrueba'] = buscarAnimalParaDictadoPrueba;
  window['ejecutarDictadoEnModuloA'] = ejecutarDictadoEnModuloA;
  window['guardarContextoVozUltimoAnimal'] = guardarContextoVozUltimoAnimal;
  window['obtenerUltimoAnimalContextoVoz'] = obtenerUltimoAnimalContextoVoz;
  window['resolverReferenciasContextoVoz'] = resolverReferenciasContextoVoz;
  window['interpretarComandoVoz'] = interpretarComandoVoz;
  window['hayFormularioActivoParaVoz'] = hayFormularioActivoParaVoz;
  window['dispararEventosCampo'] = dispararEventosCampo;
  window['construirGramaticaVozRancho'] = construirGramaticaVozRancho;
  window['calcularLevenshteinVoz'] = calcularLevenshteinVoz;
  window['autocorregirPalabraVoz'] = autocorregirPalabraVoz;
  window['limpiarYCorregirDictado'] = limpiarYCorregirDictado;
  window['preguntarDatoFaltante'] = preguntarDatoFaltante;
  window['completarConRespuestaDeVoz'] = completarConRespuestaDeVoz;
  window['clasificarIntencionVerboMasivo'] = clasificarIntencionVerboMasivo;
  window['procesarVozMasiva'] = procesarVozMasiva;
  window['procesarComandoVoz'] = procesarComandoVoz;
  window['resumenComandoVoz'] = resumenComandoVoz;
  window['pedirConfirmacionComandoVoz'] = pedirConfirmacionComandoVoz;
  window['intentarCorregirCampoPendiente'] = intentarCorregirCampoPendiente;
  window['responderConfirmacionVoz'] = responderConfirmacionVoz;
  window['registrarBitacoraVoz'] = registrarBitacoraVoz;
  window['limpiarBitacoraVoz'] = limpiarBitacoraVoz;
  window['renderBitacoraVoz'] = renderBitacoraVoz;
  window['guardarComandoVozEnSegundoPlano'] = guardarComandoVozEnSegundoPlano;
  window['animalEncontrado'] = animalEncontrado;
})();
