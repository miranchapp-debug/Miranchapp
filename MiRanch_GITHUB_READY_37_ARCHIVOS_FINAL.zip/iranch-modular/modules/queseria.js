(function(){
// MiRanch — módulo extraído automáticamente. Se ejecuta como script clásico para conservar compatibilidad con funciones globales.
// ================= MÓDULO: RECEPCIÓN DE LECHE (QUESERÍA) =================
function fondoParaHeaderQueseria(){
return (estado.configuracion && estado.configuracion.fondoHeader) || FONDO_HEADER_DEFAULT;
}
function nombreQueseriaActiva(){
if (estado.puntoActivoId){
const cuenta = estado.cuentasProductores.find(c => c.id === estado.puntoActivoId);
if (cuenta) return cuenta.predio || cuenta.nombre;
}
return estado.queseria.nombre || tr('queseria_productores__nombre_de_la_queseria');
}
// Cada "Punto receptor de leche" ve y guarda solo sus propios lecheros/productores/recepciones,
// separado de los datos de la quesería global (operadores op1/op2/op3/admin).
function lecherosDelAmbito(){
return estado.lecheros.filter(l => (l.puntoId || null) === (estado.puntoActivoId || null));
}
function productoresLecheDelAmbito(){
return estado.productoresLeche.filter(p => (p.puntoId || null) === (estado.puntoActivoId || null));
}
function recepcionesLecheDelAmbito(){
return estado.recepcionesLeche.filter(r => (r.puntoId || null) === (estado.puntoActivoId || null));
}
function logoActivo(){
return (estado.configuracion && estado.configuracion.logoPersonalizado) || LOGO_QUESERIA_B64;
}
// Actualiza el logo en TODAS las pantallas donde aparece de forma estática en el HTML
// (login, header del productor) — la quesería ya lo toma de logoActivo() en cada repintado.
function aplicarLogoPersonalizado(){
document.querySelectorAll('img[data-logo-role="horizontal"]').forEach(img => { img.src = logoActivo(); });
}
function renderHeaderQueseria(idContenedor, opciones){
opciones = opciones || {};
const cont = document.getElementById(idContenedor);
if (!cont) return;
cont.style.backgroundImage = `url('${fondoParaHeaderQueseria()}')`;
cont.className = 'miranch-topbar';
cont.innerHTML = `
<div class="miranch-brand"><img loading="eager" decoding="async" alt="MiRanch" data-logo-role="horizontal" src="${logoActivo()}"/></div>
<div class="miranch-actions">
<div class="relative">
<button class="miranch-action lang" onclick="toggleSelectorIdioma()" title="Idioma / Language / Sprache"><i class="fa-solid fa-globe"></i><span class="idioma-actual-label">ESP</span><i class="fa-solid fa-chevron-down" style="font-size:.58rem;"></i></button>
<div class="menu-idioma miranch-lang-menu hidden" style="position:absolute;background:#fff;border-radius:16px;box-shadow:0 10px 24px -6px rgba(0,0,0,.35);padding:.4rem;min-width:170px;z-index:80;">
<button class="idioma-opcion" data-idioma="es" onclick="cambiarIdioma('es')" style="display:flex;width:100%;padding:.55rem .65rem;border-radius:10px;font-size:.85rem;font-weight:700;color:var(--ink);">🇲🇽 Español</button>
<button class="idioma-opcion" data-idioma="en" onclick="cambiarIdioma('en')" style="display:flex;width:100%;padding:.55rem .65rem;border-radius:10px;font-size:.85rem;font-weight:700;color:var(--ink);">🇺🇸 English</button>
<button class="idioma-opcion" data-idioma="de" onclick="cambiarIdioma('de')" style="display:flex;width:100%;padding:.55rem .65rem;border-radius:10px;font-size:.85rem;font-weight:700;color:var(--ink);">🇩🇪 Deutsch</button>
<button class="idioma-opcion" data-idioma="pd" onclick="cambiarIdioma('pd')" style="display:flex;width:100%;padding:.55rem .65rem;border-radius:10px;font-size:.85rem;font-weight:700;color:var(--ink);">🌾 Plautdietsch</button>
<button onclick="toggleSelectorIdioma(); abrirGlosario();" style="display:flex;width:100%;padding:.55rem .65rem;border-radius:10px;font-size:.8rem;font-weight:700;color:var(--sage);border-top:1px solid var(--line);margin-top:.3rem;"><i class="fa-solid fa-book mr-1"></i><span data-i18n="glosario_titulo">Glosario técnico</span></button>
</div></div>
${opciones.mostrarSalir ? `<button class="miranch-action logout" onclick="cerrarQueseria()" title="${tr('queseria_menu__cerrar_sesion')}"><i class="fa-solid fa-right-from-bracket"></i><span>Salir</span></button>` : ''}
</div>`;
}
async function asegurarVistaQueseriaIRanch(){
const destino = document.getElementById('app-quesera');
if (!destino) return null;
if (destino.querySelector('.screen')) return destino;
if (typeof window.cargarVistaIRanch !== 'function') throw new Error('Cargador de vistas no disponible');
return window.cargarVistaIRanch('queseria', destino);
}
async function mostrarPantallaQueseraLogin(){
await asegurarVistaQueseriaIRanch();
document.getElementById('screen-login').classList.remove('active');
document.getElementById('app-quesera').classList.remove('hidden');
document.querySelectorAll('#app-quesera .screen').forEach(s => s.classList.remove('active'));
document.getElementById('screen-quesera-login').classList.add('active');
renderHeaderQueseria('header-quesera-login', {});
renderGridPerfilesQueseria();
}
function cerrarQueseria(){
estado.queseria.operadorActivo = null;
estado.queseria.rolActivoQueseria = null;
estado.puntoActivoId = null;
document.getElementById('app-quesera').classList.add('hidden');
// Se usa la misma función que ya blinda contra el modo demo (en vez de
// prender la pantalla de login directo aquí) — así este camino también
// queda cubierto, sin duplicar esa lógica una tercera vez.
mostrarPantallaLogin();
}
function renderGridPerfilesQueseria(){
const cont = document.getElementById('grid-perfiles-queseria');
if (!cont) return;
const perfiles = [
{ id:'admin', nombre: tr('queseria__administrador'), icono:'fa-user-gear', color:'var(--slate)' },
...estado.operadoresQueseria.map((op, i) => ({ id: op.id, nombre: op.nombre, icono:'fa-user', color: ['var(--pine)','var(--teal)','var(--orange)'][i % 3] })),
];
cont.innerHTML = perfiles.map(p => `
<button onclick="entrarQueseriaComo('${p.id}','${p.nombre.replace(/'/g, "\\'")}')" class="rounded-3xl p-3 flex flex-col items-center justify-center gap-2 shadow-xl" style="background:${p.color}; min-height:68px;">
<i class="fa-solid ${p.icono} text-2xl" style="color:#fff;"></i>
<span class="text-xs font-bold text-white text-center">${p.nombre}</span>
</button>`).join('');
}
async function entrarQueseriaComo(id, nombre){
await asegurarVistaQueseriaIRanch();
estado.queseria.rolActivoQueseria = id === 'admin' ? 'admin' : 'operador';
estado.queseria.operadorActivo = { id, nombre };
irAQueseraPantalla('menu');
}
function irAQueseraPantalla(nombre){
document.querySelectorAll('#app-quesera .screen').forEach(s => s.classList.remove('active'));
document.getElementById('screen-quesera-' + nombre).classList.add('active');
if (nombre === 'menu') renderMenuQueseria();
if (nombre === 'recepcion') renderRecepcionQueseria();
if (nombre === 'productores') renderGestionProductoresQueseria();
if (nombre === 'reportes') renderReportesQueseria();
}
function irAMenuQueseria(){ irAQueseraPantalla('menu'); }
function renderMenuQueseria(){
renderHeaderQueseria('header-quesera-menu', { mostrarSalir: true });
const saludo = document.getElementById('saludo-operador-queseria');
if (saludo) saludo.textContent = `${tr('queseria_menu__bienvenido')}, ${estado.queseria.operadorActivo ? estado.queseria.operadorActivo.nombre : ''}`;
const esAdmin = estado.queseria.rolActivoQueseria === 'admin';
const botones = [
{ id:'recepcion', clave:'q_recepcion', icono:'fa-droplet', labelKey:'queseria_menu__recibir_leche', color:'var(--pine)' },
];
if (esAdmin){
botones.push({ id:'reportes', clave:'q_reportes', icono:'fa-chart-column', labelKey:'queseria_menu__panel_de_reportes', color:'var(--teal)' });
botones.push({ id:'productores', clave:'q_productores', icono:'fa-users', labelKey:'queseria_menu__gestion_de_productores', color:'var(--orange)' });
}
const cont = document.getElementById('grid-menu-queseria');
if (cont) cont.innerHTML = botones.map(b => {
const url = estado.iconosBotones && estado.iconosBotones[b.clave];
const iconoHTML = url
? `<span style="width:44px; height:44px; border-radius:14px; background-image:url('${url}'); background-size:cover; background-position:center;"></span>`
: `<i class="fa-solid ${b.icono} text-3xl" style="color:#fff;"></i>`;
return `
<button onclick="irAQueseraPantalla('${b.id}')" class="rounded-3xl p-3 flex flex-col items-center justify-center gap-2 shadow-xl" style="background:${b.color}; min-height:84px;">
${iconoHTML}
<span class="text-sm font-bold text-white text-center">${tr(b.labelKey)}</span>
</button>`;
}).join('');
}
let lecheroSeleccionadoRecepcion = null;
let productorSeleccionadoRecepcion = null;
function renderRecepcionQueseria(){
renderHeaderQueseria('header-quesera-recepcion', { mostrarSalir: true });
const opEl = document.getElementById('operador-activo-recepcion');
if (opEl) opEl.textContent = estado.queseria.operadorActivo ? estado.queseria.operadorActivo.nombre : '';
const select = document.getElementById('select-lechero-recepcion');
if (select){
select.innerHTML = `<option value="">${tr('queseria_recepcion__selecciona_un_lechero')}</option>` +
lecherosDelAmbito().map(l => `<option value="${l.id}">${l.nombre}</option>`).join('');
select.value = lecheroSeleccionadoRecepcion || '';
}
renderListaProductoresLecheroRecepcion();
renderListaRecepcionesHoy();
}
function cambiarLecheroRecepcion(lecheroId){
lecheroSeleccionadoRecepcion = lecheroId || null;
productorSeleccionadoRecepcion = null;
const panel = document.getElementById('panel-confirmar-recepcion');
if (panel) panel.innerHTML = '';
renderListaProductoresLecheroRecepcion();
}
function renderListaProductoresLecheroRecepcion(){
const cont = document.getElementById('lista-productores-lechero');
if (!cont) return;
if (!lecheroSeleccionadoRecepcion){
cont.innerHTML = `<p class="text-sm" style="color:var(--sage);">${tr('queseria_recepcion__selecciona_un_lechero')}</p>`;
return;
}
const hoy = hoyISO();
const idsRecibidosHoy = recepcionesLecheDelAmbito().filter(r => r.fecha === hoy).map(r => r.productorId);
const productores = productoresLecheDelAmbito().filter(p => p.lecheroId === lecheroSeleccionadoRecepcion && !idsRecibidosHoy.includes(p.id));
if (productores.length === 0){
cont.innerHTML = `<p class="text-sm" style="color:var(--sage);">${tr('queseria_recepcion__aun_no_hay_productores_para_este_lechero')}</p>`;
return;
}
cont.innerHTML = productores.map(p => `
<button onclick="seleccionarProductorRecepcion('${p.id}')" class="px-4 py-3 rounded-2xl font-bold text-sm" style="background:${productorSeleccionadoRecepcion === p.id ? 'var(--pine)' : 'var(--parchment)'}; color:${productorSeleccionadoRecepcion === p.id ? '#fff' : 'var(--ink)'}; border:2px solid var(--line);">
${p.nombre || p.codigo}${p.codigo ? ` <span style="opacity:.7;">(${p.codigo})</span>` : ''}
</button>`).join('');
}
function seleccionarProductorRecepcion(productorId){
productorSeleccionadoRecepcion = productorId;
renderListaProductoresLecheroRecepcion();
const productor = productoresLecheDelAmbito().find(p => p.id === productorId);
const panel = document.getElementById('panel-confirmar-recepcion');
if (!panel || !productor) return;
panel.innerHTML = `
<div class="bg-white rounded-3xl p-5 space-y-3" style="border:2px solid var(--line); border-top:6px solid var(--pine);">
<p class="font-bold">${productor.nombre || productor.codigo}</p>
<div class="flex gap-2">
<input id="litros-recepcion-actual" data-i18n-placeholder="queseria__ingresa_los_litros" placeholder="${tr('queseria__ingresa_los_litros')}" type="number" inputmode="decimal" min="0" step="0.1"/>
<button type="button" onclick="activarDictadoVoz('litros-recepcion-actual')" class="w-12 h-12 flex-shrink-0 rounded-2xl flex items-center justify-center" style="background:var(--parchment); color:var(--pine); border:2px solid var(--line);"><i class="fa-solid fa-microphone"></i></button>
</div>
<button class="w-full btn-primario-plano" onclick="confirmarRecepcionLeche('${productor.id}')" style="background:var(--green);">
<i class="fa-solid fa-check"></i><span>${tr('queseria_recepcion__confirmar_recepcion')}</span>
</button>
</div>`;
}
function confirmarRecepcionLeche(productorId){
const litros = Number(valor('litros-recepcion-actual'));
if (!litros || litros <= 0){ mostrarToast(tr('queseria__ingresa_los_litros')); return; }
const productor = productoresLecheDelAmbito().find(p => p.id === productorId);
if (!productor) return;
const ahora = new Date();
estado.recepcionesLeche.unshift({
id: 'rec_' + Date.now(),
puntoId: estado.puntoActivoId || null,
productorId: productor.id,
lecheroId: productor.lecheroId,
litros,
fecha: hoyISO(),
hora: ahora.toTimeString().slice(0,5),
ts: ahora.toISOString(),
operadorId: estado.queseria.operadorActivo ? estado.queseria.operadorActivo.id : null,
operadorNombre: estado.queseria.operadorActivo ? estado.queseria.operadorActivo.nombre : '',
});
productorSeleccionadoRecepcion = null;
const panel = document.getElementById('panel-confirmar-recepcion');
if (panel) panel.innerHTML = '';
renderListaProductoresLecheroRecepcion();
renderListaRecepcionesHoy();
mostrarToast(`🔔 ${tr('queseria_recepcion__notificacion_enviada')} ${productor.nombre || productor.codigo}: ${litros} L — ${ahora.toTimeString().slice(0,5)}`);
}
function renderListaRecepcionesHoy(){
const cont = document.getElementById('lista-recepciones-hoy');
if (!cont) return;
const hoy = hoyISO();
const registros = recepcionesLecheDelAmbito().filter(r => r.fecha === hoy);
if (registros.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-droplet"></i><p>${tr('queseria_recepcion__aun_no_has_recibido_leche_hoy')}</p></div>`;
return;
}
cont.innerHTML = registros.map(r => {
const productor = productoresLecheDelAmbito().find(p => p.id === r.productorId);
return `
<div class="item-registro flex items-center justify-between gap-3" style="border-left:6px solid var(--line); opacity:.75;">
<div>
<p class="font-bold" style="text-decoration:line-through;">${productor ? (productor.nombre || productor.codigo) : r.productorId}</p>
<p class="text-sm" style="color:var(--sage);">${r.litros} L · ${r.hora} · ${r.operadorNombre}</p>
</div>
<span class="text-xs font-bold px-3 py-2 rounded-full" style="background:var(--line); color:#fff;"><i class="fa-solid fa-check"></i></span>
</div>`;
}).join('');
}
function renderGestionProductoresQueseria(){
renderHeaderQueseria('header-quesera-productores', { mostrarSalir: true });
const tarjetaNombre = document.getElementById('qp-tarjeta-nombre-queseria');
if (tarjetaNombre) tarjetaNombre.classList.toggle('hidden', !!estado.puntoActivoId);
establecerValor('qp-nombre-queseria', estado.queseria.nombre || '');
const selectLechero = document.getElementById('qp-lechero');
if (selectLechero) selectLechero.innerHTML = lecherosDelAmbito().map(l => `<option value="${l.id}">${l.nombre}</option>`).join('');
renderListaLecherosAdmin();
renderListaProductoresRegistrados();
}
function guardarNombreQueseria(){
estado.queseria.nombre = valor('qp-nombre-queseria').trim();
mostrarToast(tr('queseria_productores__nombre_guardado'));
renderHeaderQueseria('header-quesera-productores', { mostrarSalir: true });
}
function agregarLechero(){
const nombre = valor('ql-nombre').trim();
if (!nombre){ mostrarToast(tr('queseria_productores__escribe_un_nombre')); return; }
estado.lecheros.push({ id: 'lech_' + Date.now(), nombre, puntoId: estado.puntoActivoId || null });
establecerValor('ql-nombre', '');
renderListaLecherosAdmin();
const selectLechero = document.getElementById('qp-lechero');
if (selectLechero) selectLechero.innerHTML = lecherosDelAmbito().map(l => `<option value="${l.id}">${l.nombre}</option>`).join('');
}
function eliminarLechero(id){
estado.lecheros = estado.lecheros.filter(l => l.id !== id);
guardarEstadoLocal();
renderListaLecherosAdmin();
}
function renderListaLecherosAdmin(){
const cont = document.getElementById('lista-lecheros-admin');
if (!cont) return;
cont.innerHTML = lecherosDelAmbito().map(l => `
<div class="flex items-center justify-between gap-2 py-1">
<span class="text-sm font-bold">${l.nombre}</span>
<button onclick="eliminarLechero('${l.id}')" style="color:var(--red);"><i class="fa-solid fa-trash"></i></button>
</div>`).join('');
}
function registrarProductorLeche(){
const nombre = valor('qp-nombre').trim();
const codigo = valor('qp-codigo').trim();
const telefono = valor('qp-telefono').trim();
const lecheroId = valor('qp-lechero');
if (!nombre || !codigo){ mostrarToast(tr('queseria_productores__completa_nombre_y_codigo')); return; }
const nuevoProductor = { id: 'prodL_' + Date.now(), nombre, codigo, telefono, lecheroId: lecheroId || null, puntoId: estado.puntoActivoId || null };
estado.productoresLeche.push(nuevoProductor);
estado.solicitudesVinculacionLeche.push({ id: 'solL_' + Date.now(), productorId: nuevoProductor.id, fecha: hoyISO(), estatus: 'pendiente' });
establecerValor('qp-nombre', ''); establecerValor('qp-codigo', ''); establecerValor('qp-telefono', '');
renderListaProductoresRegistrados();
mostrarToast(`✓ ${tr('queseria_productores__solicitud_de_vinculacion_enviada')}: ${nombre}`);
}
function eliminarProductorLeche(id){
estado.productoresLeche = estado.productoresLeche.filter(p => p.id !== id);
guardarEstadoLocal();
renderListaProductoresRegistrados();
}
function renderListaProductoresRegistrados(){
const cont = document.getElementById('lista-productores-registrados');
if (!cont) return;
const productores = productoresLecheDelAmbito();
if (productores.length === 0){
cont.innerHTML = `<div class="vacio"><i class="fa-solid fa-user-group"></i><p>${tr('queseria_productores__aun_no_hay_productores_registrados')}</p></div>`;
return;
}
cont.innerHTML = productores.map(p => {
const lechero = estado.lecheros.find(l => l.id === p.lecheroId);
return `
<div class="item-registro flex items-center justify-between gap-3">
<div>
<p class="font-bold">${p.nombre} <span style="color:var(--sage); font-weight:400;">(${p.codigo})</span></p>
<p class="text-sm" style="color:var(--sage);">${lechero ? lechero.nombre : ''}${p.telefono ? ' · ' + p.telefono : ''}</p>
</div>
<button onclick="eliminarProductorLeche('${p.id}')" style="color:var(--red);"><i class="fa-solid fa-trash"></i></button>
</div>`;
}).join('');
}
let graficaReportesQueseriaInstancia = null;
function renderReportesQueseria(){
renderHeaderQueseria('header-quesera-reportes', { mostrarSalir: true });
const selectLechero = document.getElementById('filtro-lechero-reportes');
if (selectLechero){
selectLechero.innerHTML = `<option value="">${tr('queseria_reportes__todos_los_lecheros')}</option>` +
lecherosDelAmbito().map(l => `<option value="${l.id}">${l.nombre}</option>`).join('');
}
actualizarReportesQueseria();
}
function recepcionesEnPeriodo(periodo){
const hoy = new Date();
return recepcionesLecheDelAmbito().filter(r => {
const fecha = new Date(r.fecha + 'T00:00:00');
if (periodo === 'dia') return r.fecha === hoyISO();
if (periodo === 'semana'){ const dias = (hoy - fecha) / 86400000; return dias >= 0 && dias < 7; }
if (periodo === 'mes'){ return fecha.getFullYear() === hoy.getFullYear() && fecha.getMonth() === hoy.getMonth(); }
return true;
});
}
async function actualizarReportesQueseria(){
await cargarChartJsSiNecesario();
const periodo = valor('filtro-periodo-reportes') || 'dia';
const lecheroFiltro = valor('filtro-lechero-reportes');
let registros = recepcionesEnPeriodo(periodo);
if (lecheroFiltro) registros = registros.filter(r => r.lecheroId === lecheroFiltro);
const litrosTotales = registros.reduce((acc, r) => acc + r.litros, 0);
const productoresActivos = new Set(registros.map(r => r.productorId)).size;
const metricas = document.getElementById('metricas-reportes-queseria');
if (metricas) metricas.innerHTML = `
<div class="bg-white rounded-2xl p-3 text-center" style="border:2px solid var(--line);"><p class="text-xs" style="color:var(--sage);">${tr('queseria_reportes__litros_totales')}</p><p class="font-display text-xl font-bold">${litrosTotales.toFixed(1)}</p></div>
<div class="bg-white rounded-2xl p-3 text-center" style="border:2px solid var(--line);"><p class="text-xs" style="color:var(--sage);">${tr('queseria_reportes__productores_activos')}</p><p class="font-display text-xl font-bold">${productoresActivos}</p></div>
<div class="bg-white rounded-2xl p-3 text-center" style="border:2px solid var(--line);"><p class="text-xs" style="color:var(--sage);">${tr('queseria_reportes__recepciones')}</p><p class="font-display text-xl font-bold">${registros.length}</p></div>`;
const porProductor = {};
registros.forEach(r => {
const p = estado.productoresLeche.find(x => x.id === r.productorId);
const clave = p ? (p.nombre || p.codigo) : r.productorId;
porProductor[clave] = (porProductor[clave] || 0) + r.litros;
});
const etiquetas = Object.keys(porProductor);
const valores = Object.values(porProductor);
const canvas = document.getElementById('grafica-reportes-queseria');
if (canvas && window.Chart){
if (graficaReportesQueseriaInstancia) graficaReportesQueseriaInstancia.destroy();
graficaReportesQueseriaInstancia = new Chart(canvas.getContext('2d'), {
type: 'bar',
data: { labels: etiquetas, datasets: [{ label: tr('queseria_reportes__litros_totales'), data: valores, backgroundColor: '#3C6B4F' }] },
options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
});
}
const tabla = document.getElementById('tabla-reportes-queseria');
if (tabla){
if (etiquetas.length === 0){
tabla.innerHTML = `<p class="text-sm" style="color:var(--sage);">${tr('queseria_reportes__aun_no_hay_datos_para_este_periodo')}</p>`;
} else {
tabla.innerHTML = etiquetas.map(nombre => `
<div class="flex items-center justify-between py-1" style="border-bottom:1px solid var(--line);">
<span class="text-sm">${nombre}</span>
<span class="text-sm font-bold">${porProductor[nombre].toFixed(1)} L</span>
</div>`).join('');
}
}
}
async function exportarReportesQueseriaPDF(){
const periodo = valor('filtro-periodo-reportes') || 'dia';
const lecheroFiltro = valor('filtro-lechero-reportes');
let registros = recepcionesEnPeriodo(periodo);
if (lecheroFiltro) registros = registros.filter(r => r.lecheroId === lecheroFiltro);
if (registros.length === 0){ mostrarToast(tr('queseria_reportes__aun_no_hay_datos_para_este_periodo')); return; }
await cargarJsPDFSiNecesario();
const { jsPDF } = window.jspdf;
const doc = new jsPDF();
const litrosTotales = registros.reduce((acc, r) => acc + r.litros, 0);
const productoresActivos = new Set(registros.map(r => r.productorId)).size;
doc.setFontSize(14);
doc.text(`${tr('queseria_reportes__panel_de_reportes')} — ${estado.queseria.nombre || 'MiRanch'}`, 14, 16);
doc.setFontSize(10);
doc.setTextColor(90);
doc.text(`${tr('queseria_reportes__litros_totales')}: ${litrosTotales.toFixed(1)} L    ${tr('queseria_reportes__productores_activos')}: ${productoresActivos}    ${tr('queseria_reportes__recepciones')}: ${registros.length}`, 14, 23);
let y = 30;
const canvas = document.getElementById('grafica-reportes-queseria');
if (canvas){
try {
const imgData = canvas.toDataURL('image/png');
const anchoPagina = doc.internal.pageSize.getWidth();
const anchoImg = anchoPagina - 28;
const altoImg = anchoImg * (canvas.height / canvas.width);
doc.addImage(imgData, 'PNG', 14, y, anchoImg, altoImg);
y += altoImg + 8;
} catch(e){}
}
const filas = registros.map(r => {
const p = estado.productoresLeche.find(x => x.id === r.productorId);
const l = estado.lecheros.find(x => x.id === r.lecheroId);
return [p ? (p.nombre || p.codigo) : r.productorId, l ? l.nombre : '', r.litros, r.fecha, r.hora, r.operadorNombre];
});
doc.autoTable({
head: [[tr('queseria_productores__nombre_del_productor'), tr('queseria_recepcion__lechero_recolector'), 'L', tr('gastos_rendimiento_animal__fecha'), tr('queseria__hora'), tr('queseria__operador')]],
body: filas,
startY: y,
styles: { fontSize: 8 },
headStyles: { fillColor: [31,58,46] },
didDrawPage: function(){
const alturaPagina = doc.internal.pageSize.getHeight();
doc.setFontSize(8);
doc.setTextColor(120);
doc.text(`MiRanch — ${tr('exp_generado')}: ${formatoFechaHora()}`, 14, alturaPagina - 8);
}
});
doc.save('recepcion-de-leche.pdf');
mostrarToast(tr('exportacion_pie_pagina__pdf_exportado'));
}
// ---------- Dictado por voz (reutilizable en cualquier módulo) ----------
// Palabras dictadas que se convierten en signos de puntuación o acciones,
// en vez de escribirse tal cual — igual que el dictado de WhatsApp.
const COMANDOS_PUNTUACION_DICTADO = [
{ frase: /\bcoma\b/gi, valor: ',' },
{ frase: /\bpunto y coma\b/gi, valor: ';' },
{ frase: /\bdos puntos\b/gi, valor: ':' },
{ frase: /\bpunto\b/gi, valor: '.' },
{ frase: /\bsigno de interrogaci[oó]n\b/gi, valor: '?' },
{ frase: /\bnueva l[ií]nea\b/gi, valor: '\n' },
{ frase: /\bguion\b/gi, valor: '-' },
];
function aplicarPuntuacionDictado(texto){
let resultado = texto;
COMANDOS_PUNTUACION_DICTADO.forEach(c => { resultado = resultado.replace(c.frase, c.valor); });
// Limpia espacios que quedan antes de un signo de puntuación (ej. "hola ,").
return resultado.replace(/\s+([.,;:?])/g, '$1').replace(/\s{2,}/g, ' ').trim();
}
function activarDictadoVoz(idCampo){
const Reconocimiento = window.SpeechRecognition || window.webkitSpeechRecognition;
if (!Reconocimiento){ mostrarToast(tr('queseria__dictado_por_voz_no_disponible')); return; }
const campo = document.getElementById(idCampo);
if (!campo) return;
const reconocimiento = new Reconocimiento();
reconocimiento.lang = idiomaActual === 'en' ? 'en-US' : idiomaActual === 'de' ? 'de-DE' : 'es-MX';
reconocimiento.continuous = true;
reconocimiento.interimResults = true;
reconocimiento.maxAlternatives = 1;
mostrarToast(tr('queseria__escuchando'));
let vozFinalAcumulada = '';
reconocimiento.onresult = e => {
let interino = '';
for (let i = e.resultIndex; i < e.results.length; i++){
const texto = e.results[i][0].transcript;
if (e.results[i].isFinal){
const textoLimpio = texto.toLowerCase().trim();
// "Borrar todo" limpia el campo entero en vez de escribirse — se revisa
// aquí, antes de acumularlo, para que nunca quede como texto literal.
if (/\bborra(r)? todo\b/.test(textoLimpio)){ vozFinalAcumulada = ''; campo.value = ''; campo.dispatchEvent(new Event('input')); continue; }
vozFinalAcumulada += (vozFinalAcumulada ? ' ' : '') + texto;
} else {
interino = texto;
}
}
const combinado = aplicarPuntuacionDictado((vozFinalAcumulada + ' ' + interino).trim());
campo.value = campo.type === 'number' ? (combinado.match(/[\d.,]+/) || [''])[0].replace(',', '.') : combinado;
campo.dispatchEvent(new Event('input'));
};
reconocimiento.onerror = () => { mostrarToast(tr('queseria__dictado_por_voz_no_disponible')); };
reconocimiento.start();
}


  window['fondoParaHeaderQueseria'] = fondoParaHeaderQueseria;
  window['nombreQueseriaActiva'] = nombreQueseriaActiva;
  window['lecherosDelAmbito'] = lecherosDelAmbito;
  window['productoresLecheDelAmbito'] = productoresLecheDelAmbito;
  window['recepcionesLecheDelAmbito'] = recepcionesLecheDelAmbito;
  window['logoActivo'] = logoActivo;
  window['aplicarLogoPersonalizado'] = aplicarLogoPersonalizado;
  window['renderHeaderQueseria'] = renderHeaderQueseria;
  window['asegurarVistaQueseriaIRanch'] = asegurarVistaQueseriaIRanch;
  window['mostrarPantallaQueseraLogin'] = mostrarPantallaQueseraLogin;
  window['cerrarQueseria'] = cerrarQueseria;
  window['renderGridPerfilesQueseria'] = renderGridPerfilesQueseria;
  window['entrarQueseriaComo'] = entrarQueseriaComo;
  window['irAQueseraPantalla'] = irAQueseraPantalla;
  window['irAMenuQueseria'] = irAMenuQueseria;
  window['renderMenuQueseria'] = renderMenuQueseria;
  window['renderRecepcionQueseria'] = renderRecepcionQueseria;
  window['cambiarLecheroRecepcion'] = cambiarLecheroRecepcion;
  window['renderListaProductoresLecheroRecepcion'] = renderListaProductoresLecheroRecepcion;
  window['seleccionarProductorRecepcion'] = seleccionarProductorRecepcion;
  window['confirmarRecepcionLeche'] = confirmarRecepcionLeche;
  window['renderListaRecepcionesHoy'] = renderListaRecepcionesHoy;
  window['renderGestionProductoresQueseria'] = renderGestionProductoresQueseria;
  window['guardarNombreQueseria'] = guardarNombreQueseria;
  window['agregarLechero'] = agregarLechero;
  window['eliminarLechero'] = eliminarLechero;
  window['renderListaLecherosAdmin'] = renderListaLecherosAdmin;
  window['registrarProductorLeche'] = registrarProductorLeche;
  window['eliminarProductorLeche'] = eliminarProductorLeche;
  window['renderListaProductoresRegistrados'] = renderListaProductoresRegistrados;
  window['renderReportesQueseria'] = renderReportesQueseria;
  window['recepcionesEnPeriodo'] = recepcionesEnPeriodo;
  window['actualizarReportesQueseria'] = actualizarReportesQueseria;
  window['exportarReportesQueseriaPDF'] = exportarReportesQueseriaPDF;
  window['aplicarPuntuacionDictado'] = aplicarPuntuacionDictado;
  window['activarDictadoVoz'] = activarDictadoVoz;
})();
